# LINGU · Content Factory — README

کارخانهٔ محتوای LINGU: درس‌های English (Master Curriculum)، مانیفست و فایل‌های صوتی، ابزارهای تولید/اعتبارسنجی/Import و گزارش دسته‌ها.
وضعیت 2026-10-02: **326 درس روی Disk (L001–L326) · 320 در DB · 0 منتشرشده · 10 کلیپ صوتی واقعی از 12,766** — جزئیات: `LINGU-CONTENT-HANDOFF.md`.

## ترتیب خواندن (چت جدید)

1. `LINGU-NEW-CONTENT-CHAT-PROMPT-FA.md` — نقش و قوانین
2. `LINGU-CONTENT-HANDOFF.md` — وضعیت واقعی و نقطهٔ شروع
3. `LINGU-FILE-MANIFEST.md` — نقش هر فایل
4. `content/RUNBOOK-FA.md` — روال اجرایی
5. `content-schema/LESSON-SCHEMA-FA.md` — ساختار درس + DB
6. `CONTENT-FACTORY-MASTER-PROMPT-FA.md` (در ریپو: `docs/`) — قرارداد کامل نگارش
7. `content/VOICE-REGISTRY-FA.md` · `content/LOCALIZATION-RULES-FA.md`

## ساختار

```
content/
├── en/<A1|A2|B1>/seeds/      بذرهای متنی (منبع نگارش)
├── en/<A1|A2|B1>/specs/      خروجی parse_seed (JSON میانی)
├── en/<A1|A2|B1>/lessons/    درس نهایی L###.json (همان چیزی که Import می‌شود)
├── audio/L###.plan.json      مانیفست صوتی هر درس (326)
├── audio/generated/          صدای واقعی تولیدی (10 mp3)
├── audio/samples/            نمونه‌های دروازه (10 mp3)
├── audio/voices.json         رجیستری گوینده (ماشینی)
├── audio/registry.json       رجیستری آپلود Storage
├── audio/plans-meta.json     نقش راوی/شنیداری هر درس
├── tools/                    ابزارهای تولید، اعتبارسنجی، Import، صدا
├── tools/ops/                ابزارهای عملیاتی ماندگار (run_part, tidy_seed, vocabulary_check, qa-lessons.sql)
├── reports/                  گزارش دروازه‌ها و دسته‌ها
├── RUNBOOK-FA.md · LOCALIZATION-RULES-FA.md · VOICE-REGISTRY-FA.md
content-schema/LESSON-SCHEMA-FA.md (+ db/ در ZIP محتوا)
```

همهٔ دستورها از ریشهٔ پروژه اجرا می‌شوند؛ ابزارها فقط Node 20 و Python 3 لازم دارند.
در ZIP محتوا، ساختار طوری چیده شده که ریشهٔ ZIP همان ریشهٔ پروژه باشد (`content/` و `content-schema/` کنار هم).
