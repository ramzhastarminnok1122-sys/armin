# LINGU · Content Factory RUNBOOK (روال اجرایی تولید محتوا)

> همهٔ دستورها از ریشهٔ `lingu/` اجرا می‌شوند. Node 20 و Python 3 کافی است (ابزارها وابستگی npm ندارند).
> سند مکمل: `content/tools/ops/README.md` (قوانین زرین بذر) · قرارداد درس: `content-schema/LESSON-SCHEMA-FA.md`
> صدا: `content/VOICE-REGISTRY-FA.md` · بومی‌سازی FR/ES: `content/LOCALIZATION-RULES-FA.md`

## ۰) تعریف «تمام‌شده» (Definition of Done) — قانون جدید

**Lesson Complete = Content + Real Audio + Audio Reference + QA**

درسی که فقط مانیفست صوتی (`.plan.json`) دارد «تمام‌شده» نیست. تا 2026-10-02 فقط ۱۰ کلیپ از ۱۲٬۷۶۶ کلیپ برنامه‌ریزی‌شده صدای واقعی دارند
(L001 · L002 · L010 · L020) — این خطای گردش کار گذشته بود و نباید تکرار شود.

## ۱) چرخهٔ استاندارد هر Batch (۲۰ درس = واحد کنترل؛ معمولاً ۷ بخش بذر)

| گام | دستور / کار | خروجی و معیار عبور |
|---|---|---|
| 1. واژگان پیش از نگارش | `python3 content/tools/ops/vocabulary_check.py used <واژه‌ها>` و `… pair <۱۰ واژهٔ درس>` | هیچ هشدار PAIR>2؛ واژه‌های USED جایگزین شوند |
| 2. نگارش بذر | `content/en/<LVL>/seeds/b<N>-part<k>.seed` (قالب در §۴) | — |
| 3. پایپ‌لاین بخش | `bash content/tools/ops/run_part.sh <LVL> b<N>-part<k>` | tidy → parse → build_lessons → build_plans → validate؛ ادامه تا **«خطا: 0»** |
| 4. بررسی تازگی spec | خطوط «درس Lxxx · عنوان» آخر خروجی run_part | عنوان‌ها باید مال همین بذر باشند (دام spec کهنه) |
| 5. صدای واقعی | تولید TTS نقش‌به‌نقش از `content/audio/L###.plan.json` با شناسه‌های ثبت‌شدهٔ **همین چت** → `content/audio/generated/L###/<clip-id>.mp3` | فایل برای همهٔ کلیپ‌های P1 (و به‌قدر امکان بقیه) |
| 6. سنجش فایل صوتی | `python3 content/tools/probe_audio.py content/audio/generated` | مدت/حجم معتبر |
| 7. آپلود | `SUPABASE_URL=… SUPABASE_ANON=… SUPABASE_TOKEN=… node content/tools/upload_audio.mjs` (توکن موقت ادمین فقط از محیط) | `content/audio/registry.json` به‌روز؛ مسیر `lesson-audio/<lang>/<hash8>.mp3` |
| 8. ارجاع صوتی در درس | `node content/tools/build_audio_refs.mjs L### …` سپس `node content/tools/validate.mjs` | `content.audio` پر؛ validator «خطا: 0» |
| 9. Import | `node content/tools/build_import_sql.mjs <from> <to> batch-<N>` → `psql "<conn>" -f /tmp/import_batch-<N>.sql` | شمارش verify درست؛ اجرای دوباره = INSERT صفر |
| 10. QA | `psql … -f content/tools/ops/qa-lessons.sql` (→ `/tmp/qa_lessons.json`) سپس `node qa/batch_qa.mjs` و `node qa/audio_qa.mjs` روی preview محلی | ۱۲/۱۲ بخش، بدون خطای کنسول، پلیرها سالم |
| 11. گزارش | یک ردیف در `content/reports/RUN-L101-L340-FA.md` (یا گزارش جدید زبان) | اعداد واقعی، نه تخمین |

نکته‌ها:
- `qa/batch_qa.mjs` و `qa/audio_qa.mjs` رمز حساب QA را از `/tmp/ops_pw` می‌خوانند — این فایل از بین رفته؛ پیش از QA رمز حساب QA از داشبورد Supabase ریست و فقط در `/tmp/ops_pw` گذاشته شود (هرگز در ریپو).
- `qa/audio_qa.mjs` علاوه بر آن `/tmp/expected_audio.json` را می‌خواهد (نگاشت `عنوان درس → { lessonId (uuid در DB), بخش‌ها/کلیپ‌ها }`). سازندهٔ این فایل یک اسکریپت موقت `/tmp` بود و از بین رفته — پیش از Audio QA باید از `content.audio` درس‌ها + شناسهٔ درس در DB دوباره ساخته شود.
- هر دو اسکریپت QA به وب‌اپ در حال اجرا روی `http://127.0.0.1:4173` نیاز دارند (`lingu/web` از ZIP محصول: `.env` از روی `.env.example` با مقادیر مالک → `npm ci && npm run build && npx vite preview --host 0.0.0.0 --port 4173`) و puppeteer (`cd qa && npm ci`).
- `parse_seed.mjs` با هر خطا `exit 1` می‌دهد و پیام «خطای بذر در خط N» چاپ می‌کند؛ اگر داخل لوله با grep اجرا شود کد خروج گم می‌شود.
- `build_import_sql.mjs` خروجی را در `/tmp` می‌نویسد؛ `/tmp` بین نشست‌ها پاک می‌شود — فایل‌های ماندگار را فقط در `lingu/` نگه دار.
- انتشار (`published`) کار ادمین از پنل است، نه بخشی از Import.

## ۲) ابزارها (همه در `content/tools/`)

| ابزار | کاربرد |
|---|---|
| `parse_seed.mjs` | بذر متنی → `specs/<name>.json` (سخت‌گیر) |
| `build_lessons.mjs` | specs → `lessons/L###.json` + ادغام در `content/audio/plans-meta.json` |
| `build_plans.mjs` | مانیفست صوتی `content/audio/L###.plan.json` برای همهٔ درس‌ها |
| `validate.mjs` | اعتبارسنج کامل (فقط می‌خواند) — درس‌ها + مانیفست + ارجاع صوتی |
| `build_import_sql.mjs` | SQL ایمن و idempotent برای بازهٔ درس‌ها + ردیف `content_batches` |
| `build_audio_refs.mjs` | نوشتن `content.audio` درس از روی `registry.json` |
| `upload_audio.mjs` | آپلود mp3 به Storage (`lesson-audio`) با هش محتوا |
| `probe_audio.py` | بررسی فنی فایل‌های mp3 |
| `lesson_to_seed.mjs` | بازسازی بذر از درس موجود (Recovery) |
| `normalize_seed.py` | نرمال‌سازی سادهٔ بذر (قدیمی‌تر؛ `ops/tidy_seed.py` کامل‌تر است) |
| `run_batch.sh` | پایپ‌لاین چندبذری (مرجع قدیمی‌تر از run_part) |
| `lib/audio-map.mjs` | نگاشت مشترک کلیپ → بخش درس |
| `ops/tidy_seed.py` | ترمیم خودکار خطاهای رایج بذر + گیومه‌گذاری لاتین در فیلدهای فارسی (`--no-latin` برای خاموش) |
| `ops/run_part.sh` | پایپ‌لاین یک بخش + چاپ عنوان‌ها (ضد spec کهنه) |
| `ops/vocabulary_check.py` | `used` / `pair` / `build` — جایگزین ماندگار `free.py`/`paircheck.py`/`known.json` دوران /tmp |
| `ops/qa-lessons.sql` | خروجی JSON درس‌ها برای QA رندر |

## ۳) دام‌های شناخته‌شده (از تجربهٔ ۱۷ دسته)

1. **LST تک‌خطی:** `LST|title|script|script_fa|q|a` = دقیقاً ۵ جداکنندهٔ `|`؛ نوبت گوینده با `~`، خط جدید با `\n` لفظی. LST چندخطی parse را می‌شکند.
2. **key_points:** حداکثر ۴ کلید + `||` انتهایی (= ۵ قلم). ۵ کلید + `||` = ۶ = خطا.
3. **همپوشانی واژگان:** زیرواژه‌های عبارت چندکلمه‌ای هم شمرده می‌شوند (vane / weather vane).
4. **spec کهنه:** اگر parse شکست بخورد، build از spec قبلی درس می‌سازد و validator ممکن است چیزی نگوید → همیشه عنوان‌های چاپ‌شده را چک کن.
5. **escape لفظی:** heredoc می‌تواند `\u200c` را به متن لفظی `\u200` تبدیل کند؛ validator این را نمی‌گیرد → `grep -n '\\u[0-9a-fA-F]\{3\}' <seed>` پیش از run_part.
6. **لاتین در فارسی:** هر واژهٔ لاتین ۴+ حرفی در فیلد فارسی باید داخل «…» باشد (کلیپ‌های فارسی صوتی هم بررسی می‌شوند).
7. **RDT** با `~` به فاصله تبدیل می‌شود؛ شمارش ۸۰–۱۴۰ واژه بعد از این تبدیل است.

## ۴) قالب بذر (خلاصهٔ قرارداد `parse_seed.mjs`)

جداکننده‌ها: `|` مرز فیلد · `||` مرز آیتم فهرست · `~` مرز زیرفیلد · `\n` خط جدید · `#` توضیح.
سرصفحه: `LEVEL|B1` · `BATCH|17` · `NOTE|…` · شروع هر درس: `@@|n|title|subtitle|desc|min|topic` (۶ فیلد).
رکوردهای درس: `OBJ` · `NOTES` · `WARM` · `EXPL` · `V` (واژه) · `G` (گرامر) · `GR|label|en~fa` · `GP` (pitfalls با `||`) · `EX|en~fa~note` ·
`LST` · `ROLE` · `DLG` · `SPK` · `RD`/`RDT`/`RDG|term~fa`/`RDQ|q~a` · `X|type|prompt|question|options|answer|expl` · `XT` (truefalse) · `XF` (fill) · `QS` (quiz) · `AI` · `FA` (لایهٔ فارسی صوتی).
نمونهٔ کامل و معتبر: `content/en/B1/seeds/b17-part1.seed` (۰ خطا).
