# LINGU · Localization Rules (قواعد بومی‌سازی French / Spanish)

> مصوب مالک در Task «نجات و بسته‌بندی» (2026-10-02). این سند **قاعدهٔ محتوایی** است، نه معماری جدید.

## اصل اول: Localization ≠ Translation

- **English = Master Curriculum.** هر درس کامل انگلیسی باید Content + Real Audio + Audio Reference + QA داشته باشد.
- برای French و Spanish، درس انگلیسی فقط **Pedagogical Blueprint** است — نقشهٔ آموزشی، نه متن مبدأ ترجمه.
- Grammar، Vocabulary، Dialogue، Reading، Listening و Common Mistakes برای هر زبان **طبیعی، بومی و آموزشی** ساخته می‌شوند.

## Localization Factory — برای هر درس انگلیسی Lxxx

| از Blueprint انگلیسی **Reuse** می‌شود | برای FR/ES **از نو و بومی Rebuild** می‌شود |
|---|---|
| جایگاه درس (همان شمارهٔ Lxxx و همان سطح) | Grammar (ساختار واقعی همان زبان؛ مثلاً جنس اسم، صرف فعل، subjonctif / subjuntivo) |
| هدف آموزشی (objective) | Vocabulary (واژهٔ پربسامد و طبیعی همان زبان، نه معادل کلمه‌به‌کلمه) |
| موقعیت/بافت (context) | Dialogue (گفت‌وگوی طبیعی بومی، اسم‌ها و فرهنگ مناسب) |
| شیب سختی (difficulty progression) | Reading |
| تنوع تمرین (exercise variety) | Listening |
| جای مرورها (review placement) | Examples |
| مفهوم سناریوی AI (AI scenario concept) | توضیح فارسی (Persian explanation) — مخصوص دشواری‌های فارسی‌زبان در همان زبان |
| مفهوم بازی (game concept) | Common mistakes (خطاهای واقعی فارسی‌زبان در FR/ES) |
| | Pronunciation (IPA و نکات تلفظ همان زبان) |
| | Audio (گویندهٔ بومی همان زبان؛ نقش‌های جدا در Voice Registry) |

قاعدهٔ عملی: اگر نکتهٔ گرامری درس انگلیسی در FR/ES معادل طبیعی ندارد (مثلاً present perfect continuous)، **هدف** حفظ می‌شود و
ابزار طبیعی همان زبان آموزش داده می‌شود (مثلاً `depuis + présent` / `llevar + gerundio`) — نه یک ترجمهٔ ساختگی.

## لایهٔ فارسی (برای هر سه زبان، یکسان)

- همهٔ توضیح‌ها با فارسی معیار، روان و دوستانه؛ هدف: فهم سریع برای فارسی‌زبان.
- هیچ واژهٔ لاتین ۴+ حرفی بیرون از «…» در فیلدهای فارسی (شامل کلیپ‌های صوتی فارسی).
- بدون ي/ك عربی؛ نیم‌فاصلهٔ واقعی (U+200C)، نه متن لفظی `\u200`.
- توضیح فارسی در کلیپ‌های صوتی همیشه **اول** و در فایل جدا می‌آید (یک کلیپ = یک زبان).

## صدا (Audio Future Rule)

برای French، Spanish و درس‌های English فاقد صدا، هر Batch تا حد امکان با این زنجیره کامل شود:

**Generate Content → Generate Real Audio → Validate → Audio QA → Import**

Real Audio جزو Definition of Done است. نقش‌های صوتی FR/ES هنوز ثبت نشده‌اند — روش ثبت: `content/VOICE-REGISTRY-FA.md`.

## هدف کمی

| زبان | بازه | تعداد |
|---|---|---|
| English | L001–L340 | 340 |
| French | L001–L340 | 340 |
| Spanish | L001–L340 | 340 |
| **جمع** | | **1020** |

## پیش‌نیاز فنی شروع FR/ES (بدون تغییر قرارداد درس)

- جدول `languages` در DB از قبل `fr` و `es` دارد؛ `lessons.language_code` همان را می‌گیرد.
- ابزارها امروز English-only هستند (`validate.mjs` → «زبان باید en باشد»؛ مسیرها `content/en/...`).
  کمترین تغییر لازم: مسیر `content/fr|es/<LVL>/{seeds,specs,lessons}` + پارامتر زبان در ابزارها، و تطبیق قواعد لاتین/گیومه برای حروف لهجه‌دار.
- fingerprint یکتا روی (language_code, level, title) است — عنوان‌ها در هر زبان یکتا باشند.
