#!/usr/bin/env python3
"""LINGU · نرمال‌سازی بذر: LST با q~a و FA warmup با دنبالهٔ اضافی را اصلاح می‌کند."""
import sys
for p in sys.argv[1:]:
    lines = open(p, encoding='utf-8').read().split('\n')
    n = 0
    for i, l in enumerate(lines):
        if l.startswith('FA|warmup|') and '||' in l:
            lines[i] = l.split('||')[0]; n += 1
        if l.startswith('LST|'):
            parts = l.split('|')
            if len(parts) == 5 and '~' in parts[4]:
                a, b = parts[4].split('~', 1); lines[i] = '|'.join(parts[:4] + [a, b]); n += 1
    open(p, 'w', encoding='utf-8').write('\n'.join(lines))
    print(f'{p}: {n} خط نرمال شد')
