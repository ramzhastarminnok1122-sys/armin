#!/usr/bin/env node
/**
 * LINGU · Content Factory — ساخت SQL واردسازی (idempotent، batch-based)
 *
 * اجرا:  node content/tools/build_import_sql.mjs <from> <to> [batch-label]
 * مثال:  node content/tools/build_import_sql.mjs 21 40 batch-2
 * خروجی: /tmp/import_<label>.sql   (روی پایگاه دادهٔ زنده با psql اجرا می‌شود)
 *
 * قواعد ثابت (همان الگوی دستهٔ ۱ — آزموده‌شده):
 *   • «اول UPDATE، اگر نبود INSERT» روی کلید (language_code, level, order_index)
 *   • متن‌ها: نقل‌قول سادهٔ اس‌کیوال (نه JSON) · محتوای JSON: dollar-quote (بدون هیچ تغییر)
 *   • اجرای دوبارهٔ همین فایل باید INSERT صفر بدهد (idempotent)
 *   • ردیف دسته در content_batches با برچسب یکتا ساخته/به‌روز می‌شود و batch_id درس‌ها به آن وصل می‌شود
 */
import { readFileSync, writeFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'

const [from, to, label = `batch-${from}-${to}`] = process.argv.slice(2)
if (!from || !to) { console.error('استفاده: node build_import_sql.mjs <from> <to> [label]'); process.exit(1) }
const LESSONS_DIRS = ['content/en/A1/lessons', 'content/en/A2/lessons', 'content/en/B1/lessons']
const OWNER_EMAIL = 'aiveosora1122@gmail.com'

const fp = (lang, level, title) =>
  createHash('md5').update(`${lang}|${level}|${title}`.toLowerCase().replace(/\s+/g, '')).digest('hex')
const q = (s) => `'${String(s ?? '').replace(/'/g, "''")}'`
const jq = (obj, tag) => `$${tag}$${JSON.stringify(obj)}$${tag}$::jsonb`

const files = LESSONS_DIRS.flatMap((d) => { try { return readdirSync(d).filter((f) => f.endsWith('.json')).map((f) => join(d, f)) } catch { return [] } }).sort()
const rows = files
  .map((f) => JSON.parse(readFileSync(f, 'utf8')))
  .filter((r) => r.lesson.order_index >= Number(from) && r.lesson.order_index <= Number(to))
  .sort((a, b) => a.lesson.order_index - b.lesson.order_index)

if (rows.length === 0) { console.error('هیچ درسی در این بازه نیست'); process.exit(1) }

let sql = `-- LINGU · Content Factory — واردسازی ${label} (L${String(from).padStart(3, '0')}…L${String(to).padStart(3, '0')})
-- هیچ تغییر ساختاری: فقط درج/به‌روزرسانی ردیف‌های درس + یک ردیف دسته
begin;

-- ۱) ردیف دسته (یکتا با برچسب مدل) بساز یا به‌روز کن
insert into public.content_batches (language_code, level, requested, succeeded, failed, status, model, created_by, started_at, finished_at)
select 'en', ${q(rows[0].lesson.level)}, ${rows.length}, ${rows.length}, 0, 'completed', ${q('content-factory-agent · ' + label)},
       (select id from auth.users where email = ${q(OWNER_EMAIL)}), now(), now()
where not exists (select 1 from public.content_batches where model = ${q('content-factory-agent · ' + label)});

update public.content_batches
   set requested = ${rows.length}, succeeded = ${rows.length}, failed = 0, status = 'completed', finished_at = now()
 where model = ${q('content-factory-agent · ' + label)};

create temporary table _batch on commit drop as
  select id from public.content_batches where model = ${q('content-factory-agent · ' + label)} limit 1;
`

for (const r of rows) {
  const L = r.lesson
  const id = `L${String(L.order_index).padStart(3, '0')}`
  sql += `
-- ---------- ${id} · ${L.title.replace(/--/g, '—')} ----------
update public.lessons set
  title = ${q(L.title)}, subtitle = ${q(L.subtitle)}, description = ${q(L.description)},
  estimated_minutes = ${L.estimated_minutes}, is_free = ${L.is_free}, status = ${q(L.status)},
  content = ${jq(r.content, 'c')}, validation = ${jq(r.validation, 'v')},
  fingerprint = ${q(fp(L.language_code, L.level, L.title))}, version = ${L.version},
  batch_id = (select id from _batch), updated_at = now()
where language_code = 'en' and level = ${q(L.level)} and order_index = ${L.order_index};

insert into public.lessons (language_code, level, order_index, title, subtitle, description, estimated_minutes,
                            is_free, status, content, validation, fingerprint, version, batch_id, created_by)
select 'en', ${q(L.level)}, ${L.order_index}, ${q(L.title)}, ${q(L.subtitle)}, ${q(L.description)}, ${L.estimated_minutes},
       ${L.is_free}, ${q(L.status)}, ${jq(r.content, 'c')}, ${jq(r.validation, 'v')},
       ${q(fp(L.language_code, L.level, L.title))}, ${L.version}, (select id from _batch),
       (select id from auth.users where email = ${q(OWNER_EMAIL)})
where not exists (select 1 from public.lessons where language_code = 'en' and level = ${q(L.level)} and order_index = ${L.order_index});
`
}

sql += `
-- ۳) تأیید درون‌تراکنشی
select 'lessons_in_range' as check, count(*)::text as value from public.lessons where language_code='en' and level=${q(rows[0].lesson.level)} and order_index between ${from} and ${to}
union all select 'duplicate_order', count(*)::text from (select order_index from public.lessons where language_code='en' and order_index between ${from} and ${to} group by 1 having count(*)>1) d
union all select 'duplicate_fingerprint', count(*)::text from (select fingerprint from public.lessons group by 1 having count(*)>1) d
union all select 'status_validated', count(*)::text from public.lessons where order_index between ${from} and ${to} and status='validated'
union all select 'total_lessons', count(*)::text from public.lessons where language_code='en'
union all select 'all_levels_in_range', count(*)::text from public.lessons where language_code='en' and order_index between ${from} and ${to};

commit;
`

const out = `/tmp/import_${label}.sql`
writeFileSync(out, sql)
console.log(`${rows.length} درس → ${out}`)
console.log(rows.map((r) => `L${String(r.lesson.order_index).padStart(3, '0')} ${r.lesson.title}`).join(' · '))
