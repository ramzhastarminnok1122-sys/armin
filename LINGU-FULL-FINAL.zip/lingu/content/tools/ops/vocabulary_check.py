#!/usr/bin/env python3
"""LINGU · Content Factory — جاروی واژگان (جایِ paircheck.py + free.py)

اعتبارسنج، واژۀ درسِ جدید را با «تک‌واژه‌هایِ» همۀ درس‌هایِ ساخته‌شده می‌سنجد
(چندواژه‌ها شکسته می‌شوند: greeting-card با greeting تصادم می‌کند).

زیرفرمان‌ها:
  used  term1 term2 ...        → کدام واژه در کدام درس‌ها قبلاً آمده (USED/FREE)
  pair  term1 term2 ...        → همپوشانیِ مجموعه با هر درس؛ هشدار اگر >2 در یک درس
  build [level]                → شمارشِ موجودِ هر سطح (بازدیدِ دایرۀ تازگیِ کش)

مثال: python3 vocabulary_check.py pair almanac barometer eclipse tide
"""
import json, glob, sys, os
from collections import defaultdict

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')

def words(t):
    t = t.lower().strip()
    parts = [p for p in re_split(t) if len(p) >= 3]
    return set(parts) | {t}

def re_split(t):
    import re
    return re.split(r"[ \-]+", t)

def load():
    lesson_terms = {}
    inv = defaultdict(set)
    for f in glob.glob(os.path.join(ROOT, 'en', '*', 'lessons', '*.json')):
        d = json.load(open(f, encoding='utf-8'))
        lvl = f.split(os.sep + 'en' + os.sep)[1].split(os.sep)[0]
        num = d['lesson']['order_index']
        terms = [it['term'].lower() for it in d['content']['vocabulary'].get('items', [])]
        lesson_terms[num] = set(terms)
        w = set()
        for t in terms:
            w |= words(t)
        inv[lvl + ':' + str(num)] = w
    return lesson_terms, inv

def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ('used', 'pair', 'build'):
        print(__doc__); sys.exit(1)
    mode = sys.argv[1]
    terms = [t.lower() for t in sys.argv[2:]]
    lesson_terms, inv = load()
    if mode == 'used':
        for t in terms:
            hits = sorted(n for n, s in lesson_terms.items() if t == t and (t in s or any(t in words(x) for x in s)))
            print(f'{"USED(lessons): " + t + ":" + ",".join(map(str, hits)) if hits else "FREE: " + t}')
        return
    if mode == 'pair':
        want = set()
        for t in terms:
            want |= words(t)
        issues = []
        for key, s in inv.items():
            over = want & s
            if len(over) > 2:
                issues.append((int(key.split(':')[1]), sorted(over)))
        print('PAIR>2 issues:', sorted(issues) if issues else 'none')
        known = sorted({t for t in terms if any(t == x or t in words(x) for s in lesson_terms.values() for x in s)})
        print('already-known terms:', known if known else 'none')
        return
    if mode == 'build':
        from collections import Counter
        c = Counter(k.split(':')[0] for k in inv)
        print('built lesson JSONs:', dict(c))

main()
