#!/usr/bin/env bash
# LINGU · Content Factory — پایپ‌لاین کامل یک بخشِ بذر (جایِ runpart.sh دورانِ session)
# استفاده: bash content/tools/ops/run_part.sh <level> <seed-name>
#   مثال: bash content/tools/ops/run_part.sh B1 b17-part2
# مراحل: tidy → parse(سخت‌گیر) → build_lessons → build_plans → validate
set -e
cd "$(dirname "$0")/../../.."
LVL="$1"; NAME="$2"
SEED="content/en/$LVL/seeds/$NAME.seed"
[ -f "$SEED" ] || { echo "بذر یافت نشد: $SEED"; exit 1; }
python3 content/tools/ops/tidy_seed.py "$SEED"
node content/tools/parse_seed.mjs "$SEED"
echo "── spec‌های این بخش ──"; ls content/en/$LVL/specs/$NAME.json
node content/tools/build_lessons.mjs "content/en/$LVL/specs" | tail -3
node content/tools/build_plans.mjs | tail -1
node content/tools/validate.mjs | tail -14
echo "── عنوان‌های درس‌هایِ این بخش (برایِ اطمینان از تازگیِ spec) ──"
python3 - "$LVL" "$NAME" <<'PY'
import json, sys, glob
lvl, name = sys.argv[1], sys.argv[2]
spec = json.load(open(f'content/en/{lvl}/specs/{name}.json', encoding='utf-8'))
for L in spec['lessons']:
    print(f"درس L{L['n']} · {L['title']}")
PY
