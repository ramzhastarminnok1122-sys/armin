-- LINGU · فهرست درس‌ها برایِ رندر QA
-- خروجی را به /tmp/qa_lessons.json بریزید؛ batch_qa.mjs همان را می‌خواند.
-- اجرا: psql "$DATABASE_URL" -tAc "$(grep -v '^--' content/tools/ops/qa-lessons.sql)" > /tmp/qa_lessons.json
select jsonb_agg(jsonb_build_object('n',order_index,'title',title,'id',id))
from lessons
where language_code='en'
  and order_index in (303,307,311,315,318,320);
