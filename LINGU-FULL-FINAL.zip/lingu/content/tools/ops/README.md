# LINGU · Content Factory — ابزارهایِ عملیاتیِ session (ماندگار)

این پوشسه جایِ ابزارهایِ موقتی است که در `/tmp` زندگی می‌کردند. همه از ریشۀ
`lingu/` اجرا می‌شوند.

| ابزار | جایِ | کاربرد |
|---|---|---|
| `tidy_seed.py` | `/tmp/tidy.py` | خود-مرممِ بذر: `|~` در DLG/SPK/GP، IPA بی‌اسلش، گیومه‌گذاریِ لاتین در بخش‌هایِ فارسی (V/OBJ/NOTES/WARM/EXPL/FA/SPK/G/GP/GR/X)، حذف pipe انتهاییِ G. `--no-latin` برایِ خاموش‌کردنِ گیومه‌گذاری. |
| `run_part.sh` | `/tmp/runpart.sh` | پایپ‌لاینِ یک بخش: tidy → parse → build_lessons → build_plans → validate + چاپِ عنوانِ درس‌ها (دامِ specِ کهنه را می‌شکند). |
| `vocabulary_check.py` | `/tmp/paircheck.py` + `/tmp/free.py` | زیرفرمانِ `used` (واژه در کدام درس‌ها هست) و `pair` (همپوشانیِ >۲ در یک درس، با شکستنِ چندواژه‌ها — همان کاریِ که اعتبارسنج می‌کند). |
| `qa-lessons.sql` | فایلِ دستیِ /tmp | فهرست json درس‌ها برایِ رندر QA. |

## چرخۀ استانداردِ هر بخش
1. `python3 content/tools/ops/vocabulary_check.py pair <۱۰ واژه>` و `used` — **پیش ازِ نگارشِ بذر**.
2. نگارشِ `content/en/<LVL>/seeds/<batch>-part<k>.seed`.
3. `bash content/tools/ops/run_part.sh <LVL> <batch-part>` → تا «خطا: 0» ادامه دهید.
4. `node content/tools/build_import_sql.mjs <from> <to> batch-<N>` → `psql -f` → شمارشِ verify → اجرایِ دوباره برایِ idempotency.
5. QA رندر (`qa/batch_qa.mjs` + preview :4173) → rowsِ گزارش → `known.json` (اگر بود).

## قوانینِ زرّینِ بذر (که اعتبارسنج می‌گیرد)
- est فقط ۱۵ یا ۱۸ · vocab ۱۰–۱۲ · RDT ۸۰–۱۴۰ واژه · EXPL بدنه ۸۰–۱۴۰ + **حداکثر ۴ کلید + `||` انتهایی (۵ قلم می‌شود، ۶ نه)** · RDG ۳–۵ · RDQ ۳–۵ · G-expl ۷۰–۱۲۰ + GR ۳–۴ + GP ۲–۳ · EX/V-example/DLG-line ≤۱۲ واژه · LST ۶۰–۱۰۰ و «عنوان + یک خطِ جفت‌شده» · X ≥۴ و XF ≥۲ · QS پنج‌فیلدی با گزینه‌هایِ یکتا · همپوشانیِ واژگان <۳۰٪ با هر درسِ تک (شکستنِ چندواژه‌ها) · بی‌رقم در EN · بی‌لاتینِ ۴+ بیرونِ «…» در کلیپ‌هایِ fa · بی‌ي/ك عربی · no ≥3-word dup phrase بینِ درس‌ها.
- `parse_seed` هنگامِ خطا exit 1 می‌کند؛ اگر pipeline از داخلِ لوله grep اجرا شود، کدِ خروجیِ گم می‌شود — به «درس Lxxx»هایِ چاپ‌شده اعتماد کنید، نه tailِ تمیز.
