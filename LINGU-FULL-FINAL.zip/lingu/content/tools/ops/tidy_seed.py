#!/usr/bin/env python3
"""LINGU · Content Factory — خود-مرمم بذر (نسخهٔ ماندگارِ ابزارِ session)

این اسکریپت پیش از parse_seed.mjs اجرا می‌شود و خطاهایِ ساختاریِ رایجِ بذر را
ترمیم می‌کند. parse_seed همچنان «منبع حقیقت» است؛ این ابزار فقط کمکْ‌راهِ امن است.

ترمیم‌ها:
  1. DLG/SPK/LST/GP/GR: جداکنندۀ دوبارۀ «|~» به «~» (خطای زیرفیلد).
  2. V: IPA بدون اسلش → /ipa/ ; و حذف «اسm» → «اسم».
  3. واژۀ لاتینِ (۴+ حرف) بیرون از «…» در بخش‌هایِ فارسیِ این ردیف‌ها، داخل گیومه می‌رود:
     OBJ/NOTES/WARM/EXPL/FA(بدنه)/SPK(راهنما)/RDQ/answer-fa/note-fa.
  4. حذف pipe انتهاییِ زائد در ردیف‌های G.

استفاده: python3 tidy_seed.py <seed.seed> [seed2 ...] [--no-latin]
"""
import re, sys

LAT = r"[A-Za-z][A-Za-z().'\-]*"
FA_ONLY = ('OBJ', 'NOTES', 'WARM', 'EXPL')

def wrap_latin(txt):
    """put «» around latin words of 4+ letters outside existing guillemets"""
    parts = re.split(r'(«[^»]*»)', txt)
    out = []
    for p in parts:
        if p.startswith('«'):
            out.append(p); continue
        p = re.sub(r"(\*?)(%s(?: %s)*)(\*?)" % (LAT, LAT),
                   lambda m: (m.group(1) + '«' + m.group(2).strip() + '»' + m.group(3))
                   if len(re.sub(r"[^A-Za-z]", "", m.group(2))) >= 4 else m.group(0), p)
        out.append(p)
    return ''.join(out)

def fix(path, latin=True):
    lines = open(path, encoding='utf-8').read().split('\n')
    n = 0
    for i, l in enumerate(lines):
        o = l
        tag = l.split('|')[0]
        if tag in ('DLG', 'SPK', 'GP', 'GR', 'XT', 'XF', 'QS'):
            o = re.sub(r'([^|])\|~', r'\1~', o)
            while re.search(r'[^|]\|~', o):
                o = re.sub(r'([^|])\|~', r'\1~', o)
        if tag == 'V' and l.count('|') >= 2:
            parts = l.split('|')
            f = parts[1].split('~')
            if len(f) > 1 and f[1] and '/' not in f[1]:
                f[1] = '/' + f[1] + '/'
            f = [x.replace('اسm', 'اسم') for x in f]
            parts[1] = '~'.join(f); o = '|'.join(parts)
        if tag == 'G' and o.endswith('|') and o.count('|') == 3:
            o = o[:-1]
        if latin and tag == 'G':
            p = o.split('|')
            if len(p) >= 4:
                p[2] = wrap_latin(p[2]); o = '|'.join(p)
        if latin and tag == 'GP':
            pre, _, rest = o.partition('|')
            o = pre + '|' + '||'.join(wrap_latin(x) for x in rest.split('||'))
        if latin and tag == 'GR':
            p = o.split('|')
            if len(p) >= 3 and '~' in p[2]:
                en, _, fa = p[2].rpartition('~')
                p[2] = en + '~' + wrap_latin(fa); o = '|'.join(p)
        if latin and tag in ('X', 'XT'):
            p = o.split('|')
            if len(p) >= 5:
                p[-1] = wrap_latin(p[-1]); o = '|'.join(p)
        if latin:
            if tag in FA_ONLY:
                pre, _, rest = o.partition('|')
                o = pre + '|' + wrap_latin(rest)
            elif tag == 'FA':
                pre, stage, rest = o.split('|', 2)
                o = pre + '|' + stage + '|' + wrap_latin(rest)
            elif tag == 'SPK':
                pre, rest = o.split('|', 1)
                head, _, tail = rest.partition('||')
                o = pre + '|' + wrap_latin(head) + ('||' + tail if tail else '')
        if o != l:
            lines[i] = o; n += 1
    open(path, 'w', encoding='utf-8').write('\n'.join(lines))
    print(f'tidy ok: {path} · {n} خط ترمیم شد')

if __name__ == '__main__':
    args = [a for a in sys.argv[1:] if a != '--no-latin']
    latin = '--no-latin' not in sys.argv
    for p in args:
        fix(p, latin)
