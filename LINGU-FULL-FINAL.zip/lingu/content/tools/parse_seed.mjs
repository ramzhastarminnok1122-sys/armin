#!/usr/bin/env node
/**
 * LINGU · Content Factory — تبدیل «بذر» متن‌محور به مشخصات JSON (specs)
 *
 * اجرا:  node content/tools/parse_seed.mjs content/en/A2/seeds/b6-part1.seed
 * خروجی: content/en/A2/specs/<نام-فایل>.json   (همان قالب batch-N.json که build_lessons می‌خواند)
 *
 * چرا: نوشتن مستقیم JSON برای ۲۴۰ درس پرهزینه و خطاپذیر است. این ابزار همان
 * محتوای واقعی را با جداکننده‌های کوتاه می‌گیرد و ساختار را تضمین می‌کند.
 *
 * قواعد جداکننده:  | = مرز فیلد · || = مرز آیتم فهرست · ~ = مرز زیرفیلد · \n = خط جدید
 * هیچ فیلدی نباید خودِ کاراکترهای جداکننده را داشته باشد.
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs'
import { dirname, basename, join } from 'node:path'

const file = process.argv[2]
if (!file) { console.error('استفاده: node parse_seed.mjs <file.seed>'); process.exit(1) }
const src = readFileSync(file, 'utf8')

const nl = (s) => String(s ?? '').replace(/\\n/g, '\n').trim()
const need = (cond, msg, ln) => { if (!cond) { console.error(`خطای بذر در خط ${ln}: ${msg}`); process.exit(1) } }
const arr = (s) => String(s ?? '').split('||').map((x) => x.trim())
const parts = (s, n, ln, what) => {
  const p = String(s ?? '').split('|').map((x) => x.trim())
  need(p.length === n, `${what} باید ${n} فیلد داشته باشد (الان ${p.length})`, ln)
  return p
}
const sub = (s, n, ln, what) => {
  const p = String(s ?? '').split('~').map((x) => x.trim())
  need(p.length === n, `${what} باید ${n} زیرفیلد داشته باشد (الان ${p.length})`, ln)
  return p
}

const out = { batch: null, level: null, note: '', lessons: [] }
let cur = null
let ln = 0
const err = (m) => { console.error(`خطای بذر در خط ${ln}: ${m}`); process.exit(1) }

for (const raw of src.split('\n')) {
  ln++
  const line = raw.trim()
  if (!line || line.startsWith('#')) continue

  if (line.startsWith('@@')) {
    const p = parts(line.slice(2).replace(/^\|/, '').trim(), 6, ln, 'سرصفحهٔ @@ (n|title|subtitle|desc|min|topic)')
    const [, title, subtitle, desc, min, topic] = p
    cur = {
      n: Number(String(p[0]).replace(/[^0-9]/g, '')), title, subtitle, desc, min: Number(min), topic,
      obj: [], notes: '', warm: { p: '', q: [] }, expl: { title: 'هدف این درس', body: '', kp: [] },
      vocab: [], gram: { title: '', exp: '', pattern: '', rows: [], pit: [] }, ex: [],
      lst: { t: '', script: '', script_fa: '', q: '', a: '' }, listening_roles: null,
      dlg: { t: '', lines: [] }, spk: { task: '', ph: [], sec: 180 }, read: { title: '', text: '', gloss: [], qs: [] },
      exr: [], quiz: [], ai: { task: '', prompts: [], focus: [] }, fa: [],
    }
    need(Number.isFinite(cur.n) && cur.n > 0, 'شمارهٔ درس نامعتبر', ln)
    out.lessons.push(cur)
    continue
  }
  const i = line.indexOf('|')
  const key = (i === -1 ? line : line.slice(0, i)).trim().toUpperCase()
  const rest = i === -1 ? '' : line.slice(i + 1)

  if (key === 'LEVEL') { out.level = rest.trim(); continue }
  if (key === 'BATCH') { out.batch = Number(rest.trim()); continue }
  if (key === 'NOTE') { out.note = rest.trim(); continue }

  need(cur, 'پیش از سرصفحهٔ @@ محتوایی آمده است', ln)

  switch (key) {
    case 'NOTES': cur.notes = rest.trim(); break
    case 'OBJ': cur.obj = arr(rest); break
    case 'WARM': {
      const f = arr(rest); need(f.length >= 3 && f.length <= 4, 'WARM: prompt + ۲–۳ پرسش', ln)
      cur.warm = { p: f[0], q: f.slice(1).map((x, k) => sub(x, 2, ln, `WARM q${k + 1} (q~hint)`)) }
      break
    }
    case 'EXPL': {
      const f = arr(rest)
      need(f.length >= 4, 'EXPL: body + ۳ نکته (حداقل)', ln)
      cur.expl = { title: 'هدف این درس', body: f[0], kp: f.slice(1) }
      break
    }
    case 'V': {
      const p = sub(String(rest).replace(/\|/g, '~'), 6, ln, 'V (term~ipa~fa~en~fa~tag)')
      cur.vocab.push(p)
      break
    }
    case 'G': {
      const p = parts(rest, 3, ln, 'G (title|exp|pattern)')
      cur.gram = { ...cur.gram, title: p[0], exp: p[1], pattern: p[2] }
      break
    }
    case 'GR': { const f = parts(rest, 2, ln, 'GR (label|en~fa)'); cur.gram.rows.push([f[0], ...sub(f[1], 2, ln, 'GR en~fa')]); break }
    case 'GP': cur.gram.pit = arr(rest); break
    case 'EX': cur.ex.push(sub(String(rest).replace(/\|([^~]*)$/, '~$1'), 3, ln, 'EX (en~fa~note)')); break
    case 'LST': {
      const p = parts(rest, 5, ln, 'LST (title|script|script_fa|q|a)')
      const lines = (x) => nl(x).replace(/\s*~\s*/g, '\n')
      cur.lst = { t: p[0], script: lines(p[1]), script_fa: lines(p[2]), q: p[3], a: p[4] }
      break
    }
    case 'ROLE': {
      const roles = {}
      for (const pair of String(rest).split(/[~||]+/).map((x) => x.trim()).filter(Boolean)) {
        const [k, v] = pair.split('=').map((x) => x.trim())
        if (k && v) roles[k] = v
      }
      cur.listening_roles = Object.keys(roles).length ? roles : null
      break
    }
    case 'DLG': {
      const p = arr(rest)
      if (p[0] && p[0].includes('|')) { const [t0, ...rest0] = p[0].split('|'); p.splice(0, 1, t0, ...rest0.map((x) => x.trim())) }
      need(p.length >= 2, 'DLG: عنوان + خطوط', ln)
      cur.dlg = {
        t: p[0],
        lines: p.slice(1).map((x, k) => {
          const q = sub(x, 3, ln, `DLG خط ${k + 1} (A~en~fa)`)
          need(['A', 'B'].includes(q[0]), 'گوینده باید A یا B باشد', ln)
          return q
        }),
      }
      need(cur.dlg.lines.length >= 6 && cur.dlg.lines.length <= 10, 'DLG باید ۶ تا ۱۰ خط باشد', ln)
      break
    }
    case 'SPK': {
      const p = arr(rest)
      need(p.length >= 3, 'SPK: task + ۲–۴ عبارت (+ ثانیه)', ln)
      const last = p[p.length - 1]
      const sec = /^\d+$/.test(last) ? Number(p.pop()) : 180
      cur.spk = { task: p[0], ph: p.slice(1).map((x, k) => sub(x, 2, ln, `SPK عبارت ${k + 1} (en~fa)`)), sec }
      need(cur.spk.ph.length >= 3 && cur.spk.ph.length <= 4, 'SPK باید ۳–۴ عبارت داشته باشد', ln)
      break
    }
    case 'RD': {   // سبک چندخطی: RD|عنوان (سپس RDT / RDG / RDQ) · سبک قدیمی: RD|عنوان||متن||واژه‌ها||پرسش‌ها
      const r0 = String(rest)
      if (r0.includes('||')) {
        const p4 = r0.split('||').map((x) => x.trim())
        cur.read = {
          title: p4[0], text: (p4[1] || '').replace(/\s*~\s*/g, ' '),
          gloss: (p4[2] || '').split(';').map((x) => x.trim()).filter(Boolean).map((x) => x.split('~').map((y) => y.trim())),
          qs: (p4[3] || '').split(';').map((x) => x.trim()).filter(Boolean).map((x) => x.split('~').map((y) => y.trim())),
        }
      } else {
        cur.read = { title: r0.trim(), text: '', gloss: [], qs: [] }
      }
      break
    }
    case 'RDT': cur.read.text = nl(rest).replace(/\s*~\s*/g, ' '); break
    case 'RDG': { const q = sub(rest, 2, ln, 'RDG (term~fa)'); cur.read.gloss.push(q); break }
    case 'RDQ': { const q = sub(rest, 2, ln, 'RDQ (q~a)'); cur.read.qs.push(q); break }
    case 'RD1': {
      const p = String(rest).split('||').map((x) => x.trim())
      need(p.length === 4, 'RD (title||text||gloss;;gloss||q;;q)', ln)
      cur.read = {
        title: p[0], text: p[1],
        gloss: p[2].split(';').map((x) => x.trim()).filter(Boolean).map((x, k) => sub(x, 2, ln, `RD واژه‌نامه ${k + 1} (term~fa)`)),
        qs: p[3].split(';').map((x) => x.trim()).filter(Boolean).map((x, k) => sub(x, 2, ln, `RD پرسش ${k + 1} (q~a)`)),
      }
      break
    }
    case 'X': {   // X|type|prompt|question|options(; یا |)|answer|expl
      const c = String(rest).split('|').map((x) => x.trim())
      const type = c[0]
      let prompt, question, opts, answer, expl
      if (c.length === 8 || c.length === 9) {   // گزینه‌ها با «|» جدا شده‌اند
        prompt = c[1]; question = c[2]; opts = c.slice(3, 6); answer = c[6]; expl = c[7] ?? ''
      } else if (c.length >= 6) {
        prompt = c[1]; question = c[2]; opts = c[3].split(';').map((x) => x.trim()); answer = c[4]; expl = c.slice(5).join(' | ')
      } else {
        err('X باید دست‌کم ۶ فیلد داشته باشد')
      }
      if (type === 'mcq') cur.exr.push([type, prompt, question, opts, answer, expl])
      else if (type === 'truefalse') cur.exr.push([type, prompt, question, answer, expl])
      else cur.exr.push([type, prompt, question, String(answer).split(';').map((x) => x.trim()), expl])
      break
    }
    case 'XT': { // میان‌بر truefalse:  XT|prompt|question|True|expl
      const c = String(rest).split('|').map((x) => x.trim())
      const f = c.length === 4 ? c : [c[0], c.slice(1, -2).join(' | '), c[c.length - 2], c[c.length - 1]]
      need(f.length === 4, 'XT باید ۴ فیلد داشته باشد', ln)
      cur.exr.push(['truefalse', f[0], f[1], f[2], f[3]])
      break
    }
    case 'XF': { // میان‌بر fill:  XF|prompt|question|answers(;)...|expl
      const c = String(rest).split('|').map((x) => x.trim())
      const f = c.length === 4 ? c : [c[0], c.slice(1, -2).join(' | '), c[c.length - 2], c[c.length - 1]]
      need(f.length === 4, 'XF باید ۴ فیلد داشته باشد', ln)
      cur.exr.push(['fill', f[0], f[1], f[2].split(';').map((x) => x.trim()), f[3]])
      break
    }
    case 'QS': {
      const p = parts(rest, 4, ln, 'QS (question|options|index|expl)')
      const opts = p[1].replace(/\|/g, ';').split(';').map((x) => x.trim())
      need(opts.length === 3, 'QS باید دقیقاً ۳ گزینه داشته باشد', ln)
      cur.quiz.push([p[0], opts, Number(p[2]), p[3]])
      break
    }
    case 'AI': {
      let f = arr(rest)
      if (f.length > 5) f = [...f.slice(0, 4), f.slice(4).join(';').replace(/\|/g, ';')]
      f = f.map((x, i) => (i === f.length - 1 && f.length === 5 ? x.replace(/\|/g, ';') : x))
      need(f.length >= 5, 'AI: task + ۳–۴ دستور + focus', ln)
      const focus = f[f.length - 1].split(';').map((x) => x.trim()).filter(Boolean)
      cur.ai = { task: f[0], prompts: f.slice(1, -1), focus }
      break
    }
    case 'FA': {
      const p = parts(rest, 2, ln, 'FA (kind|text)')
      cur.fa.push(p)
      break
    }
    default: err(`کلید ناشناخته: ${key}`)
  }
}

/* --------------------------- بررسی حداقلی --------------------------- */
for (const L of out.lessons) {
  const bad = (m) => { console.error(`درس L${L.n}: ${m}`); process.exit(1) }
  if (L.vocab.length < 10 || L.vocab.length > 12) bad(`واژگان باید ۱۰–۱۲ باشد (الان ${L.vocab.length})`)
  if (L.gram.rows.length < 3 || L.gram.rows.length > 4) bad(`ردیف‌های گرامر باید ۳–۴ باشد (${L.gram.rows.length})`)
  if (L.gram.pit.length < 2 || L.gram.pit.length > 3) bad(`اشتباه‌های رایج باید ۲–۳ باشد (${L.gram.pit.length})`)
  if (L.ex.length < 4 || L.ex.length > 6) bad(`مثال‌ها باید ۴–۶ باشد (${L.ex.length})`)
  if (L.exr.length < 6 || L.exr.length > 8) bad(`تمرین‌ها باید ۶–۸ باشد (${L.exr.length})`)
  if (L.quiz.length !== 5) bad(`آزمون باید ۵ پرسش باشد (${L.quiz.length})`)
  if (L.ai.prompts.length < 3 || L.ai.prompts.length > 4) bad(`دستورهای AI باید ۳–۴ باشد (${L.ai.prompts.length})`)
  if (L.ai.focus.length !== 3) bad(`focus باید ۳ مورد باشد (${L.ai.focus.length})`)
  if (L.obj.length < 3 || L.obj.length > 5) bad(`اهداف باید ۳–۵ باشد (${L.obj.length})`)
  if (L.fa.length !== 6) bad(`کلیپ‌های فارسی باید ۶ باشد (${L.fa.length})`)
  if (L.read.gloss.length < 3 || L.read.gloss.length > 5) bad(`واژه‌نامه باید ۳–۵ باشد (${L.read.gloss.length})`)
  if (L.read.qs.length < 2 || L.read.qs.length > 3) bad(`پرسش‌های خواندن باید ۲–۳ باشد (${L.read.qs.length})`)
}

if (!out.level) out.level = 'A2'
out.batch = out.batch ?? 0

const dir = join(dirname(file), '..', 'specs')
if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
const outFile = join(dir, basename(file).replace(/\.seed$/, '.json'))
writeFileSync(outFile, JSON.stringify(out, null, 2) + '\n')
console.log(`${out.lessons.length} درس → ${outFile} (سطح ${out.level})`)
console.log(out.lessons.map((l) => `L${l.n} ${l.title}`).join(' · '))
