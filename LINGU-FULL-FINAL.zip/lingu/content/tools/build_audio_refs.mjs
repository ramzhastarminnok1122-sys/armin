#!/usr/bin/env node
/**
 * LINGU · Content Factory — ساخت ارجاع‌های صوتی داخل درس
 *
 * زنجیره: Lesson JSON  ←  Audio Plan  ←  فایل واقعی mp3
 *
 * اجرا:
 *   node content/tools/build_audio_refs.mjs            → همهٔ درس‌ها
 *   node content/tools/build_audio_refs.mjs L001 L010  → فقط این درس‌ها
 *
 * کارها:
 *   1) برای هر درس، مانیفست صدا (content/audio/L001.plan.json) را می‌خواند.
 *   2) هر کلیپی که فایل واقعی‌اش در content/audio/generated/<ID>/ باشد را برمی‌دارد
 *      (کلیپ بدون فایل هرگز ارجاع نمی‌گیرد تا هیچ فایل گم‌شده/خراب در برنامه نباشد).
 *   3) ارجاع‌ها را با کلید «audio» داخل content همان درس تزریق می‌کند:
 *        content.audio = { "<section>": [ {ref}, … ] }
 *   4) رجیستری کل پروژه را در content/audio/registry.json می‌نویسد
 *      (شناسهٔ یکتا، مسیر محتوا‌محور lesson-audio/<lang>/<hash8>.mp3، وضعیت آپلود).
 *
 * قاعدهٔ طلایی: متن ارجاع دقیقاً همان tts_text مانیفست است؛ یعنی همان چیزی که
 * به گوینده داده شده. پس «متن روی صفحه» و «صدای فایل» هرگز از هم جدا نمی‌شوند.
 */
import { readdirSync, readFileSync, writeFileSync, existsSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'
import { sectionOf, orderIn, dialogueIndex } from './lib/audio-map.mjs'

const ROOT = new URL('../../', import.meta.url).pathname.replace(/\/$/, '')
const LESSONS_DIR = join(ROOT, 'content/en/A1/lessons')
const AUDIO_DIR = join(ROOT, 'content/audio')
const GEN_DIR = join(AUDIO_DIR, 'generated')
const REGISTRY = join(AUDIO_DIR, 'registry.json')

function generatedFile(lessonId, clipId) {
  const f = join(GEN_DIR, lessonId, `${clipId}.mp3`)
  return existsSync(f) && statSync(f).size > 0 ? f : null
}

const only = process.argv.slice(2).filter((a) => /^L\d{3}$/.test(a))
const lessonIds = readdirSync(LESSONS_DIR).filter((f) => f.endsWith('.json'))
  .map((f) => f.replace('.json', '')).sort()
  .filter((id) => only.length === 0 || only.includes(id))

const registry = existsSync(REGISTRY) ? JSON.parse(readFileSync(REGISTRY, 'utf8')) : { clips: {} }
registry.generated_at = new Date().toISOString()
registry.bucket = 'lesson-audio'
registry.path_rule = '<lang>/<hash8>.mp3'
registry.clips = registry.clips ?? {}

let refsAdded = 0, filesSeen = 0, lessonsTouched = 0
const report = []

for (const id of lessonIds) {
  const lessonPath = join(LESSONS_DIR, `${id}.json`)
  const planPath = join(AUDIO_DIR, `${id}.plan.json`)
  const lesson = JSON.parse(readFileSync(lessonPath, 'utf8'))
  const lines = lesson.content?.dialogue?.lines ?? []
  const out = {}

  if (existsSync(planPath)) {
    const plan = JSON.parse(readFileSync(planPath, 'utf8'))
    for (const clip of plan.clips ?? []) {
      const file = generatedFile(id, clip.id)
      if (!file) continue
      const section = sectionOf(clip)
      if (!section) continue
      const buf = readFileSync(file)
      const hash8 = createHash('sha256').update(buf).digest('hex').slice(0, 8)
      const ref = {
        id: clip.id,
        section,
        lang: clip.language,
        role: clip.role,
        text: clip.tts_text,                     // همان متنی که خوانده شده
        path: `${clip.language}/${hash8}.mp3`,   // مسیر محتوا‌محور در باکت lesson-audio
        hash: hash8,
        bytes: buf.length,
      }
      const li = dialogueIndex(clip)
      if (li !== null) {
        ref.line = li
        if (lines[li]?.speaker) ref.speaker = lines[li].speaker
      }
      ;(out[section] = out[section] ?? []).push(ref)
      filesSeen++
      registry.clips[clip.id] = {
        lesson: id, section, lang: clip.language, role: clip.role,
        file: `content/audio/generated/${id}/${clip.id}.mp3`,
        hash: hash8, bytes: buf.length, path: ref.path,
        uploaded: registry.clips[clip.id]?.uploaded ?? false,
        public_url: registry.clips[clip.id]?.public_url ?? null,
        verified_at: registry.clips[clip.id]?.verified_at ?? null,
      }
    }
  }

  const fixed = {}
  for (const s of Object.keys(out).sort()) {
    out[s].sort((a, b) => orderIn(a) - orderIn(b))
    fixed[s] = out[s]
  }
  const had = lesson.content.audio
  lesson.content.audio = fixed
  const same = JSON.stringify(had) === JSON.stringify(fixed)
  if (!same) { writeFileSync(lessonPath, JSON.stringify(lesson), 'utf8'); lessonsTouched++ }
  refsAdded += Object.values(fixed).flat().length
  report.push(`${id}: ${Object.values(fixed).flat().length} ارجاع صوتی در ${Object.keys(fixed).length} بخش`)
}

writeFileSync(REGISTRY, JSON.stringify(registry, null, 2), 'utf8')
console.log(report.join('\n'))
console.log('———————————————————————————————————————')
console.log(`فایل صوتی موجود: ${filesSeen} · ارجاع در درس‌ها: ${refsAdded} · درس‌های به‌روزشده: ${lessonsTouched}`)
console.log(`رجیستری: content/audio/registry.json (${Object.keys(registry.clips).length} ردیف)`)
