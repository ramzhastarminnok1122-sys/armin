#!/usr/bin/env bash
# LINGU · Content Factory — اجرای یک مرحله از دسته (بذر → مشخصات → درس → مانیفست → اعتبارسنجی)
# استفاده: bash content/tools/run_batch.sh <seed> [seed2 ...]
set -e
cd "$(dirname "$0")/../.."
for seed in "$@"; do
  echo "── بذر: $seed ──"
  node content/tools/parse_seed.mjs "$seed" | tail -2
done
for lvl in A1 A2 B1; do
  [ -d "content/en/$lvl/specs" ] && node content/tools/build_lessons.mjs "content/en/$lvl/specs" | tail -3
done
node content/tools/build_plans.mjs | tail -1
node content/tools/validate.mjs | tail -8
