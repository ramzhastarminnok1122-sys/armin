#!/usr/bin/env python3
"""LINGU · بررسی فایل‌های صوتی تولیدشده بدون هیچ وابستگی (ffprobe روی این محیط نیست).

روش: هدر فریم‌های MP3 خوانده می‌شود و مدت/بیت‌ریت تخمین زده می‌شود.
اجرا: python3 content/tools/probe_audio.py content/audio/samples
"""
import os, sys, struct

BITRATES_V1_L3 = [0,32,40,48,56,64,80,96,112,128,160,192,224,256,320,0]  # kbps
BITRATES_V2_L3 = [0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,0]
RATES = {3: [44100, 48000, 32000], 2: [22050, 24000, 16000], 0: [11025, 12000, 8000]}


def id3_size(data: bytes) -> int:
    if data[:3] != b'ID3':
        return 0
    size = (data[6] & 0x7F) << 21 | (data[7] & 0x7F) << 14 | (data[8] & 0x7F) << 7 | (data[9] & 0x7F)
    return size + 10


def probe(path: str):
    data = open(path, 'rb').read()
    i = id3_size(data)
    total, frames = 0.0, 0
    while i + 4 <= len(data):
        if data[i] != 0xFF or (data[i + 1] & 0xE0) != 0xE0:
            i += 1
            continue
        h = struct.unpack('>I', data[i:i + 4])[0]
        ver = (h >> 19) & 0x3          # 3=MPEG1, 2=MPEG2, 0=MPEG2.5
        layer = (h >> 17) & 0x3        # 1 = layer III
        br_i = (h >> 12) & 0xF
        sr_i = (h >> 10) & 0x3
        pad = (h >> 9) & 0x1
        if layer != 1 or br_i in (0, 15) or sr_i == 3 or ver == 1:
            i += 1
            continue
        table = BITRATES_V1_L3 if ver == 3 else BITRATES_V2_L3
        br = table[br_i] * 1000
        rate = RATES[ver][sr_i]
        spf = 1152 if ver == 3 else 576
        flen = int((spf / 8) * br / rate) + pad
        if flen <= 4:
            i += 1
            continue
        total += spf / rate
        frames += 1
        i += flen
    return total, frames, len(data)


def main(root: str):
    files = []
    for dirpath, _, names in os.walk(root):
        files += [os.path.join(dirpath, n) for n in sorted(names) if n.lower().endswith('.mp3')]
    if not files:
        print('هیچ فایل mp3 پیدا نشد:', root); return 1
    print(f"{'فایل':<44}{'مدت(ث)':>9}{'KB':>8}{'فریم':>7}")
    print('-' * 68)
    t_tot = 0.0
    for f in files:
        d, fr, size = probe(f)
        t_tot += d
        print(f"{os.path.basename(f):<44}{d:>9.2f}{size/1024:>8.1f}{fr:>7}")
    print('-' * 68)
    print(f"جمع: {len(files)} فایل · {t_tot:.1f} ثانیه · {t_tot/60:.2f} دقیقه")
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else 'content/audio/samples'))
