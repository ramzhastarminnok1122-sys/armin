#!/usr/bin/env node
/**
 * LINGU · Content Factory — بازسازی «بذر» از فایل درس (ابزار بازیابی)
 * اجرا: node content/tools/lesson_to_seed.mjs <level> <from> <to> [outfile]
 * نمونه: node content/tools/lesson_to_seed.mjs A2 141 144 content/en/A2/seeds/b8-part1.seed
 * چرا: اگر بذر یک بخش گم یا خراب شود، متن کامل درس (۱۲ بخش) + کلیپ‌های فارسی
 *      از lessons/ و plans-meta.json بازسازی می‌شود تا کارخانه بازتولیدپذیر بماند.
 */
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const [level = 'A2', from = '1', to = '1', out = ''] = process.argv.slice(2)
const N0 = Number(from), N1 = Number(to)
const LESS = (n) => join('content/en', level, 'lessons', `L${String(n).padStart(3, '0')}.json`)
const META = JSON.parse(readFileSync('content/audio/plans-meta.json', 'utf8'))

const lines = [`# LINGU · بذر بازسازی‌شده ${level} — L${N0}–L${N1}`, `LEVEL|${level}`, '']

for (let n = N0; n <= N1; n++) {
  const j = JSON.parse(readFileSync(LESS(n), 'utf8'))
  const l = j.lesson, c = j.content, m = c.meta ?? {}
  const id = `L${String(n).padStart(3, '0')}`
  lines.push(`@@|${n}|${l.title}|${l.subtitle}|${l.description}|${l.estimated_minutes}|${m.topic ?? ''}`)
  lines.push(`OBJ|${(m.objectives ?? []).join('||')}`)
  lines.push(`WARM|${c.warmup.prompt_fa}||${c.warmup.questions.map((q) => `${q.q}~${q.hint_fa}`).join('||')}`)
  lines.push(`EXPL|${c.explanation.body_fa}||${(c.explanation.key_points ?? []).join('||')}`)
  for (const v of c.vocabulary.items) lines.push(`V|${v.term}~${v.ipa}~${v.translation_fa}~${v.example}~${v.example_fa}~${v.tag}`)
  lines.push(`G|${c.grammar.title}|${c.grammar.explanation_fa}|${c.grammar.pattern}`)
  for (const r of c.grammar.table.rows) lines.push(`GR|${r[0]}|${r[1]}~${r[2]}`)
  lines.push(`GP|${(c.grammar.pitfalls_fa ?? []).join('||')}`)
  for (const e of c.examples.items) lines.push(`EX|${e.target}~${e.fa}~${e.note_fa}`)
  const sc = c.listening.script.split('\n').map((x) => x.trim()).filter(Boolean).join('~')
  const scf = c.listening.script_fa.split('\n').map((x) => x.trim()).filter(Boolean).join('\\n')
  lines.push(`LST|${c.listening.title_fa}|${sc}|${scf}|${c.listening.question_fa}|${c.listening.answer}`)
  const roles = META[id]?.listening_roles ?? {}
  lines.push(`ROLE|${Object.entries(roles).map(([k, v]) => `${k}=${v}`).join('~')}`)
  lines.push(`DLG|${c.dialogue.title_fa}|${c.dialogue.lines.map((x) => `${x.speaker}~${x.target}~${x.fa}`).join('||')}`)
  lines.push(`SPK|${c.speaking.task_fa}||${c.speaking.useful_phrases.map((p) => `${p.target}~${p.fa}`).join('||')}||${c.speaking.seconds}`)
  lines.push(`RD|${c.reading.title}`)
  lines.push(`RDT|${c.reading.text}`)
  for (const g of c.reading.glossary) lines.push(`RDG|${g.term}~${g.fa}`)
  for (const q of c.reading.questions) lines.push(`RDQ|${q.q}~${q.a}`)
  for (const e of c.exercises.items) {
    if (e.type === 'truefalse') lines.push(`XT|${e.prompt_fa}|${e.question}|${e.answer}|${e.explanation_fa}`)
    else if (e.type === 'fill') lines.push(`XF|${e.prompt_fa}|${e.question}|${e.answer}|${e.explanation_fa}`)
    else if (e.type === 'mcq') lines.push(`X|mcq|${e.prompt_fa}|${e.question}|${(e.options ?? []).join(';')}|${e.answer}|${e.explanation_fa}`)
    else lines.push(`X|${e.type}|${e.prompt_fa}|${e.question}|${[].concat(e.answers ?? e.answer).join(';')}|${[].concat(e.answers ?? e.answer)[0]}|${e.explanation_fa}`)
  }
  for (const q of c.quiz.items) lines.push(`QS|${q.question}|${q.options.join(';')}|${Math.max(0, q.options.indexOf(q.answer))}|${q.explanation_fa}`)
  lines.push(`AI|${c.ai_practice.task_fa}||${c.ai_practice.suggested_prompts.join('||')}||${c.ai_practice.focus.join(';')}`)
  for (const f of META[id]?.fa ?? []) lines.push(`FA|${f.name}|${f.tts_text}`)
  lines.push('')
}

const target = out || `content/en/${level}/seeds/rebuilt-L${N0}-L${N1}.seed`
writeFileSync(target, lines.join('\n'))
console.log(`بذر بازسازی‌شده → ${target} (${N1 - N0 + 1} درس)`)
