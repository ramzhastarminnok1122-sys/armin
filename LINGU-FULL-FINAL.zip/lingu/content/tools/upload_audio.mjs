#!/usr/bin/env node
/**
 * LINGU · Content Factory — آپلود فایل‌های صوتی به باکت lesson-audio
 *
 * اجرا (توکن دسترسی موقت ادمین از محیط می‌آید، نه از فایل):
 *   SUPABASE_URL=… SUPABASE_ANON=… SUPABASE_TOKEN=… node content/tools/upload_audio.mjs
 *   … --force     → همه را دوباره آپلود کن
 *
 * ویژگی‌ها:
 *   · مسیر محتوا‌محور: lesson-audio/<lang>/<hash8>.mp3 (دو کلیپ یکسان = یک فایل)
 *   · Cache-Control طولانی (فایل با هش نام‌گذاری شده، تغییرناپذیر است)
 *   · آپلود فقط برای فایل‌هایی که در رجیستری uploaded نیستند (idempotent)
 *   · پس از آپلود، خودِ آدرس عمومی با GET بررسی می‌شود (۲۰۰ + حجم درست)
 *   · هیچ توکنی چاپ نمی‌شود
 */
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'

const ROOT = new URL('../../', import.meta.url).pathname.replace(/\/$/, '')
const REGISTRY = join(ROOT, 'content/audio/registry.json')
const SUPA = (process.env.SUPABASE_URL ?? '').replace(/\/$/, '')
const ANON = process.env.SUPABASE_ANON ?? ''
const TOKEN = process.env.SUPABASE_TOKEN ?? ''
const FORCE = process.argv.includes('--force')

if (!SUPA || !ANON || !TOKEN) {
  console.error('✗ SUPABASE_URL / SUPABASE_ANON / SUPABASE_TOKEN لازم است.')
  process.exit(1)
}

const reg = JSON.parse(readFileSync(REGISTRY, 'utf8'))
const clips = reg.clips ?? {}
const target = Object.entries(clips)
  .filter(([, c]) => FORCE || !c.uploaded)
  .sort((a, b) => (a[1].lesson < b[1].lesson ? -1 : 1))

const done = new Map() // path → نتیجهٔ آپلود
let uploaded = 0, reused = 0, verified = 0, failed = 0

for (const [clipId, c] of target) {
  const file = join(ROOT, c.file)
  if (!existsSync(file)) { console.log(`✗ ${clipId}: فایل نیست (${c.file})`); failed++; continue }
  const body = readFileSync(file)

  if (done.has(c.path)) {
    const r = done.get(c.path)
    Object.assign(c, r, { file: c.file })
    reused++
  } else {
    const res = await fetch(`${SUPA}/storage/v1/object/lesson-audio/${c.path}`, {
      method: 'POST',
      headers: {
        apikey: ANON,
        authorization: `Bearer ${TOKEN}`,
        'content-type': 'audio/mpeg',
        'cache-control': 'max-age=31536000',
        'x-upsert': 'true',
      },
      body,
    })
    if (!res.ok) {
      console.log(`✗ ${clipId}: آپلود نشد (${res.status} ${(await res.text()).slice(0, 90)})`)
      failed++
      continue
    }
    uploaded++
    const r = {
      uploaded: true,
      public_url: `${SUPA}/storage/v1/object/public/lesson-audio/${c.path}`,
      verified_at: null,
    }
    done.set(c.path, r)
    Object.assign(c, r)
  }

  // بررسی واقعی آدرس عمومی
  const head = await fetch(c.public_url, { method: 'GET', headers: { Range: 'bytes=0-1' } })
  const len = head.headers.get('content-range')?.split('/')[1] ?? head.headers.get('content-length')
  const cache = head.headers.get('cache-control') ?? '-'
  if ((head.status === 200 || head.status === 206) && Number(len) === c.bytes) {
    c.verified_at = new Date().toISOString()
    c.http = head.status
    c.cache_control = cache
    verified++
  } else {
    console.log(`✗ ${clipId}: بررسی عمومی ناموفق (status=${head.status} bytes=${len} / ${c.bytes})`)
    failed++
  }
}

reg.updated_at = new Date().toISOString()
writeFileSync(REGISTRY, JSON.stringify(reg, null, 2), 'utf8')
console.log('———————————————————————————————————————')
console.log(`آپلود تازه: ${uploaded} · استفاده از فایل تکراری: ${reused} · تأیید عمومی: ${verified} · خطا: ${failed}`)
console.log(`مجموع ردیف‌های آپلودشده در رجیستری: ${Object.values(clips).filter((c) => c.uploaded).length}`)
process.exit(failed === 0 ? 0 : 1)
