#!/usr/bin/env node
/**
 * LINGU · Content Factory — ساخت فایل درس از «مشخصات فشرده» (بدون وابستگی npm)
 *
 * اجرا:  node content/tools/build_lessons.mjs [specs-dir]
 * ورودی: content/en/<LEVEL>/specs/batch-N.json   ← دست‌نویسِ عامل محتوا
 * خروجی: content/en/<LEVEL>/lessons/L0NN.json    ← قالب قفل‌شدهٔ L001–L020 + ادغام در plans-meta.json
 *
 * چرا این ابزار: قالبِ درس ۱۲بخشی قفل شده است. عامل محتوا فقط «متنِ واقعی» را می‌نویسد
 * (واژگان، دیالوگ، شنیداری، خواندن، تمرین‌ها، لایهٔ فارسی)؛ ساختار را این ابزار می‌سازد
 * تا هیچ درسی از قالب جا نیفتد و هیچ کلیدی دستی اشتباه نشود.
 *
 * نگاشت مشخصات فشرده → اسکیمای درس:
 *   vocab  : [term, ipa, translation_fa, example, example_fa, tag]
 *   ex     : [target, fa, note_fa]
 *   dlg    : [speaker, target, fa]
 *   exr    : [type, prompt_fa, question, options|answers, answer, explanation_fa]
 *            type ∈ mcq | truefalse | fill | short
 *   quiz   : [question, [o1,o2,o3], answerIndex, explanation_fa]
 *   fa     : [name, tts_text]  (۶ کلیپ فارسی هر درس — «لایهٔ توضیح فارسی»)
 */
import { readdirSync, readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'

const SPECS_DIR = process.argv[2] ?? 'content/en/A1/specs'
const LESSONS_DIR = SPECS_DIR.replace(/\/specs$/, '/lessons')
const META_PATH = 'content/audio/plans-meta.json'
const TODAY = new Date().toISOString().slice(0, 10)

const fp = (lang, level, title) =>
  createHash('md5').update(`${lang}|${level}|${title}`.toLowerCase().replace(/\s+/g, '')).digest('hex')

const NUM2FA = { 0: '۰', 1: '۱', 2: '۲', 3: '۳', 4: '۴', 5: '۵', 6: '۶', 7: '۷', 8: '۸', 9: '۹' }
const faDigits = (s) => String(s).replace(/\d/g, (d) => NUM2FA[d])
const numWord = (n) => ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten',
  'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty'][n] ?? String(n)
const w = (t) => String(t ?? '').trim().split(/\s+/).filter(Boolean)
const pw = (t) => String(t ?? '').trim().split(/\s+/).filter(Boolean)

const warnings = []
const warn = (id, msg) => warnings.push(`⚠ [${id}] ${msg}`)

function buildLesson(spec) {
  const id = `L${String(spec.n).padStart(3, '0')}`
  const level = spec.level ?? 'A1'

  /* --- متن‌های انگلیسی: هیچ رقمی نباید به متن صوتی راه پیدا کند --- */
  const eng = []
  const collectEng = (t, where) => { if (/\d/.test(String(t ?? ''))) eng.push(`${where}: «${t}»`) }
  spec.vocab.forEach((v, i) => { collectEng(v[3], `vocab[${i}].example`) })
  spec.ex.forEach((e, i) => collectEng(e[0], `examples[${i}]`))
  spec.lst.script.split('\n').forEach((l, i) => collectEng(l.replace(/^[A-Za-z][A-Za-z ]{0,20}:\s*/, ''), `listening[${i}]`))
  spec.dlg.lines.forEach((l, i) => collectEng(l[1], `dialogue[${i}]`))
  collectEng(spec.read.text, 'reading.text')
  spec.gram.rows.forEach((r, i) => collectEng(r[1], `grammar.rows[${i}]`))
  for (const e of eng) warn(id, `رقم در متن انگلیسی (برای صوت مشکل می‌سازد): ${e}`)

  /* --- نزدیک‌بودن طول متن‌ها به بازهٔ اعتبارسنج (هشدار زودهنگام) --- */
  const chk = (label, val, min, max, unit = 'واژه') => {
    if (val < min || val > max) warn(id, `${label}: ${val} ${unit} (بازهٔ مجاز ${min}–${max})`)
  }
  chk('explanation.body_fa', pw(spec.expl.body).length, 80, 140)
  chk('grammar.explanation_fa', pw(spec.gram.exp).length, 70, 120)
  chk('listening.script', spec.lst.script.split('\n').reduce((n, l) => n + w(l.replace(/^[A-Za-z][A-Za-z ]{0,20}:\s*/, '')).length, 0), 60, 100)
  chk('reading.text', w(spec.read.text).length, 80, 140)
  spec.dlg.lines.forEach((l, i) => chk(`dialogue[${i}]`, w(l[1]).length, 1, 12))
  spec.ex.forEach((e, i) => chk(`examples[${i}]`, w(e[0]).length, 1, 12))
  spec.vocab.forEach((v, i) => chk(`vocab[${i}].example`, w(v[3]).length, 1, 12))

  const item = (e) => ({
    type: e[0], prompt_fa: e[1], question: e[2],
    ...(e[0] === 'truefalse'
      ? { options: ['True', 'False'], answer: e[3] }
      : e[0] === 'mcq'
        ? { options: e[3], answer: e[4] }
        : { answer: e[3] }),
    explanation_fa: e[0] === 'truefalse' ? e[4] : e[0] === 'mcq' ? e[5] : e[4],
  })
  const content = {
    meta: { cefr: level, topic: spec.topic, objectives: spec.obj },
    warmup: { prompt_fa: spec.warm.p, questions: spec.warm.q.map(([q, h]) => ({ q, hint_fa: h })) },
    explanation: { title: spec.expl.title, body_fa: spec.expl.body, key_points: spec.expl.kp },
    vocabulary: { items: spec.vocab.map(([term, ipa, translation_fa, example, example_fa, tag]) => ({ term, ipa, translation_fa, example, example_fa, tag })) },
    grammar: {
      title: spec.gram.title, explanation_fa: spec.gram.exp, pattern: spec.gram.pattern,
      table: { headers: ['ساختار', 'مثال', 'ترجمه'], rows: spec.gram.rows }, pitfalls_fa: spec.gram.pit,
    },
    examples: { items: spec.ex.map(([target, fa, note_fa]) => ({ target, fa, note_fa })) },
    listening: { title_fa: spec.lst.t, script: spec.lst.script, script_fa: spec.lst.script_fa, question_fa: spec.lst.q, answer: spec.lst.a, needs_audio: true },
    dialogue: { title_fa: spec.dlg.t, lines: spec.dlg.lines.map(([speaker, target, fa]) => ({ speaker, target, fa })) },
    speaking: { task_fa: spec.spk.task, useful_phrases: spec.spk.ph.map(([target, fa]) => ({ target, fa })), seconds: spec.spk.sec ?? 180 },
    reading: { title: spec.read.title, text: spec.read.text, glossary: spec.read.gloss.map(([term, fa]) => ({ term, fa })), questions: spec.read.qs.map(([q_fa, a]) => ({ q_fa, a })) },
    exercises: { items: spec.exr.map(item) },
    quiz: { items: spec.quiz.map(([question, options, ai, explanation_fa]) => ({ type: 'mcq', question, options, answer: options[ai], explanation_fa })) },
    ai_practice: { task_fa: spec.ai.task, suggested_prompts: spec.ai.prompts, focus: spec.ai.focus },
    audio: {},
  }
  return {
    lesson: {
      language_code: 'en', level, order_index: spec.n, title: spec.title, subtitle: spec.subtitle,
      description: spec.desc, estimated_minutes: spec.min ?? 18, is_free: Boolean(spec.free), status: 'validated', version: 1,
    },
    content,
    validation: {
      generated_by: 'content-factory-agent', validated_at: TODAY,
      checks: ['schema', 'content', 'level', 'grammar', 'vocabulary', 'tts', 'quiz', 'exercise', 'ai_practice', 'ui_compatibility', 'duplicate'],
      notes: spec.notes ?? '',
    },
    _fingerprint: fp('en', level, spec.title),
  }
}

/* ------------------------------- اجرا ------------------------------- */
if (!existsSync(SPECS_DIR)) { console.error('پوشهٔ مشخصات نیست:', SPECS_DIR); process.exit(1) }
mkdirSync(LESSONS_DIR, { recursive: true })

const metaAll = existsSync(META_PATH) ? JSON.parse(readFileSync(META_PATH, 'utf8')) : {}
let built = []
for (const f of readdirSync(SPECS_DIR).filter((x) => x.endsWith('.json')).sort()) {
  const spec = JSON.parse(readFileSync(join(SPECS_DIR, f), 'utf8'))
  for (const s of spec.lessons) built.push(buildLesson({ ...s, level: s.level ?? spec.level ?? 'A1' }))
}
built.sort((a, b) => a.lesson.order_index - b.lesson.order_index)

const PRIO = { warmup: 'P1', explanation: 'P1', 'listening-intro': 'P2', 'grammar-note': 'P2', speaking: 'P2', 'dialogue-note': 'P3', 'vocab-note': 'P3', 'ai-practice': 'P3', closing: 'P2' }
for (const b of built) {
  const id = `L${String(b.lesson.order_index).padStart(3, '0')}`
  const file = join(LESSONS_DIR, `${id}.json`)
  const { _fingerprint, ...clean } = b
  writeFileSync(file, JSON.stringify(clean, null, 2) + '\n')
  console.log(`${id}: ${b.lesson.title} · واژگان ${b.content.vocabulary.items.length} · تمرین ${b.content.exercises.items.length} · آزمون ${b.content.quiz.items.length} · اثر انگشت ${_fingerprint.slice(0, 8)}`)
}

/* ادغام لایهٔ صوتی فارسی در plans-meta.json (متن صوتی + نقش + اولویت) */
for (const f of readdirSync(SPECS_DIR).filter((x) => x.endsWith('.json')).sort()) {
  const spec = JSON.parse(readFileSync(join(SPECS_DIR, f), 'utf8'))
  for (const s of spec.lessons) {
    const id = `L${String(s.n).padStart(3, '0')}`
    metaAll[id] = {
      reading_role: s.read_role ?? 'EN-READ-F',
      ...(s.listening_roles ? { listening_roles: s.listening_roles } : {}),
      fa: (s.fa ?? []).map(([name, tts_text]) => ({ name, source: `${name} (لایهٔ توضیح فارسی درس ${id})`, priority: PRIO[name] ?? 'P3', tts_text })),
    }
  }
}
writeFileSync(META_PATH, JSON.stringify(metaAll, null, 2) + '\n')
console.log(`\n${built.length} درس ساخته شد · plans-meta: ${Object.keys(metaAll).length} درس`)
console.log(warnings.length ? `\n${warnings.length} هشدار:\n` + warnings.join('\n') : '\nبدون هشدار.')
