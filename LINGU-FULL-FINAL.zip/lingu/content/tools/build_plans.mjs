#!/usr/bin/env node
/**
 * LINGU · ساخت مانیفست صدا از محتوای واقعی درس (بدون هیچ وابستگی)
 * اجرا:  node content/tools/build_plans.mjs
 * ورودی: content/en/A1/lessons/L00N.json  +  content/audio/plans-meta.json
 * خروجی: content/audio/L00N.plan.json
 *
 * هیچ فایل صوتی‌ای نمی‌سازد؛ فقط «نسخهٔ گفتاری» هر کلیپ را آماده می‌کند.
 */
import { readdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'

const LESSONS_DIRS = (process.argv[2] ? [process.argv[2]] : ["content/en/A1/lessons","content/en/A2/lessons","content/en/B1/lessons"]).filter((d) => existsSync(d))
const META_PATH = 'content/audio/plans-meta.json'
const OUT_DIR = 'content/audio'

const meta = JSON.parse(readFileSync(META_PATH, 'utf8'))

/* --------------------- نرمال‌سازی متن برای TTS --------------------- */
const NUM = { 0: 'zero', 1: 'one', 2: 'two', 3: 'three', 4: 'four', 5: 'five', 6: 'six', 7: 'seven', 8: 'eight', 9: 'nine', 10: 'ten', 11: 'eleven', 12: 'twelve', 20: 'twenty', 30: 'thirty', 40: 'forty', 50: 'fifty', 60: 'sixty', 90: 'ninety' }
const MONO = { Mon: 'Monday', Tue: 'Tuesday', Wed: 'Wednesday', Thu: 'Thursday', Fri: 'Friday', Sat: 'Saturday', Sun: 'Sunday' }

export function normalizeTts(raw) {
  let t = String(raw ?? '')
    .replace(/^\s*[A-Za-z][A-Za-z .]{0,24}:\s*/gm, '')   // نام گوینده در ابتدای خط
    .replace(/…/g, '.')
    .replace(/[""]/g, '"')
    .replace(/\s*\/[^/\s]+\/\s*/g, ' ')                    // IPA
    .replace(/\b(Mon|Tue|Wed|Thu|Fri|Sat|Sun)\b\.?/g, (m) => MONO[m.replace('.', '')] ?? m)
    .replace(/\b(\d{4})\b/g, (m) => String(m).split('').map((d) => NUM[d]).join(' '))
    .replace(/\b(\d+)\b/g, (m) => NUM[m] ?? NUM[m[0]] + ' ' + NUM[m.slice(1)] ?? m)
    .replace(/\s{2,}/g, ' ')
    .replace(/^[.\s]+/, '')
    .trim()
  return t
}

const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]/g, '')

function clipsFor(lessonFile, id, m) {
  const c = lessonFile.content
  const clips = []
  const push = (clip) => clips.push({ ...clip, chars: clip.tts_text.length })

  /* دیالوگ — هر خط یک کلیپ، نقش بر اساس speaker */
  c.dialogue.lines.forEach((l, i) => push({
    id: `${id}-en-dialogue-${i + 1}`,
    role: l.speaker === 'B' ? 'EN-CHAR-B' : 'EN-CHAR-A',
    source: `dialogue.lines[${i}]`,
    tts_text: normalizeTts(l.target), priority: 'P1', language: 'en',
  }))

  /* شنیداری — خط‌به‌خط؛ اگر مونولوگ باشد همه یک صدا */
  const raw = c.listening.script.split('\n').map((x) => x.trim()).filter(Boolean)
  const labels = raw.map((l) => (l.includes(':') ? l.split(':')[0].trim() : null))
  const uniq = [...new Set(labels.filter(Boolean))]
  raw.forEach((line, i) => {
    const label = labels[i]
    let role
    if (m.listening_roles && label && m.listening_roles[label]) role = m.listening_roles[label]
    else if (uniq.length <= 1) role = m.reading_role
    else role = (i % 2 === 0) ? 'EN-CHAR-A' : 'EN-CHAR-B'
    push({ id: `${id}-en-listening-${i + 1}`, role, source: `listening.script[${i}]`, tts_text: normalizeTts(line), priority: 'P1', language: 'en' })
  })

  /* واژگان — سر واژه + جملهٔ نمونه در یک کلیپ */
  c.vocabulary.items.forEach((v) => push({
    id: `${id}-en-vocab-${slug(v.term)}`, role: 'EN-VOCAB', source: `vocabulary.items[${c.vocabulary.items.indexOf(v)}]`,
    tts_text: normalizeTts(`${v.term}. ${v.example}`), priority: 'P2', language: 'en',
  }))

  /* گرامر — فقط مثال‌های انگلیسی جدول */
  c.grammar.table.rows.forEach((r, i) => push({
    id: `${id}-en-grammar-row-${i + 1}`, role: 'EN-VOCAB', source: `grammar.table.rows[${i}]`,
    tts_text: normalizeTts(r[1]), priority: 'P2', language: 'en',
  }))

  /* مثال‌ها */
  c.examples.items.forEach((e, i) => push({
    id: `${id}-en-examples-${i + 1}`, role: 'EN-VOCAB', source: `examples.items[${i}]`,
    tts_text: normalizeTts(e.target), priority: 'P3', language: 'en',
  }))

  /* خواندن */
  push({ id: `${id}-en-reading`, role: m.reading_role, source: 'reading.text', tts_text: normalizeTts(c.reading.text), priority: 'P4', language: 'en' })

  /* راهنمای فارسی */
  for (const f of m.fa ?? []) push({
    id: `${id}-fa-${f.name}`, role: 'FA-COACH', source: f.source,
    tts_text: normalizeTts(f.tts_text), priority: f.priority ?? 'P2', language: 'fa',
  })

  /* نمونه‌های تولیدشده */
  for (const s of m.samples ?? []) {
    const clip = clips.find((x) => x.id === s.id)
    if (clip) { clip.sample = true; clip.file = s.file }
    else console.warn(`[هشدار] نمونهٔ ${s.id} در مانیفست ${id} پیدا نشد`)
  }
  return clips
}

const files = LESSONS_DIRS.flatMap((d) => readdirSync(d).filter((f) => f.endsWith('.json')).map((f) => join(d, f))).sort()
let n = 0
for (const f of files) {
  const lesson = JSON.parse(readFileSync(f, "utf8"))
  const id = `L${String(lesson.lesson.order_index).padStart(3, '0')}`
  const m = meta[id]
  if (!m) { console.error(`[خطا] متادیتای ${id} در plans-meta.json نیست`); process.exit(1) }
  const clips = clipsFor(lesson, id, m)
  const out = {
    lesson: id, language: 'en', level: lesson.lesson.level ?? 'A1', needs_audio: Boolean(lesson.content.listening?.needs_audio),
    voice_registry_ref: 'content/audio/voices.json', generated_by: 'content/tools/build_plans.mjs',
    mapping_note: 'نقش هر خط شنیداری از برچسب همان خط در script گرفته می‌شود؛ در مونولوگ، راوی = نقش متن خواندن.',
    clips,
  }
  writeFileSync(join(OUT_DIR, `${id}.plan.json`), JSON.stringify(out, null, 2) + '\n')
  n++
  console.log(`${id}: ${clips.length} کلیپ (انگلیسی ${clips.filter((c) => c.language === 'en').length} · فارسی ${clips.filter((c) => c.language === 'fa').length}) · نمونه ${clips.filter((c) => c.sample).length}`)
}
console.log(`\n${n} مانیفست ساخته شد.`)
