# LINGU · Content Factory — RUN خودکار (L021 → L100)
**حالت:** RUN MODE — بدون توقف بین دسته‌ها · **دسته‌ها:** ۲۰ درس · **قالب:** قفل‌شدهٔ L001–L020 · **صدا:** فقط سناریو/نقش/مانیفست (بدون فایل واقعی، طبق دستور)
**شروع:** ۲۰۲۶-۰۹-۳۰

---

## دستهٔ ۲ · L021–L040
- **Generated:** 20/20
- **QA:** PASS (اعتبارسنج: ۴۴٬۵۶۶ پاس · ۰ خطا · تکرار ۰) + آزمون مرورگر روی ۵ درس (L021 · L026 · L031 · L035 · L040): هر ۱۲ بخش در دسکتاپ و موبایل باز و سالم
- **Imported:** 20/20 (پایگاه دادهٔ زنده · UPDATE-first · اجرای دوم: ۲۱× INSERT 0 0 → idempotent)
- **Duplicate:** 0 (اثر انگشت یکتا · ترتیب یکتا · جملهٔ تکراری بین درسی: ۰)
- **Errors:** 0
- **Verify:** ۴۰ درس در DB · ۲۰ در بازه · id یکتا · واژگان ۱۲ · آزمون ۵ · ۱۲ بخش · رایگان فقط L001–002 · batch_id وصل · دسته «batch-2» در `content_batches`

## دستهٔ ۳ · L041–L060
- **Generated:** 20/20
- **QA:** PASS (اعتبارسنج: ۶۷٬۳۱۲ پاس · ۰ خطا · تکرار ۰) + آزمون مرورگر روی ۴ درس (L041 · L050 · L055 · L060): هر ۱۲ بخش در دسکتاپ سالم
- **Imported:** 20/20 (پایگاه دادهٔ زنده · اجرای دوم: ۲۱× INSERT 0 0 → idempotent)
- **Duplicate:** 0 (اثر انگشت · ترتیب · جملهٔ بین‌درسی)
- **Errors:** 0
- **Verify:** ۶۰ درس در DB · رایگان فقط L001–002 · batch_id وصل · دسته «batch-3» در `content_batches`

## دستهٔ ۴ · L061–L080
- **Generated:** 20/20
- **QA:** PASS (اعتبارسنج: ۹۰٬۴۷۶ پاس · ۰ خطا · تکرار ۰) + آزمون مرورگر روی ۴ درس (L061 · L070 · L075 · L080): هر ۱۲ بخش سالم
- **Imported:** 20/20 (اجرای دوم: ۲۱× INSERT 0 0 → idempotent)
- **Duplicate:** 0
- **Errors:** 0
- **Verify:** ۸۰ درس در DB · رایگان فقط L001–002 · دستهٔ چهارم در `content_batches`

## دستهٔ ۵ · L081–L100
- **Generated:** 20/20
- **QA:** PASS (اعتبارسنج: ۱۱۳٬۶۹۸ پاس · ۰ خطا · تکرار ۰) + آزمون مرورگر روی ۴ درس (L081 · L090 · L095 · L100): هر ۱۲ بخش سالم
- **Imported:** 20/20 (پایگاه دادهٔ زنده · اجرای دوم: ۲۱× INSERT 0 0 → idempotent)
- **Duplicate:** 0 (اثر انگشت یکتا · ترتیب یکتا · جملهٔ بین‌درسی ۰ · هم‌پوشانی واژگان زیر ۳۰٪)
- **Errors:** 0
- **Verify:** ۱۰۰ درس در DB · واژگان ۱۲ در ۲۰/۲۰ · آزمون ۵ در ۲۰/۲۰ · رایگان فقط L001–002 · ۰ منتشرشده · دستهٔ پنجم در `content_batches`
- **Next:** — (پایان اجرا)

### درس‌های دستهٔ ۵
| # | عنوان | گرامر جدید |
|---|---|---|
| 81 | Turn Left at the Corner | افعال امری و حرف اضافهٔ حرکت |
| 82 | A Table for Two | عبارت‌های سفارش در رستوران |
| 83 | Four Seasons | توصیف فصل و آب‌وهوا |
| 84 | Listen to Me! | فعل + حرف اضافهٔ ثابت |
| 85 | A Week of Small Things | مرور ۱۲ |
| 86 | At the Train Station | پرسش مدت زمان با take |
| 87 | A Cup of Tea | a، an و the |
| 88 | What Does She Look Like? | توصیف ظاهر با look like |
| 89 | I Feel Tired Today | feel + صفت و bored/boring |
| 90 | Let's Check Everything | مرور ۱۳ |
| 91 | These Shoes Are Nice | this/that/these/those |
| 92 | It Sounds Good | فعل‌های حسی + صفت |
| 93 | Someone Is at the Door | somebody/anybody/nobody/everybody |
| 94 | Can I Speak to Sara? | درخواست مؤدبانه روی تلفن |
| 95 | Look at the Detail | مرور ۱۴ |
| 96 | A New Job | What do you do? + work as |
| 97 | In the Kitchen | واژه‌های ترتیب در دستور کار |
| 98 | My Favourite Animal | like … better/best |
| 99 | A Letter to a Friend | want to / need to + مصدر |
| 100 | A Year of Small Steps | مرور پایانی (دورهٔ مقدماتی) |

---

## جمع‌بندی پایانی اجرا · L021 → L100
- **کل تولیدشده در این اجرا:** ۸۰ درس (چهار دستهٔ ۲۰تایی) · همه با قالب قفل‌شدهٔ L001–L020
- **نردبان اعتبارسنجی:** ۴۴٬۵۶۶ → ۰ خطا · ۶۷٬۳۱۲ → ۰ خطا · ۹۰٬۴۷۶ → ۰ خطا · ۱۱۳٬۶۹۸ → ۰ خطا
- **پایگاه دادهٔ زنده:** ۱۰۰ درس از L001 تا L100 · همه با وضعیت `validated` · ۱۲ بخش · واژگان ۱۲ · آزمون ۵ · ۰ تکرار · ۰ منتشرشده · ۵ ردیف در `content_batches`
- **رایگان:** فقط درس‌های ۱ و ۲ (تصمیم اشتراک بیرون از Content Factory)
- **لایهٔ فارسی:** هر درس ۶ کلیپ توضیح فارسی (طرح) + واژگان و معنی‌های فارسی؛ متن ↔ صدا هم‌خوان
- **صدا (حالت سریع):** برای L021–L100 فقط نقش/مانیفست/متن ساخته شد؛ فایل واقعی ساخته نشد و ۱۰ فایل موجود L001/L002/L010/L020 دست‌نخورده ماند (`plans-meta.json` = ۱۰۰ ردیف)
- **قالب:** دست‌نخورده — بدون تغییر ساختار درس، رجیستری صدا، لحن، ترتیب سطح و ساختار آزمون؛ بدون تغییر معماری/DB
- **وضعیت:** اجرا کامل شد. L101 شروع نشده (طبق دستور)


### درس‌های دستهٔ ۴
| # | عنوان | گرامر جدید |
|---|---|---|
| 61 | Back to Yesterday | حال کامل در برابر گذشتهٔ ساده |
| 62 | It Was Raining | گذشتهٔ استمراری |
| 63 | While We Were Waiting | ترکیب when/while |
| 64 | I Used to Live Here | used to |
| 65 | A Long Story | مرور ۹ |
| 66 | Will or Going to? | تفاوت will و going to |
| 67 | I Would Like a Coffee | درخواست مؤدبانه would like |
| 68 | I Had to Work | had to |
| 69 | He Works Harder Than Me | قیدهای مقایسه‌ای |
| 70 | The Best Worker | مرور ۱۰ |
| 71 | So Do I | توافق کوتاه |
| 72 | Good at Sports | صفت + حرف اضافه |
| 73 | One More Time, Please | درخواست تکرار و توضیح |
| 74 | The Blue One | one / ones |
| 75 | A Busy Working Day | مرور ۱۱ |
| 76 | How Much Does It Cost? | پرسیدن قیمت |
| 77 | Before and After Work | before / after |
| 78 | Would You Like to Come? | دعوت کردن و پاسخ |
| 79 | You Should See a Doctor | سلامت و توصیه |
| 80 | A Year to Remember | مرور پایانی دستهٔ ۴ |

- **Next:** Batch 5 (L081 → L100) — انجام شد

### درس‌های دستهٔ ۳
| # | عنوان | گرامر جدید |
|---|---|---|
| 41 | See You Tomorrow | حال استمراری برای قرار آینده |
| 42 | It Will Be Great | will / won't (پیش‌بینی و تصمیم) |
| 43 | Why Did You Go? | قید هدف با to |
| 44 | How Do You Do It? | قیدهای حالت |
| 45 | Too Small and Not Warm Enough | too و enough |
| 46 | Have You Ever Been There? | حال کامل با ever/never |
| 47 | I Have Just Finished | just / yet / already |
| 48 | As Good as That One | مقایسهٔ تساوی as … as |
| 49 | The Man Who Helps Us | جمله‌های موصولی who/which/that |
| 50 | Everything Is Ready | مرور ۷ |
| 51 | Because It Was Late | because و so |
| 52 | If It Rains | شرط نوع اول |
| 53 | Maybe It Will Snow | may / might |
| 54 | Such a Long Day | so و such |
| 55 | One Busy Week | مرور ۸ |
| 56 | But It Was Cheap | but و although |
| 57 | For Two Years | for و since |
| 58 | Nice Weather, Isn't It? | پرسش‌های کوتاه پایان جمله |
| 59 | The Place Where We Met | where و when |
| 60 | The Big Day | مرور پایانی دستهٔ ۳ |


### درس‌های دستهٔ ۲
| # | عنوان | گرامر جدید |
|---|---|---|
| 21 | Last Weekend | گذشتهٔ فعل‌های بی‌قاعده (۶ فعل) |
| 22 | Did You Have a Good Trip? | پرسش و منفی گذشته با did/didn't |
| 23 | A Busy Week | مرور ۴ (گذشته) |
| 24 | Which One Is Better? | صفت مقایسه‌ای |
| 25 | The Best in Town | صفت برترین |
| 26 | Dinner at Home | شمردنی/ناشمردنی + some/any |
| 27 | How Much Do We Need? | how much / how many + مقدارها |
| 28 | My Habits | قیدهای تکرار |
| 29 | Call Me Tonight | ضمیرهای مفعولی |
| 30 | A Good Story | مرور ۵ |
| 31 | Rules at Work | must / mustn't |
| 32 | You Should Rest | should / shouldn't |
| 33 | What Do We Have to Bring? | have to / don't have to |
| 34 | Where Is My Phone? | حروف اضافهٔ مکان (گروه ۲) |
| 35 | Lost and Found Day | مرور ۶ |
| 36 | Birthdays and Dates | حروف اضافهٔ زمان in/on/at |
| 37 | Let's Make a Plan | ساخت‌های پیشنهاد |
| 38 | Whose Is This? | ضمیرهای ملکی + Whose |
| 39 | The Old Neighborhood | there was / there were |
| 40 | My Best Day | مرور پایانی دستهٔ ۲ |

**ابزارهای افزوده‌شده در این دسته (تغییر معماری نیست، فقط ابزار تولید):**
- `content/tools/build_lessons.mjs` — مشخصات فشرده → فایل درس کامل طبق قالب قفل‌شده (با هشدار زودهنگام طول متن‌ها) + ادغام لایهٔ صوتی فارسی در `plans-meta.json`
- `content/tools/build_import_sql.mjs` — ساخت SQL واردسازی idempotent برای هر بازه (UPDATE-first + ردیف دسته)
