# LINGU · Voice Registry (رجیستری گوینده‌ها)

> منبع حقیقت ماشینی: `content/audio/voices.json` (session: `2026-09-30`) — این سند نسخهٔ خوانا و کامل‌شدهٔ همان فایل است.
> منبع دوم: `docs/CONTENT-FACTORY-MASTER-PROMPT-FA.md` §۶.۲ (هم‌خوان با voices.json؛ voices.json دو نقش `EN-READ-M` / `EN-READ-F` را دقیق‌تر کرده است).
> این سند در Task «نجات و بسته‌بندی» (2026-10-02) فقط **استخراج** شد. **هیچ Voice جدیدی انتخاب نشد.**

## ⚠️ هشدار حیاتی — شناسه‌ها Session-bound هستند

شناسه‌های `voice-00 … voice-05` شمارهٔ ثبت‌شده **در همان چتِ 2026-09-30** هستند و **به چت جدید منتقل نمی‌شوند**.
در چت جدید این جدول فقط «نقشهٔ نقش‌ها» است. قبل از تولید هر صدای واقعی باید هر نقش دوباره با ابزار `add_voice` ثبت شود
و شناسهٔ **برگشتیِ همان چت** در `voices.json` نوشته شود. هیچ شناسه‌ای حدس زده نمی‌شود.

## جدول نقش‌ها

| نقش (Role) | زبان | شخصیت / کاربرد | جنسیت · use_case | Current ID (فقط session 2026-09-30) | کلیپ‌های برنامه‌ریزی‌شده در ۳۲۶ مانیفست | نمونهٔ واقعی موجود |
|---|---|---|---|---|---|---|
| `FA-COACH` | fa | مربی/راوی فارسی — توضیح فارسی داخل درس (warmup، explanation، grammar-note، listening-intro، speaking، closing) | masculine · conversational | `voice-02` | 1,958 | `generated/L001/L001-fa-warmup.mp3`, `generated/L002/L002-fa-warmup.mp3`, `samples/L001/L001-fa-warmup.mp3`, `samples/L001/L001-fa-listening-intro.mp3`, `samples/L002/L002-fa-warmup.mp3` |
| `FA-NARRATOR-F` | fa | راوی فارسی (زن) — **رزرو** | feminine · narration | `voice-01` | 0 | ندارد (فقط احتمالاً بین دموهای `voice-tests/`؛ شناسهٔ سازندهٔ دموها ثبت نشده) |
| `FA-NARRATOR-M` | fa | راوی فارسی (مرد) — **رزرو** | masculine · narration | `voice-00` | 0 | ندارد (همان توضیح) |
| `EN-CHAR-A` | en | شخصیت A دیالوگ (مرد) + راوی شنیداریِ مرد | masculine · characters | `voice-03` | 2,165 | `generated/L001/L001-en-dialogue-1.mp3`, `…-dialogue-3.mp3`, `generated/L002/L002-en-dialogue-1.mp3`, `generated/L020/L020-en-dialogue-1.mp3`, `samples/L001/L001-en-dialogue-1.mp3`, `samples/L002/L002-en-dialogue-1.mp3` |
| `EN-CHAR-B` | en | شخصیت B دیالوگ (زن) + راوی شنیداریِ زن | feminine · characters | `voice-05` | 1,988 | `generated/L001/L001-en-dialogue-2.mp3`, `generated/L002/L002-en-dialogue-2.mp3`, `samples/L001/L001-en-dialogue-2.mp3`, `samples/L002/L002-en-dialogue-2.mp3` |
| `EN-VOCAB` | en | واژه‌ها، مثال‌ها، جمله‌های جدول گرامر | feminine · educational | `voice-04` | 6,159 | `generated/L001/L001-en-vocab-hello.mp3`, `samples/L001/L001-en-vocab-hello.mp3`, `samples/L002/L002-en-vocab-mother.mp3` |
| `EN-READ-M` | en | روایت متن reading — راوی مرد (هم‌صدا با EN-CHAR-A) | masculine · narration | `voice-03` | 115 | ندارد |
| `EN-READ-F` | en | روایت متن reading — راوی زن (هم‌صدا با EN-VOCAB) | feminine · narration | `voice-04` | 381 | `generated/L010/L010-en-listening-1.mp3`, `samples/L002/L002-en-reading.mp3` |

مسیرها نسبت به `content/audio/` هستند. دموهای مرحلهٔ آزمون صدا در ریشهٔ Workspace: `voice-tests/DEMO-1-fa-intro.mp3`,
`DEMO-2-fa-vocab-note.mp3`, `DEMO-3-en-vocab.mp3`, `DEMO-4-en-dialogue-A.mp3`, `DEMO-5-en-dialogue-B.mp3` (نقش از روی نام فایل؛ شناسهٔ صدا داخل فایل ثبت نشده).

## Metadata موجود

- `content/audio/voices.json` → `registry{role → voice_id, language, gender, use_case, role}` + `casting_rules`.
- `content/audio/L###.plan.json` → هر کلیپ: `id, role, source, tts_text, priority, language, chars, sample?, file?` و `voice_registry_ref = content/audio/voices.json`.
- `content/audio/plans-meta.json` → برای هر درس: `reading_role`، `listening_roles` (نگاشت گویندهٔ متن → نقش) و فهرست نمونه‌ها.
- `content/audio/registry.json` → کلیپ‌های **آپلودشده**: `file, hash, bytes, path (<lang>/<hash8>.mp3), uploaded, public_url, verified_at` — باکت `lesson-audio`.

## Where Used (زنجیرهٔ مصرف)

1. `content/tools/build_plans.mjs` — نقش هر خط را از `voices.json` / `plans-meta.json` می‌گیرد و مانیفست می‌سازد.
2. تولید TTS (بیرون از ریپو، با ابزار گفتار چت) — فایل در `content/audio/generated/<Lxxx>/<clip-id>.mp3`.
3. `content/tools/upload_audio.mjs` — آپلود به باکت `lesson-audio/<lang>/<hash8>.mp3` و نوشتن `registry.json`.
4. `content/tools/build_audio_refs.mjs` — نوشتن ارجاع در `content.audio[section][]` خود درس (با `role`).
5. `web/src/pages/app/LessonDetail.tsx` — پلیر واقعی صفحهٔ درس. QA: `qa/audio_qa.mjs`.

## قواعد Casting (از voices.json — قطعی)

- اول‌شخصِ مرد → `EN-READ-M` · اول‌شخصِ زن → `EN-READ-F` (صدای راوی با جنسیت گویندهٔ متن هم‌خوان باشد).
- یک کلیپ = یک زبان؛ صدای فارسی فقط متن فارسی و صدای انگلیسی فقط متن انگلیسی.
- شناسه‌ها در کل Batch ثابت می‌مانند؛ هیچ درسی بی‌دلیل صدا عوض نمی‌کند.

## روش ثبت دوباره (Re-registration) در چت جدید

1. برای هر نقش **فعال** (`FA-COACH`, `EN-CHAR-A`, `EN-CHAR-B`, `EN-VOCAB`؛ و در صورت نیاز `EN-READ-M/F` که فعلاً هم‌صدای A و VOCAB هستند)
   یک `add_voice` با همان `language` و `voice_identity` (gender + use_case جدول بالا) اجرا کن.
2. متن آزمون: «پیوست الف» در `docs/CONTENT-FACTORY-MASTER-PROMPT-FA.md` (یا یک خط واقعی از همان نقش در `L001.plan.json`).
3. مقایسه با نمونهٔ واقعی همان نقش (ستون «نمونهٔ واقعی موجود») تا صدای جدید به صدای قبلی نزدیک باشد.
4. شناسهٔ برگشتی را در `content/audio/voices.json` → `registry.<ROLE>.voice_id` بنویس و `session` را به تاریخ همان روز تغییر بده.
5. French/Spanish هنوز **هیچ نقش صوتی ثبت‌شده‌ای ندارند**. پیشنهاد (تصمیم نهایی با مالک): نقش‌های هم‌الگو مثل `FR-CHAR-A`, `FR-CHAR-B`, `FR-VOCAB`, `ES-CHAR-A`, … با همین روش ثبت و به `voices.json` اضافه شوند؛ و `FA-COACH` برای لایهٔ توضیح فارسی هر سه زبان مشترک بماند تا صدای مربی در کل محصول یکی باشد.
