-- ============================================================
-- LINGU · 0002 · Core: profiles, settings, theme, languages,
--                 plans, subscriptions, purchases
-- ============================================================

create table if not exists public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  display_name  text,
  avatar_url    text,
  role          app_role not null default 'user',
  is_active     boolean not null default true,
  tour_done     boolean not null default false,
  locale        text not null default 'fa',
  last_seen_at  timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
drop trigger if exists trg_profiles_touch on public.profiles;
create trigger trg_profiles_touch before update on public.profiles for each row execute function public.touch_updated_at();

-- ---------- key/value app settings (banners flag, general copy, limits) ----------
create table if not exists public.app_settings (
  key         text primary key,
  value       jsonb not null default '{}'::jsonb,
  description text,
  updated_at  timestamptz not null default now()
);
drop trigger if exists trg_app_settings_touch on public.app_settings;
create trigger trg_app_settings_touch before update on public.app_settings for each row execute function public.touch_updated_at();

-- ---------- theme (single row, applied at runtime => no redeploy) ----------
create table if not exists public.theme_settings (
  id           int primary key default 1 check (id = 1),
  mode         text not null default 'dark',
  -- `primary` is a reserved word in PostgreSQL → always quoted. The API/JSON key stays "primary".
  "primary"    text not null default '#7C6CFF',
  secondary    text not null default '#5B8CFF',
  accent       text not null default '#22D3EE',
  background   text not null default '#0A0B14',
  background_soft text not null default '#101223',
  card         text not null default '#151731',
  card_soft    text not null default '#1B1E3D',
  text         text not null default '#F4F5FF',
  text_muted   text not null default '#A7ACD4',
  line         text not null default '#282C52',
  radius       int  not null default 20,
  updated_at   timestamptz not null default now()
);
create or replace function public.theme_public() returns jsonb
language sql stable security definer set search_path = public as $$
  select to_jsonb(t) - 'updated_at' from theme_settings t where t.id = 1;
$$;

-- ---------- languages ----------
create table if not exists public.languages (
  code        text primary key,              -- en | fr | es
  name_fa     text not null,
  name_en     text not null,
  native_name text not null,
  flag        text not null default '🌍',
  gradient    text not null default 'from-indigo-500 to-cyan-400',
  description text,
  target_lessons int not null default 340,
  is_active   boolean not null default true,
  sort_order  int not null default 0,
  created_at  timestamptz not null default now()
);

-- ---------- plans (SKU duration lives in the DB, not in the app) ----------
create table if not exists public.plans (
  id             uuid primary key default gen_random_uuid(),
  code           text unique not null,              -- free | monthly | quarterly | yearly
  title_fa       text not null,
  subtitle_fa    text,
  description_fa text,
  sku            text,                              -- Myket product SKU (null for Free)
  duration_days  int not null default 0,
  display_price  bigint not null default 0,         -- Rial, display only
  price_label    text,                              -- optional override label
  badge          text,
  features       jsonb not null default '[]'::jsonb,
  is_active      boolean not null default true,
  is_recommended boolean not null default false,
  sort_order     int not null default 0,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
drop trigger if exists trg_plans_touch on public.plans;
create trigger trg_plans_touch before update on public.plans for each row execute function public.touch_updated_at();

-- ---------- subscriptions ----------
create table if not exists public.subscriptions (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references auth.users(id) on delete cascade,
  plan_id        uuid references public.plans(id) on delete set null,
  sku            text not null,
  status         subscription_status not null default 'pending',
  start_date     timestamptz not null default now(),
  end_date       timestamptz not null,
  purchase_token text,
  provider       text not null default 'myket',
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists idx_subscriptions_user on public.subscriptions(user_id, end_date desc);
drop trigger if exists trg_subscriptions_touch on public.subscriptions;
create trigger trg_subscriptions_touch before update on public.subscriptions for each row execute function public.touch_updated_at();

-- ---------- purchases (raw verification trail) ----------
create table if not exists public.purchases (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references auth.users(id) on delete cascade,
  sku            text not null,
  purchase_token text not null,
  order_id       text,
  status         text not null default 'pending',
  provider       text not null default 'myket',
  raw            jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  verified_at    timestamptz
);
create unique index if not exists uq_purchases_token on public.purchases(purchase_token);

-- ---------- myket product catalog (admin editable, real SKUs) ----------
create table if not exists public.myket_products (
  id           uuid primary key default gen_random_uuid(),
  sku          text unique not null,
  title_fa     text not null,
  duration_days int not null,
  price_rial   bigint,
  is_active    boolean not null default true,
  sort_order   int not null default 0,
  created_at   timestamptz not null default now()
);
