-- ============================================================
-- LINGU · 0001 · Foundation: enums, helpers, triggers
-- ============================================================
create extension if not exists "pgcrypto";
create extension if not exists "citext";

-- ---------- enums ----------
do $$ begin create type app_role as enum ('user','admin'); exception when duplicate_object then null; end $$;
do $$ begin create type lesson_status as enum ('draft','generated','validated','published','failed'); exception when duplicate_object then null; end $$;
do $$ begin create type plan_status as enum ('planned','generating','generated','failed'); exception when duplicate_object then null; end $$;
do $$ begin create type subscription_status as enum ('pending','active','expired','cancelled','refunded'); exception when duplicate_object then null; end $$;
do $$ begin create type progress_status as enum ('started','completed'); exception when duplicate_object then null; end $$;
do $$ begin create type ai_feature as enum ('tutor','partner'); exception when duplicate_object then null; end $$;
do $$ begin create type msg_role as enum ('user','assistant','system'); exception when duplicate_object then null; end $$;
do $$ begin create type batch_status as enum ('idle','planning','generating','validating','completed','failed','cancelled'); exception when duplicate_object then null; end $$;

-- ---------- updated_at helper ----------
create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ---------- premium check (single source of truth) ----------
-- NOTE: plpgsql (not sql) on purpose — a plain SQL body is validated at CREATE time,
-- and `subscriptions` is created a step later in 0002. plpgsql resolves at first call.
create or replace function public.has_active_premium(uid uuid)
returns boolean
language plpgsql stable security definer set search_path = public as $$
begin
  return exists (
    select 1 from subscriptions s
    where s.user_id = uid and s.status = 'active' and s.end_date > now()
  );
end $$;

-- ---------- admin check (SECURITY DEFINER => no RLS recursion) ----------
create or replace function public.is_admin()
returns boolean
language plpgsql stable security definer set search_path = public as $$
begin
  return exists (
    select 1 from profiles p
    where p.id = auth.uid() and p.role = 'admin' and p.is_active = true
  );
end $$;

-- ---------- first user becomes admin (bootstrap), rest are normal users ----------
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_is_first boolean;
begin
  select not exists (select 1 from profiles) into v_is_first;

  insert into profiles (id, display_name, role, is_active)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)),
    case when v_is_first then 'admin'::app_role else 'user'::app_role end,
    true
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- de-duplication helper for lessons ----------
create or replace function public.lesson_fingerprint(p_language text, p_level text, p_title text)
returns text language sql immutable as $$
  select md5(lower(regexp_replace(coalesce(p_language,'') || '|' || coalesce(p_level,'') || '|' || coalesce(p_title,''), '\s+', '', 'g')));
$$;
