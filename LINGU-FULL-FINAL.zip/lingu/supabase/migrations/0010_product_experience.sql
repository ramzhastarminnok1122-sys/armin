-- ============================================================
-- LINGU · 0010 · Product Experience
--   · onboarding (language + goal) and preferences on profiles
--   · media_assets: every visual asset is DB-driven (admin > Media Library)
--   · notifications: real event-driven notification center
--   · promotional pricing fields on plans
--   · in-app search RPC
-- ============================================================

-- ---------- profiles: onboarding + preferences ----------
alter table public.profiles add column if not exists goal text;
alter table public.profiles add column if not exists target_language text;
alter table public.profiles add column if not exists onboarding_done boolean not null default false;
alter table public.profiles add column if not exists reduce_motion boolean not null default false;
alter table public.profiles add column if not exists preferred_level text default 'A1';

create or replace function public.guard_profile_columns() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() then return new; end if;
  if new.role is distinct from old.role then
    raise exception 'forbidden: role change requires admin' using errcode = '42501';
  end if;
  if new.is_active is distinct from old.is_active then
    raise exception 'forbidden: account status change requires admin' using errcode = '42501';
  end if;
  return new;
end $$;

-- ---------- media assets (visual asset system) ----------
create table if not exists public.media_assets (
  id           uuid primary key default gen_random_uuid(),
  slot         text unique not null,          -- hero_background | ai_tutor | premium | lang_en ...
  name         text not null,
  category     text not null default 'general',
  url          text not null,                 -- public path or storage URL
  storage_path text,
  alt_fa       text,
  used_in      text[] not null default '{}',  -- e.g. {public_home, dashboard}
  is_active    boolean not null default true,
  sort_order   int not null default 0,
  updated_by   uuid references auth.users(id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
drop trigger if exists trg_media_touch on public.media_assets;
create trigger trg_media_touch before update on public.media_assets for each row execute function public.touch_updated_at();

-- ---------- notifications ----------
do $$ begin
  create type notification_kind as enum ('lesson_completed','new_lesson','premium_activated','quota_warning','system');
exception when duplicate_object then null; end $$;

create table if not exists public.notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  kind       notification_kind not null default 'system',
  title      text not null,
  body       text,
  url        text,
  read_at    timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists idx_notifications_user on public.notifications(user_id, created_at desc);

create or replace function public.notify(
  p_user uuid, p_kind notification_kind, p_title text, p_body text default null, p_url text default null
) returns void language sql security definer set search_path = public as $$
  insert into notifications (user_id, kind, title, body, url) values (p_user, p_kind, p_title, p_body, p_url);
$$;

-- real event: lesson completed -> notification (+ quota warning is produced by the AI function)
create or replace function public.on_lesson_completed() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_title text; v_lang text;
begin
  if new.status = 'completed' and (old.status is distinct from 'completed') then
    select title, language_code into v_title, v_lang from lessons where id = new.lesson_id;
    perform public.notify(new.user_id, 'lesson_completed', 'درس تمام شد: ' || coalesce(v_title, 'درس LINGU'),
      'پیشرفتت ذخیره شد. برای تثبیت، یک دور سریع با AI Tutor بزن.', '/app/progress');
  end if;
  return new;
end $$;
drop trigger if exists trg_notify_lesson on public.user_progress;
create trigger trg_notify_lesson after update on public.user_progress
  for each row execute function public.on_lesson_completed();

-- real event: premium activated -> notification
create or replace function public.on_subscription_activated() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'active' and (tg_op = 'INSERT' or old.status is distinct from 'active') then
    perform public.notify(new.user_id, 'premium_activated', 'اشتراک Premium فعال شد',
      'همه درس‌ها، AI Tutor و Conversation Partner بدون محدودیت در دسترس تو هستند.', '/app/subscription');
  end if;
  return new;
end $$;
drop trigger if exists trg_notify_subscription on public.subscriptions;
create trigger trg_notify_subscription after insert or update on public.subscriptions
  for each row execute function public.on_subscription_activated();

-- admin broadcast (used when a batch is published)
create or replace function public.notify_all_users(p_title text, p_body text default null, p_url text default null)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = '42501'; end if;
  insert into notifications (user_id, kind, title, body, url)
  select id, 'new_lesson', p_title, p_body, p_url from profiles where is_active;
  get diagnostics n = row_count;
  return n;
end $$;

-- ---------- plans: original / promotional pricing (display only) ----------
alter table public.plans add column if not exists original_price bigint not null default 0;
alter table public.plans add column if not exists promo_price bigint;
alter table public.plans add column if not exists promo_label text;
alter table public.plans add column if not exists promo_active boolean not null default false;
alter table public.plans add column if not exists promo_ends_at timestamptz;
alter table public.plans add column if not exists show_on_marketing boolean not null default false;

-- ---------- marketing settings + hero copy (admin editable, no redeploy) ----------
insert into public.app_settings (key, value, description) values
 ('marketing', $j${"hero_title":"زبان را فقط نخوان؛ واقعاً یاد بگیر.","hero_subtitle":"درس‌های کامل، AI Tutor و Conversation Partner در سه زبان — با تجربه‌ای که شبیه یک اپلیکیشن واقعی است، نه یک وب‌سایت.","hero_cta":"شروع رایگان","hero_cta_logged_in":"ادامه یادگیری","hero_secondary":"دیدن امکانات","show_pricing":false,"show_testimonials":true}$j$::jsonb, 'محتوای صفحه اصلی سایت'),
 ('onboarding', $j${"goals":[{"id":"travel","label_fa":"سفر"},{"id":"work","label_fa":"کار و حرفه"},{"id":"study","label_fa":"تحصیل"},{"id":"personal","label_fa":"علاقه شخصی"}]}$j$::jsonb, 'گزینه‌های Onboarding')
on conflict (key) do nothing;

-- ---------- in-app global search (real data only) ----------
create or replace function public.app_search(p_query text)
returns table (
  kind text, id uuid, title text, subtitle text, language_code text, level text,
  is_free boolean, locked boolean, url text
) language sql stable security definer set search_path = public as $$
  select 'lesson'::text, l.id, l.title, coalesce(l.subtitle, l.description),
         l.language_code, l.level, l.is_free,
         not (l.is_free or public.has_active_premium(auth.uid()) or public.is_admin()) as locked,
         '/app/lessons/' || l.id::text
  from lessons l
  where l.status = 'published'
    and (
      p_query is null or p_query = ''
      or l.title ilike '%' || p_query || '%'
      or coalesce(l.subtitle,'') ilike '%' || p_query || '%'
      or coalesce(l.description,'') ilike '%' || p_query || '%'
      or l.language_code ilike '%' || p_query || '%'
      or l.level ilike '%' || p_query || '%'
    )
  order by l.language_code, l.order_index
  limit 12;
$$;
grant execute on function public.app_search(text) to authenticated, anon;

-- ---------- dashboard: add conversation/AI detail without inventing numbers ----------
create or replace function public.admin_dashboard()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = '42501'; end if;
  return jsonb_build_object(
    'users_total',        (select count(*) from profiles),
    'users_active_7d',    (select count(*) from profiles where coalesce(last_seen_at, created_at) > now() - interval '7 days'),
    'users_new_7d',       (select count(*) from profiles where created_at > now() - interval '7 days'),
    'premium_users',      (select count(*) from subscriptions where status='active' and end_date > now()),
    'lessons_total',      (select count(*) from lessons),
    'lessons_published',  (select count(*) from lessons where status='published'),
    'lessons_draft',      (select count(*) from lessons where status in ('draft','generated','validated')),
    'lessons_failed',     (select count(*) from lessons where status='failed'),
    'plans_failed',       (select count(*) from lesson_plans where status='failed'),
    'ai_calls_24h',       (select count(*) from ai_usage where created_at > now() - interval '1 day'),
    'ai_tokens_24h',      (select coalesce(sum(prompt_tokens + completion_tokens),0) from ai_usage where created_at > now() - interval '1 day'),
    'ai_calls_total',     (select count(*) from ai_usage),
    'ai_errors_24h',      (select count(*) from ai_usage where ok = false and created_at > now() - interval '1 day'),
    'tutor_calls_24h',    (select count(*) from ai_usage where feature='tutor' and created_at > now() - interval '1 day'),
    'partner_calls_24h',  (select count(*) from ai_usage where feature='partner' and created_at > now() - interval '1 day'),
    'conversations_total',(select count(*) from conversations),
    'messages_total',     (select count(*) from messages),
    'partner_messages_24h',(select count(*) from messages m join conversations c on c.id=m.conversation_id
                            where c.mode='partner' and m.role='user' and m.created_at > now() - interval '1 day'),
    'active_subs',        (select count(*) from subscriptions where status='active' and end_date > now()),
    'recent_users',       coalesce((
      select jsonb_agg(x) from (
        select p.id, p.display_name, p.role, p.created_at,
               (select exists(select 1 from subscriptions s where s.user_id = p.id and s.status='active' and s.end_date > now())) as premium
        from profiles p order by p.created_at desc limit 6
      ) x), '[]'::jsonb),
    'lessons_by_language', coalesce((
      select jsonb_object_agg(language_code, c) from (
        select language_code, count(*) c from lessons group by language_code
      ) y), '{}'::jsonb),
    'signups_14d', coalesce((
      select jsonb_agg(jsonb_build_object('day', d::date, 'count', coalesce(cnt,0)) order by d)
      from generate_series(now()::date - interval '13 days', now()::date, interval '1 day') d
      left join (
        select created_at::date dd, count(*) cnt from profiles
        where created_at > now() - interval '14 days' group by 1
      ) z on z.dd = d::date
    ), '[]'::jsonb)
  );
end $$;

-- ---------- support inbox (real messages only; no fake contact forms) ----------
create table if not exists public.support_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  email text,
  subject text,
  body text not null,
  status text not null default 'open' check (status in ('open','answered','closed')),
  created_at timestamptz not null default now()
);
create index if not exists idx_support_created on public.support_messages(created_at desc);

alter table public.support_messages enable row level security;

drop policy if exists sm_insert_own on public.support_messages;
create policy sm_insert_own on public.support_messages for insert to authenticated
  with check (user_id = auth.uid());

drop policy if exists sm_select on public.support_messages;
create policy sm_select on public.support_messages for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

drop policy if exists sm_admin_update on public.support_messages;
create policy sm_admin_update on public.support_messages for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---------- semantic colors + light lavender identity (admin-editable, applied live) ----------
alter table public.theme_settings add column if not exists success text not null default '#16A34A';
alter table public.theme_settings add column if not exists warning text not null default '#D97706';
alter table public.theme_settings add column if not exists danger  text not null default '#E11D48';
alter table public.theme_settings add column if not exists hero_overlay numeric(3,2) not null default 0.55;

-- The phase default identity: white + light lavender + violet, premium and calm.
update public.theme_settings set
  mode = 'light',
  "primary" = '#6D5BFF', secondary = '#8B5CF6', accent = '#0EA5C6',
  background = '#FAF9FF', background_soft = '#F3F0FF',
  card = '#FFFFFF', card_soft = '#F6F3FF',
  text = '#191436', text_muted = '#5B5688', line = '#E7E2F8',
  success = '#15803D', warning = '#B45309', danger = '#DC2626',
  radius = 22
where id = 1 and mode = 'dark';   -- only rewrites an untouched default row

-- ---------- default media slots (bundled artwork; every slot is admin-replaceable) ----------
insert into public.media_assets (slot, name, category, url, alt_fa, used_in, sort_order) values
 ('hero_background','پس‌زمینه هیرو (دسکتاپ)','hero','/art/hero-aurora.webp','پس‌زمینه بنفش مایل به سفید','{public_home}',1),
 ('hero_background_mobile','پس‌زمینه هیرو (موبایل)','hero','/art/hero-aurora-sm.webp','نسخه سبک پس‌زمینه هیرو','{public_home}',2),
 ('ai_tutor','تصویر AI Tutor','ai','/art/ai-tutor.webp','مربی هوشمند LINGU','{public_home,dashboard}',3),
 ('conversation','تصویر Conversation Partner','ai','/art/conversation.webp','گفت‌وگوی نقش‌محور','{public_home,dashboard,conversation}',4),
 ('premium','تصویر Premium','premium','/art/premium.webp','اشتراک ویژه LINGU','{public_home,subscription,dashboard}',5),
 ('onboarding','تصویر خوش‌آمدگویی','onboarding','/art/onboarding.webp','مسیر یادگیری','{onboarding}',6),
 ('lang_en','تصویر زبان انگلیسی','languages','/art/lang-en.webp','نماد بصری دوره انگلیسی','{public_home,dashboard}',7),
 ('lang_fr','تصویر زبان فرانسه','languages','/art/lang-fr.webp','نماد بصری دوره فرانسه','{public_home,dashboard}',8),
 ('lang_es','تصویر زبان اسپانیایی','languages','/art/lang-es.webp','نماد بصری دوره اسپانیایی','{public_home,dashboard}',9),
 ('scenario_cafe','تصویر کافه / رستوران / خرید','scenarios','/art/scenario-cafe.webp','موقعیت کافه','{conversation}',10),
 ('scenario_travel','تصویر سفر / فرودگاه','scenarios','/art/scenario-travel.webp','موقعیت سفر و فرودگاه','{conversation}',11),
 ('scenario_job','تصویر مصاحبه کاری','scenarios','/art/conversation.webp','موقعیت کاری','{conversation}',12),
 ('scenario_school','تصویر مدرسه و دانشگاه','scenarios','/art/conversation.webp','موقعیت آموزشی','{conversation}',13)
on conflict (slot) do nothing;

-- ---------- avatar storage (each user writes only inside their own folder) ----------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars','avatars', true, 2097152, array['image/png','image/jpeg','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 2097152;

drop policy if exists avatars_public_read on storage.objects;
create policy avatars_public_read on storage.objects for select
  using (bucket_id = 'avatars');

drop policy if exists avatars_own_write on storage.objects;
create policy avatars_own_write on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists avatars_own_update on storage.objects;
create policy avatars_own_update on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists avatars_own_delete on storage.objects;
create policy avatars_own_delete on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
