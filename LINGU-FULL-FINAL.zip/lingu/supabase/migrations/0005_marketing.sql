-- ============================================================
-- LINGU · 0005 · Public content: FAQ, Testimonials, Banners, Audit log
-- ============================================================

create table if not exists public.faqs (
  id          uuid primary key default gen_random_uuid(),
  question    text not null,
  answer      text not null,
  category    text not null default 'general',
  is_published boolean not null default true,
  sort_order  int not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
drop trigger if exists trg_faqs_touch on public.faqs;
create trigger trg_faqs_touch before update on public.faqs for each row execute function public.touch_updated_at();

create table if not exists public.testimonials (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  role        text,
  quote       text not null,
  avatar_url  text,
  rating      int not null default 5 check (rating between 1 and 5),
  is_published boolean not null default true,
  sort_order  int not null default 0,
  created_at  timestamptz not null default now()
);

create table if not exists public.banners (
  id          uuid primary key default gen_random_uuid(),
  title       text not null,
  body        text,
  cta_label   text,
  cta_url     text,
  image_url   text,
  tone        text not null default 'primary',
  placement   text not null default 'user_home',
  is_active   boolean not null default true,
  starts_at   timestamptz,
  ends_at     timestamptz,
  sort_order  int not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
drop trigger if exists trg_banners_touch on public.banners;
create trigger trg_banners_touch before update on public.banners for each row execute function public.touch_updated_at();

create table if not exists public.audit_log (
  id          bigserial primary key,
  actor_id    uuid references auth.users(id) on delete set null,
  action      text not null,
  entity      text,
  entity_id   text,
  meta        jsonb not null default '{}'::jsonb,
  created_at  timestamptz not null default now()
);
create index if not exists idx_audit_created on public.audit_log(created_at desc);

-- ---------- admin dashboard counters (real numbers, one round-trip) ----------
create or replace function public.admin_dashboard()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = '42501'; end if;
  return jsonb_build_object(
    'users_total',        (select count(*) from profiles),
    'users_active_7d',    (select count(*) from profiles where coalesce(last_seen_at, created_at) > now() - interval '7 days'),
    'users_new_7d',       (select count(*) from profiles where created_at > now() - interval '7 days'),
    'premium_users',      (select count(*) from subscriptions where status='active' and end_date > now()),
    'lessons_total',      (select count(*) from lessons),
    'lessons_published',  (select count(*) from lessons where status='published'),
    'lessons_draft',      (select count(*) from lessons where status in ('draft','generated','validated')),
    'lessons_failed',     (select count(*) from lessons where status='failed'),
    'plans_failed',       (select count(*) from lesson_plans where status='failed'),
    'ai_calls_24h',       (select count(*) from ai_usage where created_at > now() - interval '1 day'),
    'ai_tokens_24h',      (select coalesce(sum(prompt_tokens + completion_tokens),0) from ai_usage where created_at > now() - interval '1 day'),
    'ai_calls_total',     (select count(*) from ai_usage),
    'ai_errors_24h',      (select count(*) from ai_usage where ok = false and created_at > now() - interval '1 day'),
    'active_subs',        (select count(*) from subscriptions where status='active' and end_date > now()),
    'recent_users',       coalesce((
      select jsonb_agg(x) from (
        select p.id, p.display_name, p.role, p.created_at,
               (select exists(select 1 from subscriptions s where s.user_id = p.id and s.status='active' and s.end_date > now())) as premium
        from profiles p order by p.created_at desc limit 6
      ) x), '[]'::jsonb),
    'lessons_by_language', coalesce((
      select jsonb_object_agg(language_code, c) from (
        select language_code, count(*) c from lessons group by language_code
      ) y), '{}'::jsonb),
    'signups_14d', coalesce((
      select jsonb_agg(jsonb_build_object('day', d::date, 'count', coalesce(cnt,0)) order by d)
      from generate_series(now()::date - interval '13 days', now()::date, interval '1 day') d
      left join (
        select created_at::date dd, count(*) cnt from profiles
        where created_at > now() - interval '14 days' group by 1
      ) z on z.dd = d::date
    ), '[]'::jsonb)
  );
end $$;
