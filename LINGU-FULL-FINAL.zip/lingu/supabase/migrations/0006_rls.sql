-- ============================================================
-- LINGU · 0006 · Row Level Security
-- Principle: clients may only read what they own; every write
-- that affects money, AI quota or role is server-side only.
-- ============================================================

alter table public.profiles        enable row level security;
alter table public.app_settings    enable row level security;
alter table public.theme_settings  enable row level security;
alter table public.languages       enable row level security;
alter table public.plans           enable row level security;
alter table public.subscriptions   enable row level security;
alter table public.purchases       enable row level security;
alter table public.myket_products  enable row level security;
alter table public.curricula       enable row level security;
alter table public.content_batches enable row level security;
alter table public.lesson_plans    enable row level security;
alter table public.lessons         enable row level security;
alter table public.user_progress   enable row level security;
alter table public.ai_settings     enable row level security;
alter table public.ai_secrets      enable row level security;
alter table public.ai_usage        enable row level security;
alter table public.conversations   enable row level security;
alter table public.messages        enable row level security;
alter table public.faqs            enable row level security;
alter table public.testimonials    enable row level security;
alter table public.banners         enable row level security;
alter table public.audit_log       enable row level security;

-- no client policy on ai_secrets at all => only service_role (edge functions) can touch it
revoke all on public.ai_secrets from anon, authenticated;

-- ---------- profiles ----------
drop policy if exists profiles_self_read on public.profiles;
create policy profiles_self_read on public.profiles for select using (id = auth.uid() or public.is_admin());
drop policy if exists profiles_self_update on public.profiles;
create policy profiles_self_update on public.profiles for update
  using (id = auth.uid() or public.is_admin())
  with check (id = auth.uid() or public.is_admin());

-- ---------- public reads ----------
drop policy if exists theme_public_read on public.theme_settings;
create policy theme_public_read on public.theme_settings for select using (true);
drop policy if exists theme_admin_write on public.theme_settings;
create policy theme_admin_write on public.theme_settings for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists settings_public_read on public.app_settings;
create policy settings_public_read on public.app_settings for select using (true);
drop policy if exists settings_admin_write on public.app_settings;
create policy settings_admin_write on public.app_settings for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists languages_public_read on public.languages;
create policy languages_public_read on public.languages for select using (is_active or public.is_admin());
drop policy if exists languages_admin_write on public.languages;
create policy languages_admin_write on public.languages for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists plans_public_read on public.plans;
create policy plans_public_read on public.plans for select using (is_active or public.is_admin());
drop policy if exists plans_admin_write on public.plans;
create policy plans_admin_write on public.plans for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists faqs_public_read on public.faqs;
create policy faqs_public_read on public.faqs for select using (is_published or public.is_admin());
drop policy if exists faqs_admin_write on public.faqs;
create policy faqs_admin_write on public.faqs for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists testi_public_read on public.testimonials;
create policy testi_public_read on public.testimonials for select using (is_published or public.is_admin());
drop policy if exists testi_admin_write on public.testimonials;
create policy testi_admin_write on public.testimonials for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists banners_public_read on public.banners;
create policy banners_public_read on public.banners for select using (
  public.is_admin() or (is_active and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at >= now()))
);
drop policy if exists banners_admin_write on public.banners;
create policy banners_admin_write on public.banners for all using (public.is_admin()) with check (public.is_admin());

-- ---------- lessons ----------
drop policy if exists lessons_read on public.lessons;
create policy lessons_read on public.lessons for select using (
  public.is_admin()
  or (
    status = 'published'
    and (
      is_free = true
      or public.has_active_premium(auth.uid())
    )
  )
);
drop policy if exists lessons_admin_write on public.lessons;
create policy lessons_admin_write on public.lessons for all using (public.is_admin()) with check (public.is_admin());

-- public catalogue of all published lessons (metadata only, no premium body)
create or replace function public.published_catalog()
returns table (
  id uuid, language_code text, level text, order_index int, title text,
  subtitle text, description text, estimated_minutes int, is_free boolean, locked boolean, completed boolean
) language sql stable security definer set search_path = public as $$
  select l.id, l.language_code, l.level, l.order_index, l.title, l.subtitle, l.description,
         l.estimated_minutes, l.is_free,
         not (l.is_free or public.has_active_premium(auth.uid()) or public.is_admin()) as locked,
         coalesce((select up.status = 'completed' from user_progress up where up.user_id = auth.uid() and up.lesson_id = l.id), false) as completed
  from lessons l
  where l.status = 'published'
  order by l.language_code, l.order_index;
$$;

-- ---------- progress ----------
drop policy if exists progress_read on public.user_progress;
create policy progress_read on public.user_progress for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists progress_write on public.user_progress;
create policy progress_write on public.user_progress for insert with check (user_id = auth.uid());
drop policy if exists progress_update on public.user_progress;
create policy progress_update on public.user_progress for update using (true) with check (user_id = auth.uid());
drop policy if exists progress_delete on public.user_progress;
create policy progress_delete on public.user_progress for delete using (user_id = auth.uid() or public.is_admin());

-- ---------- subscriptions: read-only for the owner, writes are service-role only ----------
drop policy if exists subs_read_own on public.subscriptions;
create policy subs_read_own on public.subscriptions for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists purchases_read_own on public.purchases;
create policy purchases_read_own on public.purchases for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists myket_read on public.myket_products;
create policy myket_read on public.myket_products for select using (true);
drop policy if exists myket_admin_write on public.myket_products;
create policy myket_admin_write on public.myket_products for all using (public.is_admin()) with check (public.is_admin());

-- ---------- content factory: admin only ----------
drop policy if exists curricula_admin on public.curricula;
create policy curricula_admin on public.curricula for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists batches_admin on public.content_batches;
create policy batches_admin on public.content_batches for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists plans_admin on public.lesson_plans;
create policy plans_admin on public.lesson_plans for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists audit_admin on public.audit_log;
create policy audit_admin on public.audit_log for select using (public.is_admin());

-- ---------- AI ----------
drop policy if exists ai_settings_read on public.ai_settings;
create policy ai_settings_read on public.ai_settings for select using (public.is_admin());
drop policy if exists ai_settings_admin on public.ai_settings;
create policy ai_settings_admin on public.ai_settings for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists ai_usage_own on public.ai_usage;
create policy ai_usage_own on public.ai_usage for select using (user_id = auth.uid() or public.is_admin());

drop policy if exists conv_own on public.conversations;
create policy conv_own on public.conversations for all using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid());
drop policy if exists msg_own on public.messages;
create policy msg_own on public.messages for all using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid());

-- ---------- hard guards (a client can never promote itself or a paid tier) ----------
create or replace function public.guard_profile_columns() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() then return new; end if;
  if new.role is distinct from old.role then
    raise exception 'forbidden: role change requires admin' using errcode = '42501';
  end if;
  if new.is_active is distinct from old.is_active then
    raise exception 'forbidden: account status change requires admin' using errcode = '42501';
  end if;
  return new;
end $$;
drop trigger if exists trg_guard_profile on public.profiles;
create trigger trg_guard_profile before update on public.profiles
  for each row execute function public.guard_profile_columns();

create or replace function public.guard_subscription_writes() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if current_setting('request.jwt.claim.role', true) in ('anon','authenticated') and not public.is_admin() then
    raise exception 'forbidden: subscriptions are written by the server only' using errcode = '42501';
  end if;
  return coalesce(new, old);
end $$;
drop trigger if exists trg_guard_subs on public.subscriptions;
create trigger trg_guard_subs before insert or update or delete on public.subscriptions
  for each row execute function public.guard_subscription_writes();
