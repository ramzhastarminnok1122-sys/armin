-- ============================================================
-- LINGU · 0003 · Curriculum, Lesson Plans, Lessons, Content Factory
-- ============================================================

create table if not exists public.curricula (
  id           uuid primary key default gen_random_uuid(),
  language_code text not null references languages(code) on delete cascade,
  level        text not null,                    -- A1 | A2 | B1 | B2
  title_fa     text not null,
  summary_fa   text,
  target_lessons int not null default 40,
  is_active    boolean not null default true,
  created_by   uuid references auth.users(id) on delete set null,
  created_at   timestamptz not null default now()
);

-- ---------- generation batches (the Content Factory job header) ----------
create table if not exists public.content_batches (
  id            uuid primary key default gen_random_uuid(),
  curriculum_id uuid references public.curricula(id) on delete set null,
  language_code text not null,
  level         text not null,
  requested     int not null default 10,
  succeeded     int not null default 0,
  failed        int not null default 0,
  status        batch_status not null default 'idle',
  model         text,
  last_error    text,
  created_by    uuid references auth.users(id) on delete set null,
  started_at    timestamptz,
  finished_at   timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
drop trigger if exists trg_batches_touch on public.content_batches;
create trigger trg_batches_touch before update on public.content_batches for each row execute function public.touch_updated_at();

-- ---------- lesson plans (Curriculum -> Lesson Plan -> Generation) ----------
create table if not exists public.lesson_plans (
  id            uuid primary key default gen_random_uuid(),
  curriculum_id uuid references public.curricula(id) on delete cascade,
  batch_id      uuid references public.content_batches(id) on delete set null,
  language_code text not null,
  level         text not null,
  order_index   int not null default 1,
  title         text not null,
  topic         text,
  objectives    jsonb not null default '[]'::jsonb,
  target_vocab  jsonb not null default '[]'::jsonb,
  grammar_focus text,
  status        plan_status not null default 'planned',
  attempts      int not null default 0,
  last_error    text,
  fingerprint   text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists idx_plans_lang on public.lesson_plans(language_code, level, order_index);
drop trigger if exists trg_plans_touch2 on public.lesson_plans;
create trigger trg_plans_touch2 before update on public.lesson_plans for each row execute function public.touch_updated_at();

-- ---------- lessons ----------
create table if not exists public.lessons (
  id            uuid primary key default gen_random_uuid(),
  plan_id       uuid references public.lesson_plans(id) on delete set null,
  batch_id      uuid references public.content_batches(id) on delete set null,
  language_code text not null references languages(code) on delete cascade,
  level         text not null default 'A1',
  order_index   int not null default 1,
  title         text not null,
  subtitle      text,
  description   text,
  estimated_minutes int not null default 15,
  status        lesson_status not null default 'draft',
  is_free       boolean not null default false,
  content       jsonb not null default '{}'::jsonb,   -- full lesson body (sections)
  validation    jsonb not null default '{}'::jsonb,   -- last validation report
  fingerprint   text,
  version       int not null default 1,
  published_at  timestamptz,
  created_by    uuid references auth.users(id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create unique index if not exists uq_lessons_fingerprint on public.lessons(fingerprint);
create index if not exists idx_lessons_lang_status on public.lessons(language_code, status, order_index);
drop trigger if exists trg_lessons_touch on public.lessons;
create trigger trg_lessons_touch before update on public.lessons for each row execute function public.touch_updated_at();

create or replace function public.set_lesson_fingerprint() returns trigger
language plpgsql as $$
begin
  if new.fingerprint is null then
    new.fingerprint := public.lesson_fingerprint(new.language_code, new.level, new.title);
  end if;
  return new;
end $$;
drop trigger if exists trg_lessons_fp on public.lessons;
create trigger trg_lessons_fp before insert or update of title, level, language_code on public.lessons
  for each row execute function public.set_lesson_fingerprint();

-- ---------- progress ----------
create table if not exists public.user_progress (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references auth.users(id) on delete cascade,
  lesson_id     uuid not null references public.lessons(id) on delete cascade,
  status        progress_status not null default 'started',
  last_section  text,
  sections_done jsonb not null default '[]'::jsonb,
  score         int,
  time_spent_sec int not null default 0,
  started_at    timestamptz not null default now(),
  completed_at  timestamptz,
  updated_at    timestamptz not null default now(),
  unique (user_id, lesson_id)
);
create index if not exists idx_progress_user on public.user_progress(user_id, updated_at desc);
drop trigger if exists trg_progress_touch on public.user_progress;
create trigger trg_progress_touch before update on public.user_progress for each row execute function public.touch_updated_at();

-- ---------- free lesson quota per language (2) ----------
create or replace function public.free_lessons_per_language()
returns int language sql stable security definer set search_path = public as $$
  select coalesce((select (value->>'free_lessons_per_language')::int from app_settings where key = 'learning'), 2);
$$;
