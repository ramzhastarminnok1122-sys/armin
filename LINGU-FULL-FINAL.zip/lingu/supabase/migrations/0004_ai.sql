-- ============================================================
-- LINGU · 0004 · AI: settings, secrets, conversations, usage
-- ============================================================

-- Admin-facing AI settings (NO secret here)
create table if not exists public.ai_settings (
  id                  int primary key default 1 check (id = 1),
  provider            text not null default 'groq',
  model               text not null default 'openai/gpt-oss-120b',
  fallback_model      text not null default 'openai/gpt-oss-20b',
  temperature         numeric(3,2) not null default 0.70,
  max_tokens          int not null default 1200,
  tutor_system_prompt text not null default '',
  partner_system_prompt text not null default '',
  free_partner_messages int not null default 2,
  premium_daily_messages int not null default 200,
  premium_daily_tutor int not null default 200,
  is_ai_enabled       boolean not null default true,
  updated_at          timestamptz not null default now(),
  updated_by          uuid references auth.users(id) on delete set null
);
drop trigger if exists trg_ai_settings_touch on public.ai_settings;
create trigger trg_ai_settings_touch before update on public.ai_settings for each row execute function public.touch_updated_at();

-- Server-only secret store. No client role can ever read this table.
create table if not exists public.ai_secrets (
  id           int primary key default 1 check (id = 1),
  groq_api_key text,
  key_hint     text,          -- e.g. "gsk_...AB12" (safe to show in admin)
  updated_at   timestamptz not null default now()
);

-- AI usage log (tokens + who + which feature)
create table if not exists public.ai_usage (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid references auth.users(id) on delete set null,
  feature       ai_feature not null,
  model         text,
  prompt_tokens int not null default 0,
  completion_tokens int not null default 0,
  latency_ms    int,
  ok            boolean not null default true,
  error         text,
  created_at    timestamptz not null default now()
);
create index if not exists idx_ai_usage_created on public.ai_usage(created_at desc);
create index if not exists idx_ai_usage_user on public.ai_usage(user_id, created_at desc);

-- Conversations (AI Tutor + Conversation Partner)
create table if not exists public.conversations (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  mode        ai_feature not null,
  scenario    text,
  scenario_fa text,
  title       text,
  lesson_id   uuid references public.lessons(id) on delete set null,
  message_count int not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists idx_conversations_user on public.conversations(user_id, updated_at desc);
drop trigger if exists trg_conversations_touch on public.conversations;
create trigger trg_conversations_touch before update on public.conversations for each row execute function public.touch_updated_at();

create table if not exists public.messages (
  id              uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id         uuid not null references auth.users(id) on delete cascade,
  role            msg_role not null,
  content         text not null,
  tokens          int not null default 0,
  created_at      timestamptz not null default now()
);
create index if not exists idx_messages_conv on public.messages(conversation_id, created_at);

-- ---------- quota accounting (server-side source of truth) ----------
create or replace function public.partner_messages_used(uid uuid)
returns int language sql stable security definer set search_path = public as $$
  select count(*)::int
  from messages m
  join conversations c on c.id = m.conversation_id
  where m.user_id = uid and m.role = 'user' and c.mode = 'partner';
$$;

create or replace function public.daily_ai_used(uid uuid, p_feature ai_feature)
returns int language sql stable security definer set search_path = public as $$
  select count(*)::int from ai_usage
  where user_id = uid and feature = p_feature and ok = true and created_at > now() - interval '1 day';
$$;

-- ---------- AI quota snapshot for the current user ----------
create or replace function public.my_ai_quota()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  s public.ai_settings;
  v_premium boolean;
begin
  if uid is null then return jsonb_build_object('authenticated', false); end if;
  select * into s from ai_settings where id = 1;
  v_premium := public.has_active_premium(uid) or public.is_admin();
  return jsonb_build_object(
    'authenticated', true,
    'premium', v_premium,
    'free_partner_limit', coalesce(s.free_partner_messages, 2),
    'partner_used', public.partner_messages_used(uid),
    'partner_remaining', case when v_premium then null else greatest(coalesce(s.free_partner_messages,2) - public.partner_messages_used(uid), 0) end,
    'tutor_remaining', case when v_premium then null else 0 end,
    'premium_daily_messages', coalesce(s.premium_daily_messages, 200),
    'ai_enabled', coalesce(s.is_ai_enabled, true)
  );
end $$;
