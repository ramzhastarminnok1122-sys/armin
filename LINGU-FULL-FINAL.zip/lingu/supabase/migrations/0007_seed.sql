-- ============================================================
-- LINGU · 0007 · Seed: languages, settings, theme, plans, marketing, AI
-- Idempotent: safe to run more than once.
-- ============================================================

insert into public.languages (code, name_fa, name_en, native_name, flag, gradient, description, target_lessons, sort_order) values
 ('en','انگلیسی','English','English','🇬🇧','from-indigo-500 via-blue-500 to-cyan-400','زبان جهانی کار، سفر و اینترنت — از مکالمه روزمره تا مصاحبه کاری.',340,1),
 ('fr','فرانسه','French','Français','🇫🇷','from-rose-500 via-pink-500 to-indigo-400','زبان فرهنگ، هنر و تحصیل در اروپا — با تلفظ روان و ساختار دقیق.',340,2),
 ('es','اسپانیایی','Spanish','Español','🇪🇸','from-amber-400 via-orange-500 to-rose-500','پرجمعیت‌ترین زبان مادری جهان — سریع، موزیکال و کاربردی.',340,3)
on conflict (code) do update set name_fa = excluded.name_fa, description = excluded.description, flag = excluded.flag, gradient = excluded.gradient;

insert into public.app_settings (key, value, description) values
 ('general', $j${"app_name":"LINGU","tagline":"یادگیری زبان، هوشمند و واقعی","support_email":"support@lingu.app","show_banners":true,"maintenance_mode":false}$j$::jsonb, 'تنظیمات عمومی سایت'),
 ('learning', $j${"free_lessons_per_language":2,"free_conversation_messages":2,"target_lessons_per_language":340}$j$::jsonb, 'قواعد دسترسی رایگان'),
 ('myket', $j${"package_name":"","public_key":"","enabled":false}$j$::jsonb, 'تنظیمات پرداخت میکت (کلید عمومی از پنل توسعه‌دهنده)'),
 ('features', $j${"ai_tutor":true,"conversation_partner":true,"progress":true,"subscription":true,"certificates":false}$j$::jsonb, 'فعال/غیرفعال بودن قابلیت‌ها')
on conflict (key) do nothing;

insert into public.theme_settings (id) values (1) on conflict (id) do nothing;

insert into public.plans (code, title_fa, subtitle_fa, description_fa, sku, duration_days, display_price, badge, features, is_active, is_recommended, sort_order) values
 ('free','رایگان','شروع بدون هزینه','برای همیشه رایگان — با ۲ درس کامل از هر زبان کیفیت LINGU را تجربه کن.','free',0,0,null,
   $j$["۲ درس کامل رایگان در English","۲ درس کامل رایگان در French","۲ درس کامل رایگان در Spanish","۲ پیام رایگان Conversation Partner","ثبت پیشرفت درس‌های رایگان"]$j$::jsonb, true, false, 1),
 ('monthly','اشتراک ماهانه','یک ماه دسترسی کامل','دسترسی کامل به همه زبان‌ها، AI Tutor و Conversation Partner بدون محدودیت درس.','LINGU_MONTHLY',30,0,null,
   $j$["همه درس‌های منتشرشده در سه زبان","AI Tutor نامحدود (طبق سقف روزانه)","Conversation Partner با سناریوهای واقعی","ثبت و پیگیری کامل پیشرفت","ادامه یادگیری از هر دستگاهی"]$j$::jsonb, true, false, 2),
 ('quarterly','اشتراک سه‌ماهه','سه ماه، صرفه بیشتر','همان دسترسی کامل با قیمت بهتر نسبت به ماهانه.','LINGU_QUARTERLY',90,0,'محبوب',
   $j$["همه امکانات اشتراک ماهانه","قیمت مناسب‌تر برای یادگیری پیوسته","مناسب برنامه‌های ۹۰ روزه"]$j$::jsonb, true, true, 3),
 ('yearly','اشتراک سالانه','یک سال کامل','کمترین هزینه ماهانه برای یادگیری بلندمدت و کامل سه زبان.','LINGU_YEARLY',365,0,'بهترین ارزش',
   $j$["همه امکانات اشتراک ماهانه","کمترین قیمت ماهانه","دسترسی به تمام محتوای جدید منتشرشده در طول سال"]$j$::jsonb, true, false, 4)
on conflict (code) do nothing;

insert into public.myket_products (sku, title_fa, duration_days, is_active, sort_order) values
 ('LINGU_MONTHLY','اشتراک ماهانه LINGU',30,true,1),
 ('LINGU_QUARTERLY','اشتراک سه‌ماهه LINGU',90,true,2),
 ('LINGU_YEARLY','اشتراک سالانه LINGU',365,true,3)
on conflict (sku) do nothing;

insert into public.faqs (question, answer, category, sort_order) values
 ('آیا استفاده از LINGU رایگان است؟','بله. حساب رایگان برای همیشه فعال می‌ماند و در هر سه زبان English، French و Spanish دو درس کامل رایگان دارد. برای دسترسی به همه درس‌ها و AI Tutor و Conversation Partner می‌توانی اشتراک تهیه کنی.','general',1),
 ('رایگان چه چیزی دریافت می‌کنم؟','۶ درس کامل (۲ درس در هر زبان)، ۲ پیام Conversation Partner و ثبت پیشرفت همان درس‌ها. هیچ محدودیت زمانی وجود ندارد — رایگان برای همیشه رایگان است.','pricing',2),
 ('Conversation Partner چه تفاوتی با AI Tutor دارد؟','Conversation Partner یک نقش واقعی (مثلاً گارسون کافه یا مصاحبه‌گر) بازی می‌کند و مکالمه را ادامه می‌دهد. AI Tutor توضیح می‌دهد، مثال می‌سازد و درس را ساده‌تر می‌کند.','features',3),
 ('روی چه زبان‌هایی کار می‌کنم؟','در نسخه فعلی English، French و Spanish. هدف نهایی ۳۴۰ درس برای هر زبان است و درس‌ها به‌صورت هفتگی اضافه می‌شوند.','languages',4),
 ('چطور می‌توانم اشتراک بگیرم؟','در صفحه «اشتراک» پلن دلخواه را انتخاب کن. فعال‌سازی در اپلیکیشن اندروید LINGU انجام می‌شود و بلافاصله روی همین حساب باز می‌گردد.','pricing',5),
 ('آیا تلفظ من تصحیح می‌شود؟','در نسخه فعلی تمرکز ما روی درک، واژگان، گرامر و مکالمه است؛ تمرین تلفظ صوتی در برنامه توسعه قرار دارد.','features',6)
on conflict do nothing;

-- ایـنـجـا نـظـرات کـاربـران seed نمی‌شود: هیچ نظر ساختگی در Production نمایش داده نمی‌شود.
-- نظرات واقعی از پنل مدیریت (بخش «نظرات کاربران») اضافه می‌شوند.


insert into public.ai_settings (id, provider, model, fallback_model, temperature, max_tokens,
  tutor_system_prompt, partner_system_prompt, free_partner_messages, premium_daily_messages, premium_daily_tutor, is_ai_enabled)
values (1,'groq','openai/gpt-oss-120b','openai/gpt-oss-20b',0.70,1200,
$p$تو «AI Tutor» رسمی مجموعه LINGU هستی؛ یک مربی زبان صبور، دقیق و دوستانه.
وظایف تو: توضیح ساده و مرحله‌به‌مرحله، پاسخ به سؤال زبان‌آموز، ساخت مثال تازه، توضیح گرامر و واژگان، ساخت تمرین کوتاه و صحبت درباره درس جاری.
قواعد سخت: همیشه به فارسی روان توضیح بده و مثال‌های انگلیسی/فرانسه/اسپانیایی را با ترجمه فارسی بیاور. پاسخ‌ها کوتاه و ساختارمند باشند (حداکثر ۶ bullet یا ۳ پاراگراف). هرگز از دانش‌آموز اطلاعات حساس نخواه. اگر سؤال بی‌ربط بود، با احترام به موضوع درس برگرد. هرگز نگو که مدل زبانی هستی؛ تو مربی LINGU هستی.$p$,
$p$تو «Conversation Partner» رسمی LINGU هستی: یک هم‌صحبت انسانی با نقش مشخص (مثلاً گارسون کافه، افسر فرودگاه، مصاحبه‌گر کاری).
قواعد سخت: همیشه در نقش بمان و مکالمه را طبیعی ادامه بده. هر پاسخ باید ۱) واکنش به حرف کاربر، ۲) یک سؤال تازه باشد تا گفت‌وگو قطع نشود. زبان مکالمه همان زبان هدف است (English/French/Spanish) و سطح زبان را با سطح زبان‌آموز هماهنگ کن. حداکثر ۳ جمله کوتاه در هر پاسخ. اگر کاربر جمله اشتباه گفت، در پایان و فقط با یک خط کوتاه و با عبارت «اصلاح دوستانه:» شکل درست را نشان بده. هرگز خارج از نقش حرف نزن.$p$,
2,200,200,true)
on conflict (id) do update set
  tutor_system_prompt = case when ai_settings.tutor_system_prompt = '' then excluded.tutor_system_prompt else ai_settings.tutor_system_prompt end,
  partner_system_prompt = case when ai_settings.partner_system_prompt = '' then excluded.partner_system_prompt else ai_settings.partner_system_prompt end;

insert into public.ai_secrets (id, groq_api_key, key_hint) values (1, null, null) on conflict (id) do nothing;
