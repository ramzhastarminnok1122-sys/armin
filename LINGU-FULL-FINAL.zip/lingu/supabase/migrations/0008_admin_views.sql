-- ============================================================
-- LINGU · 0008 · Admin read models (real numbers, admin-guarded)
-- ============================================================

create or replace function public.admin_users(p_query text default null)
returns table (
  id uuid, display_name text, avatar_url text, role app_role, is_active boolean, tour_done boolean,
  locale text, last_seen_at timestamptz, created_at timestamptz,
  premium boolean, premium_until timestamptz, ai_messages int, last_ai_at timestamptz,
  lessons_completed int, plan_title text
) language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = '42501'; end if;
  return query
  select p.id, p.display_name, p.avatar_url, p.role, p.is_active, p.tour_done, p.locale,
         p.last_seen_at, p.created_at,
         coalesce(s.end_date > now(), false) as premium,
         s.end_date as premium_until,
         coalesce((select count(*)::int from ai_usage a where a.user_id = p.id), 0) as ai_messages,
         (select max(a.created_at) from ai_usage a where a.user_id = p.id) as last_ai_at,
         coalesce((select count(*)::int from user_progress up where up.user_id = p.id and up.status = 'completed'), 0) as lessons_completed,
         pl.title_fa as plan_title
  from profiles p
  left join lateral (
    select s2.end_date, s2.plan_id from subscriptions s2
    where s2.user_id = p.id and s2.status = 'active' and s2.end_date > now()
    order by s2.end_date desc limit 1
  ) s on true
  left join plans pl on pl.id = s.plan_id
  where p_query is null or p_query = ''
     or p.display_name ilike '%' || p_query || '%'
     or p.id::text = p_query
  order by p.created_at desc
  limit 300;
end $$;

create or replace function public.admin_subscriptions()
returns table (
  id uuid, user_id uuid, sku text, status subscription_status, start_date timestamptz,
  end_date timestamptz, purchase_token text, provider text, created_at timestamptz,
  display_name text, plan_title text
) language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = '42501'; end if;
  return query
  select s.id, s.user_id, s.sku, s.status, s.start_date, s.end_date, s.purchase_token, s.provider, s.created_at,
         p.display_name, pl.title_fa
  from subscriptions s
  left join profiles p on p.id = s.user_id
  left join plans pl on pl.id = s.plan_id
  order by s.created_at desc
  limit 300;
end $$;

-- AI usage overview for the admin dashboard
create or replace function public.admin_ai_usage(p_limit int default 100)
returns setof ai_usage language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = '42501'; end if;
  return query select * from ai_usage order by created_at desc limit greatest(1, least(p_limit, 500));
end $$;

grant execute on function public.admin_users(text) to authenticated;
grant execute on function public.admin_subscriptions() to authenticated;
grant execute on function public.admin_ai_usage(int) to authenticated;
grant execute on function public.published_catalog() to authenticated, anon;
grant execute on function public.my_ai_quota() to authenticated;
grant execute on function public.theme_public() to authenticated, anon;
