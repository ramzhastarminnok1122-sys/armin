-- ============================================================
-- LINGU · 0011 · Backend readiness for AI + Content Production
--   * lesson-audio bucket (public read, admin-only write)
--   * daily AI usage counters (user_id, feature, day, request_count)
--   * server-only helper used by the Edge Functions
-- Everything here is idempotent.
-- ============================================================

-- ---------- storage: lesson audio ----------
-- `media`  : app images / media library (already exists)
-- `listening`: optional audio embedded in a Listening section (already exists)
-- `lesson-audio`: the audio library produced with the lessons (new here)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('lesson-audio', 'lesson-audio', true, 20971520,
        array['audio/mpeg','audio/mp4','audio/ogg','audio/wav','audio/webm'])
on conflict (id) do nothing;

-- Users may READ published lesson audio; only admins may write/replace/delete it.
drop policy if exists lesson_audio_read on storage.objects;
create policy lesson_audio_read on storage.objects for select
  using (bucket_id = 'lesson-audio');

drop policy if exists lesson_audio_write on storage.objects;
create policy lesson_audio_write on storage.objects for insert to authenticated
  with check (bucket_id = 'lesson-audio' and public.is_admin());

drop policy if exists lesson_audio_update on storage.objects;
create policy lesson_audio_update on storage.objects for update to authenticated
  using (bucket_id = 'lesson-audio' and public.is_admin());

drop policy if exists lesson_audio_delete on storage.objects;
create policy lesson_audio_delete on storage.objects for delete to authenticated
  using (bucket_id = 'lesson-audio' and public.is_admin());

-- ---------- daily AI usage counter ----------
create table if not exists public.ai_usage_daily (
  user_id       uuid not null references auth.users(id) on delete cascade,
  feature       ai_feature not null,
  day           date not null default current_date,
  request_count int not null default 0,
  updated_at    timestamptz not null default now(),
  primary key (user_id, feature, day)
);
create index if not exists idx_ai_usage_daily_day on public.ai_usage_daily(day desc);

alter table public.ai_usage_daily enable row level security;

-- Users can see their own counters; admins see everything; nobody can write from a client.
drop policy if exists ai_usage_daily_own on public.ai_usage_daily;
create policy ai_usage_daily_own on public.ai_usage_daily for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

-- Only the service role (Edge Functions) may bump a counter.
create or replace function public.bump_ai_usage(p_user uuid, p_feature ai_feature)
returns int language plpgsql security definer set search_path = public as $$
declare v int;
begin
  insert into ai_usage_daily (user_id, feature, day, request_count, updated_at)
  values (p_user, p_feature, current_date, 1, now())
  on conflict (user_id, feature, day)
  do update set request_count = ai_usage_daily.request_count + 1, updated_at = now()
  returning request_count into v;
  return v;
end $$;

revoke all on function public.bump_ai_usage(uuid, ai_feature) from public, anon, authenticated;
grant execute on function public.bump_ai_usage(uuid, ai_feature) to service_role;

-- ---------- admin view of AI usage (product-friendly, no raw ids for the client side) ----------
create or replace function public.admin_ai_usage_daily(p_days int default 14)
returns table (day date, feature ai_feature, users int, requests int)
language sql stable security definer set search_path = public as $$
  select d.day, d.feature, count(distinct d.user_id)::int, sum(d.request_count)::int
  from ai_usage_daily d
  where public.is_admin() and d.day > current_date - greatest(coalesce(p_days, 14), 1)
  group by d.day, d.feature
  order by d.day desc, d.feature;
$$;

revoke all on function public.admin_ai_usage_daily(int) from public, anon;
grant execute on function public.admin_ai_usage_daily(int) to authenticated, service_role;

-- ---------- privileges, made explicit ----------
-- Supabase grants these through project defaults; stating them here means SETUP.sql
-- behaves the same on any project (RLS still decides which ROWS anyone can see).
grant usage on schema public to anon, authenticated, service_role;
grant select on all tables in schema public to anon, authenticated;
grant insert, update, delete on all tables in schema public to authenticated;
-- the Edge Functions run as service_role: they must be able to write messages, usage and
-- counters, otherwise the AI features fail with "permission denied" on the first call.
grant select, insert, update, delete on all tables in schema public to service_role;
grant usage, select on all sequences in schema public to authenticated, service_role;
grant execute on all functions in schema public to anon, authenticated, service_role;

alter default privileges in schema public grant select on tables to anon, authenticated;
alter default privileges in schema public grant insert, update, delete on tables to authenticated;
alter default privileges in schema public grant select, insert, update, delete on tables to service_role;
alter default privileges in schema public grant execute on functions to anon, authenticated, service_role;

-- ...with the deliberate exceptions:
revoke all on public.ai_secrets from anon, authenticated;                       -- server-only key store
revoke insert, update, delete on public.ai_usage_daily from anon, authenticated; -- counters are server-written
revoke execute on function public.bump_ai_usage(uuid, ai_feature) from public, anon, authenticated;
grant execute on function public.bump_ai_usage(uuid, ai_feature) to service_role;
revoke all on function public.admin_ai_usage_daily(int) from public, anon;
grant execute on function public.admin_ai_usage_daily(int) to authenticated, service_role;
revoke all on function public.admin_users(text) from public, anon;
revoke all on function public.admin_subscriptions() from public, anon;
revoke all on function public.admin_ai_usage(int) from public, anon;
revoke all on function public.admin_dashboard() from public, anon;
