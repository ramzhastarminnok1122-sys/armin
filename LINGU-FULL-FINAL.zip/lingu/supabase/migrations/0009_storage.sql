-- ============================================================
-- LINGU · 0009 · Storage (only the bucket + access rules are created here;
-- the bucket itself is created by the setup script if it does not exist).
--   media    : admin-uploaded images used by banners / testimonials
--   listening: optional audio for Listening sections (created per-lesson, only when really needed)
-- ============================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('media', 'media', true, 5242880, array['image/png','image/jpeg','image/webp','image/svg+xml']),
  ('listening', 'listening', true, 15728640, array['audio/mpeg','audio/mp4','audio/ogg','audio/wav'])
on conflict (id) do nothing;

-- public read, admin-only write
drop policy if exists media_read on storage.objects;
create policy media_read on storage.objects for select using (bucket_id in ('media','listening'));
drop policy if exists media_write on storage.objects;
create policy media_write on storage.objects for insert to authenticated
  with check (bucket_id in ('media','listening') and public.is_admin());
drop policy if exists media_update on storage.objects;
create policy media_update on storage.objects for update to authenticated
  using (bucket_id in ('media','listening') and public.is_admin());
drop policy if exists media_delete on storage.objects;
create policy media_delete on storage.objects for delete to authenticated
  using (bucket_id in ('media','listening') and public.is_admin());
