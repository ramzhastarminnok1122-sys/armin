-- ============================================================
-- 0012 · Usage hygiene: close the two unprotected tables, add retention
--        for temporary data, and prevent duplicate storage objects.
--        Everything here is idempotent and safe to re-run.
-- ============================================================

-- ------------------------------------------------------------
-- 1) RLS gap: media_assets and notifications were created without
--    row level security. Supabase grants ALL privileges on new tables
--    to anon/authenticated, so an anonymous caller could insert into the
--    admin media library and read every notification. RLS is the only
--    thing standing between those grants and the data.
-- ------------------------------------------------------------
alter table public.media_assets  enable row level security;
alter table public.notifications enable row level security;

-- Media library: everyone reads the assets that are switched on (the public
-- site and the app render them), admins see and change everything.
drop policy if exists media_assets_read on public.media_assets;
create policy media_assets_read on public.media_assets
  for select using (is_active or public.is_admin());
drop policy if exists media_assets_admin on public.media_assets;
create policy media_assets_admin on public.media_assets
  for all using (public.is_admin()) with check (public.is_admin());

-- Notifications: a user only ever touches their own rows. Inserts come from
-- the notify()/notify_all_users() triggers, which run as the table owner.
drop policy if exists notifications_self_read on public.notifications;
create policy notifications_self_read on public.notifications
  for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists notifications_self_update on public.notifications;
create policy notifications_self_update on public.notifications
  for update using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists notifications_self_delete on public.notifications;
create policy notifications_self_delete on public.notifications
  for delete using (user_id = auth.uid() or public.is_admin());
drop policy if exists notifications_admin_insert on public.notifications;
create policy notifications_admin_insert on public.notifications
  for insert with check (public.is_admin());

-- ------------------------------------------------------------
-- 2) Duplicate storage prevention
--    a) media_assets gets a content hash + unique index so the same picture
--       cannot be registered twice.
--    b) storage_duplicates() lists objects that look identical (same bucket,
--       name, byte size and mime type) so an operator can drop the extras.
--    The content pipeline is expected to store audio under a content-addressed
--    path: lesson-audio/<lang>/<hash8>.<ext>, which makes the same clip shared
--    by every lesson that uses it instead of uploaded per lesson.
-- ------------------------------------------------------------
alter table public.media_assets add column if not exists content_hash text;
create unique index if not exists media_assets_content_hash_key
  on public.media_assets (content_hash) where content_hash is not null;

create or replace function public.storage_duplicates()
returns table (bucket_id text, object_name text, object_size bigint, copies bigint, paths text[])
language sql stable security definer set search_path = public, storage as $$
  select o.bucket_id, o.name, (o.metadata->>'size')::bigint,
         count(*), array_agg(o.name order by o.created_at)
  from storage.objects o
  group by o.bucket_id, o.name, (o.metadata->>'size'), (o.metadata->>'mimetype')
  having count(*) > 1
  order by (o.metadata->>'size')::bigint desc
$$;

-- ------------------------------------------------------------
-- 3) Retention for temporary data.
--    Nothing here ever deletes an account, a profile, progress or a
--    subscription: a user who comes back after months finds the same
--    account. Only derived, re-creatable rows are trimmed.
-- ------------------------------------------------------------

-- Old chat history: keeps the newest p_keep conversations per user and every
-- conversation touched within p_days. Messages cascade with their conversation.
create or replace function public.prune_conversations(p_days int default 180, p_keep int default 30)
returns int language plpgsql security definer set search_path = public as $$
declare v_deleted int;
begin
  with ranked as (
    select id, row_number() over (partition by user_id order by updated_at desc) as rn,
           updated_at
    from public.conversations
  ), doomed as (
    select id from ranked
    where rn > p_keep and updated_at < now() - make_interval(days => p_days)
  )
  delete from public.conversations c using doomed d where c.id = d.id;
  get diagnostics v_deleted = row_count;
  return v_deleted;
end $$;

-- Per-request AI log: the admin screen only reads the latest rows, so old
-- detail rows are pure growth. The daily counters in ai_usage_daily stay.
create or replace function public.prune_ai_usage(p_days int default 90)
returns int language plpgsql security definer set search_path = public as $$
declare v_deleted int;
begin
  delete from public.ai_usage where created_at < now() - make_interval(days => p_days);
  get diagnostics v_deleted = row_count;
  return v_deleted;
end $$;

-- Notifications a user already read and never came back to.
create or replace function public.prune_notifications(p_days int default 90)
returns int language plpgsql security definer set search_path = public as $$
declare v_deleted int;
begin
  delete from public.notifications
  where read_at is not null and read_at < now() - make_interval(days => p_days);
  get diagnostics v_deleted = row_count;
  return v_deleted;
end $$;

-- Admin audit trail: keep a year.
create or replace function public.prune_audit_log(p_days int default 365)
returns int language plpgsql security definer set search_path = public as $$
declare v_deleted int;
begin
  delete from public.audit_log where created_at < now() - make_interval(days => p_days);
  get diagnostics v_deleted = row_count;
  return v_deleted;
end $$;

-- One call for a scheduled job, returning what it trimmed.
create or replace function public.run_retention(
  p_conv_days int default 180, p_conv_keep int default 30,
  p_ai_days int default 90, p_notif_days int default 90, p_audit_days int default 365)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  return jsonb_build_object(
    'conversations',   public.prune_conversations(p_conv_days, p_conv_keep),
    'ai_usage',        public.prune_ai_usage(p_ai_days),
    'notifications',   public.prune_notifications(p_notif_days),
    'audit_log',       public.prune_audit_log(p_audit_days),
    'ran_at',          now()
  );
end $$;

-- Only the platform (service_role) and admins may trim data by hand.
revoke all on function public.prune_conversations(int, int) from public, anon, authenticated;
revoke all on function public.prune_ai_usage(int)           from public, anon, authenticated;
revoke all on function public.prune_notifications(int)      from public, anon, authenticated;
revoke all on function public.prune_audit_log(int)          from public, anon, authenticated;
revoke all on function public.run_retention(int, int, int, int, int) from public, anon, authenticated;
revoke all on function public.storage_duplicates()          from public, anon, authenticated;
grant execute on function public.prune_conversations(int, int) to service_role;
grant execute on function public.prune_ai_usage(int)           to service_role;
grant execute on function public.prune_notifications(int)      to service_role;
grant execute on function public.prune_audit_log(int)          to service_role;
grant execute on function public.run_retention(int, int, int, int, int) to service_role;
grant execute on function public.storage_duplicates()          to service_role;

-- ------------------------------------------------------------
-- 4) Daily schedule (when pg_cron is available on the project).
--    If the extension is missing the block is skipped silently and the same
--    functions can be called from the admin side or a scheduled job.
-- ------------------------------------------------------------
do $$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron')
     and not exists (select 1 from cron.job where jobname = 'lingu-retention') then
    perform cron.schedule('lingu-retention', '30 3 * * *', $cron$ select public.run_retention() $cron$);
  end if;
exception when others then
  raise notice 'pg_cron scheduling skipped: %', sqlerrm;
end $$;
