/**
 * LINGU · Edge Function test (real execution, mocked Supabase + mocked Groq).
 *
 * The real handlers are booted on a local port; only the two outbound HTTP
 * dependencies are stubbed. Everything else — JWT check, admin/premium lookups,
 * quota decisions, message storage, usage accounting, error mapping — runs for real.
 *
 * Run: deno test --allow-net --allow-env --allow-read supabase/test/functions_test.ts
 */
import './_env.ts' // ← first: the handlers read env at import time

const USER_ID = '00000000-0000-0000-0000-00000000000b'
const CONV_ID = '11111111-1111-1111-1111-111111111111'
const SUPA = 'https://fake.supabase.co'

/* ------------------------------ stubbed world ------------------------------ */
type State = {
  premium: boolean
  dailyTutor: number
  dailyPartner: number
  partnerUsed: number
  keyInDb: string | null
  aiEnabled: boolean
  groqStatus: number
  groqBody: unknown
  groqCalls: number
  inserted: string[]
}

let state: State
function reset(over: Partial<State> = {}) {
  state = {
    premium: true, dailyTutor: 0, dailyPartner: 0, partnerUsed: 0,
    keyInDb: 'gsk_test_key_1234567890', aiEnabled: true, groqStatus: 200,
    groqBody: { choices: [{ message: { content: 'Hello! How can I help you today?' } }], usage: { prompt_tokens: 10, completion_tokens: 12 } },
    groqCalls: 0, inserted: [], ...over,
  }
}

const settings = () => ({
  id: 1, provider: 'groq', model: 'llama-3.3-70b-versatile', fallback_model: 'llama-3.1-8b-instant',
  temperature: 0.7, max_tokens: 1200, tutor_system_prompt: '', partner_system_prompt: '',
  free_partner_messages: 2, premium_daily_messages: 200, premium_daily_tutor: 200,
  is_ai_enabled: state.aiEnabled,
})

const realFetch = globalThis.fetch
globalThis.fetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
  const url = typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url
  const method = (init?.method ?? 'GET').toUpperCase()
  const json = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } })

  if (url.startsWith(SUPA)) {
    const path = url.replace(SUPA, '')
    const h = init?.headers
    const accept = h instanceof Headers ? (h.get('accept') ?? '')
      : Array.isArray(h) ? (h.find(([k]) => k.toLowerCase() === 'accept')?.[1] ?? '')
      : String((h as Record<string, string> | undefined)?.['Accept'] ?? (h as Record<string, string> | undefined)?.['accept'] ?? '')
    const wantsObject = accept.includes('pgrst.object')

    if (path.startsWith('/auth/v1/user')) return json({ id: USER_ID, email: 'sara@lingu.dev' })
    if (path.startsWith('/rest/v1/ai_settings')) return json(wantsObject ? settings() : [settings()])
    if (path.startsWith('/rest/v1/ai_secrets')) return json(wantsObject ? { groq_api_key: state.keyInDb } : [{ groq_api_key: state.keyInDb }])
    if (path.startsWith('/rest/v1/profiles')) return json(wantsObject ? { role: 'user', is_active: true } : [{ role: 'user', is_active: true }])
    if (path.startsWith('/rest/v1/subscriptions')) return json(wantsObject ? null : [])
    if (path.startsWith('/rest/v1/lessons')) return json(wantsObject ? null : [])

    if (path.startsWith('/rest/v1/conversations')) {
      if (method === 'POST') {
        state.inserted.push('conversation')
        return wantsObject ? json({ id: CONV_ID }, 201) : json([{ id: CONV_ID }], 201)
      }
      return json(wantsObject ? { id: CONV_ID, user_id: USER_ID, mode: 'partner', scenario: 'cafe', scenario_fa: 'کافه' } : [])
    }
    if (path.startsWith('/rest/v1/messages')) {
      if (method === 'POST') {
        state.inserted.push('message')
        // the stub database counts a user turn, exactly like public.partner_messages_used would
        if (String(init?.body ?? '').includes('"user"')) state.partnerUsed++
        return json([], 201)
      }
      return json([])
    }
    if (path.startsWith('/rest/v1/ai_usage')) { state.inserted.push('usage'); return json([], 201) }

    if (path.includes('/rpc/has_active_premium')) return json(state.premium)
    if (path.includes('/rpc/daily_ai_used')) {
      const feat = String(init?.body ?? '').includes('partner') ? state.dailyPartner : state.dailyTutor
      return json(feat)
    }
    if (path.includes('/rpc/partner_messages_used')) return json(state.partnerUsed)
    if (path.includes('/rpc/bump_ai_usage')) return json(1)
    return json({}, 404)
  }

  if (url.startsWith('https://api.groq.com')) {
    state.groqCalls++
    return json(state.groqBody, state.groqStatus)
  }

  return realFetch(input as never, init)
}) as typeof fetch

/* ------------------------- the real handlers under test ------------------------- */
import { handler as aiChat } from '../functions/ai-chat/handler.ts'
import { handler as conversation } from '../functions/conversation/handler.ts'
import { handler as contentAdmin } from '../functions/content-admin/handler.ts'
import { assert, assertEquals } from 'jsr:@std/assert@1'

const HANDLERS: Record<string, (req: Request) => Promise<Response>> = {
  '/ai-chat': aiChat,
  '/conversation': conversation,
  '/content-admin': contentAdmin,
}

const auth = { 'Content-Type': 'application/json', Authorization: 'Bearer user-token', apikey: 'anon' }
async function call(path: string, body: unknown, headers: Record<string, string> = auth, method = 'POST') {
  const handler = HANDLERS[path]!
  return await handler(new Request('https://functions.lingu.test' + path, {
    method, headers, body: method === 'POST' ? JSON.stringify(body) : undefined,
  }))
}

/* ---------------------------------- tests ---------------------------------- */
Deno.test('ai-chat: rejects a request with no token', async () => {
  reset()
  const res = await call('/ai-chat', { message: 'hi' }, { 'Content-Type': 'application/json' })
  assertEquals(res.status, 401)
  assertEquals((await res.json()).code, 'unauthorized')
})

Deno.test('ai-chat: free user gets the Premium gate, not an AI answer', async () => {
  reset({ premium: false })
  const res = await call('/ai-chat', { message: 'توضیح بده', language: 'en', level: 'A1' })
  assertEquals(res.status, 403)
  const body = await res.json()
  assertEquals(body.code, 'tutor_requires_premium')
  assertEquals(state.groqCalls, 0, 'no provider call may happen for a blocked user')
})

Deno.test('ai-chat: without a key the user is told "not available", nothing is faked', async () => {
  reset({ keyInDb: null })
  const res = await call('/ai-chat', { message: 'توضیح بده' })
  const body = await res.json()
  const status = res.status
  assertEquals(status, 503)
  assertEquals(body.code, 'ai_disabled')
  assert(body.error.includes('در دسترس نیست'))
  assertEquals(state.groqCalls, 0)
})

Deno.test('ai-chat: premium user gets a real answer and the usage is recorded', async () => {
  reset()
  const res = await call('/ai-chat', { message: 'برای این موضوع مثال بزن', language: 'en', level: 'A2', lesson_id: null })
  const body = await res.json()
  assertEquals(res.status, 200)
  assert(body.reply.includes('Hello'))
  assertEquals(body.conversation_id, CONV_ID)
  assertEquals(state.groqCalls, 1)
  assert(state.inserted.includes('message'), 'the turn must be stored')
  assert(state.inserted.includes('usage'), 'usage must be counted')
})

Deno.test('ai-chat: a provider outage becomes a product sentence, never a provider error', async () => {
  reset({ groqStatus: 500, groqBody: { error: { message: 'internal provider stack trace' } } })
  const res = await call('/ai-chat', { message: 'سلام' })
  const raw = await res.text()
  assertEquals(res.status, 502)
  assert(raw.includes('در دسترس نیست'))
  for (const leak of ['groq', 'Groq', 'stack', 'internal']) assert(!raw.includes(leak), `leaked "${leak}"`)
})

Deno.test('ai-chat: daily cap is enforced for premium users too', async () => {
  reset({ dailyTutor: 200 })
  const res = await call('/ai-chat', { message: 'سلام' })
  assertEquals(res.status, 429)
  assertEquals((await res.json()).code, 'daily_limit_reached')
  assertEquals(state.groqCalls, 0)
})

Deno.test('conversation: free user has 2 messages, the 3rd is the Premium gate', async () => {
  reset({ premium: false, partnerUsed: 0 })
  const first = await call('/conversation', { message: 'Hello!', scenario: 'cafe', scenario_fa: 'کافه' })
  assertEquals(first.status, 200)
  assertEquals((await first.json()).usage.partner_remaining, 1)

  reset({ premium: false, partnerUsed: 2 })
  const third = await call('/conversation', { message: 'Hello again', scenario: 'cafe' })
  assertEquals(third.status, 402)
  const body = await third.json()
  assertEquals(body.code, 'partner_quota_exceeded')
  assert(body.error.includes('Premium'))
  assertEquals(state.groqCalls, 0, 'the gate must not spend a provider call')
})

Deno.test('conversation: premium user is unlimited and roleplay context reaches the model', async () => {
  reset({ premium: true })
  let sentBody = ''
  const wrapped = globalThis.fetch
  globalThis.fetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url
    if (url.startsWith('https://api.groq.com')) sentBody = String(init?.body ?? '')
    return wrapped(input as never, init)
  }) as typeof fetch

  const res = await call('/conversation', { message: 'سلام، من قهوه می‌خواهم', scenario: 'cafe', scenario_fa: 'کافه', language: 'en', level: 'A2' })
  assertEquals(res.status, 200)
  assertEquals((await res.json()).usage.partner_remaining, null)
  const parsed = JSON.parse(sentBody)
  assertEquals(parsed.messages[0].role, 'system')
  assert(parsed.messages[0].content.includes('کافه'), 'the scenario must be in the system prompt')
  assert(parsed.messages[0].content.includes('A2'), 'the level must be in the system prompt')
  assert(sentBody.includes('سلام، من قهوه می‌خواهم'), 'the user turn must be forwarded')
  globalThis.fetch = wrapped
})

Deno.test('conversation: empty message is rejected before spending anything', async () => {
  reset()
  const res = await call('/conversation', { message: '   ' })
  assertEquals(res.status, 400)
  assertEquals(state.groqCalls, 0)
})

Deno.test('content-admin: a normal user cannot use admin actions', async () => {
  reset()
  const res = await call('/content-admin', { action: 'save_groq_key', api_key: 'gsk_x'.repeat(8) })
  assertEquals(res.status, 403)
  assert((await res.json()).error.includes('مدیران'))
})

Deno.test('content-admin: only a GET-style call is rejected politely', async () => {
  reset()
  const res = await call('/ai-chat', null as never, auth, 'GET')
  assertEquals(res.status, 405)
})
