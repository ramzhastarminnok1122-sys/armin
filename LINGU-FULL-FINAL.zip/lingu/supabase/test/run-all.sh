#!/usr/bin/env bash
# LINGU · runs every backend test suite locally and prints one summary.
#   bash supabase/test/run-all.sh
# Requires: a local PostgreSQL (any 15+) and, for the Edge Function suites, Deno.
# NOTE: install Deno OUTSIDE the project folder (e.g. DENO_INSTALL=/opt/deno) — the runtime
# is ~100 MB and the workspace snapshot (files kept between sessions) has a size budget.
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
DB_URL="${DB_URL:-postgresql://postgres@localhost:5433/lingu_test}"
DENO="${DENO:-deno}"
fails=0

step() { printf '\n\033[1m── %s\033[0m\n' "$1"; }

step "1/4 · SETUP.sql runs on a clean database"
psql "$DB_URL" -q -c "drop schema public cascade; create schema public;" >/dev/null 2>&1
psql "$DB_URL" -q -f "$ROOT/supabase/test/00_local_shim.sql" >/dev/null 2>&1
if psql "$DB_URL" -v ON_ERROR_STOP=1 -q -f "$ROOT/supabase/SETUP.sql" 2>&1 | grep -viE "notice" | grep -q .; then
  echo "FAILED — see the errors above"; fails=$((fails+1))
else
  echo "OK — $(psql "$DB_URL" -tAc "select count(*) from information_schema.tables where table_schema='public'") tables, $(psql "$DB_URL" -tAc "select count(*) from pg_policies where schemaname in ('public','storage')") policies, $(psql "$DB_URL" -tAc "select count(*) from storage.buckets") storage buckets"
fi

step "2/4 · idempotency (running SETUP.sql a second time)"
if psql "$DB_URL" -v ON_ERROR_STOP=1 -q -f "$ROOT/supabase/SETUP.sql" 2>&1 | grep -viE "notice" | grep -q .; then
  echo "FAILED — second run is not clean"; fails=$((fails+1))
else
  echo "OK — safe to run twice"
fi

step "3/4 · RLS / Auth / Storage / Quota (real PostgreSQL)"
out=$(psql "$DB_URL" -f "$ROOT/supabase/test/10_rls_test.sql" 2>&1)
echo "$out" | grep -E "^ +[0-9]+\. (PASS|FAIL)" | sed 's/^/  /'
passed=$(echo "$out" | grep -cE "PASS"); failed=$(echo "$out" | grep -cE "FAIL")
echo "  → passed: $passed, failed: $failed"
[ "$failed" -gt 0 ] && fails=$((fails+1))

step "4/4 · Edge Functions"
if command -v "$DENO" >/dev/null 2>&1; then
  if "$DENO" test --allow-net --allow-env --allow-read --quiet "$ROOT/supabase/test/functions_test.ts" 2>&1 | tail -3; then :; else fails=$((fails+1)); fi
  ( cd "$ROOT" && npx --prefix web esbuild supabase/test/ai_logic_test.ts --bundle --format=esm --platform=node --outfile=/tmp/ai.mjs --log-level=error >/dev/null 2>&1 && node /tmp/ai.mjs | tail -2 )
else
  echo "  SKIPPED — deno is not installed (install: https://deno.land/install.sh)"
fi

printf '\n\033[1m=========== %s ===========\033[0m\n' "$([ $fails -eq 0 ] && echo 'ALL BACKEND SUITES GREEN' || echo "$fails SUITE(S) FAILED")"
exit $fails
