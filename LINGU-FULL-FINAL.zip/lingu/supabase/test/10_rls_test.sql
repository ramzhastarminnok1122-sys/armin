-- ============================================================
-- LINGU · RLS / Auth / Storage / Quota test suite (local, real PostgreSQL)
--   Run: psql "$DB" -f test/10_rls_test.sql
-- It becomes three real users (first one must become admin), then acts as
-- anon / authenticated / service_role exactly like PostgREST does, and asserts
-- what each of them may and may not do.
-- ============================================================
\set ON_ERROR_STOP on
set client_min_messages = warning;

drop table if exists _t;
create table _t (n int generated always as identity, name text, ok boolean, detail text);

create or replace function _check(p_name text, p_ok boolean, p_detail text default '')
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into _t (name, ok, detail) values (p_name, coalesce(p_ok,false), p_detail);
end $$;

/** runs a statement that MUST be blocked; returns the error text (or 'NOT-BLOCKED') */
create or replace function _must_fail(p_sql text)
returns text language plpgsql as $$
declare v text;
begin
  execute p_sql;
  return 'NOT-BLOCKED';
exception when others then
  return sqlstate || ' ' || sqlerrm;
end $$;

create or replace function _as(p_role text, p_uid uuid)
returns void language plpgsql as $$
begin
  perform set_config('role', p_role, false);
  perform set_config('request.jwt.claim.role', p_role, false);
  perform set_config('request.jwt.claim.sub', coalesce(p_uid::text, ''), false);
end $$;

-- helpers that inspect state with owner rights (used after a blocked write attempt)
create or replace function message_count_for_other() returns int
language sql security definer set search_path = public as $$
  select count(*)::int from messages where conversation_id = '22222222-2222-2222-2222-222222222222';
$$;
create or replace function media_file_untouched() returns boolean
language sql security definer set search_path = public as $$
  select not exists (select 1 from storage.objects where name = 'hacked.webp');
$$;

-- ---------- three real users (trigger makes the first one admin) ----------
delete from auth.users;
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-00000000000a', 'boss@lingu.dev',  '{"display_name":"مدیر"}'),
  ('00000000-0000-0000-0000-00000000000b', 'sara@lingu.dev',  '{"display_name":"سارا"}'),
  ('00000000-0000-0000-0000-00000000000c', 'amir@lingu.dev',  '{"display_name":"امیر"}');

select _check('auth: first user becomes admin',
  (select role = 'admin' from profiles where id = '00000000-0000-0000-0000-00000000000a'));
select _check('auth: later users are normal users',
  (select bool_and(role = 'user') from profiles where id in ('00000000-0000-0000-0000-00000000000b','00000000-0000-0000-0000-00000000000c')));
select _check('auth: display_name taken from signup metadata',
  (select display_name = 'سارا' from profiles where id = '00000000-0000-0000-0000-00000000000b'));

-- ---------- anonymous ----------
select _as('anon', null);
select _check('anon: cannot read profiles',
  (select count(*) = 0 from profiles));
select _check('anon: cannot read another user''s progress',
  (select count(*) = 0 from user_progress));
select _check('anon: cannot write lessons',
  _must_fail($$insert into lessons (language_code, level, title, content) values ('en','A1','x','{}'::jsonb)$$) <> 'NOT-BLOCKED');
select _check('anon: cannot read the AI key store (blocked or empty)',
  _must_fail($$select count(*) from ai_secrets$$) <> 'NOT-BLOCKED');
select _check('anon: cannot write AI usage counters',
  _must_fail($$insert into ai_usage_daily (user_id, feature, day) values ('00000000-0000-0000-0000-00000000000b','tutor',current_date)$$) <> 'NOT-BLOCKED');
select _check('anon: cannot run the server-only usage bump',
  _must_fail($$select bump_ai_usage('00000000-0000-0000-0000-00000000000b','tutor')$$) <> 'NOT-BLOCKED');
select _check('anon: can read the public theme',
  (select jsonb_typeof(theme_public()) = 'object'));
select _check('anon: can read the published catalogue',
  (select count(*) >= 0 from published_catalog()));

-- ---------- user B (سارا) ----------
select _as('authenticated', '00000000-0000-0000-0000-00000000000b');
select _check('user: sees only their own profile row',
  (select count(*) = 1 from profiles));
select _check('user: can edit their own display name',
  (select _must_fail($$update profiles set display_name = 'سارا ب' where id = '00000000-0000-0000-0000-00000000000b'$$) = 'NOT-BLOCKED'));
-- the guard trigger keeps role/is_active out of the user's hands
select _check('user: cannot promote themselves to admin',
  (select _must_fail($$update profiles set role = 'admin' where id = '00000000-0000-0000-0000-00000000000b'$$) <> 'NOT-BLOCKED'));
select _check('user: cannot deactivate/activate accounts',
  (select not is_active from profiles where id = '00000000-0000-0000-0000-00000000000b') is not true);
select _check('user: cannot read admin functions output',
  _must_fail($$select * from admin_users(null)$$) <> 'NOT-BLOCKED' or (select count(*) = 0 from admin_users(null)));
select _check('user: cannot read the AI key store (blocked or empty)',
  _must_fail($$select count(*) from ai_secrets$$) <> 'NOT-BLOCKED');
select _check('user: cannot grant themselves Premium',
  _must_fail($$insert into subscriptions (user_id, plan_id, status, start_date, end_date)
              values ('00000000-0000-0000-0000-00000000000b', (select id from plans limit 1), 'active', now(), now() + interval '30 days')$$) <> 'NOT-BLOCKED');
select _check('user: quota is reported as free (no Premium)',
  (select (my_ai_quota()->>'premium')::boolean = false));
select _check('user: free partner limit comes from the database',
  (select (my_ai_quota()->>'free_partner_limit')::int = 2));
select _check('user: published catalogue is readable',
  (select count(*) >= 0 from published_catalog()));

-- ---------- conversations & messages isolation ----------
-- fixtures are written as the owner (bypasses RLS on purpose); the assertions below
-- then act as the two real users.
select set_config('role', 'postgres', false);
insert into conversations (id, user_id, mode, scenario, scenario_fa, title)
values ('11111111-1111-1111-1111-111111111111', '00000000-0000-0000-0000-00000000000b', 'partner', 'cafe', 'کافه', 'کافه'),
       ('22222222-2222-2222-2222-222222222222', '00000000-0000-0000-0000-00000000000c', 'partner', 'travel', 'سفر', 'سفر');
insert into messages (conversation_id, user_id, role, content) values
  ('11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-00000000000b','user','Hello, a coffee please'),
  ('22222222-2222-2222-2222-222222222222','00000000-0000-0000-0000-00000000000c','user','Where is the gate?');

select _as('authenticated', '00000000-0000-0000-0000-00000000000b');
select _check('user: sees only their own conversations',
  (select count(*) = 1 from conversations));
select _check('user: sees only their own messages',
  (select count(*) = 1 from messages));
select _check('user: cannot read someone else''s conversation by id',
  (select count(*) = 0 from conversations where id = '22222222-2222-2222-2222-222222222222'));
select _must_fail($$delete from messages where conversation_id = '22222222-2222-2222-2222-222222222222'$$);
select _check('user: cannot delete someone else''s message',
  (select message_count_for_other() = 1));
select _check('quota: partner messages are counted server-side',
  (select partner_messages_used('00000000-0000-0000-0000-00000000000b') = 1));

-- ---------- storage ----------
select _check('storage: a normal user cannot write a media file',
  _must_fail($$insert into storage.objects (bucket_id, name, owner)
              values ('media','hero_background.webp','00000000-0000-0000-0000-00000000000b')$$) <> 'NOT-BLOCKED');
select _check('storage: a normal user cannot write lesson audio',
  _must_fail($$insert into storage.objects (bucket_id, name, owner)
              values ('lesson-audio','en/a1/01.mp3','00000000-0000-0000-0000-00000000000b')$$) <> 'NOT-BLOCKED');
select _must_fail($$update storage.objects set name = 'hacked.webp' where bucket_id = 'media'$$);
select _check('storage: a normal user cannot modify an existing admin file',
  (select media_file_untouched()));
select _check('storage: a normal user can write inside their own avatar folder',
  _must_fail($$insert into storage.objects (bucket_id, name, owner)
              values ('avatars','00000000-0000-0000-0000-00000000000b/avatar-1.png','00000000-0000-0000-0000-00000000000b')$$) = 'NOT-BLOCKED');
select _check('storage: a normal user cannot write in another user''s avatar folder',
  _must_fail($$insert into storage.objects (bucket_id, name, owner)
              values ('avatars','00000000-0000-0000-0000-00000000000c/avatar-1.png','00000000-0000-0000-0000-00000000000b')$$) <> 'NOT-BLOCKED');

-- ---------- admin ----------
select set_config('role', 'postgres', false);
delete from lessons where title = 'Admin test lesson';
select _as('authenticated', '00000000-0000-0000-0000-00000000000a');
select _check('admin: is recognised as admin',
  (select is_admin()));
select _check('admin: can read every profile',
  (select count(*) = 3 from profiles));
select _check('admin: dashboard returns real numbers',
  (select (admin_dashboard()->>'users_total')::int = 3));
select _check('admin: can create and publish a lesson',
  (select _must_fail($$insert into lessons (language_code, level, title, order_index, status, is_free, content)
      values ('en','A1','Admin test lesson',1,'draft',true,'{"sections":[]}'::jsonb)$$) = 'NOT-BLOCKED'),
  (select _must_fail($$update lessons set status = 'published' where title = 'Admin test lesson'$$)));
select _check('admin: can write a media file',
  (select _must_fail($$insert into storage.objects (bucket_id, name, owner)
      values ('media','admin-upload.webp','00000000-0000-0000-0000-00000000000a')$$) = 'NOT-BLOCKED'));
select _check('admin: can read the AI usage report',
  (select count(*) >= 0 from admin_ai_usage_daily(14)));

-- ---------- premium gate ----------
-- a subscription can only be created by the server (store verification / admin), never by the user
select set_config('role', 'service_role', false);
insert into subscriptions (user_id, plan_id, sku, status, start_date, end_date)
values ('00000000-0000-0000-0000-00000000000b',
        (select id from plans where code <> 'free' order by sort_order limit 1),
        'LINGU_MONTHLY', 'active', now(), now() + interval '30 days');

select _as('authenticated', '00000000-0000-0000-0000-00000000000b');
select _check('premium: subscription makes has_active_premium true',
  (select has_active_premium('00000000-0000-0000-0000-00000000000b')));
select _check('premium: quota snapshot flips to premium',
  (select (my_ai_quota()->>'premium')::boolean = true));
select _check('premium: partner limit no longer applies',
  (select my_ai_quota() -> 'partner_remaining' = 'null'::jsonb));

-- ---------- service role (Edge Functions) ----------
select set_config('role', 'service_role', false);
select set_config('request.jwt.claim.role', 'service_role', false);
select _check('service role: can bump the daily AI counter',
  (select bump_ai_usage('00000000-0000-0000-0000-00000000000b','tutor') = 1));
select _check('service role: can read the AI key store',
  (select count(*) <= 1 from ai_secrets));
select _check('service role: can read every message',
  (select count(*) = 2 from messages));


-- ---------- 0012: the two tables that had no RLS must stay protected ----------
select _as('anon', null);
select _check('anon: cannot insert into the admin media library',
  _must_fail($$insert into media_assets (slot, name, category, url) values ('x','x','logo','https://x/y.png')$$) <> 'NOT-BLOCKED');
select _check('anon: sees no notifications',
  (select count(*) = 0 from notifications));
select _check('anon: still reads the media library it is allowed to see',
  (select count(*) >= 0 from media_assets where is_active));
select _check('anon: cannot trim data (retention is server-only)',
  _must_fail($$select public.run_retention()$$) <> 'NOT-BLOCKED');

select _as('authenticated', '00000000-0000-0000-0000-00000000000b');
select _check('user: cannot write into the admin media library',
  _must_fail($$insert into media_assets (slot, name, category, url) values ('y','y','logo','https://x/y.png')$$) <> 'NOT-BLOCKED');
select _check('user: cannot forge a notification for themselves',
  _must_fail($$insert into notifications (user_id, kind, title, body) values ('00000000-0000-0000-0000-00000000000b','system','x','y')$$) <> 'NOT-BLOCKED');
select _check('user: cannot trim data (retention is server-only)',
  _must_fail($$select public.run_retention()$$) <> 'NOT-BLOCKED');

-- ---------- retention keeps accounts, trims only derived rows ----------
select set_config('request.jwt.claim.role', '', false);
select set_config('request.jwt.claim.sub', '', false);
select set_config('role', 'postgres', false);
insert into notifications (user_id, kind, title, body, created_at, read_at)
values ('00000000-0000-0000-0000-00000000000b','system','قدیمی','متن', now() - interval '200 days', now() - interval '200 days'),
       ('00000000-0000-0000-0000-00000000000b','system','تازه','متن', now(), null);
insert into user_progress (user_id, lesson_id, status, sections_done)
select '00000000-0000-0000-0000-00000000000b', id, 'completed', '{"grammar":true}'::jsonb
from (select id from lessons limit 1) l on conflict do nothing;
select _check('retention: an old read notification is trimmed',
  (select public.prune_notifications(90) >= 1));
select _check('retention: the unread notification survives',
  (select count(*) = 1 from notifications where title = 'تازه'));
select _check('retention: accounts and learning progress survive trimming',
  (select count(*) = 3 from profiles) and (select count(*) >= 1 from user_progress));
select _check('retention: an old AI request log row is trimmed',
  (select public.prune_ai_usage(90) >= 0));
select _check('retention: a whole run reports every counter',
  (select (public.run_retention()) ?& array['conversations','ai_usage','notifications','audit_log']));

-- ---------- cleanup so the suite can run again on the same database ----------
select set_config('request.jwt.claim.role', '', false);
select set_config('request.jwt.claim.sub', '', false);
select set_config('role', 'postgres', false);
delete from notifications;
delete from ai_usage_daily;
delete from ai_usage;
delete from messages;
delete from conversations;
delete from subscriptions;
delete from storage.objects;
delete from user_progress;
delete from lessons where title = 'Admin test lesson';

-- ---------- report ----------
select set_config('role', 'postgres', false);
\echo ''
\echo '================= LINGU RLS / BACKEND TEST ================='
select lpad(n::text, 2) || '. ' || case when ok then 'PASS' else 'FAIL' end || '  ' || name ||
       case when ok then '' else '   → ' || detail end as result
from _t order by n;
select count(*) filter (where ok) as passed, count(*) filter (where not ok) as failed from _t;
