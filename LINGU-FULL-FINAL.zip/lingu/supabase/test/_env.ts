/** Test environment: must be imported before the Edge Function handlers so the
 *  env vars are already in place when their modules are evaluated. */
Deno.env.set('SUPABASE_URL', 'https://fake.supabase.co')
Deno.env.set('SUPABASE_SERVICE_ROLE_KEY', 'service-role-test-key')
Deno.env.delete('GROQ_API_KEY') // the key must come from the server-only table in these tests
