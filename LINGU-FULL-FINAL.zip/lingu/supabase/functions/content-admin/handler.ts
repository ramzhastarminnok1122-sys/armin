/**
 * LINGU · Edge Function `content-admin` — admin-only server actions.
 *
 * Implemented for real in this phase:
 *   save_groq_key  → writes the key into the server-only table `ai_secrets` and returns a hint
 *   test_ai        → performs a real Groq call so the admin can verify the key works
 *   revoke_subscription → ends an active subscription immediately
 *
 * Content Production actions (create_plans / generate_next / validate_lesson / duplicates /
 * publish) are declared but answer with an explicit code, never a fake success — they belong
 * to the Content phase and are wired there.
 *
 * Every call is checked against `is_admin()` with the caller's own token.
 */
import { fail, json, MSG, preflight, ProductError } from '../_shared/http.ts'
import { admin, loadApiKey, loadSettings, requireUser } from '../_shared/context.ts'
import { complete } from '../_shared/groq.ts'

const NOT_YET = 'این عملیات در مرحلهٔ محتوا فعال می‌شود.'

export async function handler(req: Request): Promise<Response> {
  const pre = preflight(req)
  if (pre) return pre

  try {
    if (req.method !== 'POST') throw new ProductError('bad_request', 405, MSG.bad_request)

    const { db, user } = await requireUser(req)

    // admin check with the caller's own rights — service role must not be a bypass here
    const { data: profile } = await db.from('profiles').select('role,is_active').eq('id', user.id).maybeSingle()
    const isAdmin = (profile as { role?: string; is_active?: boolean } | null)?.role === 'admin'
      && (profile as { is_active?: boolean } | null)?.is_active !== false
    if (!isAdmin) throw new ProductError('unauthorized', 403, 'این بخش فقط برای مدیران LINGU است.')

    const body = await req.json().catch(() => ({})) as Record<string, unknown>
    const action = String(body.action ?? '')

    switch (action) {
      case 'save_groq_key': {
        const key = String(body.api_key ?? '').trim()
        if (key.length < 20) throw new ProductError('bad_request', 400, 'کلید معتبر نیست.')
        const hint = key.length > 8 ? `${key.slice(0, 4)}…${key.slice(-4)}` : 'ثبت‌شده'
        const { error } = await db.from('ai_secrets').upsert({ id: 1, groq_api_key: key, key_hint: hint, updated_at: new Date().toISOString() })
        if (error) throw new ProductError('server_error', 500, MSG.server_error)
        await db.from('ai_settings').update({ is_ai_enabled: true, updated_by: user.id }).eq('id', 1)
        // never echo the key back
        return json({ ok: true, hint })
      }

      case 'test_ai': {
        const settings = await loadSettings(db)
        const apiKey = await loadApiKey(db)
        if (!apiKey) return json({ ok: false, error: 'کلیدی ثبت نشده است.' })
        const prompt = String(body.prompt ?? '').trim() || 'در یک جمله کوتاه به فارسی بگو آماده‌ای.'
        const started = Date.now()
        try {
          const res = await complete({
            apiKey, model: settings.model, fallbackModel: settings.fallback_model,
            temperature: 0.3, maxTokens: 120,
            messages: [{ role: 'user', content: prompt }],
          })
          return json({ ok: true, model: res.model, reply: res.reply, latency_ms: Date.now() - started })
        } catch (e) {
          if (e instanceof ProductError) return json({ ok: false, error: e.message, code: e.code })
          throw e
        }
      }

      case 'revoke_subscription': {
        const id = String(body.subscription_id ?? '')
        if (!id) throw new ProductError('bad_request', 400, MSG.bad_request)
        const { error } = await db.from('subscriptions')
          .update({ status: 'cancelled', end_date: new Date().toISOString() }).eq('id', id)
        if (error) throw new ProductError('server_error', 500, MSG.server_error)
        return json({ ok: true })
      }

      case 'create_plans':
      case 'generate_next':
      case 'validate_lesson':
      case 'duplicates':
      case 'publish':
        return json({ ok: false, code: 'content_phase_not_started', error: NOT_YET }, 409)

      default:
        throw new ProductError('bad_request', 400, MSG.bad_request)
    }
  } catch (e) {
    return fail(e)
  }
}
