# LINGU · Edge Functions

سه تابع سمت سرور. کلید Groq، سقف مصرف و پرامپت‌ها فقط اینجا زندگی می‌کنند — هرگز در مرورگر یا Flutter.

| تابع | کار | مصرف‌کننده |
|---|---|---|
| `ai-chat` | مربی هوش مصنوعی (توضیح فارسی + تمرین در زبان مقصد) | `/app/tutor` |
| `conversation` | هم‌صحبت نقش‌محور (Roleplay) + سقف ۲ پیام رایگان | `/app/conversation` |
| `content-admin` | اکشن‌های مدیر: ذخیره/تست کلید، لغو اشتراک، (اکشن‌های محتوا در فاز بعد) | `/admin/ai`, `/admin/subscriptions` |

## قرارداد

هر سه تابع با `POST` کار می‌کنند و هدر `Authorization: Bearer <access_token>` کاربر را می‌خواهند.

```
ai-chat      ← { message, conversation_id?, lesson_id?, language?, level?, section? }
             → { reply, conversation_id, usage: { remaining } }

conversation ← { message, conversation_id?, scenario?, scenario_fa?, language?, level?, lesson_id? }
             → { reply, conversation_id, usage: { premium, partner_used, partner_remaining } }

content-admin ← { action: 'save_groq_key' | 'test_ai' | 'revoke_subscription' | … }
```

کدهای خطا (همیشه با پیام فارسی محصولی، هیچ‌وقت متن خام سرویس):

| کد | وضعیت | معنا |
|---|---|---|
| `unauthorized` | 401 / 403 | بدون ورود، یا کاربر مدیر نیست |
| `bad_request` | 400 / 405 | درخواست ناقص یا متد اشتباه |
| `tutor_requires_premium` | 403 | مربی AI ویژه Premium است |
| `partner_quota_exceeded` | 402 | ۲ پیام رایگان تمام شده → Premium Gate |
| `daily_limit_reached` | 429 | سقف روزانه Premium |
| `ai_disabled` | 503 | کلید ثبت نشده / AI خاموش است |
| `ai_unavailable` | 502 | سرویس AI موقتاً پاسخ نداد |
| `rate_limited` | 429 | درخواست‌ها زیاد شده |

## استقرار

```bash
# یک بار: ورود با توکن دسترسی Supabase
npx supabase login --token <SUPABASE_ACCESS_TOKEN>

# اتصال به پروژه
npx supabase link --project-ref <PROJECT_REF>

# استقرار سه تابع
npx supabase functions deploy ai-chat conversation content-admin

# ثبت کلید Groq به‌عنوان Secret سرور (جایگزین امن جدول ai_secrets)
npx supabase secrets set GROQ_API_KEY=<gsk_...>
```

> کلید را می‌توان از پنل مدیریت هم ثبت کرد (`Admin → تنظیمات AI`): در جدول سرور-محور `ai_secrets` ذخیره می‌شود و هیچ کلاینتی به آن دسترسی ندارد. اگر هم Secret و هم جدول مقدار داشته باشند، Secret اولویت دارد.

## تست محلی

```bash
# منطق تصمیم‌گیری و پرامپت‌ها (بدون سرور)
npx esbuild supabase/test/ai_logic_test.ts --bundle --format=esm --platform=node --outfile=/tmp/ai.mjs && node /tmp/ai.mjs

# اجرای واقعی هر سه handler با Supabase و Groq شبیه‌سازی‌شده
deno test --allow-net --allow-env --allow-read supabase/test/functions_test.ts
```
