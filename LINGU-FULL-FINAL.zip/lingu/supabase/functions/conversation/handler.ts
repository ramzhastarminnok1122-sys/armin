/**
 * LINGU · Edge Function `conversation` — the Conversation Partner (roleplay).
 *
 * Contract (client → server)
 *   { message: string, conversation_id?: string, scenario?: string, scenario_fa?: string,
 *     language?: 'en'|'fr'|'es', level?: string, lesson_id?: string|null }
 * Contract (server → client)
 *   200 { reply, conversation_id, usage: { partner_used, partner_remaining, premium } }
 *   401 unauthorized · 402 partner_quota_exceeded (free user, 2 messages used)
 *   429 daily_limit_reached (premium daily cap) · 503 ai_disabled · 502 ai_unavailable
 *
 * A free account gets `ai_settings.free_partner_messages` messages for good, then the
 * Premium gate — counted on the server from stored messages, so refresh/logout cannot reset it.
 */
import { fail, json, MSG, preflight, ProductError } from '../_shared/http.ts'
import { admin, isPremium, loadApiKey, loadSettings, requireUser } from '../_shared/context.ts'
import { assertAiAccess, buildPartnerSystemPrompt, cleanMessage, normalizeLanguage, normalizeLevel } from '../_shared/prompt.ts'
import { complete, trimHistory, type ChatTurn } from '../_shared/groq.ts'

export async function handler(req: Request): Promise<Response> {
  const pre = preflight(req)
  if (pre) return pre

  try {
    if (req.method !== 'POST') throw new ProductError('bad_request', 405, MSG.bad_request)

    const { db, user } = await requireUser(req)
    const body = await req.json().catch(() => ({})) as Record<string, unknown>

    const message = cleanMessage(body.message)
    const language = normalizeLanguage(body.language)
    const level = normalizeLevel(body.level)
    const scenario = typeof body.scenario === 'string' ? body.scenario : null
    const scenarioFa = typeof body.scenario_fa === 'string' ? body.scenario_fa : null
    const lessonId = typeof body.lesson_id === 'string' ? body.lesson_id : null

    const settings = await loadSettings(db)
    const premium = await isPremium(db, user.id)

    // partner quota = messages the user actually sent in partner conversations (server counted)
    const { data: partnerUsed } = await db.rpc('partner_messages_used', { uid: user.id })
    const { data: usedToday } = await db.rpc('daily_ai_used', { uid: user.id, p_feature: 'partner' })
    const used = Number(partnerUsed ?? 0)

    assertAiAccess({
      feature: 'partner',
      premium,
      aiEnabled: settings.is_ai_enabled,
      partnerUsed: used,
      partnerFreeLimit: settings.free_partner_messages,
      dailyUsed: Number(usedToday ?? 0),
      dailyLimit: settings.premium_daily_messages,
    })

    const apiKey = await loadApiKey(db)
    if (!apiKey) {
      console.error('[lingu] conversation: no Groq key configured')
      throw new ProductError('ai_disabled', 503, MSG.ai_disabled)
    }

    // ---- conversation row (scenario is decided on the first message and then locked to the row) ----
    let convId = typeof body.conversation_id === 'string' ? body.conversation_id : null
    let scene = scenario
    let sceneFa = scenarioFa
    if (convId) {
      const { data: conv } = await db.from('conversations').select('id,user_id,mode,scenario,scenario_fa')
        .eq('id', convId).maybeSingle()
      const row = conv as { user_id?: string; mode?: string; scenario?: string; scenario_fa?: string } | null
      if (!row || row.user_id !== user.id || row.mode !== 'partner') convId = null
      else { scene = row.scenario ?? scene; sceneFa = row.scenario_fa ?? sceneFa }
    }
    // history of the existing conversation (if any) — read before anything is written
    let history: ChatTurn[] = []
    if (convId) {
      const { data: rows } = await db.from('messages').select('role,content')
        .eq('conversation_id', convId).order('created_at', { ascending: true }).limit(40)
      history = trimHistory(((rows ?? []) as { role: string; content: string }[])
        .filter((r) => r.role === 'user' || r.role === 'assistant')
        .map((r) => ({ role: r.role as 'user' | 'assistant', content: r.content })))
    }

    const system = buildPartnerSystemPrompt({
      basePrompt: settings.partner_system_prompt,
      scenario: scene, scenarioFa: sceneFa, language, level,
    })

    // ---- the provider is called BEFORE anything is stored: if it fails, the user
    //      keeps their free message and we do not leave an empty conversation behind ----
    const started = Date.now()
    const result = await complete({
      apiKey,
      model: settings.model,
      fallbackModel: settings.fallback_model,
      temperature: Math.min(settings.temperature + 0.1, 1), // roleplay wants a little more freedom
      maxTokens: Math.min(settings.max_tokens, 700),
      messages: [{ role: 'system', content: system }, ...history, { role: 'user', content: message }],
    })

    // ---- the reply is in hand: now the conversation, both turns and the counters ----
    if (!convId) {
      const { data: created, error } = await db.from('conversations')
        .insert({
          user_id: user.id, mode: 'partner', scenario, scenario_fa: scenarioFa,
          lesson_id: lessonId, title: scenarioFa ?? scenario ?? 'Conversation Partner',
        })
        .select('id').single()
      if (error) throw new ProductError('server_error', 500, MSG.server_error)
      convId = (created as { id: string }).id
    }

    await db.from('messages').insert({ conversation_id: convId, user_id: user.id, role: 'user', content: message })
    await db.from('messages').insert({
      conversation_id: convId, user_id: user.id, role: 'assistant', content: result.reply,
      tokens: result.completionTokens,
    })
    await db.from('conversations').update({ message_count: history.length + 2, updated_at: new Date().toISOString() })
      .eq('id', convId)

    await db.from('ai_usage').insert({
      user_id: user.id, feature: 'partner', model: result.model,
      prompt_tokens: result.promptTokens, completion_tokens: result.completionTokens,
      latency_ms: Date.now() - started, ok: true,
    })
    await db.rpc('bump_ai_usage', { p_user: user.id, p_feature: 'partner' })

    const { data: after } = await db.rpc('partner_messages_used', { uid: user.id })
    const afterUsed = Number(after ?? used)
    return json({
      reply: result.reply,
      conversation_id: convId,
      usage: {
        premium,
        partner_used: afterUsed,
        partner_remaining: premium ? null : Math.max(settings.free_partner_messages - afterUsed, 0),
      },
    })
  } catch (e) {
    return fail(e)
  }
}
