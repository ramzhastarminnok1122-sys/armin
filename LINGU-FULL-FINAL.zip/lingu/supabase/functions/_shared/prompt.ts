/**
 * LINGU · prompt + access rules for the AI features.
 *
 * These functions are pure on purpose: no Deno, no network, no database.
 * The Edge Functions are thin adapters around them, so the behaviour (who may talk,
 * what the tutor is told, how levels are respected) can be tested without a server.
 */
import { MSG, ProductError } from './http.ts'

export const LANG_FA: Record<string, string> = {
  en: 'انگلیسی', fr: 'فرانسه', es: 'اسپانیایی',
}
export const LEVEL_FA: Record<string, string> = {
  A1: 'مبتدی', A2: 'پیش‌متوسط', B1: 'متوسط', B2: 'متوسط بالا', C1: 'پیشرفته',
}

export const DEFAULT_TUTOR_PROMPT = `تو «مربی هوش مصنوعی LINGU» هستی؛ یک معلم زبان حرفه‌ای، صبور و دقیق.
قواعد قطعی:
- توضیح‌ها و راهنماها را فارسی بده، اما مثال‌ها و تمرین‌ها را در زبان مقصد.
- همیشه سطح زبان‌آموز را رعایت کن: واژه و ساختار سخت‌تر از سطح او استفاده نکن.
- پاسخ‌ها کوتاه، ساخت‌یافته و قابل‌اجرا باشند (حداکثر ۳ تا ۵ خط یا فهرست کوتاه).
- در پایان، وقتی مناسب بود، یک تمرین کوچک یا یک جمله برای تکرار پیشنهاد بده.
- هرگز نگو که هوش مصنوعی، مدل یا سرویس فنی هستی و دربارهٔ زیرساخت صحبت نکن.`

export const DEFAULT_PARTNER_PROMPT = `تو «هم‌صحبت زبان LINGU» هستی؛ یک هم‌صحبت واقعی که نقش خود را باور کرده است.
قواعد قطعی:
- فقط در همان سناریو و در همان نقش بمان و مکالمه را طبیعی جلو ببر.
- در زبان مقصد حرف بزن، اما اگر کاربر در فارسی کمک خواست، کوتاه فارسی توضیح بده و بعد به نقش برگرد.
- سطح زبان‌آموز را رعایت کن؛ جمله‌ها کوتاه و طبیعی باشند.
- گاهی سؤال بپرس تا مکالمه ادامه پیدا کند و اگر جملهٔ کاربر غلط بود، در پایان پاسخ کوتاه اصلاحش کن.
- هرگز نگو که هوش مصنوعی، مدل یا سرویس فنی هستی.`

export type AccessInput = {
  feature: 'tutor' | 'partner'
  premium: boolean
  aiEnabled: boolean
  partnerUsed: number
  partnerFreeLimit: number
  dailyUsed: number
  dailyLimit: number
}

/**
 * Single place that decides whether a user may talk to the AI right now.
 * Throws the exact product error the interface already knows how to render.
 */
export function assertAiAccess(a: AccessInput): void {
  if (!a.aiEnabled) throw new ProductError('ai_disabled', 503, MSG.ai_disabled)

  if (!a.premium && a.feature === 'tutor') {
    throw new ProductError('tutor_requires_premium', 403, MSG.tutor_requires_premium)
  }
  if (!a.premium && a.feature === 'partner' && a.partnerUsed >= a.partnerFreeLimit) {
    throw new ProductError('partner_quota_exceeded', 402, MSG.partner_quota_exceeded)
  }
  if (a.premium && a.dailyUsed >= a.dailyLimit) {
    throw new ProductError('daily_limit_reached', 429, MSG.daily_limit_reached)
  }
}

export function buildTutorSystemPrompt(input: {
  basePrompt?: string | null
  language?: string | null
  level?: string | null
  lessonTitle?: string | null
  lessonSection?: string | null
}): string {
  const lang = LANG_FA[input.language ?? 'en'] ?? 'انگلیسی'
  const lvl = input.level ?? 'A1'
  const parts = [input.basePrompt?.trim() || DEFAULT_TUTOR_PROMPT]
  parts.push(`زبان مقصد: ${lang} (${input.language ?? 'en'}) · سطح زبان‌آموز: ${lvl} (${LEVEL_FA[lvl] ?? ''}).`)
  if (input.lessonTitle) {
    parts.push(`زبان‌آموز روی این درس کار می‌کند: «${input.lessonTitle}»${input.lessonSection ? ` — بخش: ${input.lessonSection}` : ''}.`)
    parts.push('توضیح‌ها و مثال‌ها را به همین درس و همین بخش گره بزن.')
  }
  return parts.join('\n')
}

export function buildPartnerSystemPrompt(input: {
  basePrompt?: string | null
  scenario?: string | null
  scenarioFa?: string | null
  language?: string | null
  level?: string | null
}): string {
  const lang = LANG_FA[input.language ?? 'en'] ?? 'انگلیسی'
  const lvl = input.level ?? 'A1'
  const scene = input.scenarioFa || input.scenario || 'مکالمه روزمره'
  const parts = [input.basePrompt?.trim() || DEFAULT_PARTNER_PROMPT]
  parts.push(`سناریو: «${scene}»${input.scenario ? ` (${input.scenario})` : ''}.`)
  parts.push(`زبان مقصد: ${lang} · سطح زبان‌آموز: ${lvl} (${LEVEL_FA[lvl] ?? ''}).`)
  parts.push('اولین جمله را خودت شروع کن و مکالمه را قدم‌به‌قدم جلو ببر.')
  return parts.join('\n')
}

/** Cheap guard against an empty or absurd request before any token is spent. */
export function cleanMessage(raw: unknown): string {
  const text = typeof raw === 'string' ? raw.trim() : ''
  if (!text) throw new ProductError('bad_request', 400, MSG.bad_request)
  return text.slice(0, 4000)
}

export function normalizeLevel(raw: unknown): string {
  const lvl = typeof raw === 'string' ? raw.toUpperCase() : ''
  return ['A1', 'A2', 'B1', 'B2', 'C1'].includes(lvl) ? lvl : 'A1'
}

export function normalizeLanguage(raw: unknown): string {
  const code = typeof raw === 'string' ? raw.toLowerCase() : ''
  return ['en', 'fr', 'es'].includes(code) ? code : 'en'
}
