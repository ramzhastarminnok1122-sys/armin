/**
 * LINGU · shared HTTP helpers for Edge Functions.
 * Nothing here ever leaks a technical detail to the user: every failure is mapped
 * to a product sentence in Persian plus a stable machine code for the client.
 */

export const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

export type ProductCode =
  | 'unauthorized'
  | 'bad_request'
  | 'ai_disabled'
  | 'tutor_requires_premium'
  | 'partner_quota_exceeded'
  | 'daily_limit_reached'
  | 'lesson_not_found'
  | 'ai_unavailable'
  | 'rate_limited'
  | 'server_error'

/** A failure that is safe (and useful) to show to a real user. */
export class ProductError extends Error {
  status: number
  code: ProductCode
  constructor(code: ProductCode, status: number, message: string) {
    super(message)
    this.code = code
    this.status = status
  }
}

/** Stable product messages — the single source of truth for AI surfaces. */
export const MSG: Record<ProductCode, string> = {
  unauthorized: 'برای استفاده از این بخش باید وارد حساب خودت شوی.',
  bad_request: 'درخواست کامل نبود. دوباره تلاش کن.',
  ai_disabled: 'مربی هوش مصنوعی فعلاً در دسترس نیست.',
  tutor_requires_premium: 'مربی هوش مصنوعی برای کاربران Premium فعال است.',
  partner_quota_exceeded: 'پیام‌های رایگان Conversation Partner تمام شده است. با اشتراک Premium بدون محدودیت ادامه بده.',
  daily_limit_reached: 'سقف استفاده امروز پر شده است. فردا ادامه بده.',
  lesson_not_found: 'این درس در دسترس نیست.',
  ai_unavailable: 'مربی هوش مصنوعی فعلاً در دسترس نیست. کمی بعد دوباره تلاش کن.',
  rate_limited: 'درخواست‌ها زیاد شده است. چند لحظه بعد دوباره تلاش کن.',
  server_error: 'مشکلی پیش آمد. کمی بعد دوباره تلاش کن.',
}

export function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json; charset=utf-8' },
  })
}

export function fail(e: unknown) {
  if (e instanceof ProductError) return json({ error: e.message, code: e.code }, e.status)
  // Never expose an upstream/technical message. Log it for the admin, answer in product language.
  console.error('[lingu] unhandled', e)
  return json({ error: MSG.server_error, code: 'server_error' }, 500)
}

export function preflight(req: Request) {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS })
  return null
}
