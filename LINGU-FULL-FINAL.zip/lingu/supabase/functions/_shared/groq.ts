/**
 * LINGU · Groq client (server-side only).
 * The provider name, the key and the raw provider errors never reach the client:
 * callers get either a plain string reply or a ProductError.
 */
import { MSG, ProductError } from './http.ts'

export type ChatTurn = { role: 'system' | 'user' | 'assistant'; content: string }

type GroqChoice = { message?: { content?: string } }
type GroqResponse = {
  choices?: GroqChoice[]
  usage?: { prompt_tokens?: number; completion_tokens?: number }
  error?: { message?: string }
}

export type CompletionResult = { reply: string; promptTokens: number; completionTokens: number; model: string }

const ENDPOINT = 'https://api.groq.com/openai/v1/chat/completions'

export async function complete(opts: {
  apiKey: string
  model: string
  fallbackModel?: string
  temperature: number
  maxTokens: number
  messages: ChatTurn[]
}): Promise<CompletionResult> {
  const models = [opts.model, opts.fallbackModel].filter(Boolean) as string[]
  let lastStatus = 0

  for (const model of models) {
    const res = await fetch(ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${opts.apiKey}`,
      },
      body: JSON.stringify({
        model,
        temperature: opts.temperature,
        max_tokens: opts.maxTokens,
        messages: opts.messages,
      }),
    })
    lastStatus = res.status

    if (res.status === 401 || res.status === 403) {
      // the key itself is wrong/revoked → the product says "not available", the admin sees the log
      console.error('[lingu] groq key rejected', res.status)
      throw new ProductError('ai_disabled', 503, MSG.ai_disabled)
    }
    if (res.status === 429) throw new ProductError('rate_limited', 429, MSG.rate_limited)
    if (res.status === 400) {
      const body = (await res.json().catch(() => ({}))) as GroqResponse
      console.error('[lingu] groq bad request', body?.error?.message)
      continue // often a model name issue → try the fallback model
    }
    if (!res.ok) continue

    const data = (await res.json().catch(() => ({}))) as GroqResponse
    const reply = data.choices?.[0]?.message?.content?.trim()
    if (!reply) continue
    return {
      reply,
      promptTokens: data.usage?.prompt_tokens ?? 0,
      completionTokens: data.usage?.completion_tokens ?? 0,
      model,
    }
  }

  console.error('[lingu] groq failed', lastStatus)
  throw new ProductError('ai_unavailable', 502, MSG.ai_unavailable)
}

/** Keep the conversation inside the context window without losing the newest turns. */
export function trimHistory(turns: ChatTurn[], maxTurns = 16): ChatTurn[] {
  const clean = turns
    .filter((t) => t && typeof t.content === 'string' && t.content.trim().length > 0 && t.role !== 'system')
    .map((t) => ({ role: t.role, content: t.content.slice(0, 2000) }))
  return clean.slice(-maxTurns)
}
