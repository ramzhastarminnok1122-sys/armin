/**
 * LINGU · Edge Function context.
 * Everything privileged (service role, Groq key, quota) stays on the server.
 * The browser only ever sends: authorization, a message, and lesson/scenario context.
 */
import { createClient, type SupabaseClient } from 'jsr:@supabase/supabase-js@2'
import { MSG, ProductError } from './http.ts'

export const SUPABASE_URL = Deno.env.get('SUPABASE_URL') ?? ''
/**
 * The privileged server key. Supabase still injects the legacy
 * SUPABASE_SERVICE_ROLE_KEY into Edge Functions; newer projects expose it as a
 * named secret in SUPABASE_SECRET_KEYS ({"default": "sb_secret_..."}). Accept
 * both so the same function code runs on old and new projects.
 */
function readServiceKey(): string {
  const legacy = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  if (legacy) return legacy
  try {
    const named = JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') ?? '{}') as Record<string, string>
    return named.default ?? Object.values(named)[0] ?? ''
  } catch {
    return ''
  }
}
const SERVICE_ROLE = readServiceKey()

/** Server-side client: bypasses RLS on purpose — every call below is user-scoped by hand. */
export function admin(): SupabaseClient {
  if (!SUPABASE_URL || !SERVICE_ROLE) throw new ProductError('server_error', 500, MSG.server_error)
  return createClient(SUPABASE_URL, SERVICE_ROLE, { auth: { persistSession: false } })
}

export type AiSettings = {
  model: string
  fallback_model: string
  temperature: number
  max_tokens: number
  tutor_system_prompt: string
  partner_system_prompt: string
  free_partner_messages: number
  premium_daily_messages: number
  premium_daily_tutor: number
  is_ai_enabled: boolean
}

export type Secret = { apiKey: string | null }

/** The signed-in user behind this request (verified against the Auth server, never trusted blindly). */
export async function requireUser(req: Request) {
  const token = req.headers.get('Authorization')?.replace(/^Bearer\s+/i, '') ?? ''
  if (!token) throw new ProductError('unauthorized', 401, MSG.unauthorized)
  const db = admin()
  const { data, error } = await db.auth.getUser(token)
  if (error || !data?.user) throw new ProductError('unauthorized', 401, MSG.unauthorized)
  return { db, user: data.user }
}

export async function loadSettings(db: SupabaseClient): Promise<AiSettings> {
  const { data } = await db.from('ai_settings').select('*').eq('id', 1).maybeSingle()
  const s = (data ?? {}) as Partial<AiSettings>
  return {
    model: s.model ?? 'llama-3.3-70b-versatile',
    fallback_model: s.fallback_model ?? 'llama-3.1-8b-instant',
    temperature: Number(s.temperature ?? 0.7),
    max_tokens: Number(s.max_tokens ?? 1200),
    tutor_system_prompt: s.tutor_system_prompt ?? '',
    partner_system_prompt: s.partner_system_prompt ?? '',
    free_partner_messages: Number(s.free_partner_messages ?? 2),
    premium_daily_messages: Number(s.premium_daily_messages ?? 200),
    premium_daily_tutor: Number(s.premium_daily_tutor ?? 200),
    is_ai_enabled: s.is_ai_enabled !== false,
  }
}

/** The Groq key lives in the server-only table `ai_secrets` (or in function secrets as a fallback). */
export async function loadApiKey(db: SupabaseClient): Promise<string | null> {
  const envKey = Deno.env.get('GROQ_API_KEY') ?? null
  if (envKey) return envKey
  const { data } = await db.from('ai_secrets').select('groq_api_key').eq('id', 1).maybeSingle()
  return (data as { groq_api_key?: string } | null)?.groq_api_key ?? null
}

export async function isPremium(db: SupabaseClient, userId: string): Promise<boolean> {
  const { data } = await db.rpc('has_active_premium', { uid: userId })
  if (typeof data === 'boolean') return data
  // fallback: profile role + subscription window
  const [{ data: prof }, { data: sub }] = await Promise.all([
    db.from('profiles').select('role').eq('id', userId).maybeSingle(),
    db.from('subscriptions').select('status,end_date').eq('user_id', userId).eq('status', 'active')
      .gt('end_date', new Date().toISOString()).maybeSingle(),
  ])
  return (prof as { role?: string } | null)?.role === 'admin' || Boolean(sub)
}
