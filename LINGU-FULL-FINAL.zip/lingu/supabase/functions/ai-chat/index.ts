/**
 * Deployment entry point — Supabase serves this module.
 * The logic lives in ./handler.ts so it can be tested without a server.
 */
import { handler } from './handler.ts'

Deno.serve(handler)
