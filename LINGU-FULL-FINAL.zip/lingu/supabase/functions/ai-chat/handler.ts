/**
 * LINGU · Edge Function `ai-chat`  — the AI Tutor.
 *
 * Contract (client → server)
 *   { message: string, conversation_id?: string, lesson_id?: string|null,
 *     language?: 'en'|'fr'|'es', level?: string, lessonTitle?: string, section?: string }
 * Contract (server → client)
 *   200 { reply, conversation_id, usage: { remaining } }
 *   401 unauthorized · 403 tutor_requires_premium · 429 daily_limit_reached
 *   503 ai_disabled (no key / disabled) · 502 ai_unavailable
 *
 * The Groq key, the quota and the system prompt live here — never in the browser.
 */
import { fail, json, MSG, preflight, ProductError } from '../_shared/http.ts'
import { admin, isPremium, loadApiKey, loadSettings, requireUser } from '../_shared/context.ts'
import { buildTutorSystemPrompt, assertAiAccess, cleanMessage, normalizeLanguage, normalizeLevel } from '../_shared/prompt.ts'
import { complete, trimHistory, type ChatTurn } from '../_shared/groq.ts'

export async function handler(req: Request): Promise<Response> {
  const pre = preflight(req)
  if (pre) return pre

  try {
    if (req.method !== 'POST') throw new ProductError('bad_request', 405, MSG.bad_request)

    const { db, user } = await requireUser(req)
    const body = await req.json().catch(() => ({})) as Record<string, unknown>

    const message = cleanMessage(body.message)
    const language = normalizeLanguage(body.language)
    const level = normalizeLevel(body.level)
    const lessonId = typeof body.lesson_id === 'string' ? body.lesson_id : null
    const conversationId = typeof body.conversation_id === 'string' ? body.conversation_id : null

    const settings = await loadSettings(db)

    // ---- access rules (server-side source of truth) ----
    const premium = await isPremium(db, user.id)
    const { data: usedToday } = await db.rpc('daily_ai_used', { uid: user.id, p_feature: 'tutor' })
    assertAiAccess({
      feature: 'tutor',
      premium,
      aiEnabled: settings.is_ai_enabled,
      partnerUsed: 0,
      partnerFreeLimit: settings.free_partner_messages,
      dailyUsed: Number(usedToday ?? 0),
      dailyLimit: settings.premium_daily_tutor,
    })

    // ---- key check happens AFTER the quota so a locked user gets a product answer, not a 503 ----
    const apiKey = await loadApiKey(db)
    if (!apiKey) {
      console.error('[lingu] ai-chat: no Groq key configured')
      throw new ProductError('ai_disabled', 503, MSG.ai_disabled)
    }

    // ---- lesson context (title + section come from the real lesson row, never from the client) ----
    let lessonTitle = typeof body.lessonTitle === 'string' ? body.lessonTitle : null
    let section = typeof body.section === 'string' ? body.section : null
    if (lessonId) {
      const { data: lesson } = await db.from('lessons').select('title,language_code,level,content')
        .eq('id', lessonId).maybeSingle()
      if (lesson) {
        lessonTitle = (lesson as any).title ?? lessonTitle
        section = section ?? (typeof (body.section) === 'string' ? body.section : null)
      }
    }

    // ---- conversation row: created on first message, always scoped to this user ----
    let convId = conversationId
    if (convId) {
      const { data: conv } = await db.from('conversations').select('id,user_id,mode').eq('id', convId).maybeSingle()
      if (!conv || (conv as any).user_id !== user.id) convId = null
      else if ((conv as any).mode !== 'tutor') convId = null
    }
    // ---- history comes from the database: the client cannot rewrite the past ----
    const history: ChatTurn[] = []
    if (convId) {
      const { data: rows } = await db.from('messages').select('role,content')
        .eq('conversation_id', convId).order('created_at', { ascending: true }).limit(40)
      history.push(...trimHistory(((rows ?? []) as { role: string; content: string }[])
        .filter((r) => r.role === 'user' || r.role === 'assistant')
        .map((r) => ({ role: r.role as 'user' | 'assistant', content: r.content }))))
    }

    const system = buildTutorSystemPrompt({
      basePrompt: settings.tutor_system_prompt,
      language, level, lessonTitle, lessonSection: section,
    })

    // ---- the provider is called BEFORE anything is stored: a provider outage must not
    //      consume a lesson-quota message nor leave an empty conversation behind ----
    const started = Date.now()
    const result = await complete({
      apiKey,
      model: settings.model,
      fallbackModel: settings.fallback_model,
      temperature: settings.temperature,
      maxTokens: settings.max_tokens,
      messages: [{ role: 'system', content: system }, ...history, { role: 'user', content: message }],
    })

    // ---- the reply is in hand: persist the conversation, both turns and the counters ----
    if (!convId) {
      const { data: created, error } = await db.from('conversations')
        .insert({ user_id: user.id, mode: 'tutor', lesson_id: lessonId, title: lessonTitle ?? 'گفت‌وگو با AI Tutor' })
        .select('id').single()
      if (error) throw new ProductError('server_error', 500, MSG.server_error)
      convId = (created as { id: string }).id
    }

    await db.from('messages').insert({ conversation_id: convId, user_id: user.id, role: 'user', content: message })
    await db.from('messages').insert({
      conversation_id: convId, user_id: user.id, role: 'assistant', content: result.reply,
      tokens: result.completionTokens,
    })
    await db.from('conversations').update({ message_count: (history.length + 2), updated_at: new Date().toISOString() })
      .eq('id', convId)

    // ---- usage accounting: one row per request + a daily counter the admin can read ----
    await db.from('ai_usage').insert({
      user_id: user.id, feature: 'tutor', model: result.model,
      prompt_tokens: result.promptTokens, completion_tokens: result.completionTokens,
      latency_ms: Date.now() - started, ok: true,
    })
    await db.rpc('bump_ai_usage', { p_user: user.id, p_feature: 'tutor' })

    const { data: after } = await db.rpc('daily_ai_used', { uid: user.id, p_feature: 'tutor' })
    return json({
      reply: result.reply,
      conversation_id: convId,
      usage: { remaining: premium ? Math.max(settings.premium_daily_tutor - Number(after ?? 0), 0) : 0 },
    })
  } catch (e) {
    return fail(e)
  }
}
