-- ============================================================
-- LINGU · SUPABASE SETUP (single file)
-- 1) Paste this whole file into Supabase → SQL Editor → New query → Run.
--    It is idempotent: running it twice is safe.
-- 2) Generated from supabase/migrations/*.sql (identical content, in order).
-- ============================================================

-- >>>>>>>>>> supabase/migrations/0001_foundation.sql
-- ============================================================
-- LINGU · 0001 · Foundation: enums, helpers, triggers
-- ============================================================
create extension if not exists "pgcrypto";
create extension if not exists "citext";

-- ---------- enums ----------
do $$ begin create type app_role as enum ('user','admin'); exception when duplicate_object then null; end $$;
do $$ begin create type lesson_status as enum ('draft','generated','validated','published','failed'); exception when duplicate_object then null; end $$;
do $$ begin create type plan_status as enum ('planned','generating','generated','failed'); exception when duplicate_object then null; end $$;
do $$ begin create type subscription_status as enum ('pending','active','expired','cancelled','refunded'); exception when duplicate_object then null; end $$;
do $$ begin create type progress_status as enum ('started','completed'); exception when duplicate_object then null; end $$;
do $$ begin create type ai_feature as enum ('tutor','partner'); exception when duplicate_object then null; end $$;
do $$ begin create type msg_role as enum ('user','assistant','system'); exception when duplicate_object then null; end $$;
do $$ begin create type batch_status as enum ('idle','planning','generating','validating','completed','failed','cancelled'); exception when duplicate_object then null; end $$;

-- ---------- updated_at helper ----------
create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ---------- premium check (single source of truth) ----------
-- NOTE: plpgsql (not sql) on purpose — a plain SQL body is validated at CREATE time,
-- and `subscriptions` is created a step later in 0002. plpgsql resolves at first call.
create or replace function public.has_active_premium(uid uuid)
returns boolean
language plpgsql stable security definer set search_path = public as $$
begin
  return exists (
    select 1 from subscriptions s
    where s.user_id = uid and s.status = 'active' and s.end_date > now()
  );
end $$;

-- ---------- admin check (SECURITY DEFINER => no RLS recursion) ----------
create or replace function public.is_admin()
returns boolean
language plpgsql stable security definer set search_path = public as $$
begin
  return exists (
    select 1 from profiles p
    where p.id = auth.uid() and p.role = 'admin' and p.is_active = true
  );
end $$;

-- ---------- first user becomes admin (bootstrap), rest are normal users ----------
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_is_first boolean;
begin
  select not exists (select 1 from profiles) into v_is_first;

  insert into profiles (id, display_name, role, is_active)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)),
    case when v_is_first then 'admin'::app_role else 'user'::app_role end,
    true
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- de-duplication helper for lessons ----------
create or replace function public.lesson_fingerprint(p_language text, p_level text, p_title text)
returns text language sql immutable as $$
  select md5(lower(regexp_replace(coalesce(p_language,'') || '|' || coalesce(p_level,'') || '|' || coalesce(p_title,''), '\s+', '', 'g')));
$$;

-- >>>>>>>>>> supabase/migrations/0002_core.sql
-- ============================================================
-- LINGU · 0002 · Core: profiles, settings, theme, languages,
--                 plans, subscriptions, purchases
-- ============================================================

create table if not exists public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  display_name  text,
  avatar_url    text,
  role          app_role not null default 'user',
  is_active     boolean not null default true,
  tour_done     boolean not null default false,
  locale        text not null default 'fa',
  last_seen_at  timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
drop trigger if exists trg_profiles_touch on public.profiles;
create trigger trg_profiles_touch before update on public.profiles for each row execute function public.touch_updated_at();

-- ---------- key/value app settings (banners flag, general copy, limits) ----------
create table if not exists public.app_settings (
  key         text primary key,
  value       jsonb not null default '{}'::jsonb,
  description text,
  updated_at  timestamptz not null default now()
);
drop trigger if exists trg_app_settings_touch on public.app_settings;
create trigger trg_app_settings_touch before update on public.app_settings for each row execute function public.touch_updated_at();

-- ---------- theme (single row, applied at runtime => no redeploy) ----------
create table if not exists public.theme_settings (
  id           int primary key default 1 check (id = 1),
  mode         text not null default 'dark',
  -- `primary` is a reserved word in PostgreSQL → always quoted. The API/JSON key stays "primary".
  "primary"    text not null default '#7C6CFF',
  secondary    text not null default '#5B8CFF',
  accent       text not null default '#22D3EE',
  background   text not null default '#0A0B14',
  background_soft text not null default '#101223',
  card         text not null default '#151731',
  card_soft    text not null default '#1B1E3D',
  text         text not null default '#F4F5FF',
  text_muted   text not null default '#A7ACD4',
  line         text not null default '#282C52',
  radius       int  not null default 20,
  updated_at   timestamptz not null default now()
);
create or replace function public.theme_public() returns jsonb
language sql stable security definer set search_path = public as $$
  select to_jsonb(t) - 'updated_at' from theme_settings t where t.id = 1;
$$;

-- ---------- languages ----------
create table if not exists public.languages (
  code        text primary key,              -- en | fr | es
  name_fa     text not null,
  name_en     text not null,
  native_name text not null,
  flag        text not null default '🌍',
  gradient    text not null default 'from-indigo-500 to-cyan-400',
  description text,
  target_lessons int not null default 340,
  is_active   boolean not null default true,
  sort_order  int not null default 0,
  created_at  timestamptz not null default now()
);

-- ---------- plans (SKU duration lives in the DB, not in the app) ----------
create table if not exists public.plans (
  id             uuid primary key default gen_random_uuid(),
  code           text unique not null,              -- free | monthly | quarterly | yearly
  title_fa       text not null,
  subtitle_fa    text,
  description_fa text,
  sku            text,                              -- Myket product SKU (null for Free)
  duration_days  int not null default 0,
  display_price  bigint not null default 0,         -- Rial, display only
  price_label    text,                              -- optional override label
  badge          text,
  features       jsonb not null default '[]'::jsonb,
  is_active      boolean not null default true,
  is_recommended boolean not null default false,
  sort_order     int not null default 0,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
drop trigger if exists trg_plans_touch on public.plans;
create trigger trg_plans_touch before update on public.plans for each row execute function public.touch_updated_at();

-- ---------- subscriptions ----------
create table if not exists public.subscriptions (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references auth.users(id) on delete cascade,
  plan_id        uuid references public.plans(id) on delete set null,
  sku            text not null,
  status         subscription_status not null default 'pending',
  start_date     timestamptz not null default now(),
  end_date       timestamptz not null,
  purchase_token text,
  provider       text not null default 'myket',
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists idx_subscriptions_user on public.subscriptions(user_id, end_date desc);
drop trigger if exists trg_subscriptions_touch on public.subscriptions;
create trigger trg_subscriptions_touch before update on public.subscriptions for each row execute function public.touch_updated_at();

-- ---------- purchases (raw verification trail) ----------
create table if not exists public.purchases (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references auth.users(id) on delete cascade,
  sku            text not null,
  purchase_token text not null,
  order_id       text,
  status         text not null default 'pending',
  provider       text not null default 'myket',
  raw            jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  verified_at    timestamptz
);
create unique index if not exists uq_purchases_token on public.purchases(purchase_token);

-- ---------- myket product catalog (admin editable, real SKUs) ----------
create table if not exists public.myket_products (
  id           uuid primary key default gen_random_uuid(),
  sku          text unique not null,
  title_fa     text not null,
  duration_days int not null,
  price_rial   bigint,
  is_active    boolean not null default true,
  sort_order   int not null default 0,
  created_at   timestamptz not null default now()
);

-- >>>>>>>>>> supabase/migrations/0003_lessons.sql
-- ============================================================
-- LINGU · 0003 · Curriculum, Lesson Plans, Lessons, Content Factory
-- ============================================================

create table if not exists public.curricula (
  id           uuid primary key default gen_random_uuid(),
  language_code text not null references languages(code) on delete cascade,
  level        text not null,                    -- A1 | A2 | B1 | B2
  title_fa     text not null,
  summary_fa   text,
  target_lessons int not null default 40,
  is_active    boolean not null default true,
  created_by   uuid references auth.users(id) on delete set null,
  created_at   timestamptz not null default now()
);

-- ---------- generation batches (the Content Factory job header) ----------
create table if not exists public.content_batches (
  id            uuid primary key default gen_random_uuid(),
  curriculum_id uuid references public.curricula(id) on delete set null,
  language_code text not null,
  level         text not null,
  requested     int not null default 10,
  succeeded     int not null default 0,
  failed        int not null default 0,
  status        batch_status not null default 'idle',
  model         text,
  last_error    text,
  created_by    uuid references auth.users(id) on delete set null,
  started_at    timestamptz,
  finished_at   timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
drop trigger if exists trg_batches_touch on public.content_batches;
create trigger trg_batches_touch before update on public.content_batches for each row execute function public.touch_updated_at();

-- ---------- lesson plans (Curriculum -> Lesson Plan -> Generation) ----------
create table if not exists public.lesson_plans (
  id            uuid primary key default gen_random_uuid(),
  curriculum_id uuid references public.curricula(id) on delete cascade,
  batch_id      uuid references public.content_batches(id) on delete set null,
  language_code text not null,
  level         text not null,
  order_index   int not null default 1,
  title         text not null,
  topic         text,
  objectives    jsonb not null default '[]'::jsonb,
  target_vocab  jsonb not null default '[]'::jsonb,
  grammar_focus text,
  status        plan_status not null default 'planned',
  attempts      int not null default 0,
  last_error    text,
  fingerprint   text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists idx_plans_lang on public.lesson_plans(language_code, level, order_index);
drop trigger if exists trg_plans_touch2 on public.lesson_plans;
create trigger trg_plans_touch2 before update on public.lesson_plans for each row execute function public.touch_updated_at();

-- ---------- lessons ----------
create table if not exists public.lessons (
  id            uuid primary key default gen_random_uuid(),
  plan_id       uuid references public.lesson_plans(id) on delete set null,
  batch_id      uuid references public.content_batches(id) on delete set null,
  language_code text not null references languages(code) on delete cascade,
  level         text not null default 'A1',
  order_index   int not null default 1,
  title         text not null,
  subtitle      text,
  description   text,
  estimated_minutes int not null default 15,
  status        lesson_status not null default 'draft',
  is_free       boolean not null default false,
  content       jsonb not null default '{}'::jsonb,   -- full lesson body (sections)
  validation    jsonb not null default '{}'::jsonb,   -- last validation report
  fingerprint   text,
  version       int not null default 1,
  published_at  timestamptz,
  created_by    uuid references auth.users(id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create unique index if not exists uq_lessons_fingerprint on public.lessons(fingerprint);
create index if not exists idx_lessons_lang_status on public.lessons(language_code, status, order_index);
drop trigger if exists trg_lessons_touch on public.lessons;
create trigger trg_lessons_touch before update on public.lessons for each row execute function public.touch_updated_at();

create or replace function public.set_lesson_fingerprint() returns trigger
language plpgsql as $$
begin
  if new.fingerprint is null then
    new.fingerprint := public.lesson_fingerprint(new.language_code, new.level, new.title);
  end if;
  return new;
end $$;
drop trigger if exists trg_lessons_fp on public.lessons;
create trigger trg_lessons_fp before insert or update of title, level, language_code on public.lessons
  for each row execute function public.set_lesson_fingerprint();

-- ---------- progress ----------
create table if not exists public.user_progress (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references auth.users(id) on delete cascade,
  lesson_id     uuid not null references public.lessons(id) on delete cascade,
  status        progress_status not null default 'started',
  last_section  text,
  sections_done jsonb not null default '[]'::jsonb,
  score         int,
  time_spent_sec int not null default 0,
  started_at    timestamptz not null default now(),
  completed_at  timestamptz,
  updated_at    timestamptz not null default now(),
  unique (user_id, lesson_id)
);
create index if not exists idx_progress_user on public.user_progress(user_id, updated_at desc);
drop trigger if exists trg_progress_touch on public.user_progress;
create trigger trg_progress_touch before update on public.user_progress for each row execute function public.touch_updated_at();

-- ---------- free lesson quota per language (2) ----------
create or replace function public.free_lessons_per_language()
returns int language sql stable security definer set search_path = public as $$
  select coalesce((select (value->>'free_lessons_per_language')::int from app_settings where key = 'learning'), 2);
$$;

-- >>>>>>>>>> supabase/migrations/0004_ai.sql
-- ============================================================
-- LINGU · 0004 · AI: settings, secrets, conversations, usage
-- ============================================================

-- Admin-facing AI settings (NO secret here)
create table if not exists public.ai_settings (
  id                  int primary key default 1 check (id = 1),
  provider            text not null default 'groq',
  model               text not null default 'openai/gpt-oss-120b',
  fallback_model      text not null default 'openai/gpt-oss-20b',
  temperature         numeric(3,2) not null default 0.70,
  max_tokens          int not null default 1200,
  tutor_system_prompt text not null default '',
  partner_system_prompt text not null default '',
  free_partner_messages int not null default 2,
  premium_daily_messages int not null default 200,
  premium_daily_tutor int not null default 200,
  is_ai_enabled       boolean not null default true,
  updated_at          timestamptz not null default now(),
  updated_by          uuid references auth.users(id) on delete set null
);
drop trigger if exists trg_ai_settings_touch on public.ai_settings;
create trigger trg_ai_settings_touch before update on public.ai_settings for each row execute function public.touch_updated_at();

-- Server-only secret store. No client role can ever read this table.
create table if not exists public.ai_secrets (
  id           int primary key default 1 check (id = 1),
  groq_api_key text,
  key_hint     text,          -- e.g. "gsk_...AB12" (safe to show in admin)
  updated_at   timestamptz not null default now()
);

-- AI usage log (tokens + who + which feature)
create table if not exists public.ai_usage (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid references auth.users(id) on delete set null,
  feature       ai_feature not null,
  model         text,
  prompt_tokens int not null default 0,
  completion_tokens int not null default 0,
  latency_ms    int,
  ok            boolean not null default true,
  error         text,
  created_at    timestamptz not null default now()
);
create index if not exists idx_ai_usage_created on public.ai_usage(created_at desc);
create index if not exists idx_ai_usage_user on public.ai_usage(user_id, created_at desc);

-- Conversations (AI Tutor + Conversation Partner)
create table if not exists public.conversations (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  mode        ai_feature not null,
  scenario    text,
  scenario_fa text,
  title       text,
  lesson_id   uuid references public.lessons(id) on delete set null,
  message_count int not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists idx_conversations_user on public.conversations(user_id, updated_at desc);
drop trigger if exists trg_conversations_touch on public.conversations;
create trigger trg_conversations_touch before update on public.conversations for each row execute function public.touch_updated_at();

create table if not exists public.messages (
  id              uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id         uuid not null references auth.users(id) on delete cascade,
  role            msg_role not null,
  content         text not null,
  tokens          int not null default 0,
  created_at      timestamptz not null default now()
);
create index if not exists idx_messages_conv on public.messages(conversation_id, created_at);

-- ---------- quota accounting (server-side source of truth) ----------
create or replace function public.partner_messages_used(uid uuid)
returns int language sql stable security definer set search_path = public as $$
  select count(*)::int
  from messages m
  join conversations c on c.id = m.conversation_id
  where m.user_id = uid and m.role = 'user' and c.mode = 'partner';
$$;

create or replace function public.daily_ai_used(uid uuid, p_feature ai_feature)
returns int language sql stable security definer set search_path = public as $$
  select count(*)::int from ai_usage
  where user_id = uid and feature = p_feature and ok = true and created_at > now() - interval '1 day';
$$;

-- ---------- AI quota snapshot for the current user ----------
create or replace function public.my_ai_quota()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  s public.ai_settings;
  v_premium boolean;
begin
  if uid is null then return jsonb_build_object('authenticated', false); end if;
  select * into s from ai_settings where id = 1;
  v_premium := public.has_active_premium(uid) or public.is_admin();
  return jsonb_build_object(
    'authenticated', true,
    'premium', v_premium,
    'free_partner_limit', coalesce(s.free_partner_messages, 2),
    'partner_used', public.partner_messages_used(uid),
    'partner_remaining', case when v_premium then null else greatest(coalesce(s.free_partner_messages,2) - public.partner_messages_used(uid), 0) end,
    'tutor_remaining', case when v_premium then null else 0 end,
    'premium_daily_messages', coalesce(s.premium_daily_messages, 200),
    'ai_enabled', coalesce(s.is_ai_enabled, true)
  );
end $$;

-- >>>>>>>>>> supabase/migrations/0005_marketing.sql
-- ============================================================
-- LINGU · 0005 · Public content: FAQ, Testimonials, Banners, Audit log
-- ============================================================

create table if not exists public.faqs (
  id          uuid primary key default gen_random_uuid(),
  question    text not null,
  answer      text not null,
  category    text not null default 'general',
  is_published boolean not null default true,
  sort_order  int not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
drop trigger if exists trg_faqs_touch on public.faqs;
create trigger trg_faqs_touch before update on public.faqs for each row execute function public.touch_updated_at();

create table if not exists public.testimonials (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  role        text,
  quote       text not null,
  avatar_url  text,
  rating      int not null default 5 check (rating between 1 and 5),
  is_published boolean not null default true,
  sort_order  int not null default 0,
  created_at  timestamptz not null default now()
);

create table if not exists public.banners (
  id          uuid primary key default gen_random_uuid(),
  title       text not null,
  body        text,
  cta_label   text,
  cta_url     text,
  image_url   text,
  tone        text not null default 'primary',
  placement   text not null default 'user_home',
  is_active   boolean not null default true,
  starts_at   timestamptz,
  ends_at     timestamptz,
  sort_order  int not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
drop trigger if exists trg_banners_touch on public.banners;
create trigger trg_banners_touch before update on public.banners for each row execute function public.touch_updated_at();

create table if not exists public.audit_log (
  id          bigserial primary key,
  actor_id    uuid references auth.users(id) on delete set null,
  action      text not null,
  entity      text,
  entity_id   text,
  meta        jsonb not null default '{}'::jsonb,
  created_at  timestamptz not null default now()
);
create index if not exists idx_audit_created on public.audit_log(created_at desc);

-- ---------- admin dashboard counters (real numbers, one round-trip) ----------
create or replace function public.admin_dashboard()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = '42501'; end if;
  return jsonb_build_object(
    'users_total',        (select count(*) from profiles),
    'users_active_7d',    (select count(*) from profiles where coalesce(last_seen_at, created_at) > now() - interval '7 days'),
    'users_new_7d',       (select count(*) from profiles where created_at > now() - interval '7 days'),
    'premium_users',      (select count(*) from subscriptions where status='active' and end_date > now()),
    'lessons_total',      (select count(*) from lessons),
    'lessons_published',  (select count(*) from lessons where status='published'),
    'lessons_draft',      (select count(*) from lessons where status in ('draft','generated','validated')),
    'lessons_failed',     (select count(*) from lessons where status='failed'),
    'plans_failed',       (select count(*) from lesson_plans where status='failed'),
    'ai_calls_24h',       (select count(*) from ai_usage where created_at > now() - interval '1 day'),
    'ai_tokens_24h',      (select coalesce(sum(prompt_tokens + completion_tokens),0) from ai_usage where created_at > now() - interval '1 day'),
    'ai_calls_total',     (select count(*) from ai_usage),
    'ai_errors_24h',      (select count(*) from ai_usage where ok = false and created_at > now() - interval '1 day'),
    'active_subs',        (select count(*) from subscriptions where status='active' and end_date > now()),
    'recent_users',       coalesce((
      select jsonb_agg(x) from (
        select p.id, p.display_name, p.role, p.created_at,
               (select exists(select 1 from subscriptions s where s.user_id = p.id and s.status='active' and s.end_date > now())) as premium
        from profiles p order by p.created_at desc limit 6
      ) x), '[]'::jsonb),
    'lessons_by_language', coalesce((
      select jsonb_object_agg(language_code, c) from (
        select language_code, count(*) c from lessons group by language_code
      ) y), '{}'::jsonb),
    'signups_14d', coalesce((
      select jsonb_agg(jsonb_build_object('day', d::date, 'count', coalesce(cnt,0)) order by d)
      from generate_series(now()::date - interval '13 days', now()::date, interval '1 day') d
      left join (
        select created_at::date dd, count(*) cnt from profiles
        where created_at > now() - interval '14 days' group by 1
      ) z on z.dd = d::date
    ), '[]'::jsonb)
  );
end $$;

-- >>>>>>>>>> supabase/migrations/0006_rls.sql
-- ============================================================
-- LINGU · 0006 · Row Level Security
-- Principle: clients may only read what they own; every write
-- that affects money, AI quota or role is server-side only.
-- ============================================================

alter table public.profiles        enable row level security;
alter table public.app_settings    enable row level security;
alter table public.theme_settings  enable row level security;
alter table public.languages       enable row level security;
alter table public.plans           enable row level security;
alter table public.subscriptions   enable row level security;
alter table public.purchases       enable row level security;
alter table public.myket_products  enable row level security;
alter table public.curricula       enable row level security;
alter table public.content_batches enable row level security;
alter table public.lesson_plans    enable row level security;
alter table public.lessons         enable row level security;
alter table public.user_progress   enable row level security;
alter table public.ai_settings     enable row level security;
alter table public.ai_secrets      enable row level security;
alter table public.ai_usage        enable row level security;
alter table public.conversations   enable row level security;
alter table public.messages        enable row level security;
alter table public.faqs            enable row level security;
alter table public.testimonials    enable row level security;
alter table public.banners         enable row level security;
alter table public.audit_log       enable row level security;

-- no client policy on ai_secrets at all => only service_role (edge functions) can touch it
revoke all on public.ai_secrets from anon, authenticated;

-- ---------- profiles ----------
drop policy if exists profiles_self_read on public.profiles;
create policy profiles_self_read on public.profiles for select using (id = auth.uid() or public.is_admin());
drop policy if exists profiles_self_update on public.profiles;
create policy profiles_self_update on public.profiles for update
  using (id = auth.uid() or public.is_admin())
  with check (id = auth.uid() or public.is_admin());

-- ---------- public reads ----------
drop policy if exists theme_public_read on public.theme_settings;
create policy theme_public_read on public.theme_settings for select using (true);
drop policy if exists theme_admin_write on public.theme_settings;
create policy theme_admin_write on public.theme_settings for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists settings_public_read on public.app_settings;
create policy settings_public_read on public.app_settings for select using (true);
drop policy if exists settings_admin_write on public.app_settings;
create policy settings_admin_write on public.app_settings for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists languages_public_read on public.languages;
create policy languages_public_read on public.languages for select using (is_active or public.is_admin());
drop policy if exists languages_admin_write on public.languages;
create policy languages_admin_write on public.languages for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists plans_public_read on public.plans;
create policy plans_public_read on public.plans for select using (is_active or public.is_admin());
drop policy if exists plans_admin_write on public.plans;
create policy plans_admin_write on public.plans for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists faqs_public_read on public.faqs;
create policy faqs_public_read on public.faqs for select using (is_published or public.is_admin());
drop policy if exists faqs_admin_write on public.faqs;
create policy faqs_admin_write on public.faqs for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists testi_public_read on public.testimonials;
create policy testi_public_read on public.testimonials for select using (is_published or public.is_admin());
drop policy if exists testi_admin_write on public.testimonials;
create policy testi_admin_write on public.testimonials for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists banners_public_read on public.banners;
create policy banners_public_read on public.banners for select using (
  public.is_admin() or (is_active and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at >= now()))
);
drop policy if exists banners_admin_write on public.banners;
create policy banners_admin_write on public.banners for all using (public.is_admin()) with check (public.is_admin());

-- ---------- lessons ----------
drop policy if exists lessons_read on public.lessons;
create policy lessons_read on public.lessons for select using (
  public.is_admin()
  or (
    status = 'published'
    and (
      is_free = true
      or public.has_active_premium(auth.uid())
    )
  )
);
drop policy if exists lessons_admin_write on public.lessons;
create policy lessons_admin_write on public.lessons for all using (public.is_admin()) with check (public.is_admin());

-- public catalogue of all published lessons (metadata only, no premium body)
create or replace function public.published_catalog()
returns table (
  id uuid, language_code text, level text, order_index int, title text,
  subtitle text, description text, estimated_minutes int, is_free boolean, locked boolean, completed boolean
) language sql stable security definer set search_path = public as $$
  select l.id, l.language_code, l.level, l.order_index, l.title, l.subtitle, l.description,
         l.estimated_minutes, l.is_free,
         not (l.is_free or public.has_active_premium(auth.uid()) or public.is_admin()) as locked,
         coalesce((select up.status = 'completed' from user_progress up where up.user_id = auth.uid() and up.lesson_id = l.id), false) as completed
  from lessons l
  where l.status = 'published'
  order by l.language_code, l.order_index;
$$;

-- ---------- progress ----------
drop policy if exists progress_read on public.user_progress;
create policy progress_read on public.user_progress for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists progress_write on public.user_progress;
create policy progress_write on public.user_progress for insert with check (user_id = auth.uid());
drop policy if exists progress_update on public.user_progress;
create policy progress_update on public.user_progress for update using (true) with check (user_id = auth.uid());
drop policy if exists progress_delete on public.user_progress;
create policy progress_delete on public.user_progress for delete using (user_id = auth.uid() or public.is_admin());

-- ---------- subscriptions: read-only for the owner, writes are service-role only ----------
drop policy if exists subs_read_own on public.subscriptions;
create policy subs_read_own on public.subscriptions for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists purchases_read_own on public.purchases;
create policy purchases_read_own on public.purchases for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists myket_read on public.myket_products;
create policy myket_read on public.myket_products for select using (true);
drop policy if exists myket_admin_write on public.myket_products;
create policy myket_admin_write on public.myket_products for all using (public.is_admin()) with check (public.is_admin());

-- ---------- content factory: admin only ----------
drop policy if exists curricula_admin on public.curricula;
create policy curricula_admin on public.curricula for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists batches_admin on public.content_batches;
create policy batches_admin on public.content_batches for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists plans_admin on public.lesson_plans;
create policy plans_admin on public.lesson_plans for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists audit_admin on public.audit_log;
create policy audit_admin on public.audit_log for select using (public.is_admin());

-- ---------- AI ----------
drop policy if exists ai_settings_read on public.ai_settings;
create policy ai_settings_read on public.ai_settings for select using (public.is_admin());
drop policy if exists ai_settings_admin on public.ai_settings;
create policy ai_settings_admin on public.ai_settings for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists ai_usage_own on public.ai_usage;
create policy ai_usage_own on public.ai_usage for select using (user_id = auth.uid() or public.is_admin());

drop policy if exists conv_own on public.conversations;
create policy conv_own on public.conversations for all using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid());
drop policy if exists msg_own on public.messages;
create policy msg_own on public.messages for all using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid());

-- ---------- hard guards (a client can never promote itself or a paid tier) ----------
create or replace function public.guard_profile_columns() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() then return new; end if;
  if new.role is distinct from old.role then
    raise exception 'forbidden: role change requires admin' using errcode = '42501';
  end if;
  if new.is_active is distinct from old.is_active then
    raise exception 'forbidden: account status change requires admin' using errcode = '42501';
  end if;
  return new;
end $$;
drop trigger if exists trg_guard_profile on public.profiles;
create trigger trg_guard_profile before update on public.profiles
  for each row execute function public.guard_profile_columns();

create or replace function public.guard_subscription_writes() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if current_setting('request.jwt.claim.role', true) in ('anon','authenticated') and not public.is_admin() then
    raise exception 'forbidden: subscriptions are written by the server only' using errcode = '42501';
  end if;
  return coalesce(new, old);
end $$;
drop trigger if exists trg_guard_subs on public.subscriptions;
create trigger trg_guard_subs before insert or update or delete on public.subscriptions
  for each row execute function public.guard_subscription_writes();

-- >>>>>>>>>> supabase/migrations/0007_seed.sql
-- ============================================================
-- LINGU · 0007 · Seed: languages, settings, theme, plans, marketing, AI
-- Idempotent: safe to run more than once.
-- ============================================================

insert into public.languages (code, name_fa, name_en, native_name, flag, gradient, description, target_lessons, sort_order) values
 ('en','انگلیسی','English','English','🇬🇧','from-indigo-500 via-blue-500 to-cyan-400','زبان جهانی کار، سفر و اینترنت — از مکالمه روزمره تا مصاحبه کاری.',340,1),
 ('fr','فرانسه','French','Français','🇫🇷','from-rose-500 via-pink-500 to-indigo-400','زبان فرهنگ، هنر و تحصیل در اروپا — با تلفظ روان و ساختار دقیق.',340,2),
 ('es','اسپانیایی','Spanish','Español','🇪🇸','from-amber-400 via-orange-500 to-rose-500','پرجمعیت‌ترین زبان مادری جهان — سریع، موزیکال و کاربردی.',340,3)
on conflict (code) do update set name_fa = excluded.name_fa, description = excluded.description, flag = excluded.flag, gradient = excluded.gradient;

insert into public.app_settings (key, value, description) values
 ('general', $j${"app_name":"LINGU","tagline":"یادگیری زبان، هوشمند و واقعی","support_email":"support@lingu.app","show_banners":true,"maintenance_mode":false}$j$::jsonb, 'تنظیمات عمومی سایت'),
 ('learning', $j${"free_lessons_per_language":2,"free_conversation_messages":2,"target_lessons_per_language":340}$j$::jsonb, 'قواعد دسترسی رایگان'),
 ('myket', $j${"package_name":"","public_key":"","enabled":false}$j$::jsonb, 'تنظیمات پرداخت میکت (کلید عمومی از پنل توسعه‌دهنده)'),
 ('features', $j${"ai_tutor":true,"conversation_partner":true,"progress":true,"subscription":true,"certificates":false}$j$::jsonb, 'فعال/غیرفعال بودن قابلیت‌ها')
on conflict (key) do nothing;

insert into public.theme_settings (id) values (1) on conflict (id) do nothing;

insert into public.plans (code, title_fa, subtitle_fa, description_fa, sku, duration_days, display_price, badge, features, is_active, is_recommended, sort_order) values
 ('free','رایگان','شروع بدون هزینه','برای همیشه رایگان — با ۲ درس کامل از هر زبان کیفیت LINGU را تجربه کن.','free',0,0,null,
   $j$["۲ درس کامل رایگان در English","۲ درس کامل رایگان در French","۲ درس کامل رایگان در Spanish","۲ پیام رایگان Conversation Partner","ثبت پیشرفت درس‌های رایگان"]$j$::jsonb, true, false, 1),
 ('monthly','اشتراک ماهانه','یک ماه دسترسی کامل','دسترسی کامل به همه زبان‌ها، AI Tutor و Conversation Partner بدون محدودیت درس.','LINGU_MONTHLY',30,0,null,
   $j$["همه درس‌های منتشرشده در سه زبان","AI Tutor نامحدود (طبق سقف روزانه)","Conversation Partner با سناریوهای واقعی","ثبت و پیگیری کامل پیشرفت","ادامه یادگیری از هر دستگاهی"]$j$::jsonb, true, false, 2),
 ('quarterly','اشتراک سه‌ماهه','سه ماه، صرفه بیشتر','همان دسترسی کامل با قیمت بهتر نسبت به ماهانه.','LINGU_QUARTERLY',90,0,'محبوب',
   $j$["همه امکانات اشتراک ماهانه","قیمت مناسب‌تر برای یادگیری پیوسته","مناسب برنامه‌های ۹۰ روزه"]$j$::jsonb, true, true, 3),
 ('yearly','اشتراک سالانه','یک سال کامل','کمترین هزینه ماهانه برای یادگیری بلندمدت و کامل سه زبان.','LINGU_YEARLY',365,0,'بهترین ارزش',
   $j$["همه امکانات اشتراک ماهانه","کمترین قیمت ماهانه","دسترسی به تمام محتوای جدید منتشرشده در طول سال"]$j$::jsonb, true, false, 4)
on conflict (code) do nothing;

insert into public.myket_products (sku, title_fa, duration_days, is_active, sort_order) values
 ('LINGU_MONTHLY','اشتراک ماهانه LINGU',30,true,1),
 ('LINGU_QUARTERLY','اشتراک سه‌ماهه LINGU',90,true,2),
 ('LINGU_YEARLY','اشتراک سالانه LINGU',365,true,3)
on conflict (sku) do nothing;

insert into public.faqs (question, answer, category, sort_order) values
 ('آیا استفاده از LINGU رایگان است؟','بله. حساب رایگان برای همیشه فعال می‌ماند و در هر سه زبان English، French و Spanish دو درس کامل رایگان دارد. برای دسترسی به همه درس‌ها و AI Tutor و Conversation Partner می‌توانی اشتراک تهیه کنی.','general',1),
 ('رایگان چه چیزی دریافت می‌کنم؟','۶ درس کامل (۲ درس در هر زبان)، ۲ پیام Conversation Partner و ثبت پیشرفت همان درس‌ها. هیچ محدودیت زمانی وجود ندارد — رایگان برای همیشه رایگان است.','pricing',2),
 ('Conversation Partner چه تفاوتی با AI Tutor دارد؟','Conversation Partner یک نقش واقعی (مثلاً گارسون کافه یا مصاحبه‌گر) بازی می‌کند و مکالمه را ادامه می‌دهد. AI Tutor توضیح می‌دهد، مثال می‌سازد و درس را ساده‌تر می‌کند.','features',3),
 ('روی چه زبان‌هایی کار می‌کنم؟','در نسخه فعلی English، French و Spanish. هدف نهایی ۳۴۰ درس برای هر زبان است و درس‌ها به‌صورت هفتگی اضافه می‌شوند.','languages',4),
 ('چطور می‌توانم اشتراک بگیرم؟','در صفحه «اشتراک» پلن دلخواه را انتخاب کن. فعال‌سازی در اپلیکیشن اندروید LINGU انجام می‌شود و بلافاصله روی همین حساب باز می‌گردد.','pricing',5),
 ('آیا تلفظ من تصحیح می‌شود؟','در نسخه فعلی تمرکز ما روی درک، واژگان، گرامر و مکالمه است؛ تمرین تلفظ صوتی در برنامه توسعه قرار دارد.','features',6)
on conflict do nothing;

-- ایـنـجـا نـظـرات کـاربـران seed نمی‌شود: هیچ نظر ساختگی در Production نمایش داده نمی‌شود.
-- نظرات واقعی از پنل مدیریت (بخش «نظرات کاربران») اضافه می‌شوند.


insert into public.ai_settings (id, provider, model, fallback_model, temperature, max_tokens,
  tutor_system_prompt, partner_system_prompt, free_partner_messages, premium_daily_messages, premium_daily_tutor, is_ai_enabled)
values (1,'groq','openai/gpt-oss-120b','openai/gpt-oss-20b',0.70,1200,
$p$تو «AI Tutor» رسمی مجموعه LINGU هستی؛ یک مربی زبان صبور، دقیق و دوستانه.
وظایف تو: توضیح ساده و مرحله‌به‌مرحله، پاسخ به سؤال زبان‌آموز، ساخت مثال تازه، توضیح گرامر و واژگان، ساخت تمرین کوتاه و صحبت درباره درس جاری.
قواعد سخت: همیشه به فارسی روان توضیح بده و مثال‌های انگلیسی/فرانسه/اسپانیایی را با ترجمه فارسی بیاور. پاسخ‌ها کوتاه و ساختارمند باشند (حداکثر ۶ bullet یا ۳ پاراگراف). هرگز از دانش‌آموز اطلاعات حساس نخواه. اگر سؤال بی‌ربط بود، با احترام به موضوع درس برگرد. هرگز نگو که مدل زبانی هستی؛ تو مربی LINGU هستی.$p$,
$p$تو «Conversation Partner» رسمی LINGU هستی: یک هم‌صحبت انسانی با نقش مشخص (مثلاً گارسون کافه، افسر فرودگاه، مصاحبه‌گر کاری).
قواعد سخت: همیشه در نقش بمان و مکالمه را طبیعی ادامه بده. هر پاسخ باید ۱) واکنش به حرف کاربر، ۲) یک سؤال تازه باشد تا گفت‌وگو قطع نشود. زبان مکالمه همان زبان هدف است (English/French/Spanish) و سطح زبان را با سطح زبان‌آموز هماهنگ کن. حداکثر ۳ جمله کوتاه در هر پاسخ. اگر کاربر جمله اشتباه گفت، در پایان و فقط با یک خط کوتاه و با عبارت «اصلاح دوستانه:» شکل درست را نشان بده. هرگز خارج از نقش حرف نزن.$p$,
2,200,200,true)
on conflict (id) do update set
  tutor_system_prompt = case when ai_settings.tutor_system_prompt = '' then excluded.tutor_system_prompt else ai_settings.tutor_system_prompt end,
  partner_system_prompt = case when ai_settings.partner_system_prompt = '' then excluded.partner_system_prompt else ai_settings.partner_system_prompt end;

insert into public.ai_secrets (id, groq_api_key, key_hint) values (1, null, null) on conflict (id) do nothing;

-- >>>>>>>>>> supabase/migrations/0008_admin_views.sql
-- ============================================================
-- LINGU · 0008 · Admin read models (real numbers, admin-guarded)
-- ============================================================

create or replace function public.admin_users(p_query text default null)
returns table (
  id uuid, display_name text, avatar_url text, role app_role, is_active boolean, tour_done boolean,
  locale text, last_seen_at timestamptz, created_at timestamptz,
  premium boolean, premium_until timestamptz, ai_messages int, last_ai_at timestamptz,
  lessons_completed int, plan_title text
) language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = '42501'; end if;
  return query
  select p.id, p.display_name, p.avatar_url, p.role, p.is_active, p.tour_done, p.locale,
         p.last_seen_at, p.created_at,
         coalesce(s.end_date > now(), false) as premium,
         s.end_date as premium_until,
         coalesce((select count(*)::int from ai_usage a where a.user_id = p.id), 0) as ai_messages,
         (select max(a.created_at) from ai_usage a where a.user_id = p.id) as last_ai_at,
         coalesce((select count(*)::int from user_progress up where up.user_id = p.id and up.status = 'completed'), 0) as lessons_completed,
         pl.title_fa as plan_title
  from profiles p
  left join lateral (
    select s2.end_date, s2.plan_id from subscriptions s2
    where s2.user_id = p.id and s2.status = 'active' and s2.end_date > now()
    order by s2.end_date desc limit 1
  ) s on true
  left join plans pl on pl.id = s.plan_id
  where p_query is null or p_query = ''
     or p.display_name ilike '%' || p_query || '%'
     or p.id::text = p_query
  order by p.created_at desc
  limit 300;
end $$;

create or replace function public.admin_subscriptions()
returns table (
  id uuid, user_id uuid, sku text, status subscription_status, start_date timestamptz,
  end_date timestamptz, purchase_token text, provider text, created_at timestamptz,
  display_name text, plan_title text
) language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = '42501'; end if;
  return query
  select s.id, s.user_id, s.sku, s.status, s.start_date, s.end_date, s.purchase_token, s.provider, s.created_at,
         p.display_name, pl.title_fa
  from subscriptions s
  left join profiles p on p.id = s.user_id
  left join plans pl on pl.id = s.plan_id
  order by s.created_at desc
  limit 300;
end $$;

-- AI usage overview for the admin dashboard
create or replace function public.admin_ai_usage(p_limit int default 100)
returns setof ai_usage language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = '42501'; end if;
  return query select * from ai_usage order by created_at desc limit greatest(1, least(p_limit, 500));
end $$;

grant execute on function public.admin_users(text) to authenticated;
grant execute on function public.admin_subscriptions() to authenticated;
grant execute on function public.admin_ai_usage(int) to authenticated;
grant execute on function public.published_catalog() to authenticated, anon;
grant execute on function public.my_ai_quota() to authenticated;
grant execute on function public.theme_public() to authenticated, anon;

-- >>>>>>>>>> supabase/migrations/0009_storage.sql
-- ============================================================
-- LINGU · 0009 · Storage (only the bucket + access rules are created here;
-- the bucket itself is created by the setup script if it does not exist).
--   media    : admin-uploaded images used by banners / testimonials
--   listening: optional audio for Listening sections (created per-lesson, only when really needed)
-- ============================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('media', 'media', true, 5242880, array['image/png','image/jpeg','image/webp','image/svg+xml']),
  ('listening', 'listening', true, 15728640, array['audio/mpeg','audio/mp4','audio/ogg','audio/wav'])
on conflict (id) do nothing;

-- public read, admin-only write
drop policy if exists media_read on storage.objects;
create policy media_read on storage.objects for select using (bucket_id in ('media','listening'));
drop policy if exists media_write on storage.objects;
create policy media_write on storage.objects for insert to authenticated
  with check (bucket_id in ('media','listening') and public.is_admin());
drop policy if exists media_update on storage.objects;
create policy media_update on storage.objects for update to authenticated
  using (bucket_id in ('media','listening') and public.is_admin());
drop policy if exists media_delete on storage.objects;
create policy media_delete on storage.objects for delete to authenticated
  using (bucket_id in ('media','listening') and public.is_admin());

-- >>>>>>>>>> supabase/migrations/0010_product_experience.sql
-- ============================================================
-- LINGU · 0010 · Product Experience
--   · onboarding (language + goal) and preferences on profiles
--   · media_assets: every visual asset is DB-driven (admin > Media Library)
--   · notifications: real event-driven notification center
--   · promotional pricing fields on plans
--   · in-app search RPC
-- ============================================================

-- ---------- profiles: onboarding + preferences ----------
alter table public.profiles add column if not exists goal text;
alter table public.profiles add column if not exists target_language text;
alter table public.profiles add column if not exists onboarding_done boolean not null default false;
alter table public.profiles add column if not exists reduce_motion boolean not null default false;
alter table public.profiles add column if not exists preferred_level text default 'A1';

create or replace function public.guard_profile_columns() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() then return new; end if;
  if new.role is distinct from old.role then
    raise exception 'forbidden: role change requires admin' using errcode = '42501';
  end if;
  if new.is_active is distinct from old.is_active then
    raise exception 'forbidden: account status change requires admin' using errcode = '42501';
  end if;
  return new;
end $$;

-- ---------- media assets (visual asset system) ----------
create table if not exists public.media_assets (
  id           uuid primary key default gen_random_uuid(),
  slot         text unique not null,          -- hero_background | ai_tutor | premium | lang_en ...
  name         text not null,
  category     text not null default 'general',
  url          text not null,                 -- public path or storage URL
  storage_path text,
  alt_fa       text,
  used_in      text[] not null default '{}',  -- e.g. {public_home, dashboard}
  is_active    boolean not null default true,
  sort_order   int not null default 0,
  updated_by   uuid references auth.users(id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
drop trigger if exists trg_media_touch on public.media_assets;
create trigger trg_media_touch before update on public.media_assets for each row execute function public.touch_updated_at();

-- ---------- notifications ----------
do $$ begin
  create type notification_kind as enum ('lesson_completed','new_lesson','premium_activated','quota_warning','system');
exception when duplicate_object then null; end $$;

create table if not exists public.notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  kind       notification_kind not null default 'system',
  title      text not null,
  body       text,
  url        text,
  read_at    timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists idx_notifications_user on public.notifications(user_id, created_at desc);

create or replace function public.notify(
  p_user uuid, p_kind notification_kind, p_title text, p_body text default null, p_url text default null
) returns void language sql security definer set search_path = public as $$
  insert into notifications (user_id, kind, title, body, url) values (p_user, p_kind, p_title, p_body, p_url);
$$;

-- real event: lesson completed -> notification (+ quota warning is produced by the AI function)
create or replace function public.on_lesson_completed() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_title text; v_lang text;
begin
  if new.status = 'completed' and (old.status is distinct from 'completed') then
    select title, language_code into v_title, v_lang from lessons where id = new.lesson_id;
    perform public.notify(new.user_id, 'lesson_completed', 'درس تمام شد: ' || coalesce(v_title, 'درس LINGU'),
      'پیشرفتت ذخیره شد. برای تثبیت، یک دور سریع با AI Tutor بزن.', '/app/progress');
  end if;
  return new;
end $$;
drop trigger if exists trg_notify_lesson on public.user_progress;
create trigger trg_notify_lesson after update on public.user_progress
  for each row execute function public.on_lesson_completed();

-- real event: premium activated -> notification
create or replace function public.on_subscription_activated() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'active' and (tg_op = 'INSERT' or old.status is distinct from 'active') then
    perform public.notify(new.user_id, 'premium_activated', 'اشتراک Premium فعال شد',
      'همه درس‌ها، AI Tutor و Conversation Partner بدون محدودیت در دسترس تو هستند.', '/app/subscription');
  end if;
  return new;
end $$;
drop trigger if exists trg_notify_subscription on public.subscriptions;
create trigger trg_notify_subscription after insert or update on public.subscriptions
  for each row execute function public.on_subscription_activated();

-- admin broadcast (used when a batch is published)
create or replace function public.notify_all_users(p_title text, p_body text default null, p_url text default null)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = '42501'; end if;
  insert into notifications (user_id, kind, title, body, url)
  select id, 'new_lesson', p_title, p_body, p_url from profiles where is_active;
  get diagnostics n = row_count;
  return n;
end $$;

-- ---------- plans: original / promotional pricing (display only) ----------
alter table public.plans add column if not exists original_price bigint not null default 0;
alter table public.plans add column if not exists promo_price bigint;
alter table public.plans add column if not exists promo_label text;
alter table public.plans add column if not exists promo_active boolean not null default false;
alter table public.plans add column if not exists promo_ends_at timestamptz;
alter table public.plans add column if not exists show_on_marketing boolean not null default false;

-- ---------- marketing settings + hero copy (admin editable, no redeploy) ----------
insert into public.app_settings (key, value, description) values
 ('marketing', $j${"hero_title":"زبان را فقط نخوان؛ واقعاً یاد بگیر.","hero_subtitle":"درس‌های کامل، AI Tutor و Conversation Partner در سه زبان — با تجربه‌ای که شبیه یک اپلیکیشن واقعی است، نه یک وب‌سایت.","hero_cta":"شروع رایگان","hero_cta_logged_in":"ادامه یادگیری","hero_secondary":"دیدن امکانات","show_pricing":false,"show_testimonials":true}$j$::jsonb, 'محتوای صفحه اصلی سایت'),
 ('onboarding', $j${"goals":[{"id":"travel","label_fa":"سفر"},{"id":"work","label_fa":"کار و حرفه"},{"id":"study","label_fa":"تحصیل"},{"id":"personal","label_fa":"علاقه شخصی"}]}$j$::jsonb, 'گزینه‌های Onboarding')
on conflict (key) do nothing;

-- ---------- in-app global search (real data only) ----------
create or replace function public.app_search(p_query text)
returns table (
  kind text, id uuid, title text, subtitle text, language_code text, level text,
  is_free boolean, locked boolean, url text
) language sql stable security definer set search_path = public as $$
  select 'lesson'::text, l.id, l.title, coalesce(l.subtitle, l.description),
         l.language_code, l.level, l.is_free,
         not (l.is_free or public.has_active_premium(auth.uid()) or public.is_admin()) as locked,
         '/app/lessons/' || l.id::text
  from lessons l
  where l.status = 'published'
    and (
      p_query is null or p_query = ''
      or l.title ilike '%' || p_query || '%'
      or coalesce(l.subtitle,'') ilike '%' || p_query || '%'
      or coalesce(l.description,'') ilike '%' || p_query || '%'
      or l.language_code ilike '%' || p_query || '%'
      or l.level ilike '%' || p_query || '%'
    )
  order by l.language_code, l.order_index
  limit 12;
$$;
grant execute on function public.app_search(text) to authenticated, anon;

-- ---------- dashboard: add conversation/AI detail without inventing numbers ----------
create or replace function public.admin_dashboard()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = '42501'; end if;
  return jsonb_build_object(
    'users_total',        (select count(*) from profiles),
    'users_active_7d',    (select count(*) from profiles where coalesce(last_seen_at, created_at) > now() - interval '7 days'),
    'users_new_7d',       (select count(*) from profiles where created_at > now() - interval '7 days'),
    'premium_users',      (select count(*) from subscriptions where status='active' and end_date > now()),
    'lessons_total',      (select count(*) from lessons),
    'lessons_published',  (select count(*) from lessons where status='published'),
    'lessons_draft',      (select count(*) from lessons where status in ('draft','generated','validated')),
    'lessons_failed',     (select count(*) from lessons where status='failed'),
    'plans_failed',       (select count(*) from lesson_plans where status='failed'),
    'ai_calls_24h',       (select count(*) from ai_usage where created_at > now() - interval '1 day'),
    'ai_tokens_24h',      (select coalesce(sum(prompt_tokens + completion_tokens),0) from ai_usage where created_at > now() - interval '1 day'),
    'ai_calls_total',     (select count(*) from ai_usage),
    'ai_errors_24h',      (select count(*) from ai_usage where ok = false and created_at > now() - interval '1 day'),
    'tutor_calls_24h',    (select count(*) from ai_usage where feature='tutor' and created_at > now() - interval '1 day'),
    'partner_calls_24h',  (select count(*) from ai_usage where feature='partner' and created_at > now() - interval '1 day'),
    'conversations_total',(select count(*) from conversations),
    'messages_total',     (select count(*) from messages),
    'partner_messages_24h',(select count(*) from messages m join conversations c on c.id=m.conversation_id
                            where c.mode='partner' and m.role='user' and m.created_at > now() - interval '1 day'),
    'active_subs',        (select count(*) from subscriptions where status='active' and end_date > now()),
    'recent_users',       coalesce((
      select jsonb_agg(x) from (
        select p.id, p.display_name, p.role, p.created_at,
               (select exists(select 1 from subscriptions s where s.user_id = p.id and s.status='active' and s.end_date > now())) as premium
        from profiles p order by p.created_at desc limit 6
      ) x), '[]'::jsonb),
    'lessons_by_language', coalesce((
      select jsonb_object_agg(language_code, c) from (
        select language_code, count(*) c from lessons group by language_code
      ) y), '{}'::jsonb),
    'signups_14d', coalesce((
      select jsonb_agg(jsonb_build_object('day', d::date, 'count', coalesce(cnt,0)) order by d)
      from generate_series(now()::date - interval '13 days', now()::date, interval '1 day') d
      left join (
        select created_at::date dd, count(*) cnt from profiles
        where created_at > now() - interval '14 days' group by 1
      ) z on z.dd = d::date
    ), '[]'::jsonb)
  );
end $$;

-- ---------- support inbox (real messages only; no fake contact forms) ----------
create table if not exists public.support_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  email text,
  subject text,
  body text not null,
  status text not null default 'open' check (status in ('open','answered','closed')),
  created_at timestamptz not null default now()
);
create index if not exists idx_support_created on public.support_messages(created_at desc);

alter table public.support_messages enable row level security;

drop policy if exists sm_insert_own on public.support_messages;
create policy sm_insert_own on public.support_messages for insert to authenticated
  with check (user_id = auth.uid());

drop policy if exists sm_select on public.support_messages;
create policy sm_select on public.support_messages for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

drop policy if exists sm_admin_update on public.support_messages;
create policy sm_admin_update on public.support_messages for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---------- semantic colors + light lavender identity (admin-editable, applied live) ----------
alter table public.theme_settings add column if not exists success text not null default '#16A34A';
alter table public.theme_settings add column if not exists warning text not null default '#D97706';
alter table public.theme_settings add column if not exists danger  text not null default '#E11D48';
alter table public.theme_settings add column if not exists hero_overlay numeric(3,2) not null default 0.55;

-- The phase default identity: white + light lavender + violet, premium and calm.
update public.theme_settings set
  mode = 'light',
  "primary" = '#6D5BFF', secondary = '#8B5CF6', accent = '#0EA5C6',
  background = '#FAF9FF', background_soft = '#F3F0FF',
  card = '#FFFFFF', card_soft = '#F6F3FF',
  text = '#191436', text_muted = '#5B5688', line = '#E7E2F8',
  success = '#15803D', warning = '#B45309', danger = '#DC2626',
  radius = 22
where id = 1 and mode = 'dark';   -- only rewrites an untouched default row

-- ---------- default media slots (bundled artwork; every slot is admin-replaceable) ----------
insert into public.media_assets (slot, name, category, url, alt_fa, used_in, sort_order) values
 ('hero_background','پس‌زمینه هیرو (دسکتاپ)','hero','/art/hero-aurora.webp','پس‌زمینه بنفش مایل به سفید','{public_home}',1),
 ('hero_background_mobile','پس‌زمینه هیرو (موبایل)','hero','/art/hero-aurora-sm.webp','نسخه سبک پس‌زمینه هیرو','{public_home}',2),
 ('ai_tutor','تصویر AI Tutor','ai','/art/ai-tutor.webp','مربی هوشمند LINGU','{public_home,dashboard}',3),
 ('conversation','تصویر Conversation Partner','ai','/art/conversation.webp','گفت‌وگوی نقش‌محور','{public_home,dashboard,conversation}',4),
 ('premium','تصویر Premium','premium','/art/premium.webp','اشتراک ویژه LINGU','{public_home,subscription,dashboard}',5),
 ('onboarding','تصویر خوش‌آمدگویی','onboarding','/art/onboarding.webp','مسیر یادگیری','{onboarding}',6),
 ('lang_en','تصویر زبان انگلیسی','languages','/art/lang-en.webp','نماد بصری دوره انگلیسی','{public_home,dashboard}',7),
 ('lang_fr','تصویر زبان فرانسه','languages','/art/lang-fr.webp','نماد بصری دوره فرانسه','{public_home,dashboard}',8),
 ('lang_es','تصویر زبان اسپانیایی','languages','/art/lang-es.webp','نماد بصری دوره اسپانیایی','{public_home,dashboard}',9),
 ('scenario_cafe','تصویر کافه / رستوران / خرید','scenarios','/art/scenario-cafe.webp','موقعیت کافه','{conversation}',10),
 ('scenario_travel','تصویر سفر / فرودگاه','scenarios','/art/scenario-travel.webp','موقعیت سفر و فرودگاه','{conversation}',11),
 ('scenario_job','تصویر مصاحبه کاری','scenarios','/art/conversation.webp','موقعیت کاری','{conversation}',12),
 ('scenario_school','تصویر مدرسه و دانشگاه','scenarios','/art/conversation.webp','موقعیت آموزشی','{conversation}',13)
on conflict (slot) do nothing;

-- ---------- avatar storage (each user writes only inside their own folder) ----------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars','avatars', true, 2097152, array['image/png','image/jpeg','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 2097152;

drop policy if exists avatars_public_read on storage.objects;
create policy avatars_public_read on storage.objects for select
  using (bucket_id = 'avatars');

drop policy if exists avatars_own_write on storage.objects;
create policy avatars_own_write on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists avatars_own_update on storage.objects;
create policy avatars_own_update on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists avatars_own_delete on storage.objects;
create policy avatars_own_delete on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

-- >>>>>>>>>> supabase/migrations/0011_backend.sql
-- ============================================================
-- LINGU · 0011 · Backend readiness for AI + Content Production
--   * lesson-audio bucket (public read, admin-only write)
--   * daily AI usage counters (user_id, feature, day, request_count)
--   * server-only helper used by the Edge Functions
-- Everything here is idempotent.
-- ============================================================

-- ---------- storage: lesson audio ----------
-- `media`  : app images / media library (already exists)
-- `listening`: optional audio embedded in a Listening section (already exists)
-- `lesson-audio`: the audio library produced with the lessons (new here)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('lesson-audio', 'lesson-audio', true, 20971520,
        array['audio/mpeg','audio/mp4','audio/ogg','audio/wav','audio/webm'])
on conflict (id) do nothing;

-- Users may READ published lesson audio; only admins may write/replace/delete it.
drop policy if exists lesson_audio_read on storage.objects;
create policy lesson_audio_read on storage.objects for select
  using (bucket_id = 'lesson-audio');

drop policy if exists lesson_audio_write on storage.objects;
create policy lesson_audio_write on storage.objects for insert to authenticated
  with check (bucket_id = 'lesson-audio' and public.is_admin());

drop policy if exists lesson_audio_update on storage.objects;
create policy lesson_audio_update on storage.objects for update to authenticated
  using (bucket_id = 'lesson-audio' and public.is_admin());

drop policy if exists lesson_audio_delete on storage.objects;
create policy lesson_audio_delete on storage.objects for delete to authenticated
  using (bucket_id = 'lesson-audio' and public.is_admin());

-- ---------- daily AI usage counter ----------
create table if not exists public.ai_usage_daily (
  user_id       uuid not null references auth.users(id) on delete cascade,
  feature       ai_feature not null,
  day           date not null default current_date,
  request_count int not null default 0,
  updated_at    timestamptz not null default now(),
  primary key (user_id, feature, day)
);
create index if not exists idx_ai_usage_daily_day on public.ai_usage_daily(day desc);

alter table public.ai_usage_daily enable row level security;

-- Users can see their own counters; admins see everything; nobody can write from a client.
drop policy if exists ai_usage_daily_own on public.ai_usage_daily;
create policy ai_usage_daily_own on public.ai_usage_daily for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

-- Only the service role (Edge Functions) may bump a counter.
create or replace function public.bump_ai_usage(p_user uuid, p_feature ai_feature)
returns int language plpgsql security definer set search_path = public as $$
declare v int;
begin
  insert into ai_usage_daily (user_id, feature, day, request_count, updated_at)
  values (p_user, p_feature, current_date, 1, now())
  on conflict (user_id, feature, day)
  do update set request_count = ai_usage_daily.request_count + 1, updated_at = now()
  returning request_count into v;
  return v;
end $$;

revoke all on function public.bump_ai_usage(uuid, ai_feature) from public, anon, authenticated;
grant execute on function public.bump_ai_usage(uuid, ai_feature) to service_role;

-- ---------- admin view of AI usage (product-friendly, no raw ids for the client side) ----------
create or replace function public.admin_ai_usage_daily(p_days int default 14)
returns table (day date, feature ai_feature, users int, requests int)
language sql stable security definer set search_path = public as $$
  select d.day, d.feature, count(distinct d.user_id)::int, sum(d.request_count)::int
  from ai_usage_daily d
  where public.is_admin() and d.day > current_date - greatest(coalesce(p_days, 14), 1)
  group by d.day, d.feature
  order by d.day desc, d.feature;
$$;

revoke all on function public.admin_ai_usage_daily(int) from public, anon;
grant execute on function public.admin_ai_usage_daily(int) to authenticated, service_role;

-- ---------- privileges, made explicit ----------
-- Supabase grants these through project defaults; stating them here means SETUP.sql
-- behaves the same on any project (RLS still decides which ROWS anyone can see).
grant usage on schema public to anon, authenticated, service_role;
grant select on all tables in schema public to anon, authenticated;
grant insert, update, delete on all tables in schema public to authenticated;
-- the Edge Functions run as service_role: they must be able to write messages, usage and
-- counters, otherwise the AI features fail with "permission denied" on the first call.
grant select, insert, update, delete on all tables in schema public to service_role;
grant usage, select on all sequences in schema public to authenticated, service_role;
grant execute on all functions in schema public to anon, authenticated, service_role;

alter default privileges in schema public grant select on tables to anon, authenticated;
alter default privileges in schema public grant insert, update, delete on tables to authenticated;
alter default privileges in schema public grant select, insert, update, delete on tables to service_role;
alter default privileges in schema public grant execute on functions to anon, authenticated, service_role;

-- ...with the deliberate exceptions:
revoke all on public.ai_secrets from anon, authenticated;                       -- server-only key store
revoke insert, update, delete on public.ai_usage_daily from anon, authenticated; -- counters are server-written
revoke execute on function public.bump_ai_usage(uuid, ai_feature) from public, anon, authenticated;
grant execute on function public.bump_ai_usage(uuid, ai_feature) to service_role;
revoke all on function public.admin_ai_usage_daily(int) from public, anon;
grant execute on function public.admin_ai_usage_daily(int) to authenticated, service_role;
revoke all on function public.admin_users(text) from public, anon;
revoke all on function public.admin_subscriptions() from public, anon;
revoke all on function public.admin_ai_usage(int) from public, anon;
revoke all on function public.admin_dashboard() from public, anon;

-- >>>>>>>>>> supabase/migrations/0012_usage_hygiene.sql
-- ============================================================
-- 0012 · Usage hygiene: close the two unprotected tables, add retention
--        for temporary data, and prevent duplicate storage objects.
--        Everything here is idempotent and safe to re-run.
-- ============================================================

-- ------------------------------------------------------------
-- 1) RLS gap: media_assets and notifications were created without
--    row level security. Supabase grants ALL privileges on new tables
--    to anon/authenticated, so an anonymous caller could insert into the
--    admin media library and read every notification. RLS is the only
--    thing standing between those grants and the data.
-- ------------------------------------------------------------
alter table public.media_assets  enable row level security;
alter table public.notifications enable row level security;

-- Media library: everyone reads the assets that are switched on (the public
-- site and the app render them), admins see and change everything.
drop policy if exists media_assets_read on public.media_assets;
create policy media_assets_read on public.media_assets
  for select using (is_active or public.is_admin());
drop policy if exists media_assets_admin on public.media_assets;
create policy media_assets_admin on public.media_assets
  for all using (public.is_admin()) with check (public.is_admin());

-- Notifications: a user only ever touches their own rows. Inserts come from
-- the notify()/notify_all_users() triggers, which run as the table owner.
drop policy if exists notifications_self_read on public.notifications;
create policy notifications_self_read on public.notifications
  for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists notifications_self_update on public.notifications;
create policy notifications_self_update on public.notifications
  for update using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists notifications_self_delete on public.notifications;
create policy notifications_self_delete on public.notifications
  for delete using (user_id = auth.uid() or public.is_admin());
drop policy if exists notifications_admin_insert on public.notifications;
create policy notifications_admin_insert on public.notifications
  for insert with check (public.is_admin());

-- ------------------------------------------------------------
-- 2) Duplicate storage prevention
--    a) media_assets gets a content hash + unique index so the same picture
--       cannot be registered twice.
--    b) storage_duplicates() lists objects that look identical (same bucket,
--       name, byte size and mime type) so an operator can drop the extras.
--    The content pipeline is expected to store audio under a content-addressed
--    path: lesson-audio/<lang>/<hash8>.<ext>, which makes the same clip shared
--    by every lesson that uses it instead of uploaded per lesson.
-- ------------------------------------------------------------
alter table public.media_assets add column if not exists content_hash text;
create unique index if not exists media_assets_content_hash_key
  on public.media_assets (content_hash) where content_hash is not null;

create or replace function public.storage_duplicates()
returns table (bucket_id text, object_name text, object_size bigint, copies bigint, paths text[])
language sql stable security definer set search_path = public, storage as $$
  select o.bucket_id, o.name, (o.metadata->>'size')::bigint,
         count(*), array_agg(o.name order by o.created_at)
  from storage.objects o
  group by o.bucket_id, o.name, (o.metadata->>'size'), (o.metadata->>'mimetype')
  having count(*) > 1
  order by (o.metadata->>'size')::bigint desc
$$;

-- ------------------------------------------------------------
-- 3) Retention for temporary data.
--    Nothing here ever deletes an account, a profile, progress or a
--    subscription: a user who comes back after months finds the same
--    account. Only derived, re-creatable rows are trimmed.
-- ------------------------------------------------------------

-- Old chat history: keeps the newest p_keep conversations per user and every
-- conversation touched within p_days. Messages cascade with their conversation.
create or replace function public.prune_conversations(p_days int default 180, p_keep int default 30)
returns int language plpgsql security definer set search_path = public as $$
declare v_deleted int;
begin
  with ranked as (
    select id, row_number() over (partition by user_id order by updated_at desc) as rn,
           updated_at
    from public.conversations
  ), doomed as (
    select id from ranked
    where rn > p_keep and updated_at < now() - make_interval(days => p_days)
  )
  delete from public.conversations c using doomed d where c.id = d.id;
  get diagnostics v_deleted = row_count;
  return v_deleted;
end $$;

-- Per-request AI log: the admin screen only reads the latest rows, so old
-- detail rows are pure growth. The daily counters in ai_usage_daily stay.
create or replace function public.prune_ai_usage(p_days int default 90)
returns int language plpgsql security definer set search_path = public as $$
declare v_deleted int;
begin
  delete from public.ai_usage where created_at < now() - make_interval(days => p_days);
  get diagnostics v_deleted = row_count;
  return v_deleted;
end $$;

-- Notifications a user already read and never came back to.
create or replace function public.prune_notifications(p_days int default 90)
returns int language plpgsql security definer set search_path = public as $$
declare v_deleted int;
begin
  delete from public.notifications
  where read_at is not null and read_at < now() - make_interval(days => p_days);
  get diagnostics v_deleted = row_count;
  return v_deleted;
end $$;

-- Admin audit trail: keep a year.
create or replace function public.prune_audit_log(p_days int default 365)
returns int language plpgsql security definer set search_path = public as $$
declare v_deleted int;
begin
  delete from public.audit_log where created_at < now() - make_interval(days => p_days);
  get diagnostics v_deleted = row_count;
  return v_deleted;
end $$;

-- One call for a scheduled job, returning what it trimmed.
create or replace function public.run_retention(
  p_conv_days int default 180, p_conv_keep int default 30,
  p_ai_days int default 90, p_notif_days int default 90, p_audit_days int default 365)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  return jsonb_build_object(
    'conversations',   public.prune_conversations(p_conv_days, p_conv_keep),
    'ai_usage',        public.prune_ai_usage(p_ai_days),
    'notifications',   public.prune_notifications(p_notif_days),
    'audit_log',       public.prune_audit_log(p_audit_days),
    'ran_at',          now()
  );
end $$;

-- Only the platform (service_role) and admins may trim data by hand.
revoke all on function public.prune_conversations(int, int) from public, anon, authenticated;
revoke all on function public.prune_ai_usage(int)           from public, anon, authenticated;
revoke all on function public.prune_notifications(int)      from public, anon, authenticated;
revoke all on function public.prune_audit_log(int)          from public, anon, authenticated;
revoke all on function public.run_retention(int, int, int, int, int) from public, anon, authenticated;
revoke all on function public.storage_duplicates()          from public, anon, authenticated;
grant execute on function public.prune_conversations(int, int) to service_role;
grant execute on function public.prune_ai_usage(int)           to service_role;
grant execute on function public.prune_notifications(int)      to service_role;
grant execute on function public.prune_audit_log(int)          to service_role;
grant execute on function public.run_retention(int, int, int, int, int) to service_role;
grant execute on function public.storage_duplicates()          to service_role;

-- ------------------------------------------------------------
-- 4) Daily schedule (when pg_cron is available on the project).
--    If the extension is missing the block is skipped silently and the same
--    functions can be called from the admin side or a scheduled job.
-- ------------------------------------------------------------
do $$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron')
     and not exists (select 1 from cron.job where jobname = 'lingu-retention') then
    perform cron.schedule('lingu-retention', '30 3 * * *', $cron$ select public.run_retention() $cron$);
  end if;
exception when others then
  raise notice 'pg_cron scheduling skipped: %', sqlerrm;
end $$;
