# LINGU — یادگیری زبان، هوشمند و واقعی

پلتفرم آموزش زبان (English · French · Spanish) با درس‌های کامل، AI Tutor و Conversation Partner.
هدف: انتشار سریع یک محصول واقعی و حرفه‌ای که بعداً بزرگ‌تر می‌شود.

```
lingu/
├── web/                  # React + TypeScript + Tailwind + Motion  (Public + App + Admin)
│   ├── src/components/layout/AppShell.tsx   # پوستهٔ مستقل برنامه (Sidebar/Topbar/BottomNav/FAB)
│   ├── src/pages/public|app|admin           # سه محیط جداشده
│   └── public/art|icons|brand               # تصاویر و آیکن‌ها (قابل جایگزینی از پنل)
├── supabase/
│   ├── migrations/       # دیتابیس، RLS، RPC ها (به ترتیب شماره اجرا شوند)
│   ├── SETUP.sql         # همان فایل‌ها در یک فایل — برای SQL Editor
│   └── functions/        # Edge Functions (فاز ۲/۳): ai-chat، myket-verify، content-admin
├── docs/                 # راهنمای کاربر + معماری + وضعیت فازها
└── .github/workflows/    # build و deploy خودکار روی Cloudflare Pages
```

## وضعیت فازها

| فاز | محتوا | وضعیت |
|---|---|---|
| **۱** | Foundation: Supabase، Auth، Database، RLS، Website، Admin، Theme، Tour | ✅ کامل — آماده تست روی پروژه واقعی Supabase |
| **۱.۵** | Product Experience: پوستهٔ مستقل برنامه، داشبورد، Onboarding، تنظیمات/راهنما، Media Library، موشن و دسترس‌پذیری، هویت بصری روشن | ✅ کامل — Build/تست پاس |
| **۱.۷** | Backend واقعی: آزمون SETUP.sql روی دیتابیس، RLS/Storage/Auth، سه Edge Function (ai-chat، conversation، content-admin)، سقف مصرف | ✅ کامل — منتظر اتصال پروژهٔ Supabase |
| **۱.۶** | نهایی‌سازی محصول: مسیر واقعی کاربر، حذف حساب ساختگی و متن‌های فنی از سطح کاربر، رفع باگ تور/بوت، پاک‌سازی | ✅ کامل — تست جریان‌کار دسکتاپ/موبایل و نسخهٔ تولیدی پاس |
| **۲** | Lessons، Content Factory، ۶ درس رایگان باکیفیت، Progress، AI Tutor، Conversation Partner | ⏳ در حال ساخت |
| **۳** | Subscription، Myket، Premium access، Purchase flow، تست | ⏳ |
| **۴** | Flutter (Android) + Myket SDK + Release APK + تست نهایی | ⏳ |

## اتصال Backend

راهنمای سه‌قدمی: **[docs/BACKEND-SETUP-FA.md](docs/BACKEND-SETUP-FA.md)**
(ساخت پروژه → اجرای `supabase/SETUP.sql` در SQL Editor → گذاشتن `VITE_SUPABASE_URL` و `VITE_SUPABASE_ANON_KEY`)
سپس استقرار توابع: `npx supabase functions deploy ai-chat conversation content-admin`

اجرای همهٔ تست‌های Backend (دیتابیس + توابع):

```bash
bash supabase/test/run-all.sh
```

## اجرای محلی (توسعه)

```bash
cd web
cp .env.example .env          # دو مقدار Supabase را وارد کن
npm install
npm run dev                   # http://localhost:5173
```

- **پیش‌نمایش طراحی (بدون Supabase):** `VITE_DEMO_MODE=true npm run dev`
  رابط کاربری با برچسب «پیش‌نمایش طراحی» و چند نمونهٔ رید-اونلی بالا می‌آید.
  این حالت در build تولیدی **ممنوع** است و `vite.config.ts` آن را مسدود می‌کند.
- **Build تولیدی:** `npm run build` → خروجی در `web/dist`

## استقرار (Cloudflare Pages)

| متغیر | مقدار |
|---|---|
| Build command | `npm run build` |
| Output directory | `dist` |
| Environment variables | `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY` |

روتینگ SPA و هدرهای امنیتی در `web/public/_redirects` و `web/public/_headers` آماده است.

## امنیت (خلاصه)

- کلیدها فقط روی سرور: جدول `ai_secrets` هیچ policy برای کلاینت ندارد (`revoke` شده) و فقط Edge Function با `service_role` به آن دسترسی دارد.
- Premium فقط از دیتابیس: RLS نوشتن روی `subscriptions` و `purchases` را به سرور محدود می‌کند و تریگر `guard_subscription_writes` جلوی درج از کلاینت را می‌گیرد.
- ارتقای نقش ممنوع: تریگر `guard_profile_columns` تغییر `role`/`is_active` توسط کاربر عادی را رد می‌کند.
- محتوای Premium در سطح دیتابیس محافظت می‌شود: `lessons` فقط وقتی قابل خواندن است که `published` باشد و درس `is_free` یا کاربر Premium داشته باشد.
- ارائه‌دهنده AI: **Groq** — کلید هرگز وارد React/Flutter/GitHub نمی‌شود.

## قواعد محصول (MVP)

- حساب رایگان **برای همیشه** رایگان است؛ هیچ Trial ۷/۳۰/۶۰ روزه‌ای وجود ندارد.
- Free user: **۲ درس کامل رایگان در هر زبان** (مجموعاً ۶ درس) + **۲ پیام Conversation Partner**.
- پس از مصرف ۲ پیام، پیام محترمانه اشتراک نمایش داده می‌شود؛ **هیچ پاسخ AI جعلی ساخته نمی‌شود**.
- تلفظ، Speech-to-Text، Scoring صوتی، Placement Test، Leaderboard، Coupon و… در MVP وجود ندارند.
- Audio فقط زمانی ساخته می‌شود که برای بخش Listening همان درس واقعاً لازم باشد.
