# LINGU — بررسی واقعی پروژه پیش از Content Factory

> این سند **فقط** چیزی را می‌نویسد که امروز در کد، دیتابیس زندهٔ پروژه و فایل‌های repo وجود دارد.
> هیچ‌جا حدس زده نشده؛ هر ادعا با مسیر فایل یا کوئری دیتابیس قابل بررسی است.
> در این مرحله **هیچ درسی تولید نشد، هیچ جدول/مهاجرت/UI تغییر نکرد** (git تمیز: `5e72be3`).

---

## ۱. ساختار واقعی پروژه

| مورد | وضعیت واقعی |
|---|---|
| ریشه | `/home/user/lingu` — `web/` + `supabase/` + `docs/` + `design/` |
| Web | React + TS + Tailwind + Motion؛ ۵۶ فایل TS/TSX؛ ۱۲ مسیر اپ + ۱۳ بخش پنل ادمین |
| دیتابیس زنده | پروژهٔ Supabase `wyzjdeqezbasuskkvhgd` (PG 17.6) — `SETUP.sql` ساخته‌شده از ۰۰۰۱–۰۰۱۲ |
| توابع مستقر | `ai-chat` ✅ · `conversation` ✅ · `content-admin` ✅ (هر سه `verify_jwt=true`) |
| جدول‌ها | ۲۶ جدول، ۲۶ RLS، ۵۷ policy، ۴ باکت |
| محتوای فعلی | **صفر درس** · `lesson_plans=0` · `content_batches=0` · `user_progress=0` |
| کرریکولوم واقعی | فقط یکی: `en` / `A1` — «مسیر انگلیسی — A1» با `target_lessons=40` |
| زبان‌ها | `en` انگلیسی · `fr` فرانسه · `es` اسپانیایی — هر سه `target_lessons=340`، فعال |
| تصاویر | ۱۳ ردیف `media_assets` (همه از `/art/*.webp`) |
| صدا | **هیچ فایل صوتی، هیچ صدا، هیچ پلیر** — هر چهار باکت ذخیره‌سازی خالی (۰ آبجکت) |

---

## ۲. قرارداد واقعی درس (استخراج‌شده از کد)

جدول `lessons` (`supabase/migrations/0003_lessons.sql`): `plan_id`, `batch_id`, `language_code`, `level`, `order_index`, `title`, `subtitle`, `description`, `estimated_minutes` (پیش‌فرض ۱۵), `status`, `is_free`, `content jsonb`, `validation jsonb`, `fingerprint`, `version`, `published_at`.

- **۱۲ بخش درس، ترتیب ثابت** (`web/src/lib/constants.ts` → `LESSON_SECTIONS`): `warmup` · `explanation` · `vocabulary` · `grammar` · `examples` · `listening` · `dialogue` · `speaking` · `reading` · `exercises` · `quiz` · `ai_practice`.
  پیشرفت کاربر با همین ۱۲ کلید در `user_progress.sections_done` ذخیره می‌شود → **هر ۱۲ بخش باید در JSON باشند**، حتی اگر بخشی کوتاه باشد.
- **شکل دقیق JSON** در `web/src/services/types.ts` → `LessonContent` و `ExerciseItem`.
- **اثر انگشت یکتا:** `lessons.fingerprint = md5(lower(زبان|سطح|عنوان با حذف فاصله‌ها))` با ایندکس **unique** → عنوان تکراری در همان زبان+سطح در سطح دیتابیس رد می‌شود (تریگر `set_lesson_fingerprint`).
- **وضعیت‌ها:** `draft → generated → validated → published` (+ `failed`).
- **RLS خواندن درس:** `status='published' AND (is_free OR has_active_premium(uid))` (`0006_rls.sql`) — یعنی درسِ منتشرنشده یا غیررایگان برای کاربر عادی در دیتابیس هم مخفی است. `published_catalog()` فقط منتشرشده‌ها را با پرچم `locked` برمی‌گرداند.

### محدودیت‌های واقعی رندرر (یافته‌های دقیق — روی محتوا اثر مستقیم دارند)

| یافته | شاهد | اثر روی تولید محتوا |
|---|---|---|
| در `exercises` فقط `mcq` و `truefalse` دکمه‌ای‌اند؛ `fill`/`short` ورودی متنی‌اند؛ **`match` و `order` هم به ورودی متنی ساده تبدیل می‌شوند** | `LessonDetail.tsx` → `ExerciseList` | تا ساخته‌شدن موتور بازی، `match`/`order` تولید نشود (تجربهٔ کاربری می‌شکند) |
| در `exercises` برای `truefalse` گزینه‌های پیش‌فرض `["True","False"]` ساخته می‌شود | همان | در `exercises` مشکلی نیست |
| در `quiz` گزینه‌های پیش‌فرض وجود **ندارد** (`item.options ?? []`) و تا همهٔ سؤال‌ها پاسخ داده نشوند دکمهٔ ثبت کار نمی‌کند | `LessonDetail.tsx` → `Quiz` | در `quiz` فقط `mcq` با `options` صریح (تلهٔ بن‌بست) |
| جواب‌ها با مقایسهٔ رشتهٔ ساده بررسی می‌شوند (`answer` می‌تواند آرایه باشد = چند پاسخ درست) | همان | فیلدهای `fill` باید `answer` را **آرایه** بدهند تا املای جایگزین پذیرفته شود |
| نشان گوینده در دیالوگ یک بَج ۹×۹ با فونت ۱۰px است | `LessonDetail.tsx` → `dialogue` | `speaker` باید کوتاه باشد: `"A"` یا `"B"` |
| `content.meta` هیچ‌جا به کاربر نمایش داده نمی‌شود | جست‌وجوی UI | `meta.objectives` فقط برای پنل/ابزار است (فارسی، ۳–۵ مورد) |
| IPA و ترجمهٔ فارسی در واژگان نمایش داده می‌شوند | `LessonDetail.tsx` → `vocabulary` | `ipa` برای هر سر واژه لازم است؛ `tag` ∈ فعل/اسم/صفت/قید/عبارت |

---

## ۳. صدا و گوینده — وضعیت واقعی

| پرسش | پاسخ واقعی |
|---|---|
| آیا پروژه صدای ثبت‌شده دارد؟ | **نه.** در هیچ جدول/فایل/`app_settings` فیلدی برای Voice یا TTS وجود ندارد |
| آیا فایل صوتی وجود دارد؟ | **نه.** باکت‌های `lesson-audio`، `listening`، `media` = ۰ آبجکت |
| آیا فیلد ارجاع صدا در محتوا هست؟ | **نه.** `LessonContent` هیچ `audio_url` ندارد؛ فقط `listening.needs_audio: boolean` |
| آیا پلیر صوتی در UI هست؟ | **نه.** هیچ `<audio>`/`new Audio` در `web/src` نیست؛ بخش شنیداری فقط متن را نشان می‌دهد |
| قرارداد مسیر (از قبل تعریف‌شده) | `lesson-audio/<lang>/<hash8>.<ext>` — از `0012_usage_hygiene.sql` (یک نسخهٔ مشترک برای هر کلیپ، `media_assets.content_hash`) |
| باکت‌ها | `lesson-audio` (۲۰MB، خواندن عمومی، نوشتن فقط ادمین) · `listening` (۱۵MB) · `media` (۵MB) · `avatars` (۲MB) |
| استاندارد مصرف | Opus 32k مونو (گزارش `USAGE-REPORT-FA.md`) |

**صداهای انتخاب‌شدهٔ کاربر در همین نشست** (تنها شناسه‌های واقعی موجود؛ از گفت‌وگوی همین پروژه):

| نقش پیشنهادی | شناسهٔ واقعی | زبان | جنسیت | کاربرد |
|---|---|---|---|---|
| راوی فارسی (مرد) | `voice-00` | fa | masculine | narration |
| راوی فارسی (زن) | `voice-01` | fa | feminine | narration |
| مربی فارسی (گرم/صمیمی) | `voice-02` | fa | masculine | conversational |

نکتهٔ فنی مهم: این شناسه‌ها **مخصوص همین نشست** هستند. در چت جدید محتوا باید با `add_voice` (همان متنِ آزمون + همان مشخصات) دوباره ثبت شوند.
صدای **انگلیسی** (زبان مقصد) هنوز انتخاب نشده — برای درس‌های انگلیسی لازم است.

---

## ۴. بازی، پیشرفت، AI، دسترسی، ادمین

| بخش | وضعیت واقعی |
|---|---|
| **Mini-game** | **وجود ندارد.** فقط `ExerciseList` و `Quiz` هست. هیچ موتور بازی، امتیاز بازی، تایمر یا لیدربوردی نیست |
| **Progress** | `user_progress` با `sections_done` (کلیدهای ۱۲ بخش)، `score`، `time_spent_sec`، `status` — ذخیرهٔ واقعی در سرور، یکتا روی (user, lesson) |
| **AI Tutor** | تابع `ai-chat` — پرامپت سرور فقط **عنوان درس + نام بخش** را می‌داند (`_shared/prompt.ts` → `buildTutorSystemPrompt`)، **متن درس را نمی‌بیند** → `ai_practice` باید خودبسنده باشد |
| **Conversation Partner** | تابع `conversation` با سناریوهای واقعی: `cafe, travel, airport, restaurant, shopping, job, school, meeting, daily` (`constants.ts`) — نام سناریو در محتوا نباید اختراع شود |
| **Free/Premium** | رایگان: ۲ درس هر زبان (`app_settings.learning`) + ۲ پیام Partner؛ Premium طبق DB؛ خرید از سمت کلاینت هرگز معتبر نیست |
| **Admin** | `adminSetLessonFlags` (انتشار/رایگان‌کردن) و حذف درس **کار می‌کند**؛ `adminLessons` لیست واقعی می‌دهد |
| **content-admin** | `create_plans` / `generate_next` / `validate_lesson` / `duplicates` / `publish` → همه `409 content_phase_not_started` (عمدی؛ مال فاز محتوا) |
| **Import/Seed** | **رابط ورود محتوا وجود ندارد.** مسیر واقعی امروز: فایل SQL + اجرای `psql` روی رشتهٔ اتصال (بدون دور زدن RLS چون با نقش `postgres` اجرا می‌شود) |
| **اعتبارسنج** | **وجود ندارد** (نه در تابع، نه در UI، نه در ابزار) → باید به‌عنوان ابزار فاز محتوا ساخته شود |

---

## ۵. فهرست Gap (چیزی که برای Content Factory لازم است و الان نیست)

> طبق دستور، هیچ‌کدام در این مرحله ساخته نشد؛ فقط فهرست و مسیر پیشنهادی.

| # | Gap | چرا لازم است | مسیر پیشنهادی |
|---|---|---|---|
| G1 | ابزار اعتبارسنجی محتوا | بدون آن «QA پیش از import» قابل اتکا نیست | `content/tools/validate.mjs` (بدون وابستگی npm) — داخل فاز محتوا |
| G2 | فیلد ارجاع صدا در محتوا | الان هیچ راهی برای وصل‌کردن کلیپ به درس نیست | افزودن `audio_url` به `listening`/`dialogue`/`vocabulary.items` — گام کوچک و لازم (همان که در ROADMAP مرحلهٔ ۳ آمده) |
| G3 | پلیر صوتی در صفحهٔ درس | بدون پلیر، فایل صوتی دیده نمی‌شود | کامپوننت کوچک در `LessonDetail` (بدون تغییر معماری) |
| G4 | انتخاب صدای انگلیسی | درس انگلیسی زبان مقصدش انگلیسی است | ۳ آزمون `add_voice` با زبان `en` در چت محتوا |
| G5 | موتور مینی‌گیم | ۵ بازی درخواستی وجود ندارد | افزودنی جدا و بعدی؛ **در چت محتوا ساخته نمی‌شود** |
| G6 | رندر `match`/`order` | الان به ورودی متن ساده تبدیل می‌شوند | همین افزودنی بازی (G5) |
| G7 | مسیر ورود محتوا بدون دست‌کاری دستی ادمین | ادمین نباید ۲۰/۳۴۰ درس را دستی وارد کند | فایل SQL تولیدی + `psql` (امروز موجود است، چیزی لازم نیست) |
| G8 | توزیع ۳۴۰ درس بین سطح‌ها | فقط یک کرریکولوم `en/A1` با هدف ۴۰ درس وجود دارد؛ تقسیم ۳۴۰ هیچ‌جا تعریف نشده | تصمیم کاربر در گام بعد (پیشنهاد: ۵ سطح × …) |

---

## ۶. چیزی که در این بررسی تغییر نکرد

- هیچ درس/طرح درس/Batch ساخته نشد (`lessons=0`, `lesson_plans=0`, `content_batches=0`).
- هیچ مهاجرت، جدول، ستون، policy، تابع Edge یا فایل UI تغییر نکرد.
- `git status` تمیز است و کامیت جدیدی زده نشد. دو سند جدید فقط در `docs/` نوشته شد.
