# LINGU — معماری و وضعیت فنی

## ۱. نمای کلی

```
                    ┌──────────────────────────────┐
   کاربر سایت ─────▶│  React SPA (Cloudflare Pages) │
   اپ اندروید ─────▶│  Flutter (فاز ۴)             │
                    └──────────────┬───────────────┘
                                   │ anon key (عمومی) + JWT کاربر
                                   ▼
                    ┌──────────────────────────────┐
                    │  Supabase                    │
                    │  · Auth (ایمیل/گذرواژه)       │
                    │  · Postgres + RLS            │
                    │  · Storage (media/listening) │
                    │  · Edge Functions            │
                    └──────────────┬───────────────┘
                                   │ service_role (فقط سرور)
                    ┌──────────────┴───────────────┐
                    │  Groq API · Myket Verify API │
                    └──────────────────────────────┘
```

تکنولوژی‌ها: React + TypeScript + Tailwind + Motion · Supabase (DB/Auth/Storage/Functions) · Groq · Flutter · Cloudflare · Myket.
عمداً **بدون** NestJS، Redis، S3 جداگانه، اپ ادمین جدا و WebView.

## ۲. جدول‌های دیتابیس (فاز ۱)

| جدول | کاربرد |
|---|---|
| `profiles` | پروفایل کاربر، `role` (user/admin)، `is_active`، `tour_done` |
| `app_settings` | تنظیمات key/value: general، learning، myket، features |
| `theme_settings` | تم پویا (رنگ‌ها، گردی گوشه‌ها) — تک‌ردیفی |
| `languages` | en / fr / es با هدف ۳۴۰ درس |
| `plans` | پلن‌های اشتراک: SKU، مدت به روز، قیمت نمایشی، ویژگی‌ها |
| `subscriptions` | start/end/SKU/purchaseToken/status — فقط سرور می‌نویسد |
| `purchases` | سابقه خام خرید + `purchase_token` یکتا |
| `myket_products` | کاتالوگ محصولات مایکت |
| `curricula` → `lesson_plans` → `lessons` | زنجیره Content Factory |
| `content_batches` | وضعیت هر Batch تولید (پایدار پس از Restart) |
| `user_progress` | وضعیت هر درس برای هر کاربر (یکتا روی user+lesson) |
| `ai_settings` | مدل، دما، پرامپت‌های سیستمی، سقف پیام‌ها |
| `ai_secrets` | **کلید Groq — بدون هیچ دسترسی کلاینتی** |
| `ai_usage` | لاگ مصرف AI (توکن، تأخیر، خطا) برای داشبورد و Quota |
| `conversations` / `messages` | تاریخچه AI Tutor و Conversation Partner |
| `faqs` / `testimonials` / `banners` | محتوای عمومی و اعلان‌های داخلی |
| `audit_log` | ثبت اقدامات مدیریتی |

## ۳. امنیت — کنترل‌های پیاده‌شده

1. **RLS روی همه جدول‌ها** + `ai_secrets` با `revoke all` برای `anon/authenticated`.
2. `has_active_premium(uid)` و `is_admin()` به‌صورت `security definer` (بدون بازگشت RLS).
3. تریگر `guard_profile_columns`: کاربر عادی نمی‌تواند `role` یا `is_active` خود را تغییر دهد.
4. تریگر `guard_subscription_writes`: درج/ویرایش اشتراک توسط کلاینت خطا می‌دهد.
5. `lessons`: خواندن فقط برای `published` + (`is_free` یا Premium). محتوای قفل‌شده در سطح دیتابیس مخفی می‌ماند.
6. `published_catalog()` یک RPC با ستون `locked` برمی‌گرداند — فهرست کامل دیده می‌شود، بدنه مخفی می‌ماند.
7. Quota در سرور محاسبه می‌شود: `partner_messages_used()`، `daily_ai_used()`، `my_ai_quota()`.
8. اولین کاربر ثبت‌نام‌شده خودکار Admin می‌شود (bootstrap)؛ بقیه کاربر عادی.
9. `.gitignore` جلوی ورود `.env` و کلیدها به GitHub را می‌گیرد؛ build تولیدی با `VITE_DEMO_MODE=true` مسدود است.

## ۴. Content Factory

مسیر: `Curriculum → Lesson Plan → AI Generation → Validation → Duplicate Check → Save → Publish`

- Batch های کوچک (۳/۵/۱۰ درس).
- وضعیت هر درس و هر Batch در دیتابیس ذخیره می‌شود → پس از Restart باقی می‌ماند.
- `lessons.fingerprint` (md5 زبان+سطح+عنوان نرمال‌شده) ایندکس **unique** دارد → جلوگیری سخت از درس تکراری.
- اعتبارسنجی ساختار: همه ۱۲ بخش، حداقل تعداد آیتم در هر بخش، تطابق اپشن‌ها با پاسخ، دامنه طول متن‌ها.
- درس ناموفق فقط خودش دوباره تولید می‌شود (`rewrite_lesson_id`).
- مالک فایل‌ها/اجرا: Edge Function `content-admin` (فاز ۲). کلید Groq هرگز به کلاینت نمی‌رود.

وضعیت‌ها: `draft → generated → validated → published` و `failed`.

## ۵. نقشه Edge Functions

| تابع | کار | فاز |
|---|---|---|
| `ai-chat` | بررسی quota، ساخت پرامپت با زمینه درس/سناریو، تماس با Groq، ذخیره پیام‌ها و `ai_usage` | ۲ |
| `content-admin` | تولید/اعتبارسنجی/انتشار درس، بررسی تکراری، ذخیره کلید Groq، تست AI | ۲ |
| `myket-verify` | تأیید `purchaseToken` با API مایکت، ثبت `purchases` و فعال‌سازی `subscriptions` | ۳ |

قواعد `ai-chat` (تصمیم‌های محصولی):
- کاربر رایگان در Conversation: سقف **۲ پیام در کل** → پاسخ `402` با پیام محترمانه؛ **هیچ پاسخ جعلی تولید نمی‌شود**.
- کاربر رایگان در Tutor: `403` (ویژه Premium).
- کاربر Premium: سقف روزانه از `ai_settings` (برای جلوگیری از مصرف انفجاری).

## ۶. تم پویا

رنگ‌ها در `theme_settings` ذخیره و در زمان اجرا به CSS Variables تبدیل می‌شوند
(`ThemeProvider` + کانال Realtime). تغییر تم در پنل مدیریت **بلافاصله** در همه مرورگرها اعمال می‌شود؛ نیازی به انتشار نسخه جدید نیست.

## ۷. تصمیم‌های MVP (حذف عمدی)

حذف‌شده: Pronunciation Engine، Speech-to-Text، Voice Scoring، Placement Test، Leaderboard، Badges، Loyalty، Support Ticket، Coupon، Dynamic Pricing، Redis، NestJS، اپ ادمین جدا، WebView، Mock Data، پاسخ AI جعلی.

## ۸. کارهای باقی‌مانده فاز ۱ (اختیاری)

- ساخت باکت‌های Storage: با `0009_storage.sql` انجام می‌شود (در SETUP.sql موجود است).
- قالب‌های ایمیل Auth (تأیید ایمیل/بازیابی گذرواژه) در Supabase قابل سفارشی‌سازی است.
- فایل‌های نمونه در حالت پیش‌نمایش طراحی، در فاز ۲ با محتوای واقعی Content Factory جایگزین می‌شوند.

## ۹. فاز Product Experience — افزوده‌ها

### Frontend (پوستهٔ مستقل برنامه)
- `components/layout/AppShell.tsx` — پوستهٔ مستقل `/app`: Sidebar ثابت دسکتاپ، Top bar + Bottom nav + FAB هوش مصنوعی در موبایل، کشوی پروفایل، مرکز اعلان، جستجوی global (`Ctrl/⌘ + K`). این پوسته بین مسیرها mount می‌ماند و هیچ بخشی از سایت عمومی را رندر نمی‌کند.
- `pages/app/Dashboard.tsx` — داشبورد تازه (جایگزین `AppHome`): ادامه یادگیری، Language Hub، AI Hub، فعالیت واقعی، بخش Premium.
- `pages/app/Onboarding.tsx` — مسیر چهار مرحله‌ای بعد از ثبت‌نام + گیت‌های `OnboardingGate` و `OnboardingRedirect` در `App.tsx`.
- `pages/app/Settings.tsx` و `pages/app/Help.tsx` — تنظیمات کامل (زبان، هدف، سطح، اعلان، کاهش انیمیشن، بازنشانی تور، گذرواژه) و راهنما + ارسال پیام واقعی به پشتیبانی.
- `pages/app/Profile.tsx` — اطلاعات حساب، وضعیت اشتراک و میان‌بر بازاجرای تور (بدون تکرار بخش‌های تنظیمات).
- `pages/admin/MediaLibrary.tsx` — مدیریت تصاویر تمام جایگاه‌ها.
- `lib/constants.ts` — منبع واحد ناوبری، سناریوهای مکالمه، ۱۲ بخش درس، جایگاه‌های رسانه، اهداف یادگیری، گام‌های تور.
- `lib/assets.ts` — نگاشت جایگاه رسانه → تصویر پیش‌فرض bundled (`DEFAULT_MEDIA`) و مسیر تصویر هر سناریو.
- `lib/motion.ts` + `Reveal`/`StaggerGroup` در `components/ui` — موشن مشترک با احترام به `prefers-reduced-motion`.
- `context/ThemeContext.tsx` — حالت روشن/تاریک، رنگ‌های معنایی و توکن مشتق‌شده.

### Database (migration 0010 + تکمیل 0009)
- `media_assets` — جایگاه تصویر (slot یکتا) با category/url/storage_path/alt_fa/used_in/is_active/sort_order و seed تصاویر پیش‌فرض.
- `notifications` + `notify()`/`notify_all_users()` + تریگرهای `trg_notify_lesson` و `trg_notify_subscription` (فقط رویداد واقعی).
- `support_messages` — پیام واقعی کاربر: insert فقط برای صاحب پیام، خواندن برای مدیر.
- `profiles` — `goal`, `target_language`, `onboarding_done`, `reduce_motion`, `preferred_level`.
- `plans` — `original_price`, `promo_price`, `promo_label`, `promo_active`, `promo_ends_at`, `show_on_marketing`.
- `theme_settings` — `success`/`warning`/`danger`/`hero_overlay` و پالت پیش‌فرض روشن بنفش.
- `app_settings` — گروه‌های `marketing` (متن و CTA هیرو) و `onboarding` (اهداف).
- `app_search(p_query)` — جستجوی درس‌های منتشرشده با پرچم قفل/رایگان.
- `admin_dashboard()` — گسترش‌یافته با معیارهای واقعی AI و رشد کاربران.
