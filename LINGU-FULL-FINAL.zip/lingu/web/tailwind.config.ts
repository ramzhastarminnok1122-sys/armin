import type { Config } from 'tailwindcss'

/**
 * LINGU design tokens.
 * Real colors are CSS variables injected at runtime from the database (admin > Theme),
 * so changing the theme never requires a new deploy.
 */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Vazirmatn', 'system-ui', 'Segoe UI', 'sans-serif'],
        display: ['Vazirmatn', 'system-ui', 'sans-serif'],
        latin: ['Vazirmatn', 'system-ui', 'sans-serif'],
      },
      colors: {
        primary: { DEFAULT: 'rgb(var(--c-primary) / <alpha-value>)', soft: 'rgb(var(--c-primary-soft) / <alpha-value>)', fg: 'rgb(var(--c-primary-fg) / <alpha-value>)' },
        secondary: { DEFAULT: 'rgb(var(--c-secondary) / <alpha-value>)' },
        accent: { DEFAULT: 'rgb(var(--c-accent) / <alpha-value>)' },
        bg: { DEFAULT: 'rgb(var(--c-bg) / <alpha-value>)', soft: 'rgb(var(--c-bg-soft) / <alpha-value>)' },
        card: { DEFAULT: 'rgb(var(--c-card) / <alpha-value>)', soft: 'rgb(var(--c-card-soft) / <alpha-value>)' },
        ink: { DEFAULT: 'rgb(var(--c-text) / <alpha-value>)', muted: 'rgb(var(--c-text-muted) / <alpha-value>)', faint: 'rgb(var(--c-text-faint) / <alpha-value>)' },
        line: { DEFAULT: 'rgb(var(--c-line) / <alpha-value>)' },
        success: 'rgb(var(--c-success) / <alpha-value>)',
        warn: 'rgb(var(--c-warning) / <alpha-value>)',
        danger: 'rgb(var(--c-danger) / <alpha-value>)',
      },
      borderRadius: { xl: '0.9rem', '2xl': '1.25rem', '3xl': '1.75rem', '4xl': '2.25rem' },
      boxShadow: {
        soft: '0 1px 2px rgb(0 0 0 / 0.04), 0 12px 32px -12px rgb(var(--c-primary) / 0.25)',
        glow: '0 0 0 1px rgb(var(--c-primary) / 0.25), 0 20px 60px -20px rgb(var(--c-primary) / 0.55)',
        card: '0 1px 0 rgb(255 255 255 / 0.04) inset, 0 18px 40px -24px rgb(0 0 0 / 0.75)',
      },
      backgroundImage: {
        'brand-grad': 'linear-gradient(135deg, rgb(var(--c-primary)) 0%, rgb(var(--c-secondary)) 55%, rgb(var(--c-accent)) 115%)',
        'brand-soft': 'linear-gradient(135deg, rgb(var(--c-primary) / 0.18), rgb(var(--c-accent) / 0.12))',
        'mesh': 'radial-gradient(60% 60% at 15% 10%, rgb(var(--c-primary) / 0.28), transparent 60%), radial-gradient(50% 50% at 85% 5%, rgb(var(--c-accent) / 0.22), transparent 60%), radial-gradient(60% 60% at 60% 90%, rgb(var(--c-secondary) / 0.20), transparent 65%)',
      },
      keyframes: {
        float: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-10px)' } },
        shimmer: { '100%': { transform: 'translateX(-100%)' } },
        'pulse-ring': { '0%': { transform: 'scale(0.9)', opacity: '0.7' }, '100%': { transform: 'scale(1.6)', opacity: '0' } },
        'gradient-x': { '0%,100%': { backgroundPosition: '0% 50%' }, '50%': { backgroundPosition: '100% 50%' } },
      },
      animation: {
        float: 'float 6s ease-in-out infinite',
        shimmer: 'shimmer 1.8s infinite',
        'pulse-ring': 'pulse-ring 2s ease-out infinite',
        'gradient-x': 'gradient-x 12s ease infinite',
      },
    },
  },
  plugins: [],
} satisfies Config
