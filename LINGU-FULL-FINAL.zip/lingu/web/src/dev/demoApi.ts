/**
 * ⚠️ DESIGN PREVIEW ONLY — never present in the shipped product.
 *
 * Loaded exclusively when VITE_DEMO_MODE=true in a local dev run (vite.config.ts
 * refuses to build a production bundle with that flag). It lets a reviewer see the
 * LINGU interface without a Supabase project.
 *
 * Two rules this file must never break:
 *  1. No fake "ready" account. The preview starts anonymous and the reviewer steps in
 *     as a brand-new user (no name, no onboarding, no progress) — exactly like signup.
 *  2. No fake intelligence. AI calls fail loudly with the product's own
 *     "AI is not available" message; nothing is invented on the server's behalf.
 * Writes that must reach a database (purchases, admin edits) throw NO_DEMO_WRITE.
 */
import type { LanguApi } from '@/services/api'
import { NO_DEMO_WRITE } from '@/services/api'
import type {
  AdminDashboard, AdminUserRow, AiQuota, AiUsageRow, Banner, Batch, ChatMessage,
  AppNotification, Conversation, Curriculum, Faq, Language, LessonFull, LessonPlan, MediaAsset,
  Membership, Plan, Profile, Progress, SearchHit, Testimonial,
} from '@/services/types'
import { DEFAULT_MEDIA } from '@/lib/assets'

/** Admin/purchase writes need a real database — the preview refuses instead of pretending. */
const fail = async (): Promise<never> => { throw new Error(NO_DEMO_WRITE) }

const languages: Language[] = [
  { code: 'en', name_fa: 'انگلیسی', name_en: 'English', native_name: 'English', flag: '🇬🇧', gradient: 'from-indigo-500 via-blue-500 to-cyan-400', description: 'زبان جهانی کار، سفر و اینترنت — از مکالمه روزمره تا مصاحبه کاری.', target_lessons: 340, is_active: true, sort_order: 1 },
  { code: 'fr', name_fa: 'فرانسه', name_en: 'French', native_name: 'Français', flag: '🇫🇷', gradient: 'from-rose-500 via-pink-500 to-indigo-400', description: 'زبان فرهنگ، هنر و تحصیل در اروپا — با ساختار دقیق و رسمی.', target_lessons: 340, is_active: true, sort_order: 2 },
  { code: 'es', name_fa: 'اسپانیایی', name_en: 'Spanish', native_name: 'Español', flag: '🇪🇸', gradient: 'from-amber-400 via-orange-500 to-rose-500', description: 'پرجمعیت‌ترین زبان مادری جهان — سریع، موزیکال و کاربردی.', target_lessons: 340, is_active: true, sort_order: 3 },
]

const plans: Plan[] = [
  { id: 'p-free', code: 'free', title_fa: 'رایگان', subtitle_fa: 'شروع بدون هزینه', description_fa: 'برای همیشه رایگان — با ۲ درس کامل از هر زبان کیفیت LINGU را تجربه کن.', sku: 'free', duration_days: 0, display_price: 0, price_label: null, badge: null, features: ['۲ درس کامل رایگان در English', '۲ درس کامل رایگان در French', '۲ درس کامل رایگان در Spanish', '۲ پیام رایگان Conversation Partner', 'ثبت پیشرفت درس‌های رایگان'], is_active: true, is_recommended: false, original_price: 750000, promo_price: 299000, promo_label: 'پیشنهاد ویژه ماه مهر', promo_active: true, promo_ends_at: null, show_on_marketing: true, sort_order: 1 },
  { id: 'p-m', code: 'monthly', title_fa: 'اشتراک ماهانه', subtitle_fa: 'یک ماه دسترسی کامل', description_fa: 'دسترسی کامل به همه زبان‌ها، AI Tutor و Conversation Partner.', sku: 'LINGU_MONTHLY', duration_days: 30, display_price: 0, price_label: null, badge: null, features: ['همه درس‌های منتشرشده در سه زبان', 'AI Tutor نامحدود (طبق سقف روزانه)', 'Conversation Partner با سناریوهای واقعی', 'ثبت و پیگیری کامل پیشرفت', 'ادامه یادگیری از هر دستگاهی'], is_active: true, is_recommended: false, original_price: 750000, promo_price: 299000, promo_label: 'پیشنهاد ویژه ماه مهر', promo_active: true, promo_ends_at: null, show_on_marketing: true, sort_order: 2 },
  { id: 'p-q', code: 'quarterly', title_fa: 'اشتراک سه‌ماهه', subtitle_fa: 'سه ماه، صرفه بیشتر', description_fa: 'همان دسترسی کامل با قیمت بهتر نسبت به ماهانه.', sku: 'LINGU_QUARTERLY', duration_days: 90, display_price: 0, price_label: null, badge: 'محبوب', features: ['همه امکانات اشتراک ماهانه', 'قیمت مناسب‌تر برای یادگیری پیوسته', 'مناسب برنامه‌های ۹۰ روزه'], is_active: true, is_recommended: true, original_price: 750000, promo_price: 299000, promo_label: 'پیشنهاد ویژه ماه مهر', promo_active: true, promo_ends_at: null, show_on_marketing: true, sort_order: 3 },
  { id: 'p-y', code: 'yearly', title_fa: 'اشتراک سالانه', subtitle_fa: 'یک سال کامل', description_fa: 'کمترین هزینه ماهانه برای یادگیری بلندمدت.', sku: 'LINGU_YEARLY', duration_days: 365, display_price: 0, price_label: null, badge: 'بهترین ارزش', features: ['همه امکانات اشتراک ماهانه', 'کمترین قیمت ماهانه', 'دسترسی به تمام محتوای جدید سال'], is_active: true, is_recommended: false, original_price: 750000, promo_price: 299000, promo_label: 'پیشنهاد ویژه ماه مهر', promo_active: true, promo_ends_at: null, show_on_marketing: true, sort_order: 4 },
]

const faqs: Faq[] = [
  { id: 'f1', question: 'آیا استفاده از LINGU رایگان است؟', answer: 'بله. حساب رایگان برای همیشه فعال می‌ماند و در هر سه زبان دو درس کامل رایگان دارد.', category: 'general', is_published: true, sort_order: 1 },
  { id: 'f2', question: 'رایگان چه چیزی دریافت می‌کنم؟', answer: '۶ درس کامل، ۲ پیام Conversation Partner و ثبت پیشرفت. بدون محدودیت زمانی.', category: 'pricing', is_published: true, sort_order: 2 },
  { id: 'f3', question: 'Conversation Partner چه تفاوتی با AI Tutor دارد؟', answer: 'Partner نقش واقعی بازی می‌کند و مکالمه را ادامه می‌دهد؛ Tutor توضیح می‌دهد و تمرین می‌سازد.', category: 'features', is_published: true, sort_order: 3 },
  { id: 'f4', question: 'چطور می‌توانم اشتراک بگیرم؟', answer: 'در صفحه «اشتراک» پلن دلخواه را انتخاب کن. خرید در نسخه اندروید انجام می‌شود و بعد از تأیید، اشتراک به‌صورت خودکار روی همین حساب فعال می‌شود.', category: 'pricing', is_published: true, sort_order: 4 },
]

const testimonials: Testimonial[] = [
  { id: 't1', name: 'سارا م.', role: 'دانشجوی ارشد', quote: 'درس‌ها واقعاً منظم‌اند؛ از warmup تا مکالمه هر بخش یک قدم منطقی است.', avatar_url: null, rating: 5, is_published: true, sort_order: 1 },
  { id: 't2', name: 'امیر ک.', role: 'برنامه‌نویس', quote: 'Conversation Partner بیشتر شبیه یک هم‌صحبت واقعی است تا ربات.', avatar_url: null, rating: 5, is_published: true, sort_order: 2 },
  { id: 't3', name: 'نگار ر.', role: 'معلم زبان', quote: 'ساختار درس‌ها و کیفیت محتوا بالاست؛ برای تمرین شخصی خودم استفاده می‌کنم.', avatar_url: null, rating: 5, is_published: true, sort_order: 3 },
]

const banners: Banner[] = [
  { id: 'b1', title: 'پیشنهاد ویژه ماه مهر', body: 'اشتراک سالانه LINGU با تخفیف ویژه — دسترسی کامل به همه درس‌ها، AI Tutor و Conversation Partner.', cta_label: 'دیدن پلن‌ها', cta_url: '/app/subscription', image_url: null, tone: 'primary', placement: 'user_home', is_active: true, sort_order: 1 },
]



/* ---------------------------------------------------------------------------
 * Preview lessons: one per language, so the lesson reader can be reviewed
 * before the real Content Factory pipeline (phase 2) produces production lessons.
 * They are marked with the PREVIEW badge in the UI.
 * ------------------------------------------------------------------------- */
const previewLesson = (lang: 'en' | 'fr' | 'es', id: string, title: string, subtitle: string): LessonFull => ({
  id, language_code: lang, level: 'A1', order_index: 1, title, subtitle,
  description: subtitle, estimated_minutes: 18, is_free: true, status: 'published',
  published_at: new Date().toISOString(),
  content: {
    meta: { cefr: 'A1', topic: subtitle, objectives: ['درخواست مؤدبانه', 'ساخت جمله سؤال', 'واژگان پایه'] },
    warmup: {
      prompt_fa: 'قبل از شروع، به این سؤال‌ها فکر کن (نیازی به نوشتن نیست):',
      questions: [
        { q: 'آخرین بار کجا سفارش دادی؟', hint_fa: 'کافه، رستوران، اینترنتی…' },
        { q: 'معمولاً چطور شروع می‌کنی؟', hint_fa: 'با سلام یا با سؤال؟' },
      ],
    },
    explanation: {
      title: 'هدف این درس',
      body_fa: 'در این درس یاد می‌گیری یک سفارش ساده را کامل و مؤدبانه انجام بدهی: سلام، سفارش، سؤال درباره جزئیات و پرداخت.\nساختار جمله‌ها کوتاه است و با کمی تمرین می‌توانی همان‌ها را در موقعیت واقعی استفاده کنی.',
      key_points: [
        'با عبارت مؤدبانه شروع کن، نه با «I want».',
        'برای سؤال از ساختار ساده استفاده کن.',
        'در پایان، تشکر کردن بخشی از مکالمه است.',
      ],
    },
    vocabulary: {
      items: [
        { term: 'order', ipa: '/ˈɔːdər/', translation_fa: 'سفارش دادن', example: 'I would like to order a coffee.', example_fa: 'می‌خواهم یک قهوه سفارش بدهم.', tag: 'فعل' },
        { term: 'menu', ipa: '/ˈmenjuː/', translation_fa: 'منو', example: 'Could I see the menu, please?', example_fa: 'می‌توانم منو را ببینم؟', tag: 'اسم' },
        { term: 'please', ipa: '/pliːz/', translation_fa: 'لطفاً', example: 'A glass of water, please.', example_fa: 'یک لیوان آب، لطفاً.', tag: 'قید' },
        { term: 'bill', ipa: '/bɪl/', translation_fa: 'صورت‌حساب', example: 'Could we have the bill, please?', example_fa: 'می‌شود صورت‌حساب را بیاورید؟', tag: 'اسم' },
      ],
    },
    grammar: {
      title: 'درخواست مؤدبانه با would like',
      explanation_fa: 'برای درخواست مؤدبانه به‌جای «I want» از «I would like» استفاده می‌کنیم. در گفت‌وگوی روزمره کوتاه‌شده آن «I\'d like» است. این ساختار هم مؤدبانه است و هم در همه موقعیت‌ها طبیعی به نظر می‌رسد.',
      pattern: 'I would like + [مورد درخواست] + , please.',
      table: {
        headers: ['ساختار', 'مثال', 'ترجمه'],
        rows: [
          ['I would like a tea.', 'I would like a tea, please.', 'یک چای می‌خواهم، لطفاً.'],
          ['I\'d like to order.', 'I\'d like to order now.', 'می‌خواهم الان سفارش بدهم.'],
          ['Could I have…?', 'Could I have the menu?', 'می‌توانم منو را داشته باشم؟'],
        ],
      },
      pitfalls_fa: [
        '«I want a coffee, please» مؤدبانه نیست؛ از «I\'d like» استفاده کن.',
        'فراموش نکن «please» را در پایان جمله بیاوری.',
      ],
    },
    examples: {
      items: [
        { target: 'Good morning! I\'d like a coffee, please.', fa: 'صبح بخیر! یک قهوه می‌خواهم، لطفاً.', note_fa: 'شروع استاندارد و مؤدبانه.' },
        { target: 'Could I have it with milk?', fa: 'می‌توانم با شیر بگیرم؟', note_fa: 'برای تغییر جزئیات سفارش.' },
        { target: 'That\'s all, thank you.', fa: 'همین کافی است، ممنون.', note_fa: 'پایان دادن مؤدبانه به سفارش.' },
      ],
    },
    listening: {
      title_fa: 'گفت‌وگوی کوتاه در کافه',
      script: 'Barista: Good morning! What can I get for you?\nCustomer: Good morning. I would like a cappuccino, please.\nBarista: Sure. Anything else?\nCustomer: No, that\'s all. Thank you!',
      script_fa: 'باریستا: صبح بخیر! چه چیزی برایتان بیاورم؟\nمشتری: صبح بخیر. یک کاپوچینو می‌خواهم، لطفاً.\nباریستا: حتماً. چیز دیگری هم می‌خواهید؟\nمشتری: نه، همین. ممنون!',
      question_fa: 'مشتری چه چیزی سفارش داد؟',
      answer: 'A cappuccino.',
      needs_audio: false,
    },
    dialogue: {
      title_fa: 'سفارش در کافه',
      lines: [
        { speaker: 'A', target: 'Hi! What can I get you?', fa: 'سلام! چه چیزی بیاورم؟' },
        { speaker: 'B', target: 'I\'d like a coffee, please.', fa: 'یک قهوه می‌خواهم، لطفاً.' },
        { speaker: 'A', target: 'Small or large?', fa: 'کوچک یا بزرگ؟' },
        { speaker: 'B', target: 'Large, please. Thanks!', fa: 'بزرگ، لطفاً. ممنون!' },
      ],
    },
    speaking: {
      task_fa: 'این مکالمه را دو بار بلند تمرین کن: یک‌بار در نقش مشتری و یک‌بار در نقش باریستا. سپس همان مکالمه را در Conversation Partner با سناریوی «کافه» اجرا کن.',
      useful_phrases: [
        { target: 'I\'d like…, please.', fa: 'می‌خواهم…، لطفاً.' },
        { target: 'Could I have…?', fa: 'می‌توانم … داشته باشم؟' },
        { target: 'That\'s all, thanks.', fa: 'همین، ممنون.' },
      ],
      seconds: 180,
    },
    reading: {
      title: 'A Short Note',
      text: 'Hi Sara,\nI am at the cafe near the station. I ordered a coffee and a cake. The coffee here is very good. See you at 6!\n— Amir',
      glossary: [{ term: 'ordered', fa: 'سفارش داد' }, { term: 'cake', fa: 'کیک' }, { term: 'near the station', fa: 'نزدیک ایستگاه' }],
      questions: [
        { q_fa: 'امیر کجا است؟', a: 'At the cafe near the station.' },
        { q_fa: 'چه چیزی سفارش داد؟', a: 'A coffee and a cake.' },
      ],
    },
    exercises: {
      items: [
        { type: 'mcq', prompt_fa: 'کدام جمله مؤدبانه‌تر است؟', question: 'انتخاب کن:', options: ['I want a tea.', 'I\'d like a tea, please.', 'Give me a tea.'], answer: 'I\'d like a tea, please.', explanation_fa: '«I would like» ساختار مؤدبانه درخواست است.' },
        { type: 'fill', prompt_fa: 'جای خالی را پر کن:', question: 'Could I ______ the menu, please?', answer: ['have', 'see'], explanation_fa: 'با Could I have/see ساختار مؤدبانه سؤال می‌سازیم.' },
        { type: 'truefalse', prompt_fa: 'درست یا غلط:', question: '«please» در پایان جمله مؤدبانه‌تر است.', answer: 'True' },
      ],
    },
    quiz: {
      items: [
        { type: 'mcq', question: 'بهترین شروع برای سفارش در کافه:', options: ['I want coffee now.', 'I\'d like a coffee, please.', 'Coffee!'], answer: 'I\'d like a coffee, please.', explanation_fa: 'مؤدبانه و طبیعی.' },
        { type: 'mcq', question: 'معنی «bill» چیست؟', options: ['منو', 'صورت‌حساب', 'فنجان'], answer: 'صورت‌حساب' },
        { type: 'truefalse', question: 'پس از گرفتن سفارش، تشکر کردن بخشی از مکالمه است.', answer: 'True' },
      ],
    },
    ai_practice: {
      task_fa: 'با AI Tutor همین موقعیت را تمرین کن: او نقش باریستا را بازی می‌کند و تو سفارش می‌دهی. می‌توانی بخواهی جمله‌هایت را هم اصلاح کند.',
      suggested_prompts: ['نقش باریستا را بازی کن و مکالمه کافه را با من تمرین کن', 'جمله‌های من درست بود؟ اصلاحشان کن', 'سه جمله مؤدبانه دیگر برای سفارش بگو'],
      focus: ['درخواست مؤدبانه', 'واژگان کافه', 'پرسش‌های کوتاه'],
    },
  },
})

const previewLessons: LessonFull[] = [
  previewLesson('en', 'preview-en-1', 'Ordering at a Café', 'مکالمه روزمره — سفارش دادن در کافه'),
  previewLesson('fr', 'preview-fr-1', 'Commander au Café', 'مکالمه روزمره — سفارش دادن در کافه'),
  previewLesson('es', 'preview-es-1', 'Pedir en una Cafetería', 'مکالمه روزمره — سفارش دادن در کافه'),
]

const emptyDashboard: AdminDashboard = {
  users_total: 0, users_active_7d: 0, users_new_7d: 0, premium_users: 0,
  lessons_total: 0, lessons_published: 0, lessons_draft: 0, lessons_failed: 0, plans_failed: 0,
  ai_calls_24h: 0, ai_tokens_24h: 0, ai_calls_total: 0, ai_errors_24h: 0, active_subs: 0,
  recent_users: [], lessons_by_language: {}, signups_14d: [],
  tutor_calls_24h: 0, partner_calls_24h: 0, conversations_total: 0, messages_total: 0, partner_messages_24h: 0,
}

const aiUnavailable = async (): Promise<never> => {
  throw Object.assign(new Error('مربی هوش مصنوعی فعلاً در دسترس نیست.'), { status: 503, payload: { code: 'ai_disabled' } })
}

/* ---------------------------------------------------------------------------
 * Preview state.
 * The real product keeps the profile and progress on the server, so they survive
 * a refresh, a direct URL and a logout/login round-trip. The preview mirrors that
 * with localStorage — same behaviour, no server. Nothing here ships to production.
 * ------------------------------------------------------------------------- */
export const PREVIEW_PROFILE_KEY = 'lingu.preview.profile'
export const PREVIEW_PROGRESS_KEY = 'lingu.preview.progress'

const freshProfile = (): Profile => ({
  // a brand-new account: no name, no onboarding, no tour, no progress
  id: 'demo-user', display_name: null, avatar_url: null, role: 'user',
  is_active: true, tour_done: false, locale: 'fa', last_seen_at: null,
  created_at: new Date().toISOString(),
  goal: null, target_language: null, onboarding_done: false,
  reduce_motion: false, preferred_level: null,
})

function readStore<T>(key: string, fallback: T): T {
  try { const raw = localStorage.getItem(key); return raw ? (JSON.parse(raw) as T) : fallback } catch { return fallback }
}
function writeStore(key: string, value: unknown) {
  try { localStorage.setItem(key, JSON.stringify(value)) } catch { /* private mode */ }
}

const state: { profile: Profile; progress: Progress[] } = {
  profile: readStore<Profile>(PREVIEW_PROFILE_KEY, freshProfile()),
  progress: readStore<Progress[]>(PREVIEW_PROGRESS_KEY, []),
}

/** Used by the preview banner: back to a brand-new account. */
export function resetPreviewState() {
  state.profile = freshProfile()
  state.progress = []
  writeStore(PREVIEW_PROFILE_KEY, state.profile)
  writeStore(PREVIEW_PROGRESS_KEY, state.progress)
}

const quota: AiQuota = {
  authenticated: true, premium: false, free_partner_limit: 2, partner_used: 0,
  partner_remaining: 2, tutor_remaining: 0, premium_daily_messages: 200, ai_enabled: true,
}

export function createDemoApi(): LanguApi {
  return {
    mode: 'demo',
    async bootstrap() {
      return { languages, plans, settings: { general: { app_name: 'LINGU', tagline: 'یادگیری زبان، هوشمند و واقعی', show_banners: true }, learning: { free_lessons_per_language: 2, free_conversation_messages: 2 } }, theme: null }
    },
    async publicContent() { return { faqs, testimonials, banners } },
    async profile(): Promise<Profile | null> { return state.profile },
    async media(): Promise<MediaAsset[]> {
      const cat = (slot: string) =>
        slot.startsWith('hero') ? 'hero' : slot.startsWith('lang') ? 'languages'
        : slot.startsWith('scenario') ? 'scenarios' : slot === 'premium' ? 'premium'
        : slot === 'onboarding' ? 'onboarding' : 'ai'
      return Object.entries(DEFAULT_MEDIA).map(([slot, v], i) => ({
        id: `media-${slot}`, slot, name: slot, category: cat(slot), url: v.url,
        storage_path: null, alt_fa: v.alt ?? null, used_in: [], is_active: true,
        sort_order: i + 1, created_at: new Date().toISOString(),
      }))
    },
    uploadAvatar: fail as any,
    supportRequest: fail as any,
    async adminSupport(): Promise<any[]> { return [] },
    adminSupportStatus: fail as any,
    saveMediaAsset: fail as any,
    uploadMedia: fail as any,
    deleteMediaAsset: fail as any,
    async notifications(): Promise<AppNotification[]> { return [] },
    async markNotificationsRead() { /* preview */ },
    async search(query: string): Promise<SearchHit[]> {
      const q = query.trim().toLowerCase()
      if (!q) return []
      return previewLessons
        .filter((l) => l.title.toLowerCase().includes(q) || (l.subtitle ?? '').includes(q))
        .map((l) => ({
          kind: 'lesson' as const, id: l.id, title: l.title, subtitle: l.subtitle,
          language_code: l.language_code, level: l.level, is_free: l.is_free, locked: false,
          url: `/app/lessons/${l.id}`,
        }))
    },
    async membership(): Promise<Membership> { return { premium: false, subscription: null, plan: null, days_left: null } },
    async touchLastSeen() { /* no-op */ },
    async updateProfile(patch) {
      // in-memory only: the preview can walk through onboarding/profile edits,
      // but nothing pretends to be persisted on a server
      state.profile = { ...state.profile, ...(patch as Partial<Profile>) }
      writeStore(PREVIEW_PROFILE_KEY, state.profile)
    },
    async catalog() {
      return previewLessons.map((l) => ({
        id: l.id, language_code: l.language_code, level: l.level, order_index: l.order_index,
        title: l.title, subtitle: l.subtitle, description: l.description,
        estimated_minutes: l.estimated_minutes, is_free: l.is_free, locked: false, completed: false,
      }))
    },
    async lesson(id) { return previewLessons.find((l) => l.id === id) ?? null },
    async myProgress(): Promise<Progress[]> { return state.progress },
    async saveProgress(input) {
      const prev = state.progress.find((x) => x.lesson_id === input.lesson_id)
      const row: Progress = {
        id: prev?.id ?? `demo-progress-${input.lesson_id}`,
        lesson_id: input.lesson_id,
        status: input.status,
        last_section: input.last_section ?? prev?.last_section ?? null,
        sections_done: input.sections_done ?? prev?.sections_done ?? [],
        score: input.score ?? prev?.score ?? null,
        time_spent_sec: input.time_spent_sec ?? prev?.time_spent_sec ?? 0,
        started_at: prev?.started_at ?? new Date().toISOString(),
        completed_at: input.status === 'completed' ? new Date().toISOString() : (prev?.completed_at ?? null),
      }
      state.progress = [...state.progress.filter((x) => x.lesson_id !== input.lesson_id), row]
      writeStore(PREVIEW_PROGRESS_KEY, state.progress)
      return row
    },
    async aiQuota() { return quota },
    async conversations(): Promise<Conversation[]> { return [] },
    async messages(): Promise<ChatMessage[]> { return [] },
    createConversation: aiUnavailable,
    async deleteConversation() { return },
    sendMessage: aiUnavailable,
    async adminDashboard() { return emptyDashboard },
    async adminUsers(): Promise<AdminUserRow[]> { return [] },
    adminSetUserActive: fail as any,
    adminSetUserRole: fail as any,
    async adminSubscriptions() { return [] },
    adminRevokeSubscription: fail as any,
    async adminAiUsage(): Promise<AiUsageRow[]> { return [] },
    async adminMedia(): Promise<MediaAsset[]> { return await this.media() as any },
    async adminLessons() { return [] },
    adminSetLessonFlags: fail as any,
    adminDeleteLesson: fail as any,
    adminSaveLesson: fail as any,
    async curricula(): Promise<Curriculum[]> { return [] },
    createCurriculum: fail as any,
    deleteCurriculum: fail as any,
    async plans(): Promise<LessonPlan[]> { return [] },
    createPlans: fail as any,
    generateNext: fail as any,
    async batches(): Promise<Batch[]> { return [] },
    validateLesson: fail as any,
    async duplicateReport() { return { duplicates: [] } },
    publishLessons: fail as any,
    saveTheme: fail as any,
    saveAppSetting: fail as any,
    saveAiSettings: fail as any,
    saveGroqKey: fail as any,
    testAi: fail as any,
    savePlan: fail as any,
    saveFaq: fail as any,
    saveTestimonial: fail as any,
    saveBanner: fail as any,
    saveLanguage: fail as any,
    deleteRow: fail as any,
  } as LanguApi
}
