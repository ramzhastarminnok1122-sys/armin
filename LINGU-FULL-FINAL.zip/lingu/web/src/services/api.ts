import { supabase, callFunction, hasBackend } from '@/lib/supabase'
import type {
  AdminDashboard, AdminUserRow, AiQuota, AiSettings, AiUsageRow, AppNotification, Banner, Batch,
  ChatMessage, Conversation, Curriculum, Faq, Language, LessonFull, LessonMeta, LessonPlan, MediaAsset,
  Membership, Plan, Profile, Progress, SearchHit, Subscription, Testimonial,
} from './types'

/** Everything the UI can ask for. Two implementations: Supabase (real) and demo (design showcase). */
export interface LanguApi {
  mode: 'supabase' | 'demo'
  // bootstrap
  bootstrap(): Promise<{ languages: Language[]; plans: Plan[]; settings: Record<string, any>; theme: any }>
  publicContent(): Promise<{ faqs: Faq[]; testimonials: Testimonial[]; banners: Banner[] }>
  // profile / membership
  profile(): Promise<Profile | null>
  // media + notifications + search
  media(): Promise<MediaAsset[]>
  saveMediaAsset(payload: Partial<MediaAsset> & { slot: string; name: string; url: string }): Promise<void>
  uploadMedia(file: File, slot: string): Promise<{ url: string; path: string }>
  uploadAvatar(file: File): Promise<string>
  deleteMediaAsset(id: string, storagePath?: string | null): Promise<void>
  notifications(limit?: number): Promise<AppNotification[]>
  markNotificationsRead(ids?: string[]): Promise<void>
  search(query: string): Promise<SearchHit[]>
  supportRequest(body: string, subject?: string): Promise<void>
  adminSupport(): Promise<{ id: string; email: string | null; subject: string | null; body: string; status: string; created_at: string }[]>
  adminSupportStatus(id: string, status: 'open' | 'answered' | 'closed'): Promise<void>
  membership(): Promise<Membership>
  touchLastSeen(): Promise<void>
  updateProfile(patch: Partial<Pick<Profile, 'display_name' | 'avatar_url' | 'tour_done' | 'locale'>>): Promise<void>
  // learning
  catalog(): Promise<LessonMeta[]>
  lesson(id: string): Promise<LessonFull | null>
  myProgress(): Promise<Progress[]>
  saveProgress(p: { lesson_id: string; status: 'started' | 'completed'; last_section?: string; sections_done?: string[]; score?: number | null; time_spent_sec?: number }): Promise<Progress>
  // ai
  aiQuota(): Promise<AiQuota>
  conversations(mode?: 'tutor' | 'partner'): Promise<Conversation[]>
  messages(conversationId: string): Promise<ChatMessage[]>
  createConversation(input: { mode: 'tutor' | 'partner'; scenario?: string; scenario_fa?: string; lesson_id?: string | null; title?: string }): Promise<Conversation>
  deleteConversation(id: string): Promise<void>
  sendMessage(input: {
    conversation_id: string; message: string; mode?: 'tutor' | 'partner'
    lesson_id?: string | null; scenario?: string; scenario_fa?: string
    language?: string; level?: string; section?: string
  }): Promise<{ reply: string }>
  // admin
  adminDashboard(): Promise<AdminDashboard>
  adminUsers(q: string): Promise<AdminUserRow[]>
  adminSetUserActive(id: string, active: boolean): Promise<void>
  adminSetUserRole(id: string, role: 'user' | 'admin'): Promise<void>
  adminSubscriptions(): Promise<(Subscription & { profile?: Profile; plan_title?: string | null })[]>
  adminRevokeSubscription(id: string): Promise<void>
  adminAiUsage(limit?: number): Promise<AiUsageRow[]>
  adminMedia(): Promise<MediaAsset[]>
  adminLessons(filters: { language?: string; status?: string; q?: string }): Promise<(LessonMeta & { status: string; fingerprint: string | null; created_at: string })[]>
  adminSetLessonFlags(id: string, patch: { status?: string; is_free?: boolean }): Promise<void>
  adminDeleteLesson(id: string): Promise<void>
  adminSaveLesson(payload: { id?: string; language_code: string; level: string; order_index: number; title: string; subtitle?: string; description?: string; estimated_minutes?: number; is_free?: boolean; status?: string; content: any; validation?: any }): Promise<{ id: string }>
  // content factory
  curricula(): Promise<Curriculum[]>
  createCurriculum(payload: { language_code: string; level: string; title_fa: string; summary_fa?: string; target_lessons: number }): Promise<void>
  deleteCurriculum(id: string): Promise<void>
  plans(curriculumId?: string): Promise<LessonPlan[]>
  createPlans(input: { curriculum_id: string; count: number; start_order?: number; mode?: 'ai' | 'manual'; titles?: string[] }): Promise<{ created: number }>
  generateNext(input: { language_code: string; level: string; size?: number; curriculum_id?: string | null; rewrite_lesson_id?: string | null }): Promise<{ batch_id: string; succeeded: number; failed: number; lesson_ids: string[]; errors?: string[] }>
  batches(limit?: number): Promise<Batch[]>
  validateLesson(lessonId: string): Promise<{ ok: boolean; issues: string[]; report: any }>
  duplicateReport(): Promise<{ duplicates: { fingerprint: string; titles: string[]; ids: string[] }[] }>
  publishLessons(ids: string[]): Promise<{ published: number }>
  // settings (admin writes)
  saveTheme(patch: Record<string, unknown>): Promise<void>
  saveAppSetting(key: string, value: any): Promise<void>
  saveAiSettings(patch: Partial<AiSettings>): Promise<void>
  saveGroqKey(key: string): Promise<{ ok: boolean; hint: string }>
  testAi(prompt?: string): Promise<{ ok: boolean; model?: string; reply?: string; error?: string; latency_ms?: number }>
  savePlan(payload: Partial<Plan> & { id?: string; code?: string }): Promise<void>
  saveFaq(payload: Partial<Faq> & { id?: string }): Promise<void>
  saveTestimonial(payload: Partial<Testimonial> & { id?: string }): Promise<void>
  saveBanner(payload: Partial<Banner> & { id?: string }): Promise<void>
  saveLanguage(payload: Partial<Language> & { code: string }): Promise<void>
  deleteRow(table: 'faqs' | 'testimonials' | 'banners' | 'plans' | 'plans_bad', id: string): Promise<void>
}

const assertOk = <T,>(res: { data: T | null; error: { message: string } | null }): T => {
  if (res.error) throw new Error(res.error.message)
  return res.data as T
}

/* ---------------------------------------------------------------------------
 *  REAL implementation — Supabase Postgres + RLS + Edge Functions
 * ------------------------------------------------------------------------- */
export function createSupabaseApi(): LanguApi {
  return {
    mode: 'supabase',

    async bootstrap() {
      const [languages, plans, settings, theme] = await Promise.all([
        supabase.from('languages').select('*').eq('is_active', true).order('sort_order'),
        supabase.from('plans').select('*').eq('is_active', true).order('sort_order'),
        supabase.from('app_settings').select('key,value'),
        supabase.rpc('theme_public'),
      ])
      const map: Record<string, any> = {}
      for (const row of (settings.data ?? []) as { key: string; value: any }[]) map[row.key] = row.value
      return {
        languages: (languages.data ?? []) as Language[],
        plans: (plans.data ?? []) as Plan[],
        settings: map,
        theme: theme.data ?? null,
      }
    },

    async publicContent() {
      const [faqs, testimonials, banners] = await Promise.all([
        supabase.from('faqs').select('*').eq('is_published', true).order('sort_order'),
        supabase.from('testimonials').select('*').eq('is_published', true).order('sort_order'),
        supabase.from('banners').select('*').eq('is_active', true).order('sort_order'),
      ])
      return {
        faqs: (faqs.data ?? []) as Faq[],
        testimonials: (testimonials.data ?? []) as Testimonial[],
        banners: (banners.data ?? []) as Banner[],
      }
    },

    async profile() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return null
      const { data } = await supabase.from('profiles').select('*').eq('id', user.id).maybeSingle()
      return (data as Profile) ?? null
    },

    async media() {
      const { data, error } = await supabase.from('media_assets').select('*').order('sort_order')
      if (error) throw new Error(error.message)
      return (data ?? []) as MediaAsset[]
    },

    async saveMediaAsset(payload) {
      const { data: { user } } = await supabase.auth.getUser()
      const { error } = await supabase.from('media_assets')
        .upsert({ ...payload, updated_by: user?.id ?? null } as any, { onConflict: 'slot' })
      if (error) throw new Error(error.message)
    },

    /** Uploads to Supabase Storage (bucket: media) and returns a public URL. */
    async uploadMedia(file, slot) {
      const ext = (file.name.split('.').pop() || 'png').toLowerCase()
      const path = `${slot}/${Date.now()}.${ext}`
      const up = await supabase.storage.from('media').upload(path, file, { upsert: true, cacheControl: '31536000' })
      if (up.error) throw new Error(up.error.message)
      const { data } = supabase.storage.from('media').getPublicUrl(path)
      return { url: data.publicUrl, path }
    },

    /** Profile picture: stored in the `avatars` bucket under the user's own folder. */
    async uploadAvatar(file) {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error('برای تغییر تصویر باید وارد حساب شوی.')
      const ext = (file.name.split('.').pop() || 'png').toLowerCase()
      const path = `${user.id}/avatar-${Date.now()}.${ext}`
      const up = await supabase.storage.from('avatars').upload(path, file, { upsert: true, cacheControl: '3600' })
      if (up.error) throw new Error(up.error.message)
      const { data } = supabase.storage.from('avatars').getPublicUrl(path)
      const { error } = await supabase.from('profiles').update({ avatar_url: data.publicUrl }).eq('id', user.id)
      if (error) throw new Error(error.message)
      return data.publicUrl
    },

    async deleteMediaAsset(id, storagePath) {
      if (storagePath) await supabase.storage.from('media').remove([storagePath])
      const { error } = await supabase.from('media_assets').delete().eq('id', id)
      if (error) throw new Error(error.message)
    },

    async notifications(limit = 30) {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return []
      const { data } = await supabase.from('notifications').select('*')
        .eq('user_id', user.id).order('created_at', { ascending: false }).limit(limit)
      return (data ?? []) as AppNotification[]
    },

    async markNotificationsRead(ids) {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      let q = supabase.from('notifications').update({ read_at: new Date().toISOString() }).eq('user_id', user.id).is('read_at', null)
      if (ids?.length) q = q.in('id', ids)
      await q
    },

    async supportRequest(body, subject) {
      const { data: { user } } = await supabase.auth.getUser()
      const { error } = await supabase.from('support_messages')
        .insert({ user_id: user?.id ?? null, email: user?.email ?? null, subject: subject ?? null, body })
      if (error) throw new Error(error.message)
    },

    async adminSupport() {
      const { data, error } = await supabase.from('support_messages').select('*').order('created_at', { ascending: false }).limit(200)
      if (error) throw new Error(error.message)
      return (data ?? []) as any
    },

    async adminSupportStatus(id, status) {
      const { error } = await supabase.from('support_messages').update({ status }).eq('id', id)
      if (error) throw new Error(error.message)
    },

    async search(query) {
      if (!query.trim()) return []
      const { data, error } = await supabase.rpc('app_search', { p_query: query.trim() })
      if (error) throw new Error(error.message)
      return (data ?? []) as SearchHit[]
    },

    async membership() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return { premium: false, subscription: null, plan: null, days_left: null }
      const { data: subs } = await supabase
        .from('subscriptions').select('*').eq('user_id', user.id)
        .eq('status', 'active').gt('end_date', new Date().toISOString())
        .order('end_date', { ascending: false }).limit(1)
      const sub = (subs?.[0] as Subscription) ?? null
      let plan: Plan | null = null
      if (sub?.plan_id) {
        const { data } = await supabase.from('plans').select('*').eq('id', sub.plan_id).maybeSingle()
        plan = (data as Plan) ?? null
      }
      const days = sub ? Math.max(0, Math.ceil((new Date(sub.end_date).getTime() - Date.now()) / 86_400_000)) : null
      return { premium: Boolean(sub), subscription: sub, plan, days_left: days }
    },

    async touchLastSeen() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      await supabase.from('profiles').update({ last_seen_at: new Date().toISOString() }).eq('id', user.id)
    },

    async updateProfile(patch) {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error('not_authenticated')
      const { error } = await supabase.from('profiles').update(patch).eq('id', user.id)
      if (error) throw new Error(error.message)
    },

    async catalog() {
      const { data, error } = await supabase.rpc('published_catalog')
      if (error) throw new Error(error.message)
      return (data ?? []) as LessonMeta[]
    },

    async lesson(id) {
      const { data, error } = await supabase.from('lessons').select('*').eq('id', id).maybeSingle()
      if (error) throw new Error(error.message)
      return (data as unknown as LessonFull) ?? null
    },

    async myProgress() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return []
      const { data } = await supabase.from('user_progress').select('*').eq('user_id', user.id)
      return (data ?? []) as Progress[]
    },

    async saveProgress(p) {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error('not_authenticated')
      const { data: existing } = await supabase.from('user_progress')
        .select('*').eq('user_id', user.id).eq('lesson_id', p.lesson_id).maybeSingle()
      const payload: Record<string, any> = {
        user_id: user.id,
        lesson_id: p.lesson_id,
        status: p.status,
        last_section: p.last_section ?? existing?.last_section ?? null,
        sections_done: p.sections_done ?? existing?.sections_done ?? [],
        score: p.score ?? existing?.score ?? null,
        time_spent_sec: Math.max(existing?.time_spent_sec ?? 0, p.time_spent_sec ?? 0),
        completed_at: p.status === 'completed' ? new Date().toISOString() : existing?.completed_at ?? null,
      }
      const { data, error } = await supabase.from('user_progress')
        .upsert(payload, { onConflict: 'user_id,lesson_id' }).select('*').single()
      if (error) throw new Error(error.message)
      return data as Progress
    },

    async aiQuota() {
      const { data, error } = await supabase.rpc('my_ai_quota')
      if (error) throw new Error(error.message)
      return data as AiQuota
    },

    async conversations(mode) {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return []
      let q = supabase.from('conversations').select('*').eq('user_id', user.id).order('updated_at', { ascending: false })
      if (mode) q = q.eq('mode', mode)
      const { data } = await q
      return (data ?? []) as Conversation[]
    },

    async messages(conversationId) {
      const { data } = await supabase.from('messages')
        .select('id,role,content,created_at').eq('conversation_id', conversationId).order('created_at')
      return (data ?? []) as ChatMessage[]
    },

    async createConversation(input) {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error('not_authenticated')
      const { data, error } = await supabase.from('conversations')
        .insert({ ...input, user_id: user.id }).select('*').single()
      if (error) throw new Error(error.message)
      return data as Conversation
    },

    async deleteConversation(id) {
      await supabase.from('conversations').delete().eq('id', id)
    },

    /**
     * AI never runs in the browser: the key, the quota and the prompts live in the
     * Edge Functions (`ai-chat` for the tutor, `conversation` for the partner).
     */
    async sendMessage(input) {
      const fn = input.mode === 'partner' ? 'conversation' : 'ai-chat'
      const { mode, ...payload } = input
      const res = await callFunction<{ reply: string }>(fn, payload)
      return { reply: res.reply }
    },

    /* ---------------- admin ---------------- */
    async adminDashboard() {
      const { data, error } = await supabase.rpc('admin_dashboard')
      if (error) throw new Error(error.message)
      return data as AdminDashboard
    },

    async adminUsers(q) {
      const { data, error } = await supabase.rpc('admin_users', { p_query: q || null })
      if (error) throw new Error(error.message)
      return (data ?? []) as AdminUserRow[]
    },

    async adminSetUserActive(id, active) {
      const { error } = await supabase.from('profiles').update({ is_active: active }).eq('id', id)
      if (error) throw new Error(error.message)
    },

    async adminSetUserRole(id, role) {
      const { error } = await supabase.from('profiles').update({ role }).eq('id', id)
      if (error) throw new Error(error.message)
    },

    async adminSubscriptions() {
      const { data, error } = await supabase.rpc('admin_subscriptions')
      if (error) throw new Error(error.message)
      return (data ?? []) as any[]
    },

    async adminRevokeSubscription(id) {
      await callFunction('content-admin', { action: 'revoke_subscription', subscription_id: id })
    },

    async adminAiUsage(limit = 100) {
      const { data } = await supabase.from('ai_usage').select('*').order('created_at', { ascending: false }).limit(limit)
      return (data ?? []) as AiUsageRow[]
    },

    async adminMedia() {
      const { data, error } = await supabase.from('media_assets').select('*').order('sort_order')
      if (error) throw new Error(error.message)
      return (data ?? []) as MediaAsset[]
    },

    async adminLessons(filters) {
      let q = supabase.from('lessons')
        .select('id,language_code,level,order_index,title,subtitle,description,estimated_minutes,is_free,status,fingerprint,created_at')
        .order('language_code').order('order_index')
      if (filters.language) q = q.eq('language_code', filters.language)
      if (filters.status) q = q.eq('status', filters.status as any)
      if (filters.q) q = q.ilike('title', `%${filters.q}%`)
      const { data, error } = await q.limit(500)
      if (error) throw new Error(error.message)
      return (data ?? []) as any[]
    },

    async adminSetLessonFlags(id, patch) {
      const { error } = await supabase.from('lessons').update({
        ...patch,
        published_at: patch.status === 'published' ? new Date().toISOString() : null,
      }).eq('id', id)
      if (error) throw new Error(error.message)
    },

    async adminDeleteLesson(id) {
      const { error } = await supabase.from('lessons').delete().eq('id', id)
      if (error) throw new Error(error.message)
    },

    async adminSaveLesson(payload) {
      const { data, error } = await supabase.from('lessons')
        .upsert(payload as any).select('id').single()
      if (error) throw new Error(error.message)
      return { id: (data as { id: string }).id }
    },

    /* ---------------- content factory (server side work) ---------------- */
    async curricula() {
      const { data } = await supabase.from('curricula').select('*').order('created_at', { ascending: false })
      return (data ?? []) as Curriculum[]
    },
    async createCurriculum(payload) {
      const { error } = await supabase.from('curricula').insert(payload)
      if (error) throw new Error(error.message)
    },
    async deleteCurriculum(id) {
      const { error } = await supabase.from('curricula').delete().eq('id', id)
      if (error) throw new Error(error.message)
    },
    async plans(curriculumId) {
      let q = supabase.from('lesson_plans').select('*').order('order_index')
      if (curriculumId) q = q.eq('curriculum_id', curriculumId)
      const { data } = await q.limit(1000)
      return (data ?? []) as LessonPlan[]
    },
    async createPlans(input) {
      const res = await callFunction<{ created: number }>('content-admin', { action: 'create_plans', ...input })
      return res
    },
    async generateNext(input) {
      return await callFunction('content-admin', { action: 'generate_next', ...input })
    },
    async batches(limit = 20) {
      const { data } = await supabase.from('content_batches').select('*')
        .order('created_at', { ascending: false }).limit(limit)
      return (data ?? []) as Batch[]
    },
    async validateLesson(lessonId) {
      return await callFunction('content-admin', { action: 'validate_lesson', lesson_id: lessonId })
    },
    async duplicateReport() {
      return await callFunction('content-admin', { action: 'duplicates' })
    },
    async publishLessons(ids) {
      return await callFunction('content-admin', { action: 'publish', lesson_ids: ids })
    },

    /* ---------------- settings ---------------- */
    async saveTheme(patch) {
      const { error } = await supabase.from('theme_settings').update(patch).eq('id', 1)
      if (error) throw new Error(error.message)
    },
    async saveAppSetting(key, value) {
      const { error } = await supabase.from('app_settings').upsert({ key, value })
      if (error) throw new Error(error.message)
    },
    async saveAiSettings(patch) {
      const { error } = await supabase.from('ai_settings').update(patch as any).eq('id', 1)
      if (error) throw new Error(error.message)
    },
    async saveGroqKey(key) {
      return await callFunction('content-admin', { action: 'save_groq_key', api_key: key })
    },
    async testAi(prompt) {
      return await callFunction('content-admin', { action: 'test_ai', prompt })
    },
    async savePlan(payload) {
      const { error } = await supabase.from('plans').upsert(payload as any, { onConflict: 'id' })
      if (error) throw new Error(error.message)
    },
    async saveFaq(payload) {
      const { error } = await supabase.from('faqs').upsert(payload as any, { onConflict: 'id' })
      if (error) throw new Error(error.message)
    },
    async saveTestimonial(payload) {
      const { error } = await supabase.from('testimonials').upsert(payload as any, { onConflict: 'id' })
      if (error) throw new Error(error.message)
    },
    async saveBanner(payload) {
      const { error } = await supabase.from('banners').upsert(payload as any, { onConflict: 'id' })
      if (error) throw new Error(error.message)
    },
    async saveLanguage(payload) {
      const { error } = await supabase.from('languages').upsert(payload as any, { onConflict: 'code' })
      if (error) throw new Error(error.message)
    },
    async deleteRow(table, id) {
      const t = table === 'plans_bad' ? 'plans' : table
      const { error } = await supabase.from(t as any).delete().eq('id', id)
      if (error) throw new Error(error.message)
    },
  }
}

/* ---------------------------------------------------------------------------
 *  Demo (design showcase) — only reachable when VITE_DEMO_MODE=true locally.
 *  It is intentionally read-only and labelled: LINGU ships no mock data.
 * ------------------------------------------------------------------------- */
export const NO_DEMO_WRITE = 'حالت پیش‌نمایش طراحی: برای این عملیات باید Supabase متصل باشد.'

export async function getApi(): Promise<LanguApi> {
  const forced = import.meta.env.VITE_DEMO_MODE === 'true'
  if (forced) {
    const { createDemoApi } = await import('@/dev/demoApi')
    return createDemoApi()
  }
  return createSupabaseApi()
}

export const backendConfigured = hasBackend || import.meta.env.VITE_DEMO_MODE === 'true'
export { assertOk }
