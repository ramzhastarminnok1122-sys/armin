export type Id = string

export interface Profile {
  id: Id; display_name: string | null; avatar_url: string | null
  role: 'user' | 'admin'; is_active: boolean; tour_done: boolean
  locale: string; last_seen_at: string | null; created_at: string
  goal: string | null; target_language: string | null
  onboarding_done: boolean; reduce_motion: boolean; preferred_level: string | null
}
export interface Language {
  code: string; name_fa: string; name_en: string; native_name: string
  flag: string; gradient: string; description: string | null
  target_lessons: number; is_active: boolean; sort_order: number
}
export interface Plan {
  id: Id; code: string; title_fa: string; subtitle_fa: string | null; description_fa: string | null
  sku: string | null; duration_days: number; display_price: number; price_label: string | null
  badge: string | null; features: string[]; is_active: boolean; is_recommended: boolean; sort_order: number
  original_price: number; promo_price: number | null; promo_label: string | null
  promo_active: boolean; promo_ends_at: string | null; show_on_marketing: boolean
}

export interface MediaAsset {
  id: Id; slot: string; name: string; category: string; url: string
  storage_path: string | null; alt_fa: string | null; used_in: string[]
  is_active: boolean; sort_order: number; created_at: string
}

export interface AppNotification {
  id: Id; user_id: Id; kind: 'lesson_completed' | 'new_lesson' | 'premium_activated' | 'quota_warning' | 'system'
  title: string; body: string | null; url: string | null; read_at: string | null; created_at: string
}

export interface SearchHit {
  kind: 'lesson' | 'feature'; id: string; title: string; subtitle: string | null
  language_code: string | null; level: string | null; is_free: boolean; locked: boolean; url: string
}
export interface Subscription {
  id: Id; user_id: Id; plan_id: Id | null; sku: string; status: 'pending'|'active'|'expired'|'cancelled'|'refunded'
  start_date: string; end_date: string; purchase_token: string | null; provider: string; created_at: string
}
export interface Membership {
  premium: boolean; subscription: Subscription | null; plan: Plan | null; days_left: number | null
}
export interface Faq { id: Id; question: string; answer: string; category: string; is_published: boolean; sort_order: number }
export interface Testimonial { id: Id; name: string; role: string | null; quote: string; avatar_url: string | null; rating: number; is_published: boolean; sort_order: number }
export interface Banner { id: Id; title: string; body: string | null; cta_label: string | null; cta_url: string | null; image_url: string | null; tone: string; placement: string; is_active: boolean; sort_order: number }

export interface LessonMeta {
  id: Id; language_code: string; level: string; order_index: number
  title: string; subtitle: string | null; description: string | null
  estimated_minutes: number; is_free: boolean; locked: boolean; completed: boolean
}
export type LessonStatus = 'draft' | 'generated' | 'validated' | 'published' | 'failed'
export interface LessonFull extends Omit<LessonMeta, 'locked' | 'completed'> {
  status: LessonStatus; content: LessonContent; published_at: string | null
}
export interface LessonAudioRef {
  id: string; section: string; lang: 'en' | 'fa'; role: string; text: string
  path: string; hash: string; bytes: number; speaker?: string; line?: number
}
export interface LessonContent {
  /** ارجاع‌های صوتی درس، گروه‌بندی‌شده با کلید هر بخش (warmup، dialogue، …) */
  audio?: Record<string, LessonAudioRef[]>
  meta?: { cefr?: string; topic?: string; objectives?: string[] }
  warmup?: { prompt_fa: string; questions: { q: string; hint_fa?: string }[] }
  explanation?: { title?: string; body_fa: string; key_points?: string[] }
  vocabulary?: { items: { term: string; ipa?: string; translation_fa: string; example: string; example_fa?: string; tag?: string }[] }
  grammar?: { title: string; explanation_fa: string; pattern?: string; table?: { headers: string[]; rows: string[][] }; pitfalls_fa?: string[] }
  examples?: { items: { target: string; fa: string; note_fa?: string }[] }
  listening?: { title_fa: string; script: string; script_fa?: string; question_fa: string; answer: string; needs_audio?: boolean }
  dialogue?: { title_fa: string; lines: { speaker: string; target: string; fa: string }[] }
  speaking?: { task_fa: string; useful_phrases: { target: string; fa: string }[]; seconds: number }
  reading?: { title: string; text: string; glossary?: { term: string; fa: string }[]; questions: { q_fa: string; a: string }[] }
  exercises?: { items: ExerciseItem[] }
  quiz?: { items: ExerciseItem[] }
  ai_practice?: { task_fa: string; suggested_prompts: string[]; focus?: string[] }
}
export interface ExerciseItem {
  type: 'mcq' | 'fill' | 'match' | 'order' | 'truefalse' | 'short'
  prompt_fa?: string
  question: string
  options?: string[]
  answer: string | string[]
  explanation_fa?: string
}
export interface Progress {
  id: Id; lesson_id: Id; status: 'started' | 'completed'; last_section: string | null
  sections_done: string[]; score: number | null; time_spent_sec: number
  started_at: string; completed_at: string | null
}
export interface AiQuota {
  authenticated: boolean; premium: boolean; free_partner_limit: number; partner_used: number
  partner_remaining: number | null; tutor_remaining: number | null
  premium_daily_messages: number; ai_enabled: boolean
}
export interface AiSettings {
  id: number; provider: string; model: string; fallback_model: string; temperature: number; max_tokens: number
  tutor_system_prompt: string; partner_system_prompt: string
  free_partner_messages: number; premium_daily_messages: number; premium_daily_tutor: number
  is_ai_enabled: boolean; key_hint?: string | null; has_key?: boolean
}
export interface Conversation {
  id: Id; mode: 'tutor' | 'partner'; scenario: string | null; scenario_fa: string | null
  title: string | null; lesson_id: Id | null; message_count: number; created_at: string; updated_at: string
}
export interface ChatMessage { id: Id; role: 'user' | 'assistant' | 'system'; content: string; created_at: string }

export interface AdminDashboard {
  tutor_calls_24h: number; partner_calls_24h: number; conversations_total: number
  messages_total: number; partner_messages_24h: number;
  users_total: number; users_active_7d: number; users_new_7d: number; premium_users: number
  lessons_total: number; lessons_published: number; lessons_draft: number; lessons_failed: number
  plans_failed: number; ai_calls_24h: number; ai_tokens_24h: number; ai_calls_total: number; ai_errors_24h: number
  active_subs: number; recent_users: { id: string; display_name: string | null; role: string; created_at: string; premium: boolean }[]
  lessons_by_language: Record<string, number>
  signups_14d: { day: string; count: number }[]
}
export interface AdminUserRow extends Profile {
  premium: boolean; premium_until: string | null; ai_messages: number; last_ai_at: string | null
  lessons_completed: number; plan_title: string | null
}
export interface Curriculum {
  id: Id; language_code: string; level: string; title_fa: string; summary_fa: string | null
  target_lessons: number; is_active: boolean; created_at: string
}
export interface LessonPlan {
  id: Id; curriculum_id: Id | null; batch_id: Id | null; language_code: string; level: string
  order_index: number; title: string; topic: string | null; objectives: string[]
  target_vocab: string[]; grammar_focus: string | null
  status: 'planned' | 'generating' | 'generated' | 'failed'; attempts: number; last_error: string | null
}
export interface Batch {
  id: Id; curriculum_id: Id | null; language_code: string; level: string; requested: number
  succeeded: number; failed: number; status: 'idle'|'planning'|'generating'|'validating'|'completed'|'failed'|'cancelled'
  model: string | null; last_error: string | null; created_at: string; started_at: string | null; finished_at: string | null
}
export interface AiUsageRow {
  id: Id; user_id: Id | null; feature: 'tutor' | 'partner'; model: string | null
  prompt_tokens: number; completion_tokens: number; latency_ms: number | null
  ok: boolean; error: string | null; created_at: string
}
