import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { ArrowLeft, Compass, Sparkles, X } from 'lucide-react'
import { TOUR_STEPS } from '@/lib/constants'
import { useApp } from '@/context/AppContext'
import { Button, Chip } from '@/components/ui'
import { faNum } from '@/lib/utils'

type Rect = { top: number; left: number; width: number; height: number }
const PAD = 10

/**
 * Guided product tour: short, skippable, replayable.
 * Runs once on first visit (profiles.tour_done) and can be replayed from Profile.
 */
export function Tour({ force, onClose }: { force?: boolean; onClose?: () => void }) {
  const { profile, finishTour, ready, api } = useApp()
  const [open, setOpen] = useState(false)
  const [step, setStep] = useState(0)
  const [rect, setRect] = useState<Rect | null>(null)
  const nav = useNavigate()
  const loc = useLocation()

  // auto start on first entry
  useEffect(() => {
    if (!ready || !profile) return
    if (force) { setOpen(true); setStep(0); return }
    if (profile.tour_done) return
    const t = window.setTimeout(() => setOpen(true), 900)
    return () => window.clearTimeout(t)
  }, [ready, profile, force])

  const current = TOUR_STEPS[step]

  // The tour walks the app, so it follows its own route changes — but the moment the
  // user navigates somewhere themselves, the tour steps aside instead of dragging them
  // back. A product tour must never fight the person using the app.
  const tourNavigated = useRef<string | null>(null)
  useEffect(() => {
    if (!open || !current) return
    if (loc.pathname === current.route) { tourNavigated.current = null; return }
    if (tourNavigated.current && tourNavigated.current !== loc.pathname) {
      setOpen(false)
      onClose?.()
      void finishTour()
      return
    }
    tourNavigated.current = current.route
    nav(current.route)
  }, [open, current, loc.pathname, nav, onClose, finishTour])

  useLayoutEffect(() => {
    if (!open || !current) return
    const find = () => {
      const el = document.querySelector(`[data-tour="${current.id}"]`) as HTMLElement | null
      if (!el) { setRect(null); return }
      const r = el.getBoundingClientRect()
      setRect({ top: r.top - PAD, left: r.left - PAD, width: r.width + PAD * 2, height: r.height + PAD * 2 })
    }
    find()
    const t = window.setTimeout(find, 420) // after route transition
    window.addEventListener('resize', find)
    window.addEventListener('scroll', find, true)
    return () => { window.clearTimeout(t); window.removeEventListener('resize', find); window.removeEventListener('scroll', find, true) }
  }, [open, current, loc.pathname])

  const finish = async (done: boolean) => {
    setOpen(false)
    onClose?.()
    if (done && !force) await finishTour()
    if (done && force) await finishTour()
  }

  const total = TOUR_STEPS.length
  const placement = useMemo(() => {
    if (!rect) return { top: '50%', left: '50%', transform: 'translate(-50%,-50%)' }
    const below = rect.top + rect.height + 16
    const fitsBelow = below + 240 < window.innerHeight
    return fitsBelow
      ? { top: below, left: Math.max(16, Math.min(rect.left, window.innerWidth - 360)), transform: 'none' }
      : { top: Math.max(16, rect.top - 260), left: Math.max(16, Math.min(rect.left, window.innerWidth - 360)), transform: 'none' }
  }, [rect])

  if (api?.mode === 'demo' && !profile) return null

  return (
    <AnimatePresence>
      {open && current && (
        <motion.div className="fixed inset-0 z-[100]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          {/*
            Dim layer with a REAL hole (SVG mask), not a blurred sheet over the page.
            The highlighted control must stay perfectly sharp and readable — a
            backdrop-blur here would blur the very thing the step is explaining.
          */}
          <svg className="absolute inset-0 h-full w-full" onClick={() => finish(false)} aria-hidden="true">
            <defs>
              <mask id="lingu-tour-mask">
                <rect x="0" y="0" width="100%" height="100%" fill="#fff" />
                {rect && <rect x={rect.left} y={rect.top} width={rect.width} height={rect.height} rx="18" fill="#000" />}
              </mask>
            </defs>
            <rect x="0" y="0" width="100%" height="100%" fill="rgba(12,9,28,0.62)" mask="url(#lingu-tour-mask)" />
          </svg>
          {rect && (
            <motion.div
              className="pointer-events-none absolute rounded-3xl ring-2 ring-primary/70"
              initial={false}
              animate={{ top: rect.top, left: rect.left, width: rect.width, height: rect.height }}
              transition={{ type: 'spring', stiffness: 320, damping: 32 }}
              style={{ boxShadow: '0 10px 40px rgba(109,91,255,0.35)' }}
            />
          )}
          <motion.div
            initial={{ opacity: 0, y: 14, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.98 }}
            transition={{ type: 'spring', stiffness: 320, damping: 30 }}
            className="glass-strong absolute w-[min(92vw,340px)] rounded-3xl p-5 shadow-glow"
            style={placement as any}
          >
            <div className="mb-3 flex items-center justify-between">
              <Chip tone="primary"><Compass className="size-3" /> تور {faNum(step + 1)} از {faNum(total)}</Chip>
              <button onClick={() => finish(true)} className="rounded-lg p-1 text-ink-faint hover:bg-card-soft" aria-label="بستن">
                <X className="size-4" />
              </button>
            </div>
            <h3 className="flex items-center gap-2 text-lg font-extrabold"><Sparkles className="size-4 text-primary-soft" /> {current.title}</h3>
            <p className="mt-2 text-sm leading-7 text-ink-muted">{current.body}</p>
            <div className="mt-4 flex items-center justify-between gap-2">
              <div className="flex gap-1">
                {TOUR_STEPS.map((s, i) => (
                  <span key={s.id} className={i === step ? 'h-1.5 w-6 rounded-full bg-brand-grad' : 'h-1.5 w-1.5 rounded-full bg-line'} />
                ))}
              </div>
              <div className="flex items-center gap-1.5">
                <Button variant="ghost" size="sm" onClick={() => finish(true)}>رد کردن</Button>
                {step > 0 && <Button variant="outline" size="sm" onClick={() => setStep((s) => s - 1)}>قبلی</Button>}
                {step < total - 1
                  ? <Button size="sm" onClick={() => setStep((s) => s + 1)}>بعدی <ArrowLeft className="size-3.5" /></Button>
                  : <Button size="sm" onClick={() => finish(true)}>شروع یادگیری</Button>}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export default Tour
