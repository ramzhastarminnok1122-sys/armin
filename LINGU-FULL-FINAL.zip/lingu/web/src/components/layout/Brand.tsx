import { motion } from 'motion/react'
import { Link } from 'react-router-dom'
import { cn } from '@/lib/utils'

export function Logo({ className, size = 36, animated = true }: { className?: string; size?: number; animated?: boolean }) {
  return (
    <motion.span
      initial={animated ? { rotate: -8, scale: 0.9, opacity: 0 } : false}
      animate={{ rotate: 0, scale: 1, opacity: 1 }}
      transition={{ type: 'spring', stiffness: 260, damping: 20 }}
      className={cn('relative grid shrink-0 place-items-center rounded-2xl bg-brand-grad shadow-glow', className)}
      style={{ width: size, height: size }}
    >
      <svg viewBox="0 0 64 64" width={size * 0.62} height={size * 0.62} aria-hidden>
        <path d="M18 44V20h5v19h9v5H18Zm18.5 0V20h5.6l6.4 10.6V20H54v24h-5.6L42 33.2V44h-5.5Z" fill="#fff" />
      </svg>
      <span className="pointer-events-none absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/25" />
    </motion.span>
  )
}

export function Brand({ withText = true, to = '/', size = 36 }: { withText?: boolean; to?: string; size?: number }) {
  return (
    <Link to={to} className="flex items-center gap-3">
      <Logo size={size} />
      {withText && (
        <span className="leading-none">
          <span className="block text-lg font-extrabold tracking-tight">LINGU</span>
          <span className="mt-0.5 block text-[10px] font-bold text-ink-faint">یادگیری زبان، هوشمند و واقعی</span>
        </span>
      )}
    </Link>
  )
}
