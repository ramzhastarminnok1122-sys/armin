import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useMemo, useRef, useState } from 'react'
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import {
  Bell, BookOpen, ChevronLeft, Crown, GraduationCap, LayoutDashboard, LifeBuoy, Lock, LogOut,
  MessageSquareHeart, Route, Search, Settings2, ShieldCheck, Sparkles, UserRound, X, BadgeCheck, Check,
} from 'lucide-react'
import { Brand, Logo } from './Brand'
import { useApp } from '@/context/AppContext'
import { cn, faNum, faRelative, initials } from '@/lib/utils'
import { Button, Chip } from '@/components/ui'
import { Tour } from '@/components/tour/Tour'
import { APP_FEATURES, APP_NAV, APP_NAV_SECONDARY } from '@/lib/constants'
import type { SearchHit } from '@/services/types'
import { pageTransition } from '@/lib/motion'
import { resetPreviewState } from '@/dev/demoApi'

const ICONS: Record<string, typeof LayoutDashboard> = {
  LayoutDashboard, BookOpen, GraduationCap, MessageSquareHeart, Route, Crown, UserRound, Settings2, LifeBuoy,
}

/**
 * The Learning Application shell.
 * It never renders any part of the public website: its own rail, its own header,
 * its own bottom navigation and its own background. The shell stays mounted while
 * routes change inside it, so the app never "reloads" around the user.
 */
export default function AppShell() {
  const {
    profile, membership, isAdmin, signOut, toast, languages,
    unreadCount, markAllRead, search, settings, api, tourReplay, stopTourReplay,
  } = useApp()
  const [drawer, setDrawer] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [notifOpen, setNotifOpen] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const loc = useLocation()
  const nav = useNavigate()

  const activeLanguage = useMemo(() => {
    const code = profile?.target_language ?? languages[0]?.code
    return languages.find((l) => l.code === code) ?? languages[0] ?? null
  }, [languages, profile?.target_language])

  useEffect(() => {
    setDrawer(false); setNotifOpen(false); setMenuOpen(false); setSearchOpen(false)
    window.scrollTo({ top: 0 })
  }, [loc.pathname])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setSearchOpen(true) }
      if (e.key === 'Escape') { setSearchOpen(false); setNotifOpen(false); setMenuOpen(false) }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  const logout = async () => {
    await signOut()
    toast('از حساب خارج شدی. موفق باشی!', 'success')
    nav('/login', { replace: true })
  }

  const NavRow = ({ item, onNavigate }: { item: (typeof APP_NAV)[number] | (typeof APP_NAV_SECONDARY)[number]; onNavigate?: () => void }) => {
    const Icon = ICONS[item.icon] ?? LayoutDashboard
    return (
      <NavLink to={item.to} end={'end' in item ? item.end : undefined} data-tour={item.tour}
        onClick={onNavigate}
        className={({ isActive }) => cn('app-nav-item', isActive && 'app-nav-active')}>
        <Icon className="size-[18px] shrink-0" />
        <span className="flex-1">{item.label}</span>
        {item.to === '/app/subscription' && !membership.premium && <Crown className="size-3.5 text-warn" />}
      </NavLink>
    )
  }

  return (
    <div className="app-shell">
      <a href="#app-main" className="skip-link btn btn-md bg-brand-grad text-white">رفتن به محتوای اصلی</a>
      {tourReplay && <Tour force onClose={stopTourReplay} />}
      <Tour />

      {/* ───────────────────────── desktop rail ───────────────────────── */}
      <aside className="fixed inset-y-0 right-0 z-40 hidden w-[264px] flex-col border-l border-line/70 bg-bg-soft/60 px-4 py-5 backdrop-blur-2xl lg:flex">
        <div className="px-1"><Brand to="/app" /></div>

        <div className="mt-5 rounded-3xl border border-line/70 bg-card/70 p-3.5">
          <div className="flex items-center gap-3">
            <Avatar profile={profile} size={44} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[13px] font-extrabold">{profile?.display_name || 'زبان‌آموز LINGU'}</p>
              {membership.premium
                ? <Chip tone="success" className="mt-1 !px-2 !py-0.5 !text-[10px]"><BadgeCheck className="size-3" /> Premium</Chip>
                : <Chip className="mt-1 !px-2 !py-0.5 !text-[10px]">نسخه رایگان</Chip>}
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between rounded-2xl border border-line/60 bg-bg-soft/60 px-3 py-2">
            <span className="flex items-center gap-2 text-[11px] font-bold text-ink-muted">
              <span className="text-base">{activeLanguage?.flag ?? '🌍'}</span> {activeLanguage?.name_fa ?? 'زبان‌ها'}
            </span>
            <Link to="/app/settings" className="text-[10px] font-bold text-primary-soft hover:underline">تغییر</Link>
          </div>
          {membership.premium && membership.days_left !== null && (
            <p className="mt-2 text-center text-[10px] text-ink-faint">{faNum(membership.days_left)} روز باقی‌مانده از اشتراک</p>
          )}
        </div>

        <nav className="mt-4 flex-1 space-y-1 overflow-y-auto pl-1">
          {APP_NAV.map((item) => <NavRow key={item.to} item={item} />)}
          <div className="my-3 h-px bg-line/70" />
          {APP_NAV_SECONDARY.map((item) => <NavRow key={item.to} item={item} />)}
          {isAdmin && (
            <NavLink to="/admin" className={({ isActive }) => cn('app-nav-item mt-2 border border-primary/25', isActive && 'app-nav-active')}>
              <ShieldCheck className="size-[18px]" />
              <span className="flex-1">پنل مدیریت</span>
              <ChevronLeft className="size-3.5" />
            </NavLink>
          )}
        </nav>

        <button onClick={logout} className="app-nav-item mt-2 w-full text-danger hover:bg-danger/10 hover:text-danger">
          <LogOut className="size-[18px]" /><span className="flex-1 text-right">خروج از حساب</span>
        </button>
      </aside>

      {/* ───────────────────────── mobile top bar ───────────────────────── */}
      <header className="sticky top-0 z-40 border-b border-line/70 bg-bg/85 backdrop-blur-2xl lg:hidden">
        <div className="flex h-16 items-center justify-between gap-2 px-4">
          <button onClick={() => setDrawer(true)} className="flex items-center gap-2.5" aria-label="باز کردن منو">
            <Avatar profile={profile} size={36} />
            <span className="text-right">
              <span className="block text-[13px] font-extrabold leading-4">{profile?.display_name || 'LINGU'}</span>
              <span className="block text-[10px] text-ink-faint">{membership.premium ? 'Premium فعال' : 'نسخه رایگان'}</span>
            </span>
          </button>
          <div className="flex items-center gap-1.5">
            <button onClick={() => setSearchOpen(true)} className="icon-btn" aria-label="جستجو"><Search className="size-4" /></button>
            <button onClick={() => { setNotifOpen((v) => !v); if (!notifOpen) markAllRead() }} className="icon-btn relative" aria-label="اعلان‌ها">
              <Bell className="size-4" />
              {unreadCount > 0 && <span className="absolute -left-0.5 -top-0.5 grid size-4 place-items-center rounded-full bg-danger text-[9px] font-extrabold text-white">{faNum(unreadCount)}</span>}
            </button>
            {!membership.premium && <Link to="/app/subscription"><Button size="sm" className="!h-9"><Crown className="size-3.5" /> Premium</Button></Link>}
          </div>
        </div>
        <AnimatePresence>{notifOpen && <NotificationPanel onClose={() => setNotifOpen(false)} />}</AnimatePresence>
      </header>

      {/* ───────────────────────── desktop header bar ───────────────────────── */}
      <div className="sticky top-0 z-30 hidden border-b border-line/60 bg-bg/70 backdrop-blur-xl lg:block">
        <div className="flex h-16 items-center justify-between gap-4 px-8">
          <button onClick={() => setSearchOpen(true)}
            className="flex h-11 w-full max-w-md items-center gap-3 rounded-2xl border border-line/80 bg-card/60 px-4 text-[12px] text-ink-faint transition-all hover:border-primary/40 hover:text-ink">
            <Search className="size-4" />
            جستجوی درس، بخش یا قابلیت…
            <kbd className="ltr mr-auto rounded-lg border border-line/80 bg-bg-soft/70 px-2 py-0.5 text-[10px] font-bold">Ctrl K</kbd>
          </button>
          <div className="flex items-center gap-2">
            {!membership.premium && (
              <Link to="/app/subscription">
                <Button size="sm" className="!h-10"><Crown className="size-4" /> ارتقا به Premium</Button>
              </Link>
            )}
            <button onClick={() => { setNotifOpen((v) => !v); if (!notifOpen) markAllRead() }} className="icon-btn relative" aria-label="اعلان‌ها">
              <Bell className="size-4" />
              {unreadCount > 0 && <span className="absolute -left-1 -top-1 grid size-[18px] place-items-center rounded-full bg-danger text-[9px] font-extrabold text-white">{faNum(unreadCount)}</span>}
            </button>
            <button onClick={() => setMenuOpen((v) => !v)} className="relative" aria-label="منوی حساب">
              <Avatar profile={profile} size={40} />
            </button>
          </div>
        </div>
        <AnimatePresence>
          {menuOpen && <ProfileMenu onClose={() => setMenuOpen(false)} onLogout={logout} isAdmin={isAdmin} profile={profile} />}
        </AnimatePresence>
        <AnimatePresence>{notifOpen && <NotificationPanel onClose={() => setNotifOpen(false)} align="end" />}</AnimatePresence>
      </div>

      {/* ───────────────────────── mobile drawer ───────────────────────── */}
      <AnimatePresence>
        {drawer && (
          <motion.div className="fixed inset-0 z-[70] lg:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setDrawer(false)} />
            <motion.aside initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}
              transition={{ type: 'spring', stiffness: 340, damping: 32 }}
              className="absolute inset-y-0 right-0 flex w-[86%] max-w-sm flex-col border-l border-line bg-bg/95 p-5 backdrop-blur-2xl">
              <div className="mb-5 flex items-center justify-between">
                <Brand to="/app" size={32} />
                <button onClick={() => setDrawer(false)} className="icon-btn" aria-label="بستن"><X className="size-4" /></button>
              </div>

              <div className="mb-4 flex items-center gap-3 rounded-3xl border border-line/70 bg-card/70 p-3.5">
                <Avatar profile={profile} size={42} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-extrabold">{profile?.display_name}</p>
                  <p className="text-[10px] text-ink-faint">{membership.premium ? 'Premium فعال' : 'نسخه رایگان'}</p>
                </div>
                <span className="text-xl">{activeLanguage?.flag}</span>
              </div>

              <nav className="flex-1 space-y-1 overflow-y-auto">
                {APP_NAV.map((item) => <NavRow key={item.to} item={item} onNavigate={() => setDrawer(false)} />)}
                <div className="my-3 h-px bg-line/70" />
                {APP_NAV_SECONDARY.map((item) => <NavRow key={item.to} item={item} onNavigate={() => setDrawer(false)} />)}
                {isAdmin && <NavLink to="/admin" className="app-nav-item mt-1"><ShieldCheck className="size-[18px]" /><span className="flex-1">پنل مدیریت</span></NavLink>}
              </nav>

              <button onClick={logout} className="app-nav-item mt-3 w-full text-danger"><LogOut className="size-[18px]" /><span className="flex-1 text-right">خروج از حساب</span></button>
              <p className="mt-3 text-center text-[10px] text-ink-faint">{settings.general?.app_name ?? 'LINGU'} · نسخه ۰.۲</p>
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ───────────────────────── content ───────────────────────── */}
      <main id="app-main" className="min-w-0 overflow-x-clip lg:mr-[264px]">
        {api?.mode === 'demo' && <PreviewRibbon />}
        <AnimatePresence mode="wait">
          <motion.div key={loc.pathname} {...pageTransition} className="mx-auto w-full max-w-[1180px] px-4 pb-28 pt-6 lg:px-8 lg:pb-14 lg:pt-8">
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>

      {/* ───────────────────────── mobile bottom nav + AI shortcut ───────────────────────── */}
      <FloatingAI />
      <nav className="safe-bottom fixed inset-x-0 bottom-0 z-40 border-t border-line/70 bg-bg/90 backdrop-blur-2xl lg:hidden">
        <div className="grid grid-cols-5">
          {APP_NAV.map((item) => {
            const Icon = ICONS[item.icon] ?? LayoutDashboard
            return (
              <NavLink key={item.to} to={item.to} end={'end' in item ? item.end : undefined}
                className={({ isActive }) => cn('flex flex-col items-center gap-1 py-2.5 text-[10px] font-bold transition-colors',
                  isActive ? 'text-primary-soft' : 'text-ink-faint')}>
                {({ isActive }) => (
                  <>
                    <span className={cn('grid size-9 place-items-center rounded-2xl transition-all', isActive && 'bg-brand-soft')}>
                      <Icon className="size-[18px]" />
                    </span>
                    {item.label}
                  </>
                )}
              </NavLink>
            )
          })}
        </div>
      </nav>

      {/* ───────────────────────── overlays ───────────────────────── */}
      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} search={search} />
    </div>
  )
}

/* ───────────────────────────── pieces ───────────────────────────── */

function Avatar({ profile, size = 40 }: { profile: { display_name: string | null; avatar_url: string | null } | null; size?: number }) {
  if (profile?.avatar_url) {
    return <img src={profile.avatar_url} alt={profile.display_name ?? 'کاربر'} width={size} height={size}
      className="shrink-0 rounded-2xl border border-line/70 object-cover" style={{ width: size, height: size }} />
  }
  return (
    <span className="grid shrink-0 place-items-center rounded-2xl bg-brand-grad font-extrabold text-white"
      style={{ width: size, height: size, fontSize: size * 0.34 }} aria-hidden>
      {initials(profile?.display_name)}
    </span>
  )
}

function ProfileMenu({ onClose, onLogout, isAdmin, profile }: { onClose: () => void; onLogout: () => void; isAdmin: boolean; profile: { display_name: string | null; role: string } | null }) {
  const items = [
    { to: '/app/profile', label: 'پروفایل من', icon: UserRound },
    { to: '/app/settings', label: 'تنظیمات', icon: Settings2 },
    { to: '/app/help', label: 'راهنما', icon: LifeBuoy },
  ]
  return (
    <>
      <div className="fixed inset-0 z-30" onClick={onClose} />
      <motion.div initial={{ opacity: 0, y: -8, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -6 }}
        transition={{ duration: 0.18 }} className="absolute left-8 top-[62px] z-40 w-64 overflow-hidden rounded-3xl border border-line bg-card/95 p-2 shadow-soft backdrop-blur-2xl">
        <div className="px-3 py-2.5">
          <p className="text-[13px] font-extrabold">{profile?.display_name}</p>
          <p className="text-[10px] text-ink-faint">{profile?.role === 'admin' ? 'مدیر LINGU' : 'زبان‌آموز LINGU'}</p>
        </div>
        <div className="my-1 h-px bg-line/70" />
        {items.map((i) => (
          <Link key={i.to} to={i.to} onClick={onClose} className="flex items-center gap-2.5 rounded-2xl px-3 py-2.5 text-[12px] font-bold text-ink-muted hover:bg-card-soft hover:text-ink">
            <i.icon className="size-4" /> {i.label}
          </Link>
        ))}
        {isAdmin && <Link to="/admin" onClick={onClose} className="flex items-center gap-2.5 rounded-2xl px-3 py-2.5 text-[12px] font-bold text-primary-soft hover:bg-primary/10"><ShieldCheck className="size-4" /> پنل مدیریت</Link>}
        <div className="my-1 h-px bg-line/70" />
        <button onClick={onLogout} className="flex w-full items-center gap-2.5 rounded-2xl px-3 py-2.5 text-[12px] font-bold text-danger hover:bg-danger/10">
          <LogOut className="size-4" /> خروج از حساب
        </button>
      </motion.div>
    </>
  )
}

function NotificationPanel({ onClose, align = 'start' }: { onClose: () => void; align?: 'start' | 'end' }) {
  const { notifications, refreshNotifications } = useApp()
  useEffect(() => { refreshNotifications() }, [refreshNotifications])
  const kindMeta: Record<string, { icon: typeof Bell; tone: string }> = {
    lesson_completed: { icon: Check, tone: 'text-success bg-success/12' },
    premium_activated: { icon: Crown, tone: 'text-warn bg-warn/12' },
    new_lesson: { icon: Sparkles, tone: 'text-primary-soft bg-primary/12' },
    quota_warning: { icon: Lock, tone: 'text-danger bg-danger/12' },
    system: { icon: Bell, tone: 'text-ink-muted bg-card-soft' },
  }
  return (
    <>
      <div className="fixed inset-0 z-30" onClick={onClose} />
      <motion.div initial={{ opacity: 0, y: -8, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -6 }}
        transition={{ duration: 0.18 }}
        className={cn('fixed left-3 right-3 top-[68px] z-40 max-h-[70vh] overflow-hidden rounded-3xl border border-line bg-card/95 shadow-soft backdrop-blur-2xl sm:left-auto sm:right-auto sm:w-96',
          align === 'end' && 'lg:left-8 lg:right-auto')}>
        <div className="flex items-center justify-between border-b border-line/70 px-4 py-3">
          <h3 className="text-[13px] font-extrabold">اعلان‌ها</h3>
          <button onClick={onClose} className="rounded-xl p-1.5 text-ink-faint hover:bg-card-soft" aria-label="بستن"><X className="size-4" /></button>
        </div>
        <div className="max-h-[56vh] overflow-y-auto p-2">
          {notifications.length === 0 ? (
            <div className="px-3 py-10 text-center">
              <Bell className="mx-auto size-6 text-ink-faint" />
              <p className="mt-3 text-[12px] font-bold">هنوز اعلانی نداری</p>
              <p className="mt-1 text-[11px] leading-6 text-ink-faint">با کامل کردن اولین درس یا فعال‌شدن اشتراک، اعلان‌های واقعی همین‌جا نمایش داده می‌شوند.</p>
            </div>
          ) : notifications.map((n) => {
            const meta = kindMeta[n.kind] ?? kindMeta.system
            const Icon = meta.icon
            return (
              <Link key={n.id} to={n.url ?? '/app'} onClick={onClose}
                className={cn('flex gap-3 rounded-2xl p-3 transition-colors hover:bg-card-soft/70', !n.read_at && 'bg-primary/5')}>
                <span className={cn('grid size-9 shrink-0 place-items-center rounded-2xl', meta.tone)}><Icon className="size-4" /></span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[12px] font-extrabold">{n.title}</span>
                  {n.body && <span className="mt-0.5 block text-[11px] leading-6 text-ink-muted">{n.body}</span>}
                  <span className="mt-1 block text-[10px] text-ink-faint">{faRelative(n.created_at)}</span>
                </span>
              </Link>
            )
          })}
        </div>
      </motion.div>
    </>
  )
}

function FloatingAI() {
  const loc = useLocation()
  const hidden = loc.pathname.startsWith('/app/tutor') || loc.pathname.startsWith('/app/conversation')
  return (
    <AnimatePresence>
      {!hidden && (
        <motion.div initial={{ opacity: 0, scale: 0.6, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.6, y: 20 }}
          transition={{ type: 'spring', stiffness: 340, damping: 26 }}
          className="fixed bottom-24 left-4 z-40 lg:bottom-8 lg:left-8">
          <Link to="/app/tutor" className="group relative flex items-center gap-2 rounded-full bg-brand-grad px-4 py-3 text-[12px] font-extrabold text-white shadow-glow transition-transform hover:-translate-y-0.5 active:scale-95">
            <span className="absolute inset-0 -z-10 animate-pulse-ring rounded-full border-2 border-primary/50" />
            <GraduationCap className="size-4" />
            <span className="hidden sm:inline">پرسیدن از AI Tutor</span>
            <span className="sm:hidden">AI</span>
          </Link>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

function SearchOverlay({ open, onClose, search }: { open: boolean; onClose: () => void; search: (q: string) => Promise<SearchHit[]> }) {
  const [q, setQ] = useState('')
  const [hits, setHits] = useState<SearchHit[]>([])
  const [loading, setLoading] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const nav = useNavigate()

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 120)
    else { setQ(''); setHits([]) }
  }, [open])

  useEffect(() => {
    if (!open) return
    const t = window.setTimeout(async () => {
      if (!q.trim()) { setHits([]); return }
      setLoading(true)
      try {
        const lessonHits = await search(q)
        const featureHits: SearchHit[] = APP_FEATURES
          .filter((f) => (f.label + ' ' + f.keywords).toLowerCase().includes(q.toLowerCase()))
          .map((f) => ({ kind: 'feature' as const, id: f.to, title: f.label, subtitle: 'قابلیت برنامه', language_code: null, level: null, is_free: true, locked: false, url: f.to }))
        setHits([...featureHits, ...lessonHits])
      } finally { setLoading(false) }
    }, 220)
    return () => window.clearTimeout(t)
  }, [q, open, search])

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-[95]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <div className="absolute inset-0 bg-black/45 backdrop-blur-sm" onClick={onClose} />
          <motion.div initial={{ opacity: 0, y: -16, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-x-3 top-[9vh] mx-auto max-w-2xl overflow-hidden rounded-4xl border border-line bg-card/97 shadow-soft backdrop-blur-2xl">
            <div className="flex items-center gap-3 border-b border-line/70 px-5 py-4">
              <Search className="size-5 text-ink-faint" />
              <input ref={inputRef} value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجو در درس‌ها و قابلیت‌های LINGU…"
                className="flex-1 bg-transparent text-sm outline-none placeholder:text-ink-faint" />
              <button onClick={onClose} className="rounded-xl border border-line/70 px-2 py-1 text-[10px] font-bold text-ink-faint">ESC</button>
            </div>
            <div className="max-h-[52vh] overflow-y-auto p-3">
              {!q.trim() && (
                <div className="p-4">
                  <p className="mb-3 text-[11px] font-extrabold text-ink-faint">پیشنهادهای سریع</p>
                  <div className="flex flex-wrap gap-2">
                    {['گرامر', 'A1', 'مکالمه', 'مصاحبه کاری', 'اشتراک', 'پیشرفت'].map((s) => (
                      <button key={s} onClick={() => setQ(s)} className="rounded-2xl border border-line/80 bg-bg-soft/60 px-3 py-2 text-[11px] font-bold text-ink-muted hover:border-primary/40 hover:text-ink">{s}</button>
                    ))}
                  </div>
                </div>
              )}
              {loading && <div className="p-4 text-[12px] text-ink-faint">در حال جستجو…</div>}
              {!loading && q.trim() && hits.length === 0 && (
                <div className="p-8 text-center">
                  <p className="text-[12px] font-bold">نتیجه‌ای پیدا نشد</p>
                  <p className="mt-1 text-[11px] text-ink-faint">املای دیگری امتحان کن یا از فهرست درس‌ها استفاده کن.</p>
                </div>
              )}
              {!loading && hits.map((h) => (
                <button key={`${h.kind}-${h.id}`} onClick={() => { nav(h.url); onClose() }}
                  className="flex w-full items-center gap-3 rounded-2xl p-3 text-right transition-colors hover:bg-card-soft/70">
                  <span className={cn('grid size-9 shrink-0 place-items-center rounded-2xl text-[10px] font-extrabold',
                    h.kind === 'lesson' ? 'bg-brand-soft text-primary-soft' : 'bg-card-soft text-ink-muted')}>
                    {h.kind === 'lesson' ? (h.level ?? 'درس') : 'ویژگی'}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[12.5px] font-extrabold">{h.title}</span>
                    <span className="block truncate text-[10.5px] text-ink-faint">
                      {h.kind === 'lesson' ? (h.subtitle || 'درس LINGU') : h.subtitle}
                    </span>
                  </span>
                  {h.locked && <Chip tone="warn" className="!px-2 !py-0.5 !text-[10px]"><Lock className="size-2.5" /> Premium</Chip>}
                  {h.kind === 'lesson' && h.is_free && <Chip tone="success" className="!px-2 !py-0.5 !text-[10px]">رایگان</Chip>}
                </button>
              ))}
            </div>
            <div className="flex items-center justify-between border-t border-line/70 px-5 py-3 text-[10px] text-ink-faint">
              <span>نتایج فقط از محتوای واقعی منتشرشده ساخته می‌شوند.</span>
              <span className="hidden sm:block"><Logo size={14} className="inline-block align-middle" /> LINGU</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

/**
 * Design-preview chrome — exists only in a local preview run (VITE_DEMO_MODE).
 * It is the single place where a reviewer can restart the flow, and it never
 * appears in a production build.
 */
function PreviewRibbon() {
  const [busy, setBusy] = useState(false)
  const restart = async () => {
    setBusy(true)
    resetPreviewState()
    localStorage.removeItem('lingu.preview.session')
    window.location.href = '/login'
  }
  return (
    <div className="mx-4 mt-4 flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-warn/30 bg-warn/10 px-4 py-2.5 text-[11px] font-bold text-warn lg:mx-8">
      <span>پیش‌نمایش طراحی — داده‌ها واقعی نیستند و ذخیره‌سازی روی سرور انجام نمی‌شود.</span>
      <button onClick={restart} disabled={busy} className="rounded-xl border border-warn/40 px-3 py-1.5 font-extrabold hover:bg-warn/15">
        {busy ? 'در حال بازنشانی…' : 'شروع تازه (کاربر جدید)'}
      </button>
    </div>
  )
}
