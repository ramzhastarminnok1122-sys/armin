import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useState } from 'react'
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import {
  BadgeCheck, ChevronLeft, CreditCard, Factory, HelpCircle, Home, Image as ImageIcon, LayoutDashboard,
  LogOut, Menu, MessageSquareQuote, Palette, Server, Sparkles, Users, BookOpen, Settings2, X,
} from 'lucide-react'
import { Brand } from './Brand'
import { useApp } from '@/context/AppContext'
import { cn, initials } from '@/lib/utils'

export const ADMIN_NAV = [
  { to: '/admin', label: 'داشبورد', icon: LayoutDashboard, end: true },
  { to: '/admin/users', label: 'کاربران', icon: Users },
  { to: '/admin/lessons', label: 'درس‌ها', icon: BookOpen },
  { to: '/admin/content-factory', label: 'Content Factory', icon: Factory },
  { to: '/admin/subscriptions', label: 'اشتراک‌ها', icon: CreditCard },
  { to: '/admin/plans', label: 'پلن‌ها', icon: BadgeCheck },
  { to: '/admin/ai', label: 'تنظیمات AI', icon: Sparkles },
  { to: '/admin/media', label: 'کتابخانه رسانه', icon: ImageIcon },
  { to: '/admin/settings', label: 'تنظیمات برنامه', icon: Settings2 },
  { to: '/admin/theme', label: 'ظاهر و تم', icon: Palette },
  { to: '/admin/banners', label: 'بنرها', icon: ImageIcon },
  { to: '/admin/faq', label: 'سؤالات متداول', icon: HelpCircle },
  { to: '/admin/testimonials', label: 'نظرات کاربران', icon: MessageSquareQuote },
]

export default function AdminLayout() {
  const { profile, signOut, toast, api } = useApp()
  const [drawer, setDrawer] = useState(false)
  const loc = useLocation()
  const nav = useNavigate()

  useEffect(() => { setDrawer(false); window.scrollTo({ top: 0 }) }, [loc.pathname])

  return (
    <div className="min-h-dvh lg:flex">
      <aside className="sticky top-0 hidden h-dvh w-72 shrink-0 flex-col overflow-y-auto border-l border-line/60 bg-bg-soft/50 p-4 backdrop-blur-xl lg:flex">
        <div className="px-2 py-3"><Brand to="/admin" /></div>
        <div className="mb-3 mt-1 flex items-center gap-2 rounded-2xl border border-primary/25 bg-primary/10 px-3 py-2 text-xs font-extrabold text-primary-soft">
          <Server className="size-3.5" /> پنل مدیریت
        </div>
        {api?.mode === 'demo' && (
          <p className="mb-3 rounded-2xl border border-warn/30 bg-warn/10 px-3 py-2 text-[10.5px] leading-5 font-bold text-warn">
            پیش‌نمایش طراحی: داده‌ها نمونه‌اند و ذخیره‌سازی غیرفعال است.
          </p>
        )}
        <nav className="flex-1 space-y-1">
          {ADMIN_NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} className={({ isActive }) => cn('nav-item text-[13px]', isActive && 'nav-item-active')}>
              <n.icon className="size-4" /><span className="flex-1">{n.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="mt-3 rounded-2xl border border-line/70 bg-card/60 p-3">
          <div className="flex items-center gap-2.5">
            <div className="grid size-9 place-items-center rounded-xl bg-brand-grad text-xs font-extrabold text-white">{initials(profile?.display_name)}</div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-extrabold">{profile?.display_name}</p>
              <p className="text-[10px] text-ink-faint">مدیر سیستم</p>
            </div>
          </div>
          <Link to="/app" className="mt-3 flex items-center gap-2 rounded-xl px-2 py-2 text-[11px] font-bold text-ink-muted hover:bg-card-soft hover:text-ink">
            <Home className="size-3.5" /> بازگشت به برنامه کاربر
          </Link>
          <button onClick={async () => { await signOut(); toast('خارج شدی.', 'success'); nav('/login', { replace: true }) }}
            className="mt-1 flex w-full items-center gap-2 rounded-xl px-2 py-2 text-[11px] font-bold text-danger hover:bg-danger/10">
            <LogOut className="size-3.5" /> خروج
          </button>
        </div>
      </aside>

      <header className="sticky top-0 z-40 flex h-16 items-center justify-between gap-3 border-b border-line/60 bg-bg/85 px-4 backdrop-blur-xl lg:hidden">
        <Brand to="/admin" size={30} />
        <div className="flex items-center gap-2">
          <Link to="/app" className="rounded-xl border border-line px-3 py-2 text-[11px] font-bold text-ink-muted">برنامه کاربر</Link>
          <button onClick={() => setDrawer(true)} className="rounded-xl border border-line p-2.5" aria-label="منو"><Menu className="size-5" /></button>
        </div>
      </header>

      <AnimatePresence>
        {drawer && (
          <motion.div className="fixed inset-0 z-[70] lg:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setDrawer(false)} />
            <motion.aside initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}
              transition={{ type: 'spring', stiffness: 340, damping: 32 }}
              className="absolute inset-y-0 right-0 w-[88%] max-w-sm overflow-y-auto border-l border-line bg-bg-soft/95 p-5">
              <div className="mb-5 flex items-center justify-between">
                <Brand to="/admin" size={30} />
                <button onClick={() => setDrawer(false)} className="rounded-xl p-2 text-ink-faint"><X className="size-5" /></button>
              </div>
              <div className="space-y-1">
                {ADMIN_NAV.map((n) => (
                  <NavLink key={n.to} to={n.to} end={n.end} className={({ isActive }) => cn('nav-item text-[13px]', isActive && 'nav-item-active')}>
                    <n.icon className="size-4" /><span className="flex-1">{n.label}</span><ChevronLeft className="size-3.5 opacity-40" />
                  </NavLink>
                ))}
              </div>
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="min-w-0 flex-1">
        <AnimatePresence mode="wait">
          <motion.div key={loc.pathname}
            initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.26, ease: [0.22, 1, 0.36, 1] }}
            className="container-x py-6 lg:py-9">
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  )
}
