import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useState } from 'react'
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom'
import { ArrowLeft, LogIn, Menu, Sparkles, UserPlus, X } from 'lucide-react'
import { Brand } from './Brand'
import { useApp } from '@/context/AppContext'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui'

const NAV = [
  { to: '/', label: 'خانه', end: true },
  { to: '/features', label: 'امکانات' },
  { to: '/languages', label: 'زبان‌ها' },
  { to: '/how-it-works', label: 'چگونه کار می‌کند' },
  { to: '/faq', label: 'سؤالات' },
]

export default function PublicLayout() {
  const { session, settings, api } = useApp()
  const [open, setOpen] = useState(false)
  const loc = useLocation()
  const appName = settings.general?.app_name ?? 'LINGU'

  useEffect(() => { setOpen(false); window.scrollTo({ top: 0, behavior: 'smooth' }) }, [loc.pathname])

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="sticky top-0 z-50 border-b border-line/60 bg-bg/70 backdrop-blur-xl">
        <div className="container-x flex h-16 items-center justify-between gap-4">
          <Brand />
          <nav className="hidden items-center gap-1 md:flex">
            {NAV.map((n) => (
              <NavLink key={n.to} to={n.to} end={n.end}
                className={({ isActive }) => cn('rounded-xl px-3.5 py-2 text-sm font-bold transition-colors',
                  isActive ? 'bg-card-soft/80 text-ink' : 'text-ink-muted hover:bg-card-soft/50 hover:text-ink')}>
                {n.label}
              </NavLink>
            ))}
          </nav>
          <div className="hidden items-center gap-2 md:flex">
            {session ? (
              <Link to="/app"><Button size="sm"><Sparkles className="size-4" /> ادامه یادگیری <ArrowLeft className="size-3.5" /></Button></Link>
            ) : (
              <>
                <Link to="/login"><Button size="sm" variant="ghost"><LogIn className="size-4" /> ورود</Button></Link>
                <Link to="/signup"><Button size="sm"><UserPlus className="size-4" /> ثبت‌نام رایگان</Button></Link>
              </>
            )}
          </div>
          <button onClick={() => setOpen((v) => !v)} className="rounded-xl border border-line p-2.5 md:hidden" aria-label="منو">
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
        <AnimatePresence>
          {open && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden border-t border-line/60 bg-bg/95 md:hidden">
              <div className="container-x space-y-1 py-4">
                {NAV.map((n) => (
                  <NavLink key={n.to} to={n.to} end={n.end}
                    className={({ isActive }) => cn('block rounded-xl px-3 py-3 text-sm font-bold', isActive ? 'bg-card-soft text-ink' : 'text-ink-muted')}>
                    {n.label}
                  </NavLink>
                ))}
                <div className="grid grid-cols-2 gap-2 pt-3">
                  {session ? (
                    <Link to="/app" className="col-span-2"><Button className="w-full">ادامه یادگیری در LINGU</Button></Link>
                  ) : (
                    <>
                      <Link to="/login"><Button variant="outline" className="w-full">ورود</Button></Link>
                      <Link to="/signup"><Button className="w-full">ثبت‌نام</Button></Link>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {api?.mode === 'demo' && (
        <div className="border-b border-warn/30 bg-warn/10 px-4 py-2 text-center text-xs font-bold text-warn">
          پیش‌نمایش طراحی LINGU — این نسخه برای بازبینی رابط کاربری است و در انتشار نهایی وجود ندارد.
          {session && <> · <Link to="/?preview=public" className="underline">صفحه عمومی</Link> · <Link to="/onboarding?preview=1" className="underline">مرور مسیر آشنایی</Link></>}
        </div>
      )}

      <main className="flex-1"><Outlet /></main>

      <footer className="mt-20 border-t border-line/60 bg-bg-soft/50">
        <div className="container-x grid gap-10 py-12 sm:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-4">
            <Brand />
            <p className="max-w-xs text-sm leading-7 text-ink-muted">
              {appName} یک پلتفرم آموزش زبان است: درس‌های کامل، AI Tutor و Conversation Partner در سه زبان.
            </p>
          </div>
          <FooterCol title="محصول" links={[['امکانات', '/features'], ['زبان‌ها', '/languages'], ['چگونه کار می‌کند', '/how-it-works']]} />
          <FooterCol title="یادگیری" links={[[session ? 'برنامه من' : 'شروع رایگان', session ? '/app' : '/signup'], ['درس‌ها', session ? '/app/lessons' : '/features'], ['اشتراک', session ? '/app/subscription' : '/faq']]} />
          <FooterCol title="پشتیبانی" links={session
            ? [['راهنما در برنامه', '/app/help'], ['سؤالات متداول', '/faq'], ['تنظیمات حساب', '/app/settings']]
            : [['سؤالات متداول', '/faq'], ['ورود', '/login'], ['ثبت‌نام رایگان', '/signup']]} />
        </div>
        <div className="border-t border-line/60 py-5">
          <p className="container-x text-center text-xs text-ink-faint">© {new Date().getFullYear()} {appName} — تمام حقوق محفوظ است.</p>
        </div>
      </footer>
    </div>
  )
}

function FooterCol({ title, links }: { title: string; links: [string, string][] }) {
  return (
    <div>
      <h3 className="mb-3 text-sm font-extrabold">{title}</h3>
      <ul className="space-y-2 text-sm">
        {links.map(([label, to]) => (
          <li key={label + to}><Link to={to} className="text-ink-muted transition-colors hover:text-ink">{label}</Link></li>
        ))}
      </ul>
    </div>
  )
}
