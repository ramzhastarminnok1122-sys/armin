import { useState } from 'react'
import { Plus, Save, Trash2 } from 'lucide-react'
import { Button, Card, Chip, Confirmed, EmptyState, Field, Input, Modal, Select, Switch, Textarea } from '@/components/ui'
import { cn } from '@/lib/utils'

export type FieldDef<T> = {
  name: keyof T & string
  label: string
  type: 'text' | 'textarea' | 'number' | 'switch' | 'select'
  options?: { value: string; label: string }[]
  hint?: string
  placeholder?: string
  half?: boolean
}

type Props<T extends { id?: string }> = {
  rows: T[]
  fields: FieldDef<T>[]
  columns: { key: keyof T & string; label: string; render?: (row: T) => React.ReactNode; className?: string }[]
  title: string
  subtitle?: string
  emptyTitle: string
  emptyBody?: string
  defaults: Partial<T>
  onSave: (row: T) => Promise<void>
  onDelete: (id: string) => Promise<void>
  loading?: boolean
}

/** Schema-driven CRUD used by the small admin sections (plans, FAQ, testimonials, banners, languages). */
export function AdminCrud<T extends { id?: string }>({
  rows, fields, columns, title, subtitle, emptyTitle, emptyBody, defaults, onSave, onDelete, loading,
}: Props<T>) {
  const [open, setOpen] = useState(false)
  const [draft, setDraft] = useState<T>(defaults as T)
  const [busy, setBusy] = useState(false)

  const openNew = () => { setDraft(defaults as T); setOpen(true) }
  const openEdit = (row: T) => { setDraft({ ...row }); setOpen(true) }

  const save = async () => {
    setBusy(true)
    try { await onSave(draft); setOpen(false) }
    finally { setBusy(false) }
  }

  const setValue = (name: string, value: unknown) => setDraft((d) => ({ ...d, [name]: value }) as T)

  return (
    <>
      <Card className="!p-5">
        <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="text-lg font-extrabold">{title}</h2>
            {subtitle && <p className="mt-1 text-[11px] leading-6 text-ink-muted">{subtitle}</p>}
          </div>
          <Button size="sm" onClick={openNew}><Plus className="size-3.5" /> افزودن</Button>
        </div>

        {loading ? (
          <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="skeleton h-12" />)}</div>
        ) : rows.length === 0 ? (
          <EmptyState icon={<Plus className="size-6" />} title={emptyTitle} body={emptyBody} action={<Button size="sm" variant="outline" onClick={openNew}>افزودن اولین مورد</Button>} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] text-sm">
              <thead className="bg-card-soft/40">
                <tr className="text-[11px] text-ink-faint">
                  {columns.map((c) => <th key={c.key} className={cn('px-4 py-3 text-right font-bold', c.className)}>{c.label}</th>)}
                  <th className="px-4 py-3 text-right font-bold">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row, i) => (
                  <tr key={row.id ?? i} className="border-t border-line/50 transition-colors hover:bg-card-soft/25">
                    {columns.map((c) => (
                      <td key={c.key} className={cn('px-4 py-3 align-middle', c.className)}>
                        {c.render ? c.render(row) : String((row as Record<string, unknown>)[c.key] ?? '—')}
                      </td>
                    ))}
                    <td className="px-4 py-3">
                      <div className="flex gap-1.5">
                        <Button size="sm" variant="ghost" onClick={() => openEdit(row)}>ویرایش</Button>
                        {row.id && (
                          <Confirmed label={<Trash2 className="size-3.5" />} confirmLabel="حذف کن" onConfirm={() => onDelete(row.id!)} />
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title={draft.id ? 'ویرایش' : 'افزودن مورد جدید'} wide>
        <div className="grid gap-4 sm:grid-cols-2">
          {fields.map((f) => (
            <div key={f.name} className={f.half ? '' : 'sm:col-span-2'}>
              {f.type === 'switch' ? (
                <div className="flex items-center justify-between rounded-2xl border border-line/70 bg-bg-soft/50 px-4 py-3">
                  <span className="text-xs font-bold">{f.label}</span>
                  <Switch checked={Boolean((draft as Record<string, unknown>)[f.name])} onChange={(v) => setValue(f.name, v)} />
                </div>
              ) : (
                <Field label={f.label} hint={f.hint}>
                  {f.type === 'textarea' ? (
                    <Textarea value={String((draft as Record<string, unknown>)[f.name] ?? '')} placeholder={f.placeholder} onChange={(e) => setValue(f.name, e.target.value)} />
                  ) : f.type === 'select' ? (
                    <Select value={String((draft as Record<string, unknown>)[f.name] ?? '')} onChange={(e) => setValue(f.name, e.target.value)}>
                      {(f.options ?? []).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                    </Select>
                  ) : f.type === 'number' ? (
                    <Input type="number" value={String((draft as Record<string, unknown>)[f.name] ?? 0)} placeholder={f.placeholder} onChange={(e) => setValue(f.name, Number(e.target.value))} />
                  ) : (
                    <Input value={String((draft as Record<string, unknown>)[f.name] ?? '')} placeholder={f.placeholder} onChange={(e) => setValue(f.name, e.target.value)} />
                  )}
                </Field>
              )}
            </div>
          ))}
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <Button variant="ghost" onClick={() => setOpen(false)}>انصراف</Button>
          <Button onClick={save} loading={busy}><Save className="size-4" /> ذخیره</Button>
        </div>
      </Modal>
    </>
  )
}

export const CrudChip = Chip
