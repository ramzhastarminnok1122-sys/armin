import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { AlertTriangle, ArrowUp, Crown, GraduationCap, Loader2, RefreshCw, Sparkles, Trash2 } from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { Button, Card } from '@/components/ui'
import { cn, faNum, faError } from '@/lib/utils'
import type { ChatMessage } from '@/services/types'

export const PARTNER_LIMIT_TEXT = 'دو پیام رایگان Conversation Partner را استفاده کردی. برای ادامه گفت‌وگو و دسترسی کامل به LINGU، اشتراک تهیه کن.'

type Props = {
  conversationId: string | null
  mode: 'tutor' | 'partner'
  scenario?: string | null
  scenarioFa?: string | null
  lessonId?: string | null
  suggestions?: string[]
  onQuotaBlocked?: () => void
  onConversationCreated?: (id: string) => void
}

export function ChatPanel({ conversationId, mode, scenario, scenarioFa, lessonId, suggestions = [], onQuotaBlocked, onConversationCreated }: Props) {
  const { api, quota, membership, toast, refreshQuota, refreshProfile, profile } = useApp()
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [booting, setBooting] = useState(false)
  const [blocked, setBlocked] = useState<string | null>(null)
  const [convId, setConvId] = useState<string | null>(conversationId)
  const listRef = useRef<HTMLDivElement>(null)

  useEffect(() => { setConvId(conversationId) }, [conversationId])

  // load history
  useEffect(() => {
    let alive = true
    ;(async () => {
      if (!api || !convId) { setMessages([]); return }
      setBooting(true)
      try {
        const msgs = await api.messages(convId)
        if (alive) setMessages(msgs)
      } catch (e) { console.error(e) } finally { if (alive) setBooting(false) }
    })()
    return () => { alive = false }
  }, [api, convId])

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages, loading])

  const quotaLeft = mode === 'partner' && !membership.premium ? quota?.partner_remaining ?? null : null
  const exhausted = !membership.premium && (mode === 'tutor' || (quotaLeft !== null && quotaLeft <= 0))

  const send = async (text: string) => {
    const message = text.trim()
    if (!message || loading) return
    if (!api) return
    setInput('')

    // Free user with no partner messages left: never fake an AI answer, show the honest wall.
    if (!membership.premium && mode === 'partner' && (quota?.partner_remaining ?? 0) <= 0) {
      setBlocked(PARTNER_LIMIT_TEXT)
      onQuotaBlocked?.()
      return
    }

    const optimistic: ChatMessage = { id: `tmp-${Date.now()}`, role: 'user', content: message, created_at: new Date().toISOString() }
    setMessages((m) => [...m, optimistic])
    setLoading(true)
    try {
      let id = convId
      if (!id) {
        const conv = await api.createConversation({
          mode, scenario: scenario ?? undefined, scenario_fa: scenarioFa ?? undefined,
          lesson_id: lessonId ?? null, title: scenarioFa ?? (mode === 'tutor' ? 'گفت‌وگو با AI Tutor' : 'Conversation Partner'),
        })
        id = conv.id
        setConvId(conv.id)
        onConversationCreated?.(conv.id)
      }
      const { reply } = await api.sendMessage({
        conversation_id: id, message, mode, lesson_id: lessonId ?? null,
        scenario: scenario ?? undefined, scenario_fa: scenarioFa ?? undefined,
        language: profile?.target_language ?? 'en', level: profile?.preferred_level ?? 'A1',
      })
      setMessages((m) => [...m, { id: `a-${Date.now()}`, role: 'assistant', content: reply, created_at: new Date().toISOString() }])
      await Promise.all([refreshQuota(), refreshProfile()])
    } catch (e: any) {
      setMessages((m) => m.filter((x) => x.id !== optimistic.id))
      if (e?.payload?.code === 'partner_quota_exceeded' || e?.status === 402) {
        setBlocked(e?.payload?.error || PARTNER_LIMIT_TEXT)
        onQuotaBlocked?.()
        await refreshQuota()
      } else if (e?.payload?.code === 'tutor_requires_premium' || e?.status === 403) {
        setBlocked(e?.payload?.error || 'مربی هوش مصنوعی برای کاربران Premium فعال است.')
      } else if (e?.payload?.code === 'daily_limit_reached' || e?.status === 429) {
        setBlocked(e?.payload?.error || 'سقف استفاده امروز پر شده است. فردا ادامه بده.')
      } else if (e?.payload?.code === 'ai_disabled' || e?.status === 503) {
        setBlocked('دستیار هوش مصنوعی موقتاً توسط مدیر غیرفعال شده است. کمی بعد دوباره تلاش کن.')
      } else if (e?.status === 401) {
        setBlocked('برای استفاده از دستیار AI باید وارد حساب شوی.')
      } else {
        toast(faError(e, 'ارسال پیام ناموفق بود. دوباره تلاش کن.'), 'error')
      }
    } finally { setLoading(false) }
  }

  const clear = async () => {
    if (!api || !convId) return
    await api.deleteConversation(convId)
    setMessages([]); setConvId(null); setBlocked(null)
    toast('گفت‌وگو پاک شد.', 'success')
  }

  return (
    <Card className="flex h-[calc(100dvh-15rem)] min-h-[520px] flex-col !p-0">
      {/* header */}
      <div className="flex items-center justify-between gap-3 border-b border-line/60 p-4">
        <div className="flex items-center gap-3">
          <span className={cn('relative grid size-10 place-items-center rounded-2xl text-white', mode === 'tutor' ? 'bg-brand-grad' : 'bg-gradient-to-br from-emerald-400 to-cyan-500')}>
            {mode === 'tutor' ? <GraduationCap className="size-5" /> : <Sparkles className="size-5" />}
            {loading && <span className="absolute inset-0 animate-pulse-ring rounded-2xl border border-white/60" />}
          </span>
          <div>
            <p className="text-sm font-extrabold">{mode === 'tutor' ? 'AI Tutor' : scenarioFa || 'Conversation Partner'}</p>
            <p className="text-[10px] text-ink-faint">
              {mode === 'tutor'
                ? (membership.premium
                  ? `دسترسی کامل · پاسخ بر اساس درس جاری${typeof quota?.tutor_remaining === 'number' ? ` · ${faNum(quota.tutor_remaining)} پیام باقی‌مانده امروز` : ''}`
                  : 'برای کاربران Premium')
                : (membership.premium
                  ? `بدون محدودیت پیام`
                  : quotaLeft === null ? '—' : `${faNum(quotaLeft)} پیام رایگان باقی‌مانده`)}
            </p>
          </div>
        </div>
        {convId && (
          <button onClick={clear} className="rounded-xl p-2 text-ink-faint transition-colors hover:bg-danger/10 hover:text-danger" title="پاک کردن گفت‌وگو">
            <Trash2 className="size-4" />
          </button>
        )}
      </div>

      {/* messages */}
      <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto p-4">
        {booting && <div className="flex justify-center py-6"><Loader2 className="size-5 animate-spin text-primary" /></div>}

        {!booting && messages.length === 0 && (
          <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
            <span className="grid size-14 place-items-center rounded-3xl bg-brand-soft text-primary-soft">
              {mode === 'tutor' ? <GraduationCap className="size-6" /> : <Sparkles className="size-6" />}
            </span>
            <p className="text-sm font-extrabold">{mode === 'tutor' ? 'هر سؤالی درباره درس داری بپرس' : 'مکالمه را شروع کن'}</p>
            <p className="max-w-sm text-[11px] leading-6 text-ink-faint">
              {mode === 'tutor'
                ? 'مثلاً: «این گرامر را ساده‌تر توضیح بده»، «برای این واژه مثال بساز» یا «یک تمرین کوتاه بده».'
                : 'می‌توانی با یک سلام ساده شروع کنی؛ هم‌صحبت تو در نقش می‌ماند و گفت‌وگو را ادامه می‌دهد.'}
            </p>
          </div>
        )}

        <AnimatePresence initial={false}>
          {messages.map((m) => (
            <motion.div key={m.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className={cn('flex gap-2.5', m.role === 'user' ? 'flex-row-reverse' : '')}>
              <span className={cn('grid size-8 shrink-0 place-items-center rounded-2xl text-[10px] font-extrabold',
                m.role === 'user' ? 'bg-card-soft text-ink-muted' : mode === 'tutor' ? 'bg-brand-grad text-white' : 'bg-gradient-to-br from-emerald-400 to-cyan-500 text-white')}>
                {m.role === 'user' ? 'تو' : mode === 'tutor' ? 'AI' : 'CP'}
              </span>
              <div className={cn('max-w-[82%] rounded-2xl border px-4 py-3',
                m.role === 'user' ? 'border-primary/30 bg-primary/10' : 'border-line/70 bg-bg-soft/70')}>
                <p className={cn('whitespace-pre-line text-[13px] leading-7', mode === 'partner' && m.role === 'assistant' && 'ltr text-left')}>{m.content}</p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-2.5">
            <span className={cn('grid size-8 place-items-center rounded-2xl', mode === 'tutor' ? 'bg-brand-grad' : 'bg-gradient-to-br from-emerald-400 to-cyan-500')}>
              <Loader2 className="size-3.5 animate-spin text-white" />
            </span>
            <div className="rounded-2xl border border-line/70 bg-bg-soft/70 px-4 py-3">
              <div className="flex gap-1">
                {[0, 1, 2].map((i) => (
                  <motion.span key={i} className="size-1.5 rounded-full bg-ink-faint"
                    animate={{ opacity: [0.25, 1, 0.25] }} transition={{ duration: 1.1, repeat: Infinity, delay: i * 0.18 }} />
                ))}
              </div>
            </div>
          </motion.div>
        )}

        <AnimatePresence>
          {blocked && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <div className="rounded-3xl border border-warn/35 bg-warn/10 p-5">
                <div className="flex items-start gap-3">
                  <span className="grid size-9 shrink-0 place-items-center rounded-2xl bg-warn/20 text-warn"><AlertTriangle className="size-4" /></span>
                  <div>
                    <p className="text-[13px] font-extrabold leading-7 text-warn">{blocked}</p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <Link to="/app/subscription"><Button size="sm"><Crown className="size-3.5" /> تهیه اشتراک Premium</Button></Link>
                      <Link to="/app/lessons"><Button size="sm" variant="outline">ادامه درس‌ها</Button></Link>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* composer */}
      <div className="border-t border-line/60 p-4">
        {exhausted && !blocked && (
          <div className="mb-3 rounded-2xl border border-warn/35 bg-warn/10 p-4">
            <p className="text-[12px] font-bold leading-7 text-warn">{PARTNER_LIMIT_TEXT}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Link to="/app/subscription"><Button size="sm"><Crown className="size-3.5" /> تهیه اشتراک</Button></Link>
            </div>
          </div>
        )}

        {!!suggestions.length && !exhausted && (
          <div className="no-scrollbar mb-3 flex gap-2 overflow-x-auto">
            {suggestions.map((s) => (
              <button key={s} onClick={() => send(s)}
                className="shrink-0 rounded-2xl border border-line/80 bg-card/50 px-3 py-2 text-[11px] font-bold text-ink-muted transition-colors hover:border-primary/40 hover:text-ink">
                {s}
              </button>
            ))}
          </div>
        )}

        <form onSubmit={(e) => { e.preventDefault(); send(input) }} className="flex items-end gap-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(input) } }}
            rows={1}
            placeholder={mode === 'tutor' ? 'سؤالت را بنویس…' : 'پاسخ خود را بنویس…'}
            disabled={exhausted}
            className={cn('input h-auto max-h-32 min-h-[48px] flex-1 resize-none py-3 leading-6', mode === 'partner' && 'ltr text-left')}
          />
          <Button type="submit" size="md" loading={loading} disabled={exhausted || !input.trim()} className="!h-12 !w-12 !px-0" aria-label="ارسال">
            {!loading && <ArrowUp className="size-4" />}
          </Button>
        </form>

        <p className="mt-2 flex items-center gap-1.5 text-[10px] text-ink-faint">
          <RefreshCw className="size-3" />
          {mode === 'tutor'
            ? 'پاسخ‌ها بر اساس محتوای درس LINGU و سؤال تو تولید می‌شوند.'
            : 'دستیار نقش‌محور LINGU — برای ادامه گفت‌وگو در نقش می‌ماند.'}
        </p>
      </div>
    </Card>
  )
}
