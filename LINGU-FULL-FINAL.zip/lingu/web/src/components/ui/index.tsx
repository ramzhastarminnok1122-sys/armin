import {
  AnimatePresence, motion, useInView, useMotionValue, useReducedMotion, useSpring, type HTMLMotionProps,
} from 'motion/react'
import {
  useEffect, useMemo, useRef, useState, type ButtonHTMLAttributes, type InputHTMLAttributes,
  type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes,
} from 'react'
import { AlertTriangle, CheckCircle2, Info, Loader2, X } from 'lucide-react'
import { cn, faNum } from '@/lib/utils'

/* ---------------------------------- basics --------------------------------- */

export function Card({ className, children, ...rest }: HTMLMotionProps<'div'> & { children?: ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className={cn('card-surface p-5 ring-card', className)}
      {...rest}
    >
      {children}
    </motion.div>
  )
}

export function Chip({ children, className, tone = 'default' }: { children: ReactNode; className?: string; tone?: 'default' | 'primary' | 'success' | 'warn' | 'danger' }) {
  const tones = {
    default: 'bg-card-soft/60 text-ink-muted border-line/80',
    primary: 'bg-primary/15 text-primary-soft border-primary/30',
    success: 'bg-success/15 text-success border-success/30',
    warn: 'bg-warn/15 text-warn border-warn/30',
    danger: 'bg-danger/15 text-danger border-danger/30',
  }
  return <span className={cn('inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-bold', tones[tone], className)}>{children}</span>
}

export function Button({
  variant = 'primary', size = 'md', loading, className, children, ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'outline' | 'ghost' | 'danger'; size?: 'sm' | 'md' | 'lg'; loading?: boolean }) {
  const sizes = { sm: 'h-9 px-3.5 text-xs', md: 'h-11 px-5 text-sm', lg: 'h-13 px-7 text-base' }
  const variants = {
    primary: 'bg-brand-grad text-white shadow-glow hover:brightness-110 hover:-translate-y-0.5',
    outline: 'border border-line bg-card/50 hover:bg-card-soft text-ink',
    ghost: 'text-ink-muted hover:text-ink hover:bg-card-soft/70',
    danger: 'bg-danger/90 text-white hover:bg-danger',
  }
  return (
    <button
      className={cn('btn', sizes[size], variants[variant], className)}
      disabled={loading || rest.disabled}
      {...rest}
    >
      {loading && <Loader2 className="size-4 animate-spin" />}
      {children}
    </button>
  )
}

export const Spinner = ({ className }: { className?: string }) => (
  <Loader2 className={cn('size-5 animate-spin text-primary', className)} />
)

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('skeleton h-4 w-full', className)} />
}

export function SkeletonCard() {
  return (
    <div className="card-surface p-5 space-y-3">
      <Skeleton className="h-5 w-1/3" />
      <Skeleton className="h-3 w-2/3" />
      <Skeleton className="h-24 w-full" />
    </div>
  )
}

/* --------------------------------- feedback -------------------------------- */

export function EmptyState({ title, body, icon, action }: { title: string; body?: string; icon?: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-3xl border border-dashed border-line/80 bg-card/40 px-6 py-14 text-center">
      <div className="grid size-14 place-items-center rounded-2xl bg-brand-soft text-primary-soft">{icon ?? <Info className="size-6" />}</div>
      <h3 className="text-lg font-extrabold">{title}</h3>
      {body && <p className="max-w-md text-sm leading-7 text-ink-muted">{body}</p>}
      {action}
    </div>
  )
}

export function Toaster({ toasts, onDismiss }: { toasts: { id: number; kind: string; text: string }[]; onDismiss: (id: number) => void }) {
  const icons: Record<string, ReactNode> = {
    success: <CheckCircle2 className="size-4 text-success" />,
    error: <AlertTriangle className="size-4 text-danger" />,
    info: <Info className="size-4 text-primary-soft" />,
  }
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[80] flex flex-col items-center gap-2 px-4 sm:bottom-6">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: 24, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.97 }}
            transition={{ type: 'spring', stiffness: 400, damping: 30 }}
            className="glass-strong pointer-events-auto flex w-full max-w-md items-center gap-3 rounded-2xl px-4 py-3 text-sm shadow-soft"
          >
            {icons[t.kind] ?? icons.info}
            <span className="flex-1 leading-6">{t.text}</span>
            <button onClick={() => onDismiss(t.id)} className="rounded-lg p-1 text-ink-faint hover:bg-card-soft hover:text-ink" aria-label="بستن">
              <X className="size-3.5" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  )
}

export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    if (open) window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])
  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-[90] flex items-end justify-center p-0 sm:items-center sm:p-6"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
          <motion.div
            initial={{ y: 40, opacity: 0, scale: 0.98 }} animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 20, opacity: 0, scale: 0.98 }} transition={{ type: 'spring', stiffness: 320, damping: 30 }}
            className={cn('glass-strong relative z-10 w-full overflow-hidden rounded-t-4xl p-5 sm:rounded-4xl', wide ? 'max-w-3xl' : 'max-w-lg')}
          >
            <div className="mb-4 flex items-center justify-between gap-4">
              <h3 className="text-lg font-extrabold">{title}</h3>
              <button onClick={onClose} className="rounded-xl p-2 text-ink-faint hover:bg-card-soft hover:text-ink" aria-label="بستن"><X className="size-4" /></button>
            </div>
            <div className="max-h-[70vh] overflow-y-auto pl-1">{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

/* ----------------------------------- forms --------------------------------- */

export function Field({ label, hint, children, required }: { label: string; hint?: string; children: ReactNode; required?: boolean }) {
  return (
    <label className="block">
      <span className="label">{label}{required && <span className="text-danger"> *</span>}</span>
      {children}
      {hint && <span className="mt-1 block text-[11px] leading-5 text-ink-faint">{hint}</span>}
    </label>
  )
}

export const Input = ({ className, ...rest }: InputHTMLAttributes<HTMLInputElement>) => (
  <input className={cn('input', className)} {...rest} />
)
export const Textarea = ({ className, ...rest }: TextareaHTMLAttributes<HTMLTextAreaElement>) => (
  <textarea className={cn('input h-auto min-h-[110px] py-3 leading-7', className)} {...rest} />
)
export const Select = ({ className, children, ...rest }: SelectHTMLAttributes<HTMLSelectElement>) => (
  <select className={cn('input appearance-none pl-3 pr-9 bg-[left_0.75rem_center] bg-no-repeat', className)} {...rest}>{children}</select>
)

export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button type="button" onClick={() => onChange(!checked)}
      className={cn('inline-flex items-center gap-2.5 text-sm font-bold', checked ? 'text-ink' : 'text-ink-muted')}>
      <span className={cn('relative h-6 w-11 rounded-full border transition-colors', checked ? 'bg-brand-grad border-transparent' : 'bg-card-soft border-line')}>
        <motion.span layout transition={{ type: 'spring', stiffness: 500, damping: 32 }}
          className={cn('absolute top-0.5 size-5 rounded-full bg-white shadow', checked ? 'right-0.5' : 'right-[22px]')} />
      </span>
      {label}
    </button>
  )
}

/* ---------------------------------- display -------------------------------- */

export function AnimatedNumber({ value, duration = 1.1, className, suffix }: { value: number; duration?: number; className?: string; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null)
  const inView = useInView(ref, { once: true, margin: '-40px' })
  const mv = useMotionValue(0)
  const spring = useSpring(mv, { duration: duration * 1000, bounce: 0 })
  const [shown, setShown] = useState(0)
  useEffect(() => { if (inView) mv.set(value) }, [inView, value, mv])
  useEffect(() => spring.on('change', (v) => setShown(Math.round(v))), [spring])
  return <span ref={ref} className={className}>{faNum(shown.toLocaleString('en-US'))}{suffix}</span>
}

export function Progress({ value, className, tone = 'primary', showLabel }: { value: number; className?: string; tone?: 'primary' | 'success'; showLabel?: boolean }) {
  const pct = Math.max(0, Math.min(100, value))
  return (
    <div className={cn('flex items-center gap-3', className)}>
      <div className="relative h-2.5 flex-1 overflow-hidden rounded-full bg-card-soft">
        <motion.div
          initial={{ width: 0 }} animate={{ width: `${pct}%` }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className={cn('h-full rounded-full bg-brand-grad', tone === 'success' && 'bg-success')}
        />
      </div>
      {showLabel && <span className="w-10 text-left text-xs font-bold text-ink-muted">{faNum(pct)}٪</span>}
    </div>
  )
}

export function Ring({ value, size = 96, label }: { value: number; size?: number; label?: string }) {
  const pct = Math.max(0, Math.min(100, value))
  const r = (size - 12) / 2
  const c = 2 * Math.PI * r
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} strokeWidth="8" className="stroke-card-soft" fill="none" />
        <motion.circle
          cx={size / 2} cy={size / 2} r={r} strokeWidth="8" fill="none" strokeLinecap="round"
          className="stroke-[rgb(var(--c-primary))]"
          initial={{ strokeDasharray: c, strokeDashoffset: c }}
          animate={{ strokeDashoffset: c - (pct / 100) * c }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
        />
      </svg>
      <div className="absolute text-center">
        <div className="text-xl font-extrabold">{faNum(pct)}٪</div>
        {label && <div className="text-[10px] font-bold text-ink-faint">{label}</div>}
      </div>
    </div>
  )
}

export function StatCard({ title, value, hint, icon, tone = 'primary', suffix }: { title: string; value: number | string; hint?: string; icon?: ReactNode; tone?: 'primary' | 'success' | 'warn' | 'danger'; suffix?: string }) {
  const tones = { primary: 'text-primary-soft bg-primary/12', success: 'text-success bg-success/12', warn: 'text-warn bg-warn/12', danger: 'text-danger bg-danger/12' }
  const numeric = typeof value === 'number'
  return (
    <motion.div whileHover={{ y: -4 }} transition={{ type: 'spring', stiffness: 300, damping: 24 }}
      className="card-surface relative overflow-hidden p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-bold text-ink-muted">{title}</p>
          <p className="mt-2 whitespace-nowrap text-3xl font-extrabold tracking-tight">
            {numeric ? <AnimatedNumber value={value as number} suffix={suffix} /> : value}
          </p>
          {hint && <p className="mt-1 text-[11px] text-ink-faint">{hint}</p>}
        </div>
        {icon && <div className={cn('grid size-11 place-items-center rounded-2xl', tones[tone])}>{icon}</div>}
      </div>
      <div className="pointer-events-none absolute -left-8 -bottom-10 size-24 rounded-full bg-brand-grad opacity-[0.08] blur-2xl" />
    </motion.div>
  )
}

export function PageHeader({ title, subtitle, actions, badge }: { title: string; subtitle?: string; actions?: ReactNode; badge?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        {badge && <div className="mb-2">{badge}</div>}
        <h1 className="text-2xl font-extrabold sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1.5 max-w-2xl text-sm leading-7 text-ink-muted">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  )
}

export function Tabs<T extends string>({ tabs, value, onChange, className }: { tabs: { id: T; label: string; count?: number }[]; value: T; onChange: (v: T) => void; className?: string }) {
  return (
    <div className={cn('no-scrollbar flex gap-1.5 overflow-x-auto rounded-2xl border border-line/70 bg-card/40 p-1.5', className)}>
      {tabs.map((t) => (
        <button key={t.id} onClick={() => onChange(t.id)}
          className={cn('relative shrink-0 rounded-xl px-4 py-2 text-xs font-bold transition-colors', value === t.id ? 'text-white' : 'text-ink-muted hover:text-ink')}>
          {value === t.id && (
            <motion.span layoutId={`tab-${tabs.map((x) => x.id).join()}`} className="absolute inset-0 rounded-xl bg-brand-grad"
              transition={{ type: 'spring', stiffness: 420, damping: 32 }} />
          )}
          <span className="relative z-10">{t.label}{t.count !== undefined && <span className="mr-1.5 opacity-70">{faNum(t.count)}</span>}</span>
        </button>
      ))}
    </div>
  )
}

export function SectionTitle({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h2 className="text-lg font-extrabold sm:text-xl">{title}</h2>
        {subtitle && <p className="mt-1 text-xs leading-6 text-ink-muted">{subtitle}</p>}
      </div>
      {actions}
    </div>
  )
}

export function Confirmed({ onConfirm, label, confirmLabel = 'مطمئنی؟', ariaLabel, variant = 'danger', size = 'sm', className }: { onConfirm: () => void; label: ReactNode; confirmLabel?: string; ariaLabel?: string; variant?: 'danger' | 'outline' | 'primary'; size?: 'sm' | 'md'; className?: string }) {
  const [armed, setArmed] = useState(false)
  const caption = useMemo(() => confirmLabel, [confirmLabel])
  useEffect(() => {
    if (!armed) return
    const t = window.setTimeout(() => setArmed(false), 4000)
    return () => window.clearTimeout(t)
  }, [armed])
  return (
    <Button variant={armed ? 'danger' : variant} size={size} className={className}
      aria-label={ariaLabel}
      onClick={() => { if (armed) { onConfirm(); setArmed(false) } else setArmed(true) }}>
      {armed ? caption : label}
    </Button>
  )
}

/* ------------------------------- scroll reveal ------------------------------- */

/** Sections fade/slide into view on the public website. Motion is opt-out aware. */
export function Reveal({ children, delay = 0, y = 22, blur = false, className }:
  { children: ReactNode; delay?: number; y?: number; blur?: boolean; className?: string }) {
  const reduce = useReducedMotion()
  if (reduce) return <div className={className}>{children}</div>
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y, filter: blur ? 'blur(10px)' : 'blur(0px)' }}
      whileInView={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
      viewport={{ once: true, amount: 0.18 }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  )
}

/** Staggered container for grids of cards. */
export function StaggerGroup({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  const reduce = useReducedMotion()
  if (reduce) return <div className={className}>{children}</div>
  return (
    <motion.div
      className={className}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, amount: 0.15 }}
      variants={{ hidden: {}, show: { transition: { staggerChildren: 0.09, delayChildren: delay } } }}
    >
      {children}
    </motion.div>
  )
}

export const staggerItem = {
  hidden: { opacity: 0, y: 24, scale: 0.98 },
  show: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] as const } },
}

/** Full-width page-level error surface (never a blank page). */
export function ErrorState({ title = 'خطا در بارگذاری', body, onRetry }: { title?: string; body?: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-3xl border border-danger/25 bg-danger/5 px-6 py-10 text-center">
      <span className="grid size-11 place-items-center rounded-2xl bg-danger/15 text-danger"><AlertTriangle className="size-5" /></span>
      <p className="text-sm font-extrabold">{title}</p>
      <p className="max-w-md text-[12px] leading-6 text-ink-muted">
        {body ?? 'ارتباط برقرار نشد. اتصال اینترنت را بررسی کن و دوباره تلاش کن.'}
      </p>
      {onRetry && <Button size="sm" variant="outline" onClick={onRetry}>تلاش مجدد</Button>}
    </div>
  )
}
