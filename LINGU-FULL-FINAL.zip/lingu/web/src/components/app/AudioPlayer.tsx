/**
 * LINGU · پخش‌کنندهٔ صوتی درس
 *
 * روی یک عنصر <audio> واقعی ساخته شده و کنترل‌های فارسی دارد:
 *   پخش/توقف · نوار پیشرفت با جابه‌جایی (seek) · زمان · پخش دوباره · سرعت ۰٫۷۵ / ۱ / ۱٫۲۵ / ۱٫۵
 *
 * فایل‌ها از باکت عمومی lesson-audio می‌آیند (نام فایل = هش محتوا + Cache-Control یک‌ساله)،
 * پس بار اول دانلود و بعد در مرورگر کش می‌شوند.
 *
 * متن نمایشی همیشه همان متن ارجاع صوتی است؛ یعنی دقیقاً چیزی که خوانده شده.
 * AudioQueue همان پخش‌کننده است، به‌علاوهٔ این امکان که خودِ خط‌های درس
 * (مثل خط‌های دیالوگ یا واژه‌ها) بتوانند همان کلیپ را پخش کنند — با یک عنصر صوتی،
 * تا هرگز دو صدا روی هم نیفتد.
 */
import {
  createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode,
} from 'react'
import { AlertCircle, Gauge, Headphones, Pause, Play, RotateCcw, SkipBack, SkipForward, Volume2 } from 'lucide-react'
import { audioUrl, clipBadge, fmtClock, type AudioClip } from '@/lib/audio'
import { faNum } from '@/lib/utils'

const RATES = [0.75, 1, 1.25, 1.5] as const

type QueueCtx = { current: string | null; play: (id: string) => void }

const AudioQueueContext = createContext<QueueCtx | null>(null)

interface PlayerProps {
  clips: AudioClip[]
  title?: string
  /** inline = فقط کنترل‌ها و متن کلیپ جاری (خط‌های درس خودشان متن را نشان می‌دهند) */
  variant?: 'full' | 'inline'
  /** پیام «همین الان این کلیپ را پخش کن» (کلیک روی خط دیالوگ یا واژه) */
  playSignal?: { id: string; n: number } | null
}

/** پخش‌کنندهٔ ساده (بدون اشتراک کلیپ با خط‌های درس). */
export function AudioPlayer({ clips, title, variant = 'full' }: PlayerProps) {
  return <PlayerCore clips={clips} title={title} variant={variant} />
}

/**
 * AudioQueue: یک پخش‌کنندهٔ واحد که خط‌های داخل درس هم می‌توانند کلیپ‌هایش را پخش کنند.
 * استفاده: <AudioQueue clips={clips}> … <ClipPlayButton id="…"/> … </AudioQueue>
 */
export function AudioQueue({ clips, title, variant = 'inline', children }: PlayerProps & { children?: ReactNode }) {
  const [current, setCurrent] = useState<string | null>(clips[0]?.id ?? null)
  const [signal, setSignal] = useState(0)
  /* کلیک روی خط/واژه همیشه پخش می‌کند — حتی اگر همان کلیپ از قبل انتخاب شده باشد */
  const api = useMemo<QueueCtx>(() => ({ current, play: (id) => { setCurrent(id); setSignal((n) => n + 1) } }), [current])
  return (
    <AudioQueueContext.Provider value={api}>
      <PlayerCore clips={clips} title={title} variant={variant} controlled={current} onControlled={setCurrent}
        playSignal={signal ? { id: current ?? '', n: signal } : null} />
      {children}
    </AudioQueueContext.Provider>
  )
}

/** دکمهٔ کوچک پخش برای یک کلیپ مشخص، داخل AudioQueue. */
export function ClipPlayButton({ id, className = '' }: { id: string; className?: string }) {
  const ctx = useContext(AudioQueueContext)
  if (!ctx) return null
  const active = ctx.current === id
  return (
    <button
      type="button"
      onClick={(e) => { e.stopPropagation(); ctx.play(id) }}
      aria-label={active ? 'پخش دوبارهٔ این خط' : 'شنیدن این خط'}
      title={active ? 'پخش دوباره' : 'شنیدن'}
      className={`grid size-7 shrink-0 place-items-center rounded-lg border transition ${
        active ? 'border-primary/40 bg-brand-soft text-primary-soft' : 'border-line/70 bg-card/60 text-ink-faint hover:text-ink'
      } ${className}`}
    >
      <Volume2 className="size-3.5" />
    </button>
  )
}

/* ================================ هستهٔ پخش ================================ */
function PlayerCore({ clips, title, variant = 'full', controlled, onControlled, playSignal }: PlayerProps & {
  controlled?: string | null
  onControlled?: (id: string) => void
}) {
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const [index, setIndex] = useState(0)
  const [playing, setPlaying] = useState(false)
  const [time, setTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [rate, setRate] = useState<number>(1)
  const [failed, setFailed] = useState(false)
  const [ready, setReady] = useState(false)

  /* حالت کنترل‌شده: انتخاب کلیپ از بیرون (خط‌های درس) */
  const playOnSelect = useRef(false)
  useEffect(() => {
    if (controlled === undefined || controlled === null) return
    const i = clips.findIndex((c) => c.id === controlled)
    if (i >= 0 && i !== index) { playOnSelect.current = true; setIndex(i) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [controlled])

  const clip = clips[Math.min(index, Math.max(clips.length - 1, 0))]
  const src = useMemo(() => (clip ? audioUrl(clip.path) : ''), [clip])

  /* با تغییر کلیپ: تازه‌سازی وضعیت و پخش از ابتدا (اگر کاربر در حال شنیدن بود) */
  const wasPlaying = useRef(false)
  useEffect(() => {
    const el = audioRef.current
    if (!el) return
    setFailed(false); setReady(false); setTime(0); setDuration(0)
    el.load()
    if (wasPlaying.current || playOnSelect.current) {
      playOnSelect.current = false
      const id = requestAnimationFrame(() => { void el.play().catch(() => setFailed(true)) })
      return () => cancelAnimationFrame(id)
    }
    setPlaying(false)
  }, [src])

  /* پخش فوری کلیپ انتخاب‌شده از بیرون (کلیک روی خط دیالوگ یا واژه) */
  useEffect(() => {
    if (!playSignal || !clip || clip.id !== playSignal.id) return
    const el = audioRef.current
    if (!el) return
    el.currentTime = 0; setTime(0)
    void el.play().catch(() => setFailed(true))
  }, [playSignal, clip?.id])

  useEffect(() => {
    const el = audioRef.current
    if (el) el.playbackRate = rate
  }, [rate, src, ready])

  const play = async () => {
    const el = audioRef.current
    if (!el || failed) return
    try {
      if (el.ended) el.currentTime = 0
      await el.play()
    } catch { setFailed(true) }
  }
  const pause = () => audioRef.current?.pause()
  const toggle = () => (playing ? pause() : play())

  const replay = async () => {
    const el = audioRef.current
    if (!el || failed) return
    el.currentTime = 0; setTime(0)
    try { await el.play() } catch { setFailed(true) }
  }

  const seek = (value: number) => {
    const el = audioRef.current
    if (!el || !Number.isFinite(el.duration)) return
    el.currentTime = value; setTime(value)
  }

  const select = (i: number, autoplay = false) => {
    const next = clips[i]
    if (!next) return
    if (i !== index) {
      wasPlaying.current = autoplay || playing
      setIndex(i)
      onControlled?.(next.id)
      if (autoplay) requestAnimationFrame(() => { void play() })
    } else if (autoplay) {
      void play()
    }
  }

  const changeRate = (value: number) => {
    setRate(value)
    const el = audioRef.current
    if (el) el.playbackRate = value
  }

  if (!clip) return null
  const pct = duration > 0 ? (time / duration) * 100 : 0
  const isFa = clip.lang === 'fa'

  return (
    <div className="rounded-2xl border border-line/70 bg-bg-soft/50 p-4 sm:p-5" dir="rtl">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <p className="flex items-center gap-2 text-xs font-extrabold text-ink-muted">
          <Headphones className="size-3.5 text-primary-soft" />
          {title ?? 'صدا و تلفظ این بخش'}
        </p>
        <span className={`rounded-full px-2.5 py-1 text-[10px] font-extrabold ${isFa ? 'bg-primary/12 text-primary-soft' : 'bg-success/12 text-success'}`}>
          {clipBadge(clip)}
        </span>
      </div>

      {/* متن دقیقاً همان چیزی که خوانده شده */}
      <div className="rounded-xl border border-line/60 bg-card/60 px-3.5 py-3">
        <p className={`text-[13px] leading-7 ${isFa ? '' : 'ltr text-left'}`}>{clip.text}</p>
      </div>

      <audio
        ref={audioRef}
        src={src}
        preload="metadata"
        onLoadedMetadata={(e) => { setDuration(e.currentTarget.duration || 0); setReady(true) }}
        onTimeUpdate={(e) => setTime(e.currentTarget.currentTime)}
        onPlay={() => { wasPlaying.current = true; setPlaying(true) }}
        onPause={() => { wasPlaying.current = false; setPlaying(false) }}
        onEnded={() => { wasPlaying.current = false; setPlaying(false); if (index < clips.length - 1) select(index + 1, false) }}
        onError={() => { setFailed(true); setPlaying(false) }}
      />

      {/* نوار پیشرفت با جابه‌جایی */}
      <div className="mt-3.5 flex items-center gap-2.5" dir="ltr">
        <span className="w-9 shrink-0 text-center text-[10px] font-bold tabular-nums text-ink-faint">{fmtClock(time)}</span>
        <input
          type="range" min={0} max={duration || 0} step={0.1} value={Math.min(time, duration || 0)}
          onChange={(e) => seek(Number(e.target.value))}
          disabled={failed || !ready || duration === 0}
          aria-label="جای پخش"
          className="h-1.5 w-full flex-1 cursor-pointer appearance-none rounded-full disabled:cursor-not-allowed"
          style={{ background: `linear-gradient(to right, rgb(var(--c-primary)) ${pct}%, rgba(148,163,184,.35) ${pct}%)` }}
        />
        <span className="w-9 shrink-0 text-center text-[10px] font-bold tabular-nums text-ink-faint">{fmtClock(duration)}</span>
      </div>

      {/* کنترل‌ها */}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <button type="button" onClick={toggle} disabled={failed}
          aria-label={playing ? 'توقف' : 'پخش'}
          className="grid size-11 place-items-center rounded-full bg-brand-grad text-white shadow-soft transition-transform hover:scale-[1.03] disabled:opacity-40">
          {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
        </button>

        <button type="button" onClick={replay} disabled={failed} aria-label="پخش دوباره" title="پخش دوباره"
          className="grid size-9 place-items-center rounded-xl border border-line/70 bg-card/60 text-ink-muted transition hover:text-ink disabled:opacity-40">
          <RotateCcw className="size-3.5" />
        </button>

        {clips.length > 1 && (
          <>
            <button type="button" onClick={() => select(index - 1, true)} disabled={failed || index === 0}
              aria-label="کلیپ قبلی" title="قبلی"
              className="grid size-9 place-items-center rounded-xl border border-line/70 bg-card/60 text-ink-muted transition hover:text-ink disabled:opacity-30">
              <SkipBack className="size-3.5" />
            </button>
            <button type="button" onClick={() => select(index + 1, true)} disabled={failed || index >= clips.length - 1}
              aria-label="کلیپ بعدی" title="بعدی"
              className="grid size-9 place-items-center rounded-xl border border-line/70 bg-card/60 text-ink-muted transition hover:text-ink disabled:opacity-30">
              <SkipForward className="size-3.5" />
            </button>
            <span className="text-[10px] font-bold text-ink-faint">
              {faNum(index + 1)} از {faNum(clips.length)}
            </span>
          </>
        )}

        <div className="ms-auto flex items-center gap-1.5 rounded-xl border border-line/70 bg-card/60 px-2 py-1">
          <Gauge className="size-3.5 text-ink-faint" />
          <span className="text-[10px] font-bold text-ink-faint">سرعت</span>
          {RATES.map((r) => (
            <button key={r} type="button" onClick={() => changeRate(r)} aria-pressed={rate === r}
              className={`rounded-lg px-2 py-1 text-[10px] font-extrabold transition ${rate === r ? 'bg-brand-soft text-primary-soft' : 'text-ink-muted hover:text-ink'}`}>
              {faNum(r)}×
            </button>
          ))}
        </div>
      </div>

      {failed && (
        <p className="mt-3 flex items-center gap-2 rounded-xl border border-warn/25 bg-warn/10 px-3 py-2 text-[11px] leading-6 text-warn">
          <AlertCircle className="size-3.5 shrink-0" /> فایل صوتی این بخش در دسترس نیست؛ بقیهٔ درس بدون مشکل کار می‌کند.
        </p>
      )}

      {/* فهرست کلیپ‌ها (وقتی خط‌های درس متن را نشان نمی‌دهند) */}
      {variant === 'full' && clips.length > 1 && (
        <ul className="mt-4 space-y-1.5 border-t border-line/60 pt-3.5">
          {clips.map((c, i) => (
            <li key={c.id}>
              <button type="button" onClick={() => select(i, true)}
                className={`flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-start transition ${i === index ? 'bg-brand-soft/70' : 'hover:bg-card/70'}`}>
                <span className={`grid size-6 shrink-0 place-items-center rounded-lg text-[10px] font-extrabold ${c.lang === 'fa' ? 'bg-primary/12 text-primary-soft' : 'bg-success/12 text-success'}`}>
                  {c.lang === 'fa' ? 'فا' : (c.speaker ?? faNum(i + 1))}
                </span>
                <span className={`min-w-0 flex-1 truncate text-[12px] ${c.lang === 'fa' ? '' : 'ltr text-left'} ${i === index ? 'font-bold text-ink' : 'text-ink-muted'}`}>
                  {c.text}
                </span>
                {i === index && playing && <span className="shrink-0 text-[10px] font-bold text-primary-soft">در حال پخش</span>}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
