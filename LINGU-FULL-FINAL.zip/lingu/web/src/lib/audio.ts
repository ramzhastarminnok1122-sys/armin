/**
 * LINGU · صدا در درس‌ها
 *
 * زنجیرهٔ واقعی: Lesson JSON → ارجاع صوتی (content.audio) → باکت lesson-audio → پخش‌کننده
 *
 * هر درس می‌تواند در content.audio مجموعه‌ای از «ارجاع صوتی» داشته باشد که با کلید بخش
 * (warmup، dialogue، listening، …) گروه‌بندی شده‌اند. هر ارجاع یک فایل واقعی و یک متن
 * دارد؛ آن متن دقیقاً همان چیزی است که خوانده شده (خروجی مانیفست صدا)، پس متن روی صفحه
 * و صدای فایل هرگز از هم جدا نمی‌شوند.
 *
 * هیچ فایل گم‌شده‌ای ارجاع نمی‌گیرد: ابزار ساخت ارجاع فقط کلیپ‌هایی را وارد درس می‌کند
 * که فایل واقعی‌شان وجود دارد و آپلود شده است.
 */
import { supabaseUrl } from './supabase'

export type ClipLang = 'en' | 'fa'

export interface AudioClip {
  id: string
  section: string
  lang: ClipLang
  role: string
  /** متن دقیق همان فایل صوتی (نه ترجمه، نه بازنویسی) */
  text: string
  /** مسیر در باکت: <lang>/<hash8>.mp3 */
  path: string
  hash: string
  bytes: number
  /** برای خطوط دیالوگ: A یا B */
  speaker?: string
  /** شمارهٔ خط دیالوگ در محتوا (صفرپایه) */
  line?: number
}

export type LessonAudioMap = Record<string, AudioClip[]>

export const AUDIO_BUCKET = 'lesson-audio'

/** آدرس عمومی و کش‌شدنی فایل صوتی (Cache-Control یک‌ساله؛ نام فایل هش محتواست). */
export function audioUrl(path: string): string {
  const base = (supabaseUrl ?? '').replace(/\/$/, '')
  return `${base}/storage/v1/object/public/${AUDIO_BUCKET}/${path}`
}

/** همهٔ ارجاع‌های صوتی یک درس، گروه‌بندی‌شده بر اساس بخش. */
export function lessonAudio(content: unknown): LessonAudioMap {
  const map = (content as { audio?: LessonAudioMap } | null)?.audio
  if (!map || typeof map !== 'object') return {}
  const out: LessonAudioMap = {}
  for (const [section, clips] of Object.entries(map)) {
    const list = (Array.isArray(clips) ? clips : []).filter(
      (c) => c && typeof c.path === 'string' && c.path.length > 0 && typeof c.text === 'string' && c.text.length > 0,
    )
    if (list.length) out[section] = list
  }
  return out
}

/** ارجاع‌های صوتی یک بخش مشخص (خالی = این بخش صدا ندارد). */
export function clipsFor(content: unknown, section: string): AudioClip[] {
  return lessonAudio(content)[section] ?? []
}

/** آیا این درس در هیچ بخشی صدا دارد؟ */
export function hasAudio(content: unknown): boolean {
  return Object.keys(lessonAudio(content)).length > 0
}

/** کلیپ مربوط به یک خط دیالوگ (با شمارهٔ خط در محتوا). */
export function clipForLine(clips: AudioClip[], line: number): AudioClip | undefined {
  return clips.find((c) => c.line === line)
}

/** کلیپ مربوط به یک واژه (کلیپ واژگان با «term.» شروع می‌شود). */
export function clipForVocab(clips: AudioClip[], term: string): AudioClip | undefined {
  const t = term.trim().toLowerCase()
  return clips.find((c) => c.text.toLowerCase().startsWith(`${t}.`)) ?? clips.find((c) => c.text.toLowerCase().startsWith(t))
}

const ROLE_LABEL_FA: Record<string, string> = {
  'FA-COACH': 'مربی فارسی',
  'FA-NARRATOR-F': 'راوی فارسی',
  'FA-NARRATOR-M': 'راوی فارسی',
  'EN-CHAR-A': 'گویندهٔ A',
  'EN-CHAR-B': 'گویندهٔ B',
  'EN-VOCAB': 'گویندهٔ واژگان',
  'EN-READ-M': 'راوی',
  'EN-READ-F': 'راوی',
}

/** برچسب کوتاه فارسی برای هر کلیپ (نوع صدا / گوینده). */
export function clipBadge(clip: AudioClip): string {
  if (clip.lang === 'fa') return ROLE_LABEL_FA[clip.role] ?? 'توضیح فارسی'
  if (clip.speaker) return `گویندهٔ ${clip.speaker}`
  return ROLE_LABEL_FA[clip.role] ?? 'انگلیسی'
}

const isFa = (clip: AudioClip) => clip.lang === 'fa'
export const persianClips = (clips: AudioClip[]) => clips.filter(isFa)
export const englishClips = (clips: AudioClip[]) => clips.filter((c) => !isFa(c))

/** قالب زمان m:ss با رقم فارسی. */
export function fmtClock(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) seconds = 0
  const m = Math.floor(seconds / 60)
  const s = Math.floor(seconds % 60)
  return `${m}:${String(s).padStart(2, '0')}`
}
