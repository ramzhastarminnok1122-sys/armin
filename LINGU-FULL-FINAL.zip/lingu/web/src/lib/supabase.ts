import { createClient, type SupabaseClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined
// Supabase renamed the browser key: projects created after Nov 2025 ship a
// "publishable" key (sb_publishable_...) instead of the legacy anon JWT.
// Both work the same way here — same role, same RLS — so accept either name.
const anon = (import.meta.env.VITE_SUPABASE_ANON_KEY
  || import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY) as string | undefined

/**
 * LINGU runs against real Supabase only.
 * DEMO ONLY (local design preview): if the env keys are missing we fall back to the
 * public Supabase demo endpoint so the UI can still boot. A production build with
 * VITE_DEMO_MODE=true is blocked in vite.config.ts, and `hasBackend` below stays
 * false, which forces every page into its explicit "backend not configured" state
 * instead of inventing data.
 */
export const supabaseUrl = url ?? ''
export const hasBackend = Boolean(url && anon)
export const supabase: SupabaseClient = createClient(
  url || 'https://demo.supabase.co',
  anon || 'demo-anon-key',
  { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } },
)

export const FUNCTIONS_URL = `${(url || '').replace(/\/$/, '')}/functions/v1`

export async function callFunction<T>(name: string, body: Record<string, unknown>): Promise<T> {
  const { data: { session } } = await supabase.auth.getSession()
  const res = await fetch(`${FUNCTIONS_URL}/${name}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      apikey: anon as string,
      Authorization: `Bearer ${session?.access_token ?? anon}`,
    },
    body: JSON.stringify(body),
  })
  const json = await res.json().catch(() => ({}))
  if (!res.ok) throw Object.assign(new Error((json as any)?.error || `خطای سرور (${res.status})`), { status: res.status, payload: json })
  return json as T
}
