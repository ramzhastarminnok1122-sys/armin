import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) { return twMerge(clsx(inputs)) }

const faDigits = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹']
/** Persian numerals for display (LINGU is a fully RTL Persian product). */
export const faNum = (n: number | string | null | undefined) =>
  n === null || n === undefined ? '' : String(n).replace(/\d/g, (d) => faDigits[Number(d)])

export const faDate = (iso?: string | null) => {
  if (!iso) return '—'
  try {
    return new Intl.DateTimeFormat('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' }).format(new Date(iso))
  } catch { return '—' }
}
export const faDateTime = (iso?: string | null) => {
  if (!iso) return '—'
  try {
    return new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(iso))
  } catch { return '—' }
}
export const faRelative = (iso?: string | null) => {
  if (!iso) return '—'
  const diff = (Date.now() - new Date(iso).getTime()) / 1000
  const rtf = new Intl.RelativeTimeFormat('fa-IR', { numeric: 'auto' })
  const steps: [number, Intl.RelativeTimeFormatUnit][] = [[60,'second'],[60,'minute'],[24,'hour'],[7,'day'],[4.34,'week'],[12,'month'],[Number.POSITIVE_INFINITY,'year']]
  let v = diff
  for (const [step, unit] of steps) {
    if (Math.abs(v) < step) return rtf.format(-Math.round(v), unit)
    v = v / step
  }
  return '—'
}
export const faPrice = (rial: number, label?: string | null) => {
  if (label) return label
  if (!rial) return 'به‌زودی'
  return `${faNum(rial.toLocaleString('en-US'))} ریال`
}
export const minutesLabel = (m: number) => `${faNum(m)} دقیقه`
export const initials = (name?: string | null) => (name || '?').trim().split(/\s+/).slice(0, 2).map((p) => p[0]).join('')
export const clamp = (n: number, min: number, max: number) => Math.min(Math.max(n, min), max)
export const uid = () => Math.random().toString(36).slice(2, 10)

/**
 * Turns any thrown value into something a Persian user can read.
 * Raw server/network messages (English, codes) must never reach the interface.
 */
export function faError(e: unknown, fallback = 'انجام نشد. کمی بعد دوباره تلاش کن.'): string {
  const raw = e instanceof Error ? e.message : typeof e === 'string' ? e : ''
  const m = raw.toLowerCase()
  if (!raw) return fallback
  if (/failed to fetch|networkerror|network request failed|err_name_not_resolved|timeout|timed out/.test(m))
    return 'ارتباط برقرار نشد. اتصال اینترنت را بررسی کن و دوباره تلاش کن.'
  if (m.includes('not_authenticated')) return 'برای این کار باید وارد حساب خودت شوی.'
  if (m.includes('permission denied') || m.includes('row-level security')) return 'این عملیات برای حساب تو مجاز نیست.'
  if (m.includes('invalid login')) return 'ایمیل یا گذرواژه اشتباه است.'
  if (m.includes('duplicate key')) return 'این مورد قبلاً ثبت شده است.'
  if (m.includes('payload too large') || m.includes('entity too large')) return 'حجم فایل بیش از حد مجاز است.'
  if (m.includes('mime') || m.includes('content type')) return 'قالب فایل پشتیبانی نمی‌شود.'
  if (m.includes('ai_disabled')) return 'مربی هوش مصنوعی فعلاً در دسترس نیست.'
  if (m.includes('partner_quota_exceeded')) return 'پیام‌های رایگان این بخش تمام شده است.'
  if (m.includes('quota') || m.includes('rate limit') || m.includes('too many')) return 'سقف استفاده امروز پر شده است. فردا ادامه بده.'
  if (m.includes('not configured')) return 'این بخش هنوز فعال نشده است.'
  // keep our own Persian messages; never echo a foreign technical string
  return /[\u0600-\u06FF]/.test(raw) ? raw : fallback
}
