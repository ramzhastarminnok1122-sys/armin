import { useCallback, useEffect, useRef, useState } from 'react'

/** Tiny async data hook — no state library needed for MVP. */
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[] = [], opts: { immediate?: boolean } = {}) {
  const { immediate = true } = opts
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(immediate)
  const [error, setError] = useState<string | null>(null)
  const fnRef = useRef(fn)
  fnRef.current = fn

  const run = useCallback(async () => {
    setLoading(true); setError(null)
    try {
      const res = await fnRef.current()
      setData(res)
      return res
    } catch (e) {
      setError(e instanceof Error ? e.message : 'خطای نامشخص')
      return null
    } finally { setLoading(false) }
  }, [])

  useEffect(() => { if (immediate) run() /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, deps)

  return { data, loading, error, reload: run, setData }
}

export function useMediaQuery(query: string) {
  const [matches, setMatches] = useState(() => (typeof window === 'undefined' ? false : window.matchMedia(query).matches))
  useEffect(() => {
    const mq = window.matchMedia(query)
    const on = () => setMatches(mq.matches)
    on(); mq.addEventListener('change', on)
    return () => mq.removeEventListener('change', on)
  }, [query])
  return matches
}

export function useCountUp(target: number, active = true, duration = 1200) {
  const [v, setV] = useState(0)
  useEffect(() => {
    if (!active) return
    let raf = 0
    const start = performance.now()
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / duration)
      setV(Math.round(target * (1 - Math.pow(1 - p, 3))))
      if (p < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [target, active, duration])
  return v
}

/** Small persisted state helper (client preferences that must survive reloads). */
export function useLocalStorage<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key)
      return raw === null ? initial : (JSON.parse(raw) as T)
    } catch { return initial }
  })
  const set = useCallback((next: T) => {
    setValue(next)
    try { localStorage.setItem(key, JSON.stringify(next)) } catch { /* storage disabled */ }
  }, [key])
  return [value, set] as const
}

/** Reads a CSS custom property so canvas/SVG code can follow the live theme. */
export function useThemeVar(name: string, fallback = '#6D5BFF') {
  const [v, setV] = useState(fallback)
  useEffect(() => {
    const read = () => {
      const raw = getComputedStyle(document.documentElement).getPropertyValue(`--c-${name}`).trim()
      setV(raw ? `rgb(${raw.split(/\s+/).join(' ')})` : fallback)
    }
    read()
    const obs = new MutationObserver(read)
    obs.observe(document.documentElement, { attributes: true, attributeFilter: ['style'] })
    return () => obs.disconnect()
  }, [name, fallback])
  return v
}
