/**
 * Bundled artwork defaults.
 * The database (`media_assets`) always wins: an admin can replace any of these
 * from Admin → Media Library without a new build. These paths only guarantee the
 * interface never shows a broken image before the DB is seeded (or if a slot is off).
 */
export type MediaEntry = { url: string; alt?: string | null }
export type MediaMap = Record<string, MediaEntry>

export const DEFAULT_MEDIA: MediaMap = {
  hero_background:        { url: '/art/hero-aurora.webp',     alt: 'پس‌زمینه بنفش مایل به سفید' },
  hero_background_mobile: { url: '/art/hero-aurora-sm.webp',  alt: 'پس‌زمینه هیرو (موبایل)' },
  ai_tutor:               { url: '/art/ai-tutor.webp',        alt: 'مربی هوش مصنوعی LINGU' },
  conversation:           { url: '/art/conversation.webp',    alt: 'گفت‌وگوی نقش‌محور' },
  premium:                { url: '/art/premium.webp',         alt: 'اشتراک ویژه LINGU' },
  onboarding:             { url: '/art/onboarding.webp',      alt: 'مسیر یادگیری' },
  lang_en:                { url: '/art/lang-en.webp',         alt: 'دوره انگلیسی' },
  lang_fr:                { url: '/art/lang-fr.webp',         alt: 'دوره فرانسه' },
  lang_es:                { url: '/art/lang-es.webp',         alt: 'دوره اسپانیایی' },
  scenario_cafe:          { url: '/art/scenario-cafe.webp',   alt: 'موقعیت کافه' },
  scenario_travel:        { url: '/art/scenario-travel.webp', alt: 'موقعیت سفر و فرودگاه' },
  scenario_job:           { url: '/art/conversation.webp',    alt: 'موقعیت مصاحبه کاری' },
  scenario_school:        { url: '/art/conversation.webp',    alt: 'موقعیت مدرسه و دانشگاه' },
}

/** Rows from `media_assets` (active ones win) over the bundled defaults. */
export function buildMediaMap(rows: { slot: string; url: string; alt_fa: string | null; is_active: boolean }[]): MediaMap {
  const map: MediaMap = { ...DEFAULT_MEDIA }
  for (const row of rows) {
    if (!row.is_active || !row.url) continue
    map[row.slot] = { url: row.url, alt: row.alt_fa }
  }
  return map
}

export const mediaOf = (map: MediaMap | undefined, slot: string): MediaEntry =>
  map?.[slot] ?? DEFAULT_MEDIA[slot] ?? { url: '', alt: '' }

export const LANG_SLOT: Record<string, string> = { en: 'lang_en', fr: 'lang_fr', es: 'lang_es' }

/** Every Conversation Partner scenario points at an admin-replaceable image slot. */
export const SCENARIO_SLOT: Record<string, string> = {
  cafe: 'scenario_cafe', restaurant: 'scenario_cafe', shopping: 'scenario_cafe', daily: 'scenario_cafe',
  travel: 'scenario_travel', airport: 'scenario_travel', meeting: 'scenario_travel',
  job: 'scenario_job', school: 'scenario_school',
}
