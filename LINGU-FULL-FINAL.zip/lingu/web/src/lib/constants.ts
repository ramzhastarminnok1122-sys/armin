export type Lang = 'en' | 'fr' | 'es'

export const LANGUAGE_ORDER: Lang[] = ['en', 'fr', 'es']

export const LEVELS = ['A1', 'A2', 'B1', 'B2', 'C1'] as const
export type Level = (typeof LEVELS)[number]

export const LEVEL_FA: Record<string, string> = {
  A1: 'مبتدی', A2: 'پیش‌متوسط', B1: 'متوسط', B2: 'متوسط بالا', C1: 'پیشرفته',
}

/** Every image slot of the product. Admin > Media Library owns the real value of each one. */
export const MEDIA_SLOTS = [
  { slot: 'hero_background', label: 'پس‌زمینه هیرو (دسکتاپ)', where: 'صفحه اصلی سایت' },
  { slot: 'hero_background_mobile', label: 'پس‌زمینه هیرو (موبایل)', where: 'صفحه اصلی سایت' },
  { slot: 'ai_tutor', label: 'تصویر AI Tutor', where: 'سایت + داشبورد' },
  { slot: 'conversation', label: 'تصویر Conversation Partner', where: 'سایت + داشبورد + انتخاب سناریو' },
  { slot: 'premium', label: 'تصویر بخش Premium', where: 'سایت + اشتراک + داشبورد' },
  { slot: 'onboarding', label: 'تصویر خوش‌آمدگویی', where: 'Onboarding' },
  { slot: 'lang_en', label: 'تصویر زبان انگلیسی', where: 'سایت + داشبورد' },
  { slot: 'lang_fr', label: 'تصویر زبان فرانسه', where: 'سایت + داشبورد' },
  { slot: 'lang_es', label: 'تصویر زبان اسپانیایی', where: 'سایت + داشبورد' },
  { slot: 'scenario_cafe', label: 'تصویر سناریوی کافه/رستوران/خرید', where: 'Conversation Partner' },
  { slot: 'scenario_travel', label: 'تصویر سناریوی سفر/فرودگاه/آشنایی', where: 'Conversation Partner' },
  { slot: 'scenario_work', label: 'تصویر سناریوی مصاحبه کاری', where: 'Conversation Partner' },
  { slot: 'scenario_school', label: 'تصویر سناریوی مدرسه', where: 'Conversation Partner' },
  { slot: 'scenario_social', label: 'تصویر سناریوهای روزمره', where: 'Conversation Partner' },
] as const

export const MEDIA_CATEGORIES = ['hero', 'ai', 'premium', 'languages', 'onboarding', 'scenarios', 'empty', 'general'] as const

export const GOALS = [
  { id: 'travel', label_fa: 'سفر', desc_fa: 'برای سفر و مکالمه‌های روزمره در سفر', emoji: '🧭' },
  { id: 'work', label_fa: 'کار و حرفه', desc_fa: 'برای محیط کار، جلسه و مصاحبه', emoji: '💼' },
  { id: 'study', label_fa: 'تحصیل', desc_fa: 'برای دانشگاه، آزمون و مطالعه منابع', emoji: '🎓' },
  { id: 'personal', label_fa: 'علاقه شخصی', desc_fa: 'برای لذت یادگیری و رشد شخصی', emoji: '🌱' },
] as const

export type GoalId = (typeof GOALS)[number]['id']

export const GOAL_FA: Record<string, string> = Object.fromEntries(GOALS.map((g) => [g.id, g.label_fa]))

/** Conversation Partner scenarios — real roles with their own level and pacing. */
export const PARTNER_SCENARIOS = [
  { id: 'cafe',       title_fa: 'کافه',            title_en: 'Cafe',               emoji: '☕', gradient: 'from-amber-400 to-orange-500',   role_en: 'a friendly barista',                       role_fa: 'باریستای خوش‌برخورد', level: 'A1', opener_en: "Hi! Welcome in. What can I get for you today?", what_fa: 'سفارش دادن، پرسیدن جزئیات سفارش و پرداخت.' },
  { id: 'travel',     title_fa: 'سفر',             title_en: 'Travel',             emoji: '🧭', gradient: 'from-sky-400 to-indigo-500',    role_en: 'a travel agent',                           role_fa: 'کارمند آژانس سفر', level: 'A2', opener_en: "Hello! So, where are we going this time?", what_fa: 'برنامه سفر، هتل و انتخاب مقصد.' },
  { id: 'airport',    title_fa: 'فرودگاه',         title_en: 'Airport',            emoji: '✈️', gradient: 'from-slate-400 to-blue-600',    role_en: 'an airline check-in agent',                role_fa: 'کارمند پذیرش پرواز', level: 'A2', opener_en: "Good morning — passport and ticket, please. Where are you flying today?", what_fa: 'پذیرش، بار و اطلاعات پرواز.' },
  { id: 'restaurant', title_fa: 'رستوران',         title_en: 'Restaurant',         emoji: '🍽️', gradient: 'from-rose-400 to-red-500',      role_en: 'a waiter',                                 role_fa: 'گارسون رستوران', level: 'A1', opener_en: "Good evening! Table for one, or are you expecting someone?", what_fa: 'رزرو میز، سفارش غذا و صورتحساب.' },
  { id: 'shopping',   title_fa: 'خرید',            title_en: 'Shopping',           emoji: '🛍️', gradient: 'from-fuchsia-400 to-purple-500', role_en: 'a shop assistant',                         role_fa: 'فروشنده مغازه', level: 'A1', opener_en: "Good afternoon! Are you looking for anything in particular?", what_fa: 'قیمت، سایز، رنگ و خرید.' },
  { id: 'job',        title_fa: 'مصاحبه کاری',     title_en: 'Job Interview',      emoji: '💼', gradient: 'from-indigo-500 to-violet-600', role_en: 'a hiring manager',                        role_fa: 'مدیر استخدام', level: 'B1', opener_en: "Thanks for coming in today. Tell me a little about yourself.", what_fa: 'معرفی خود، مهارت‌ها و پاسخ به سؤال‌های حرفه‌ای.' },
  { id: 'school',     title_fa: 'مدرسه',           title_en: 'School',             emoji: '🎓', gradient: 'from-teal-400 to-emerald-500',  role_en: 'a classmate after the first lecture',      role_fa: 'هم‌کلاسی بعد از کلاس اول', level: 'A2', opener_en: "Hey! You're in Professor Lin's class too, right?", what_fa: 'دوستی با هم‌کلاسی، درس و برنامه مطالعه.' },
  { id: 'meeting',    title_fa: 'آشنایی با یک نفر', title_en: 'Meeting Someone',   emoji: '🤝', gradient: 'from-cyan-400 to-sky-500',      role_en: 'someone at a friend\u2019s party',           role_fa: 'یک مهمان در مهمانی دوستت', level: 'A2', opener_en: "Hey, I don't think we've met. I'm Alex — how do you know Sara?", what_fa: 'معرفی خود، سؤال‌های ساده و شروع گفت‌وگو.' },
  { id: 'daily',      title_fa: 'زندگی روزمره',    title_en: 'Daily Life',         emoji: '💬', gradient: 'from-violet-400 to-purple-600', role_en: 'a friendly neighbor',                      role_fa: 'همسایه خوش‌برخورد', level: 'A1', opener_en: "Morning! Lovely day, isn't it? How's your week going?", what_fa: 'احوال‌پرسی، برنامه روز، آب‌وهوا و کارهای روزانه.' },
] as const

export type ScenarioId = (typeof PARTNER_SCENARIOS)[number]['id']

/** Section order of every LINGU lesson (identical for all lessons). */
export const LESSON_SECTIONS = [
  { key: 'warmup',      title_fa: 'گرم‌کردن',           icon: 'Flame' },
  { key: 'explanation', title_fa: 'توضیح درس',          icon: 'BookOpen' },
  { key: 'vocabulary',  title_fa: 'واژگان',             icon: 'Languages' },
  { key: 'grammar',     title_fa: 'گرامر',              icon: 'Blocks' },
  { key: 'examples',    title_fa: 'مثال‌ها',            icon: 'Quote' },
  { key: 'listening',   title_fa: 'شنیداری',            icon: 'Headphones' },
  { key: 'dialogue',    title_fa: 'دیالوگ',             icon: 'MessagesSquare' },
  { key: 'speaking',    title_fa: 'تمرین گفت‌وگو',      icon: 'Mic' },
  { key: 'reading',     title_fa: 'خواندن',             icon: 'Newspaper' },
  { key: 'exercises',   title_fa: 'تمرین‌ها',           icon: 'PencilLine' },
  { key: 'quiz',        title_fa: 'آزمون',              icon: 'ListChecks' },
  { key: 'ai_practice', title_fa: 'تمرین با AI',        icon: 'Sparkles' },
] as const

/** Primary navigation of the learning app. */
export const APP_NAV = [
  { to: '/app', label: 'خانه', icon: 'LayoutDashboard', end: true, tour: 'home' },
  { to: '/app/lessons', label: 'درس‌ها', icon: 'BookOpen', tour: 'lessons' },
  { to: '/app/tutor', label: 'مربی AI', icon: 'GraduationCap', tour: 'tutor' },
  { to: '/app/conversation', label: 'مکالمه', icon: 'MessageSquareHeart', tour: 'partner' },
  { to: '/app/progress', label: 'پیشرفت', icon: 'Route', tour: 'progress' },
] as const

export const APP_NAV_SECONDARY = [
  { to: '/app/subscription', label: 'اشتراک', icon: 'Crown', tour: 'sub' },
  { to: '/app/profile', label: 'پروفایل', icon: 'UserRound', tour: undefined },
  { to: '/app/settings', label: 'تنظیمات', icon: 'Settings2', tour: undefined },
  { to: '/app/help', label: 'راهنما', icon: 'LifeBuoy', tour: undefined },
] as const

/** Searchable app features (real destinations, no dead ends). */
export const APP_FEATURES = [
  { label: 'خانه / داشبورد', to: '/app', keywords: 'dashboard home خانه داشبورد' },
  { label: 'کتابخانه درس‌ها', to: '/app/lessons', keywords: 'lessons courses درس‌ها کتابخانه' },
  { label: 'AI Tutor', to: '/app/tutor', keywords: 'ai tutor مربی هوشمند پرسش' },
  { label: 'Conversation Partner', to: '/app/conversation', keywords: 'conversation partner مکالمه گفت‌وگو' },
  { label: 'پیشرفت من', to: '/app/progress', keywords: 'progress پیشرفت آمار' },
  { label: 'اشتراک و پلن‌ها', to: '/app/subscription', keywords: 'subscription premium اشتراک پلن خرید' },
  { label: 'پروفایل و تنظیمات', to: '/app/settings', keywords: 'profile settings پروفایل تنظیمات' },
  { label: 'راهنما و پشتیبانی', to: '/app/help', keywords: 'help support راهنما پشتیبانی' },
] as const

export const TOUR_STEPS = [
  { id: 'home',     title: 'داشبورد',            body: 'اینجا هر روز می‌بینی کجا هستی و قدم بعدی چیست: ادامه یادگیری، زبان‌ها و وضعیت دسترسی.', route: '/app' },
  { id: 'lessons',  title: 'درس‌ها',             body: 'سه زبان و ۱۲ بخش در هر درس: از گرم‌کردن تا آزمون و تمرین با AI. با فیلتر زبان و سطح، سریع پیدا می‌کنی.', route: '/app/lessons' },
  { id: 'tutor',    title: 'AI Tutor',           body: 'هر بخشی که مبهم بود، همین‌جا بپرس: توضیح ساده‌تر، مثال تازه و تمرین اضافه — بر اساس همان درس.', route: '/app/tutor' },
  { id: 'partner',  title: 'Conversation Partner', body: 'نقش واقعی انتخاب کن — کافه، فرودگاه، مصاحبه کاری — و مکالمه را ادامه بده. هم‌صحبت در نقش می‌ماند.', route: '/app/conversation' },
  { id: 'progress', title: 'پیشرفت',             body: 'درصد تکمیل، درس‌های تمام‌شده، امتیاز آزمون‌ها و فعالیت روزانه‌ات؛ همه از داده واقعی.', route: '/app/progress' },
  { id: 'sub',      title: 'اشتراک',             body: 'رایگان برای همیشه رایگان است. برای همه درس‌ها و AI نامحدود، از همین صفحه پلن مناسب را ببین.', route: '/app/subscription' },
] as const
