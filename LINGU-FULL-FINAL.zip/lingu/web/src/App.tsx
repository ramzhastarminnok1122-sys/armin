import { lazy, Suspense, useEffect } from 'react'
import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { motion } from 'motion/react'
import { Loader2, ShieldAlert } from 'lucide-react'
import { AppProvider, useApp } from '@/context/AppContext'
import { ThemeProvider } from '@/context/ThemeContext'
import { Button, Card, Toaster } from '@/components/ui'
import { Logo } from '@/components/layout/Brand'
import PublicLayout from '@/components/layout/PublicLayout'
import AppShell from '@/components/layout/AppShell'
import AdminLayout from '@/components/layout/AdminLayout'

/* ------------------------------- public site ------------------------------- */
import Home from '@/pages/public/Home'
import Features from '@/pages/public/Features'
import LanguagesPage from '@/pages/public/Languages'
import HowItWorks from '@/pages/public/HowItWorks'
import FaqPage from '@/pages/public/FAQ'
import Contact from '@/pages/public/Contact'
import Login from '@/pages/auth/Login'
import Signup from '@/pages/auth/Signup'
import ForgotPassword from '@/pages/auth/ForgotPassword'
import ResetPassword from '@/pages/auth/ResetPassword'
import NotFound from '@/pages/misc/NotFound'

/* --------------------------------- user app -------------------------------- */
const Dashboard = lazy(() => import('@/pages/app/Dashboard'))
const Lessons = lazy(() => import('@/pages/app/Lessons'))
const LessonDetail = lazy(() => import('@/pages/app/LessonDetail'))
const Tutor = lazy(() => import('@/pages/app/Tutor'))
const Conversation = lazy(() => import('@/pages/app/Conversation'))
const ProgressPage = lazy(() => import('@/pages/app/ProgressPage'))
const SubscriptionPage = lazy(() => import('@/pages/app/Subscription'))
const ProfilePage = lazy(() => import('@/pages/app/Profile'))
const SettingsPage = lazy(() => import('@/pages/app/Settings'))
const HelpPage = lazy(() => import('@/pages/app/Help'))
const Onboarding = lazy(() => import('@/pages/app/Onboarding'))

/* ---------------------------------- admin --------------------------------- */
const AdminDashboard = lazy(() => import('@/pages/admin/Dashboard'))
const AdminUsers = lazy(() => import('@/pages/admin/Users'))
const AdminLessons = lazy(() => import('@/pages/admin/Lessons'))
const AdminContentFactory = lazy(() => import('@/pages/admin/ContentFactory'))
const AdminSubscriptions = lazy(() => import('@/pages/admin/Subscriptions'))
const AdminPlans = lazy(() => import('@/pages/admin/Plans'))
const AdminAi = lazy(() => import('@/pages/admin/AISettings'))
const AdminMedia = lazy(() => import('@/pages/admin/MediaLibrary'))
const AdminAppSettings = lazy(() => import('@/pages/admin/AppSettings'))
const AdminTheme = lazy(() => import('@/pages/admin/ThemeSettings'))
const AdminBanners = lazy(() => import('@/pages/admin/Banners'))
const AdminFaq = lazy(() => import('@/pages/admin/FaqAdmin'))
const AdminTestimonials = lazy(() => import('@/pages/admin/TestimonialsAdmin'))

function Splash({ label = 'در حال آماده‌سازی LINGU…' }: { label?: string }) {
  return (
    <div className="grid min-h-dvh place-items-center">
      <div className="flex flex-col items-center gap-4">
        <Logo size={56} />
        <div className="flex items-center gap-2 text-sm font-bold text-ink-muted"><Loader2 className="size-4 animate-spin" /> {label}</div>
      </div>
    </div>
  )
}

function RouteFallback() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
      <div className="skeleton h-9 w-56" />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => <div key={i} className="card-surface h-40 p-5"><div className="skeleton h-5 w-1/2" /></div>)}
      </div>
    </motion.div>
  )
}

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { ready, session } = useApp()
  const loc = useLocation()
  if (!ready) return <Splash />
  if (!session) return <Navigate to="/login" replace state={{ from: loc.pathname }} />
  return <>{children}</>
}

/** A logged-in user never sees the marketing home page again — the app opens instead. */
function HomeGate({ children }: { children: React.ReactNode }) {
  const { session, ready, profile, api } = useApp()
  const loc = useLocation()
  // the design preview keeps the marketing page reachable for review
  const previewPublic = api?.mode === 'demo' && loc.search.includes('preview=public')
  if (!ready) return <Splash />
  if (session && !previewPublic) return <Navigate to={profile && !profile.onboarding_done ? '/onboarding' : '/app'} replace />
  return <>{children}</>
}

/** Onboarding runs once, right after signup, inside its own full-screen flow. */
function OnboardingGate() {
  const { ready, session, profile, api } = useApp()
  const loc = useLocation()
  const previewOnboarding = api?.mode === 'demo' && loc.search.includes('preview=1')
  if (!ready) return <Splash label="آماده‌سازی مسیر یادگیری…" />
  if (!session) return <Navigate to="/login" replace />
  if (profile?.onboarding_done && !previewOnboarding) return <Navigate to="/app" replace />
  return <Onboarding />
}

function RequireAdmin({ children }: { children: React.ReactNode }) {
  const { ready, session, isAdmin, profile, api } = useApp()
  if (!ready) return <Splash label="بررسی دسترسی…" />
  if (!session) return <Navigate to="/login" replace state={{ from: '/admin' }} />
  // design preview only: lets a reviewer open the admin panel without a real admin account.
  // A production build never runs in demo mode, so this can never grant real access.
  if (!isAdmin && api?.mode === 'demo') return <>{children}</>
  if (!isAdmin && profile) {
    return (
      <div className="container-x grid min-h-dvh place-items-center py-10">
        <Card className="max-w-md text-center !rounded-4xl !p-9">
          <span className="mx-auto grid size-14 place-items-center rounded-3xl bg-danger/15 text-danger"><ShieldAlert className="size-7" /></span>
          <h1 className="mt-5 text-xl font-extrabold">دسترسی به پنل مدیریت ندارید</h1>
          <p className="mt-3 text-sm leading-7 text-ink-muted">این بخش فقط برای مدیران LINGU است.</p>
          <a href="/app" className="mt-6 block"><Button className="w-full">بازگشت به برنامه</Button></a>
        </Card>
      </div>
    )
  }
  if (!profile) return <Splash label="بارگذاری پروفایل…" />
  return <>{children}</>
}

/** Sends a user who never finished onboarding straight into it, whatever app page they opened. */
function OnboardingRedirect() {
  const { profile, ready, session, api } = useApp()
  const loc = useLocation()
  useEffect(() => { window.scrollTo({ top: 0 }) }, [loc.pathname])
  const previewOnboarding = api?.mode === 'demo' && loc.search.includes('preview.onboarding')
  if (!ready) return <Splash />
  if (!previewOnboarding && session && profile && !profile.onboarding_done) return <Navigate to="/onboarding" replace />
  return null
}

function Body() {
  const { toasts, dismissToast } = useApp()
  return (
    <>
      <Suspense fallback={<div className="container-x py-10"><RouteFallback /></div>}>
        <Routes>
          {/* ------------------------------ public ------------------------------ */}
          <Route element={<PublicLayout />}>
            <Route path="/" element={<HomeGate><Home /></HomeGate>} />
            <Route path="/features" element={<Features />} />
            <Route path="/languages" element={<LanguagesPage />} />
            <Route path="/how-it-works" element={<HowItWorks />} />
            <Route path="/faq" element={<FaqPage />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="*" element={<NotFound />} />
          </Route>

          {/* ---------------------------- onboarding ---------------------------- */}
          <Route path="/onboarding" element={<OnboardingGate />} />

          {/* --------------------- the learning application ---------------------- */}
          <Route path="/app" element={<RequireAuth><AppShell /></RequireAuth>}>
            <Route index element={<><OnboardingRedirect /><Dashboard /></>} />
            <Route path="lessons" element={<><OnboardingRedirect /><Lessons /></>} />
            <Route path="lessons/:lessonId" element={<><OnboardingRedirect /><LessonDetail /></>} />
            <Route path="tutor" element={<><OnboardingRedirect /><Tutor /></>} />
            <Route path="tutor/:conversationId" element={<><OnboardingRedirect /><Tutor /></>} />
            <Route path="conversation" element={<><OnboardingRedirect /><Conversation /></>} />
            <Route path="conversation/new/:scenarioId" element={<><OnboardingRedirect /><Conversation /></>} />
            <Route path="conversation/:conversationId" element={<><OnboardingRedirect /><Conversation /></>} />
            <Route path="progress" element={<><OnboardingRedirect /><ProgressPage /></>} />
            <Route path="subscription" element={<><OnboardingRedirect /><SubscriptionPage /></>} />
            <Route path="profile" element={<><OnboardingRedirect /><ProfilePage /></>} />
            <Route path="settings" element={<><OnboardingRedirect /><SettingsPage /></>} />
            <Route path="help" element={<><OnboardingRedirect /><HelpPage /></>} />
          </Route>

          {/* ------------------------------- admin ------------------------------ */}
          <Route path="/admin" element={<RequireAdmin><AdminLayout /></RequireAdmin>}>
            <Route index element={<AdminDashboard />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="lessons" element={<AdminLessons />} />
            <Route path="content-factory" element={<AdminContentFactory />} />
            <Route path="subscriptions" element={<AdminSubscriptions />} />
            <Route path="plans" element={<AdminPlans />} />
            <Route path="ai" element={<AdminAi />} />
            <Route path="media" element={<AdminMedia />} />
            <Route path="settings" element={<AdminAppSettings />} />
            <Route path="theme" element={<AdminTheme />} />
            <Route path="banners" element={<AdminBanners />} />
            <Route path="faq" element={<AdminFaq />} />
            <Route path="testimonials" element={<AdminTestimonials />} />
          </Route>
        </Routes>
      </Suspense>
      <Toaster toasts={toasts} onDismiss={dismissToast} />
    </>
  )
}

export default function App() {
  return (
    <ThemeProvider>
      <AppProvider>
        <Body />
      </AppProvider>
    </ThemeProvider>
  )
}
