import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { KeyRound, Save } from 'lucide-react'
import { Button, Card, Field, Input } from '@/components/ui'
import { useApp } from '@/context/AppContext'
import { supabase } from '@/lib/supabase'

export default function ResetPassword() {
  const { updatePassword, toast, session } = useApp()
  const nav = useNavigate()
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  // Supabase puts the recovery token in the URL hash; the client picks it up automatically.
  useEffect(() => { supabase.auth.getSession() }, [])

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setErr(null)
    try {
      await updatePassword(password)
      toast('گذرواژه به‌روز شد.', 'success')
      nav('/app')
    } catch (e2) { setErr(e2 instanceof Error ? e2.message : 'خطا') } finally { setBusy(false) }
  }

  return (
    <div className="container-x flex min-h-[75dvh] items-center justify-center py-12">
      <Card className="w-full max-w-md !rounded-4xl !p-8">
        <h1 className="text-2xl font-extrabold">گذرواژه جدید</h1>
        <p className="mt-2 text-sm leading-7 text-ink-muted">یک گذرواژه تازه انتخاب کن (حداقل ۶ کاراکتر).</p>
        {!session && <p className="mt-4 rounded-2xl border border-warn/30 bg-warn/10 px-4 py-3 text-[11px] font-bold text-warn">لینک بازیابی معتبر نیست یا منقضی شده است. دوباره درخواست بده.</p>}
        <form onSubmit={submit} className="mt-6 space-y-4">
          <Field label="گذرواژه جدید" required>
            <div className="relative">
              <KeyRound className="pointer-events-none absolute right-4 top-1/2 size-4 -translate-y-1/2 text-ink-faint" />
              <Input type="password" dir="ltr" minLength={6} required className="pr-11" value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
          </Field>
          {err && <p className="rounded-2xl border border-danger/40 bg-danger/10 px-4 py-3 text-xs font-bold text-danger">{err}</p>}
          <Button type="submit" loading={busy} className="w-full" disabled={!session}><Save className="size-4" /> ذخیره گذرواژه</Button>
        </form>
      </Card>
    </div>
  )
}
