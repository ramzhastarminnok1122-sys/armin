import { useState } from 'react'
import { Link } from 'react-router-dom'
import { CheckCircle2, Mail, Send } from 'lucide-react'
import { Button, Card, Field, Input } from '@/components/ui'
import { useApp } from '@/context/AppContext'

export default function ForgotPassword() {
  const { resetPassword } = useApp()
  const [email, setEmail] = useState('')
  const [busy, setBusy] = useState(false)
  const [sent, setSent] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setErr(null)
    try { await resetPassword(email.trim()); setSent(true) }
    catch (e2) { setErr(e2 instanceof Error ? e2.message : 'خطا') }
    finally { setBusy(false) }
  }

  return (
    <div className="container-x flex min-h-[75dvh] items-center justify-center py-12">
      <Card className="w-full max-w-md !rounded-4xl !p-8">
        <h1 className="text-2xl font-extrabold">بازیابی گذرواژه</h1>
        <p className="mt-2 text-sm leading-7 text-ink-muted">ایمیل حسابت را وارد کن؛ لینک تعیین گذرواژه جدید برایت ارسال می‌شود.</p>
        {sent ? (
          <div className="mt-6 rounded-2xl border border-success/40 bg-success/10 p-5 text-center">
            <CheckCircle2 className="mx-auto size-6 text-success" />
            <p className="mt-3 text-sm font-bold">لینک بازیابی ارسال شد</p>
            <p className="mt-1 text-xs text-ink-muted">صندوق ایمیل (و پوشه اسپم) را بررسی کن.</p>
            <Link to="/login" className="mt-4 inline-block text-xs font-bold text-primary-soft hover:underline">بازگشت به ورود</Link>
          </div>
        ) : (
          <form onSubmit={submit} className="mt-6 space-y-4">
            <Field label="ایمیل" required>
              <div className="relative">
                <Mail className="pointer-events-none absolute right-4 top-1/2 size-4 -translate-y-1/2 text-ink-faint" />
                <Input type="email" dir="ltr" required className="pr-11" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
            </Field>
            {err && <p className="rounded-2xl border border-danger/40 bg-danger/10 px-4 py-3 text-xs font-bold text-danger">{err}</p>}
            <Button type="submit" loading={busy} className="w-full"><Send className="size-4" /> ارسال لینک</Button>
            <Link to="/login" className="block text-center text-xs font-bold text-ink-muted hover:text-ink">بازگشت به ورود</Link>
          </form>
        )}
      </Card>
    </div>
  )
}
