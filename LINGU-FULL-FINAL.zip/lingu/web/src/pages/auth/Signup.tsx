import { motion } from 'motion/react'
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ArrowLeft, CheckCircle2, KeyRound, Mail, Sparkles, UserPlus, UserRound } from 'lucide-react'
import { Logo } from '@/components/layout/Brand'
import { Button, Card, Chip, Field, Input, Select } from '@/components/ui'
import { useApp } from '@/context/AppContext'
import { LEVELS, LEVEL_FA } from '@/lib/constants'

export default function Signup() {
  const { signUp, toast, api, languages, startPreview } = useApp()
  const nav = useNavigate()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [language, setLanguage] = useState('en')
  const [level, setLevel] = useState('A1')
  const [busy, setBusy] = useState(false)
  const [done, setDone] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setErr(null); setBusy(true)
    try {
      if (password.length < 6) throw new Error('گذرواژه باید حداقل ۶ کاراکتر باشد.')
      const { needsConfirm } = await signUp(email.trim(), password, name.trim() || email.split('@')[0])
      localStorage.setItem('lingu_goal', JSON.stringify({ language, level }))
      if (needsConfirm) { setDone(true); toast('حساب ساخته شد. ایمیلت را بررسی کن.', 'success') }
      else { toast('حساب ساخته شد. خوش آمدی!', 'success'); nav('/app') }
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : 'خطا در ثبت‌نام')
    } finally { setBusy(false) }
  }

  if (done) {
    return (
      <div className="container-x flex min-h-[70dvh] items-center justify-center py-12">
        <Card className="max-w-md text-center !rounded-4xl !p-9">
          <span className="mx-auto grid size-14 place-items-center rounded-3xl bg-success/15 text-success"><CheckCircle2 className="size-7" /></span>
          <h1 className="mt-5 text-2xl font-extrabold">یک قدم مانده</h1>
          <p className="mt-3 text-sm leading-7 text-ink-muted">
            ایمیل <b className="ltr text-ink">{email}</b> را باز کن و روی لینک تأیید بزن، بعد وارد شو و یادگیری را شروع کن.
          </p>
          <Link to="/login" className="mt-6 block"><Button className="w-full">رفتن به صفحه ورود</Button></Link>
        </Card>
      </div>
    )
  }

  return (
    <div className="container-x grid min-h-[calc(100dvh-4rem)] items-center gap-10 py-12 lg:grid-cols-2">
      <div>
        <motion.div initial={{ opacity: 0, x: 18 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.55 }}>
          <Chip tone="primary"><Sparkles className="size-3" /> ثبت‌نام رایگان</Chip>
          <h2 className="mt-5 text-3xl font-extrabold leading-relaxed sm:text-4xl">۶ درس کامل رایگان، بدون محدودیت زمانی</h2>
          <p className="mt-5 max-w-md text-sm leading-8 text-ink-muted">
            حساب رایگان برای همیشه رایگان می‌ماند: ۲ درس کامل در English، ۲ درس در French و ۲ درس در Spanish — به‌علاوه ۲ پیام Conversation Partner.
          </p>
          <div className="mt-7 grid gap-3 sm:grid-cols-2">
            {languages.map((l) => (
              <div key={l.code} className="flex items-center gap-3 rounded-2xl border border-line/70 bg-card/50 px-4 py-3">
                <span className="text-2xl">{l.flag}</span>
                <div>
                  <p className="text-xs font-extrabold">{l.name_fa}</p>
                  <p className="text-[10px] text-ink-faint">۲ درس کامل رایگان</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <Card className="!rounded-4xl !p-7 sm:!p-9">
          <div className="mb-7 flex flex-col items-center gap-3 text-center">
            <Logo size={48} />
            <h1 className="text-2xl font-extrabold">ساخت حساب LINGU</h1>
            <p className="text-xs text-ink-muted">کمتر از یک دقیقه — بدون کارت بانکی.</p>
          </div>

          <form onSubmit={submit} className="space-y-4">
            <Field label="نام نمایشی">
              <div className="relative">
                <UserRound className="pointer-events-none absolute right-4 top-1/2 size-4 -translate-y-1/2 text-ink-faint" />
                <Input className="pr-11" placeholder="مثلاً: سارا" value={name} onChange={(e) => setName(e.target.value)} />
              </div>
            </Field>
            <Field label="ایمیل" required>
              <div className="relative">
                <Mail className="pointer-events-none absolute right-4 top-1/2 size-4 -translate-y-1/2 text-ink-faint" />
                <Input type="email" dir="ltr" required className="pr-11" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
            </Field>
            <Field label="گذرواژه" required hint="حداقل ۶ کاراکتر">
              <div className="relative">
                <KeyRound className="pointer-events-none absolute right-4 top-1/2 size-4 -translate-y-1/2 text-ink-faint" />
                <Input type="password" dir="ltr" required minLength={6} className="pr-11" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="زبان هدف">
                <Select value={language} onChange={(e) => setLanguage(e.target.value)}>
                  {languages.map((l) => <option key={l.code} value={l.code}>{l.flag} {l.name_fa}</option>)}
                </Select>
              </Field>
              <Field label="سطح تقریبی">
                <Select value={level} onChange={(e) => setLevel(e.target.value)}>
                  {LEVELS.map((lv) => <option key={lv} value={lv}>{lv} — {LEVEL_FA[lv]}</option>)}
                </Select>
              </Field>
            </div>

            {err && <p className="rounded-2xl border border-danger/40 bg-danger/10 px-4 py-3 text-xs font-bold text-danger">{err}</p>}

            <Button type="submit" size="lg" loading={busy} className="w-full"><UserPlus className="size-4" /> ساخت حساب و شروع رایگان</Button>
            <p className="text-center text-[11px] leading-6 text-ink-faint">
              با ساخت حساب، شرایط استفاده و سیاست حریم خصوصی LINGU را می‌پذیری.
            </p>
          </form>

          <div className="mt-6 text-center text-xs">
            <span className="text-ink-muted">حساب داری؟ </span>
            <Link to="/login" className="font-bold text-primary-soft hover:underline">ورود <ArrowLeft className="inline size-3" /></Link>
          </div>

          {api?.mode === 'demo' && (
            <div className="mt-5 rounded-2xl border border-primary/25 bg-primary/8 px-4 py-3.5 text-[11px] leading-6 text-ink-muted">
              <p className="font-extrabold text-ink">پیش‌نمایش طراحی LINGU</p>
              <p className="mt-1">این نسخه برای بازبینی رابط کاربری است. مسیر واقعی ثبت‌نام → آشنایی → داشبورد را می‌توانی همین‌جا ببینی.</p>
              <Button variant="outline" size="sm" className="mt-3 w-full" onClick={() => { startPreview(); nav('/app', { replace: true }) }}>
                دیدن مسیر ثبت‌نام و شروع
              </Button>
            </div>
          )}
        </Card>
      </motion.div>
    </div>
  )
}
