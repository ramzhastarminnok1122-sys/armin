import { motion } from 'motion/react'
import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { ArrowLeft, KeyRound, LogIn, Mail, ShieldCheck } from 'lucide-react'
import { Logo } from '@/components/layout/Brand'
import { Button, Card, Field, Input } from '@/components/ui'
import { useApp } from '@/context/AppContext'

export default function Login() {
  const { signIn, toast, api, startPreview } = useApp()
  const nav = useNavigate()
  const loc = useLocation() as { state?: { from?: string } }
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setErr(null); setBusy(true)
    try {
      await signIn(email.trim(), password)
      toast('خوش آمدی! ادامه بده.', 'success')
      nav(loc.state?.from || '/app', { replace: true })
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : 'خطا در ورود')
    } finally { setBusy(false) }
  }

  return (
    <div className="container-x grid min-h-[calc(100dvh-4rem)] items-center gap-10 py-12 lg:grid-cols-2">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="order-2 lg:order-1">
        <Card className="!rounded-4xl !p-7 sm:!p-9">
          <div className="mb-7 flex flex-col items-center gap-3 text-center">
            <Logo size={48} />
            <h1 className="text-2xl font-extrabold">ورود به LINGU</h1>
            <p className="text-xs text-ink-muted">خوش برگشتی! مسیر یادگیری‌ات منتظرت است.</p>
          </div>

          <form onSubmit={submit} className="space-y-4">
            <Field label="ایمیل" required>
              <div className="relative">
                <Mail className="pointer-events-none absolute right-4 top-1/2 size-4 -translate-y-1/2 text-ink-faint" />
                <Input type="email" dir="ltr" required autoComplete="email" placeholder="you@example.com"
                  className="pr-11" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
            </Field>
            <Field label="گذرواژه" required>
              <div className="relative">
                <KeyRound className="pointer-events-none absolute right-4 top-1/2 size-4 -translate-y-1/2 text-ink-faint" />
                <Input type="password" dir="ltr" required autoComplete="current-password" placeholder="••••••••"
                  className="pr-11" value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
            </Field>

            {err && <p className="rounded-2xl border border-danger/40 bg-danger/10 px-4 py-3 text-xs font-bold text-danger">{err}</p>}

            <Button type="submit" size="lg" loading={busy} className="w-full"><LogIn className="size-4" /> ورود</Button>
          </form>

          <div className="mt-6 flex items-center justify-between text-xs">
            <Link to="/forgot-password" className="font-bold text-primary-soft hover:underline">گذرواژه را فراموش کرده‌ام</Link>
            <Link to="/signup" className="font-bold text-ink-muted hover:text-ink">حساب ندارم <ArrowLeft className="inline size-3" /></Link>
          </div>

          {api?.mode === 'demo' && (
            <div className="mt-5 rounded-2xl border border-primary/25 bg-primary/8 px-4 py-3.5 text-[11px] leading-6 text-ink-muted">
              <p className="font-extrabold text-ink">پیش‌نمایش طراحی LINGU</p>
              <p className="mt-1">این نسخه برای بازبینی رابط کاربری است و به حساب واقعی وصل نیست. می‌توانی برنامه را از دید یک کاربر تازه ببینی.</p>
              <Button variant="outline" size="sm" className="mt-3 w-full" onClick={() => { startPreview(); nav('/app', { replace: true }) }}>
                دیدن برنامه با یک حساب تازه
              </Button>
            </div>
          )}
        </Card>
      </motion.div>

      <div className="order-1 lg:order-2">
        <motion.div initial={{ opacity: 0, x: -18 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.55, delay: 0.1 }}>
          <h2 className="text-3xl font-extrabold leading-relaxed sm:text-4xl">یادگیری‌ات را ادامه بده، از همان‌جایی که مانده بودی</h2>
          <p className="mt-5 max-w-md text-sm leading-8 text-ink-muted">
            پیشرفت هر درس ذخیره می‌شود؛ بخش‌های تمام‌شده را می‌بینی و دقیقاً می‌دانی امروز باید چه کاری انجام بدهی.
          </p>
          <ul className="mt-7 space-y-3 text-sm text-ink-muted">
            {['پیشرفت ذخیره‌شده در همه دستگاه‌ها', 'AI Tutor در دسترس برای هر درس', 'Conversation Partner با سناریوهای واقعی'].map((t) => (
              <li key={t} className="flex items-center gap-2"><ShieldCheck className="size-4 text-success" /> {t}</li>
            ))}
          </ul>
        </motion.div>
      </div>
    </div>
  )
}
