import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  BadgeCheck, Bell, BookOpen, Crown, Globe2, KeyRound, LifeBuoy, LogOut, Pause, Play,
  Share2, Sparkles, Target, Trash2, UserRound, Volume2,
} from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { Button, Card, Chip, Field, Input, SectionTitle, Select, Switch, Confirmed, ErrorState, Skeleton } from '@/components/ui'
import { faNum, faRelative, faError } from '@/lib/utils'
import { GOALS, GOAL_FA, LEVELS } from '@/lib/constants'
import { useLocalStorage } from '@/lib/hooks'

export default function Settings() {
  const { api, profile, membership, languages, refreshProfile, toast, signOut, setTour, updatePassword } = useApp()
  const [name, setName] = useState(profile?.display_name ?? '')
  const [savingProfile, setSavingProfile] = useState(false)
  const [pw1, setPw1] = useState(''); const [pw2, setPw2] = useState(''); const [savingPw, setSavingPw] = useState(false)
  const [notify, setNotify] = useLocalStorage('lingu_notify', true)
  const [sound, setSound] = useLocalStorage('lingu_sound', false)
  const [reduce, setReduce] = useLocalStorage('lingu_reduce_motion', false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => { setName(profile?.display_name ?? '') }, [profile?.display_name])

  // the accessibility switch is also stored on the profile so it follows the user across devices
  useEffect(() => {
    if (!api) return
    api.updateProfile({ reduce_motion: reduce } as any).catch(() => {})
  }, [reduce, api])

  const saveProfile = async () => {
    if (!api) return
    setSavingProfile(true); setError(null)
    try {
      await api.updateProfile({ display_name: name.trim() })
      await refreshProfile()
      toast('پروفایل ذخیره شد.', 'success')
    } catch (e: any) { setError(faError(e, 'ذخیره نشد')); toast('ذخیره پروفایل انجام نشد.', 'error') }
    finally { setSavingProfile(false) }
  }

  const saveLanguage = async (code: string) => {
    if (!api) return
    try {
      await api.updateProfile({ target_language: code } as any)
      await refreshProfile()
      toast('زبان فعلی تغییر کرد.', 'success')
    } catch { toast('تغییر زبان انجام نشد.', 'error') }
  }

  const saveGoal = async (goal: string) => {
    if (!api) return
    try { await api.updateProfile({ goal } as any); await refreshProfile(); toast('هدف یادگیری ذخیره شد.', 'success') }
    catch { toast('ذخیره هدف انجام نشد.', 'error') }
  }

  const saveLevel = async (level: string) => {
    if (!api) return
    try { await api.updateProfile({ preferred_level: level } as any); await refreshProfile() }
    catch { /* ignore */ }
  }

  const changePassword = async () => {
    if (!api) return
    if (pw1.length < 6) { setError('رمز عبور باید حداقل ۶ کاراکتر باشد.'); return }
    if (pw1 !== pw2) { setError('دو رمز وارد‌شده یکسان نیستند.'); return }
    setSavingPw(true); setError(null)
    try {
      await updatePassword(pw1); setPw1(''); setPw2('')
      toast('رمز عبور تغییر کرد.', 'success')
    } catch (e: any) { setError(faError(e, 'تغییر رمز انجام نشد')) }
    finally { setSavingPw(false) }
  }

  if (!profile) return <div className="grid gap-4"><Skeleton className="h-28" /><Skeleton className="h-64" /></div>

  return (
    <div className="space-y-7">
      <header>
        <Chip><UserRound className="size-3" /> حساب من</Chip>
        <h1 className="mt-3 text-2xl font-extrabold">پروفایل و تنظیمات</h1>
        <p className="mt-2 text-[13px] leading-7 text-ink-muted">
          اطلاعات حساب، زبان فعلی، هدف یادگیری و ترجیح‌های برنامه را از اینجا مدیریت کن.
        </p>
      </header>

      {error && <ErrorState title="انجام نشد" body={error} />}

      {/* ---------- identity ---------- */}
      <section className="grid gap-5 lg:grid-cols-[1.4fr_1fr]">
        <Card className="!p-6">
          <SectionTitle title="اطلاعات حساب" subtitle="نام نمایشی در برنامه و اعلان‌ها استفاده می‌شود." />
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <Field label="نام نمایشی" required>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثلاً سارا" />
            </Field>
            <Field label="ایمیل" hint="ایمیل حساب قابل ویرایش نیست.">
              <Input value={profile.id === 'demo-preview' ? 'preview@lingu.app' : '—'} readOnly className="opacity-70" />
            </Field>
          </div>
          <div className="mt-4 flex justify-end"><Button onClick={saveProfile} loading={savingProfile}>ذخیره تغییرات</Button></div>

          <div className="mt-6 border-t border-line/60 pt-5">
            <SectionTitle title="تغییر رمز عبور" subtitle="برای امنیت حساب، رمز قوی و یکتا انتخاب کن." />
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <Field label="رمز جدید" required><Input type="password" value={pw1} onChange={(e) => setPw1(e.target.value)} placeholder="حداقل ۶ کاراکتر" /></Field>
              <Field label="تکرار رمز جدید" required><Input type="password" value={pw2} onChange={(e) => setPw2(e.target.value)} /></Field>
            </div>
            <div className="mt-4 flex justify-end"><Button variant="outline" onClick={changePassword} loading={savingPw}><KeyRound className="size-4" /> تغییر رمز</Button></div>
          </div>
        </Card>

        <div className="space-y-5">
          <Card className="!p-6">
            <SectionTitle title="وضعیت حساب" />
            <div className="mt-4 space-y-3">
              <Row label="پلن">
                {membership.premium
                  ? <Chip tone="warn"><Crown className="size-3" /> Premium {membership.days_left !== null ? `· ${faNum(membership.days_left)} روز` : ''}</Chip>
                  : <Chip>نسخه رایگان</Chip>}
              </Row>
              <Row label="زبان فعلی">
                <span className="text-[12px] font-bold">{languages.find((l) => l.code === profile.target_language)?.name_fa ?? 'انتخاب نشده'}</span>
              </Row>
              <Row label="هدف"><span className="text-[12px] font-bold">{profile.goal ? GOAL_FA[profile.goal] : 'انتخاب نشده'}</span></Row>
              <Row label="آخرین فعالیت"><span className="text-[11px] text-ink-faint">{profile.last_seen_at ? faRelative(profile.last_seen_at) : '—'}</span></Row>
            </div>
            {!membership.premium && <Link to="/app/subscription" className="mt-5 block"><Button className="w-full"><Crown className="size-4" /> دیدن پلن‌ها</Button></Link>}
          </Card>

          <Card className="!p-6">
            <SectionTitle title="تور راهنما" subtitle="اگر تور را رد کردی یا می‌خواهی دوباره ببینی." />
            <div className="mt-4 flex items-center justify-between gap-3">
              <span className="text-[11.5px] text-ink-muted">
                {profile.tour_done ? `دیده‌شده${profile.last_seen_at ? '' : ''}` : 'هنوز کامل نشده'}
              </span>
              <div className="flex gap-2">
                {profile.tour_done && (
                  <Confirmed label={<span className="inline-flex items-center gap-1"><Trash2 className="size-3.5" /> بازنشانی</span>}
                    confirmLabel="بازنشانی شود؟" variant="outline"
                    onConfirm={async () => { await setTour(false); toast('تور بازنشانی شد؛ در صفحه اصلی دوباره اجرا می‌شود.', 'success') }} />
                )}
                <Button size="sm" onClick={async () => { await setTour(false); window.location.assign('/app') }}>
                  <Play className="size-3.5" /> اجرای تور
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* ---------- learning preferences ---------- */}
      <section className="grid gap-5 lg:grid-cols-2">
        <Card className="!p-6">
          <SectionTitle title="ترجیح‌های یادگیری" subtitle="بر اساس این‌ها، پیشنهادهای برنامه تنظیم می‌شود." />
          <div className="mt-5 space-y-4">
            <Field label="زبان فعلی"><Select value={profile.target_language ?? ''} onChange={(e) => saveLanguage(e.target.value)}>
              <option value="" disabled>انتخاب زبان</option>
              {languages.map((l) => <option key={l.code} value={l.code}>{l.flag} {l.name_fa}</option>)}
            </Select></Field>
            <Field label="هدف من"><Select value={profile.goal ?? ''} onChange={(e) => saveGoal(e.target.value)}>
              <option value="" disabled>انتخاب هدف</option>
              {GOALS.map((g) => <option key={g.id} value={g.id}>{g.label_fa} — {g.desc_fa}</option>)}
            </Select></Field>
            <Field label="سطح ترجیحی" hint="سطح شروع درس‌های پیشنهادی."><Select value={profile.preferred_level ?? 'A1'} onChange={(e) => saveLevel(e.target.value)}>
              {LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
            </Select></Field>
            <div className="rounded-3xl border border-line/70 bg-bg-soft/50 p-4 text-[11.5px] leading-7 text-ink-muted">
              <Target className="mb-1 size-3.5 text-primary-soft" /> هدف فعلی: <b className="text-ink">{profile.goal ? GOAL_FA[profile.goal] : 'انتخاب نشده'}</b>
            </div>
          </div>
        </Card>

        <div className="space-y-5">
          <Card className="!p-6">
            <SectionTitle title="ترجیح‌های برنامه" subtitle="همه این تنظیمات روی همین دستگاه ذخیره می‌شوند." />
            <div className="mt-5 space-y-2">
              <Toggle icon={<Bell className="size-4" />} title="اعلان‌های برنامه" body="اعلان‌های واقعی برنامه: تکمیل درس، اشتراک و درس‌های تازه." checked={notify} onChange={setNotify} />
              <Toggle icon={<Volume2 className="size-4" />} title="صدای رابط کاربری" body="پخش صدای فایل‌های شنیداری درس(در صورت وجود)." checked={sound} onChange={setSound} />
              <Toggle icon={<Pause className="size-4" />} title="کاهش انیمیشن‌ها" body="برای کاربرانی که حرکت کمتر را ترجیح می‌دهند (معادل prefers-reduced-motion)." checked={reduce} onChange={setReduce} />
            </div>
          </Card>

          <Card className="!p-6">
            <SectionTitle title="پشتیبانی و اشتراک‌گذاری" />
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <Link to="/app/help"><Button variant="outline" className="w-full"><LifeBuoy className="size-4" /> راهنمای برنامه</Button></Link>
              <Button variant="outline" className="w-full" onClick={async () => {
                const url = 'https://lingu.ir'
                try {
                  if (navigator.share) await navigator.share({ title: 'LINGU', text: 'یادگیری زبان با مربی هوشمند و مکالمه نقش‌محور', url })
                  else { await navigator.clipboard.writeText(url); toast('لینک LINGU کپی شد.', 'success') }
                } catch { /* user cancelled */ }
              }}><Share2 className="size-4" /> اشتراک‌گذاری LINGU</Button>
            </div>
            <p className="mt-4 text-[11px] leading-6 text-ink-faint">
              راه ارتباطی پشتیبانی از بخش «راهنما» در دسترس است. برای بازخورد درباره درس‌ها، از همان صفحه پیام بگذار.
            </p>
          </Card>
        </div>
      </section>

      {/* ---------- shortcuts + logout ---------- */}
      <Card className="!p-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap gap-3">
            <Link to="/app/lessons"><Button variant="outline" size="sm"><BookOpen className="size-4" /> درس‌ها</Button></Link>
            <Link to="/app/progress"><Button variant="outline" size="sm"><Sparkles className="size-4" /> پیشرفت من</Button></Link>
            <Link to="/app/subscription"><Button variant="outline" size="sm"><BadgeCheck className="size-4" /> اشتراک</Button></Link>
            <Link to="/"><Button variant="ghost" size="sm"><Globe2 className="size-4" /> صفحه عمومی سایت</Button></Link>
          </div>
          <Button variant="danger" onClick={async () => { await signOut(); toast('از حساب خارج شدی.', 'success') }}>
            <LogOut className="size-4" /> خروج از حساب
          </Button>
        </div>
      </Card>
    </div>
  )
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="flex items-center justify-between gap-3 border-b border-line/50 pb-2.5 last:border-0 last:pb-0">
    <span className="text-[11.5px] text-ink-faint">{label}</span>{children}
  </div>
}

function Toggle({ icon, title, body, checked, onChange }: { icon: React.ReactNode; title: string; body: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-start justify-between gap-4 rounded-3xl border border-line/70 bg-card/50 p-4">
      <div className="flex gap-3">
        <span className="grid size-9 shrink-0 place-items-center rounded-2xl bg-brand-soft text-primary-soft">{icon}</span>
        <div>
          <p className="text-[12.5px] font-extrabold">{title}</p>
          <p className="mt-0.5 text-[11px] leading-6 text-ink-muted">{body}</p>
        </div>
      </div>
      <Switch checked={checked} onChange={onChange} />
    </div>
  )
}
