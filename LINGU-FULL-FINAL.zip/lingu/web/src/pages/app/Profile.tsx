import { useEffect, useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import {
  BadgeCheck, BookOpenCheck, Calendar, Camera, Compass, Crown, LifeBuoy, LogOut, RefreshCw,
  Save, Settings as SettingsIcon, ShieldCheck, Sparkles, Target, TrendingUp, UserRound,
} from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { Button, Card, Chip, Field, Input, Progress, SectionTitle, Select, Skeleton } from '@/components/ui'
import { faDate, faDateTime, faNum, initials, faError } from '@/lib/utils'
import { GOALS, GOAL_FA, LESSON_SECTIONS } from '@/lib/constants'

/**
 * Profile = identity + learning identity + plan.
 * Device/account preferences (notifications, motion, password) live in Settings,
 * so nothing is duplicated between the two screens.
 */
export default function Profile() {
  const { profile, membership, quota, isAdmin, signOut, toast, api, refreshProfile, settings, languages, startTourReplay } = useApp()
  const nav = useNavigate()
  const [name, setName] = useState(profile?.display_name ?? '')
  const [busy, setBusy] = useState(false)
  const [avatarBusy, setAvatarBusy] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => { setName(profile?.display_name ?? '') }, [profile?.display_name])

  const { data: progressData, loading: progressLoading } = useAsync(async () => {
    if (!api) return null
    const [catalog, progress] = await Promise.all([api.catalog(), api.myProgress()])
    const done = progress.filter((p) => p.status === 'completed')
    return {
      completed: done.length,
      catalog: catalog.length,
      minutes: Math.round(progress.reduce((s, p) => s + (p.time_spent_sec || 0), 0) / 60),
      pct: catalog.length ? Math.round((done.length / catalog.length) * 100) : 0,
    }
  }, [api])

  const saveName = async () => {
    if (!api) return
    setBusy(true)
    try {
      await api.updateProfile({ display_name: name.trim() })
      await refreshProfile()
      toast('نام نمایشی ذخیره شد.', 'success')
    } catch (e) { toast(faError(e, 'ذخیره ناموفق بود'), 'error') }
    finally { setBusy(false) }
  }

  const pickAvatar = async (file: File) => {
    if (!api) return
    if (file.size > 2 * 1024 * 1024) { toast('حجم تصویر باید کمتر از ۲ مگابایت باشد.', 'error'); return }
    setAvatarBusy(true)
    try {
      await api.uploadAvatar(file)
      await refreshProfile()
      toast('تصویر پروفایل به‌روز شد.', 'success')
    } catch (e) { toast(faError(e, 'بارگذاری تصویر ناموفق بود'), 'error') }
    finally { setAvatarBusy(false) }
  }

  const saveLanguage = async (code: string) => {
    if (!api) return
    try { await api.updateProfile({ target_language: code } as any); await refreshProfile(); toast('زبان فعلی تغییر کرد.', 'success') }
    catch { toast('تغییر زبان انجام نشد.', 'error') }
  }

  const saveGoal = async (goal: string) => {
    if (!api) return
    try { await api.updateProfile({ goal } as any); await refreshProfile(); toast('هدف یادگیری ذخیره شد.', 'success') }
    catch { toast('ذخیره هدف انجام نشد.', 'error') }
  }

  const logout = async () => { await signOut(); toast('از حساب خارج شدی.', 'success'); nav('/') }

  return (
    <div className="space-y-6">

      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Chip tone="primary"><UserRound className="size-3" /> پروفایل</Chip>
          <h1 className="mt-3 text-2xl font-extrabold">حساب من</h1>
          <p className="mt-2 text-sm leading-7 text-ink-muted">
            هویت یادگیری‌ات: نام و تصویر، زبان و هدف، وضعیت اشتراک و مسیر پیشرفت.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={startTourReplay}><Compass className="size-4" /> تکرار تور آموزشی</Button>
          <Link to="/app/settings"><Button variant="outline"><SettingsIcon className="size-4" /> تنظیمات</Button></Link>
          <Button variant="ghost" onClick={logout}><LogOut className="size-4" /> خروج</Button>
        </div>
      </header>

      <div className="grid gap-5 lg:grid-cols-[1.2fr_1fr]">
        <div className="space-y-5">
          {/* identity */}
          <Card>
            <div className="flex flex-wrap items-center gap-4">
              <button type="button" onClick={() => fileRef.current?.click()} className="group relative" aria-label="تغییر تصویر پروفایل">
                {profile?.avatar_url ? (
                  <img src={profile.avatar_url} alt={profile.display_name ?? ''} className="size-16 rounded-3xl border border-line object-cover" />
                ) : (
                  <span className="grid size-16 place-items-center rounded-3xl bg-brand-grad text-lg font-extrabold text-white">{initials(profile?.display_name)}</span>
                )}
                <span className="absolute -bottom-1 -left-1 grid size-7 place-items-center rounded-xl border border-line bg-card text-ink-muted shadow-soft transition-colors group-hover:text-primary-soft">
                  <Camera className="size-3.5" />
                </span>
              </button>
              <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp" className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) pickAvatar(f); e.target.value = '' }} />

              <div className="min-w-0 flex-1">
                <p className="text-lg font-extrabold">{profile?.display_name || 'زبان‌آموز LINGU'}</p>
                <p className="mt-0.5 text-[11px] text-ink-faint">
                  {avatarBusy ? 'در حال بارگذاری تصویر…' : 'برای تغییر تصویر، روی آن بزن (PNG/JPG/WebP تا ۲MB).'}
                </p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {profile?.role === 'admin' && <Chip tone="primary"><ShieldCheck className="size-3" /> مدیر</Chip>}
                  {membership.premium ? <Chip tone="success"><BadgeCheck className="size-3" /> Premium</Chip> : <Chip>رایگان همیشگی</Chip>}
                </div>
              </div>
            </div>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <Field label="نام نمایشی"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثلاً: سارا" /></Field>
              <div className="flex items-end"><Button onClick={saveName} loading={busy} className="w-full"><Save className="size-4" /> ذخیره</Button></div>
            </div>

            <div className="mt-5 space-y-2 rounded-2xl border border-line/70 bg-bg-soft/50 p-4 text-[11px]">
              <InfoRow icon={<Calendar className="size-3.5" />} label="تاریخ عضویت" value={faDate(profile?.created_at)} />
              <InfoRow icon={<RefreshCw className="size-3.5" />} label="آخرین فعالیت" value={faDateTime(profile?.last_seen_at)} />
              <InfoRow icon={<Sparkles className="size-3.5" />} label="وضعیت تور آموزشی" value={profile?.tour_done ? 'دیده‌شده' : 'دیده‌نشده'} />
              <InfoRow icon={<Target className="size-3.5" />} label="هدف یادگیری" value={profile?.goal ? (GOAL_FA[profile.goal] ?? profile.goal) : 'انتخاب نشده'} />
            </div>
          </Card>

          {/* learning identity */}
          <Card>
            <SectionTitle title="مسیر یادگیری من" subtitle="زبان و هدف، پیشنهادهای برنامه را تنظیم می‌کند." />
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <Field label="زبان فعلی" hint="می‌توانی هر سه زبان را موازی پیش ببری.">
                <Select value={profile?.target_language ?? ''} onChange={(e) => saveLanguage(e.target.value)}>
                  <option value="" disabled>انتخاب زبان</option>
                  {languages.map((l) => <option key={l.code} value={l.code}>{l.flag} {l.name_fa}</option>)}
                </Select>
              </Field>
              <Field label="هدف من">
                <Select value={profile?.goal ?? ''} onChange={(e) => saveGoal(e.target.value)}>
                  <option value="" disabled>انتخاب هدف</option>
                  {GOALS.map((g) => <option key={g.id} value={g.id}>{g.label_fa} — {g.desc_fa}</option>)}
                </Select>
              </Field>
            </div>
            <Link to="/app/settings" className="mt-4 block">
              <Button variant="outline" className="w-full"><SettingsIcon className="size-4" /> تنظیمات کامل (سطح، اعلان‌ها، گذرواژه)</Button>
            </Link>
          </Card>

          {/* progress snapshot */}
          <Card>
            <SectionTitle title="نگاه سریع به پیشرفت" subtitle="جزئیات کامل در صفحه پیشرفت." />
            {progressLoading ? <Skeleton className="mt-4 h-24" /> : (
              <>
                <div className="mt-4 grid gap-3 sm:grid-cols-3">
                  <MiniStat label="درس کامل‌شده" value={faNum(progressData?.completed ?? 0)} />
                  <MiniStat label="دقیقه یادگیری" value={faNum(progressData?.minutes ?? 0)} />
                  <MiniStat label="پیشرفت کل" value={`${faNum(progressData?.pct ?? 0)}٪`} />
                </div>
                <Progress className="mt-4" value={progressData?.pct ?? 0} />
                <div className="mt-4 flex gap-2">
                  <Link to="/app/progress" className="flex-1"><Button variant="outline" className="w-full"><TrendingUp className="size-4" /> صفحه پیشرفت</Button></Link>
                  <Link to="/app/lessons" className="flex-1"><Button className="w-full"><BookOpenCheck className="size-4" /> درس‌ها</Button></Link>
                </div>
              </>
            )}
          </Card>
        </div>

        <div className="space-y-5">
          {/* plan */}
          <Card className="relative overflow-hidden">
            <div className="absolute inset-0 bg-brand-soft opacity-30" />
            <div className="relative">
              <h3 className="flex items-center gap-2 text-sm font-extrabold"><Crown className="size-4 text-warn" /> وضعیت اشتراک</h3>
              {membership.premium ? (
                <>
                  <p className="mt-3 text-lg font-extrabold">{membership.plan?.title_fa}</p>
                  <p className="mt-1 text-[11px] text-ink-faint">تا {faDate(membership.subscription?.end_date)} · {faNum(membership.days_left ?? 0)} روز باقی‌مانده</p>
                  <div className="mt-4 space-y-2 text-[11px]">
                    <InfoRow icon={<BadgeCheck className="size-3.5" />} label="پلن" value={membership.plan?.title_fa ?? 'Premium'} />
                    <InfoRow icon={<Calendar className="size-3.5" />} label="شروع" value={faDate(membership.subscription?.start_date)} />
                  </div>
                  <Link to="/app/subscription" className="mt-5 block"><Button variant="outline" className="w-full">جزئیات و تمدید</Button></Link>
                </>
              ) : (
                <>
                  <p className="mt-3 text-sm leading-7 text-ink-muted">
                    حساب تو برای همیشه رایگان است: {faNum(Number(settings.learning?.free_lessons_per_language ?? 2))} درس کامل در هر زبان و {faNum(2)} پیام Conversation Partner.
                  </p>
                  <div className="mt-4 space-y-2 text-[11px]">
                    <InfoRow icon={<Sparkles className="size-3.5" />} label="پیام Conversation باقی‌مانده" value={quota?.premium ? '—' : faNum(quota?.partner_remaining ?? 0)} />
                    <InfoRow icon={<BookOpenCheck className="size-3.5" />} label="بخش هر درس" value={`${faNum(LESSON_SECTIONS.length)} بخش`} />
                  </div>
                  <Link to="/app/subscription" className="mt-5 block"><Button className="w-full"><Crown className="size-4" /> دیدن پلن‌ها</Button></Link>
                </>
              )}
            </div>
          </Card>

          {isAdmin && (
            <Card>
              <h3 className="flex items-center gap-2 text-sm font-extrabold"><ShieldCheck className="size-4 text-primary-soft" /> دسترسی مدیریتی</h3>
              <p className="mt-2 text-[11px] leading-6 text-ink-muted">تو مدیر LINGU هستی و به پنل مدیریت دسترسی داری.</p>
              <Link to="/admin" className="mt-4 block"><Button variant="outline" className="w-full">ورود به پنل مدیریت</Button></Link>
            </Card>
          )}

          <Card>
            <h3 className="flex items-center gap-2 text-sm font-extrabold"><LifeBuoy className="size-4 text-primary-soft" /> میان‌برها</h3>
            <div className="mt-4 grid gap-2">
              <Link to="/app/help"><Button variant="outline" className="w-full justify-start">راهنمای برنامه</Button></Link>
              <Link to="/app/settings"><Button variant="outline" className="w-full justify-start">تنظیمات برنامه و حساب</Button></Link>
              <Link to="/"><Button variant="ghost" className="w-full justify-start">صفحه عمومی سایت</Button></Link>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}

function InfoRow({ icon, label, value, ltr }: { icon: React.ReactNode; label: string; value: string; ltr?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="flex items-center gap-1.5 text-ink-faint">{icon} {label}</span>
      <span className={`font-bold ${ltr ? 'ltr' : ''}`}>{value}</span>
    </div>
  )
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-line/70 bg-bg-soft/50 p-3 text-center">
      <p className="text-lg font-extrabold">{value}</p>
      <p className="text-[10.5px] text-ink-faint">{label}</p>
    </div>
  )
}
