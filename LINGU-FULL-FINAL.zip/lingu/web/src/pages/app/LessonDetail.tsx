import { AnimatePresence, motion } from 'motion/react'
import { useMemo, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import {
  ArrowLeft, ArrowRight, BookOpenCheck, CheckCircle2, Clock, Crown, Flame, GraduationCap,
  Headphones, Languages as LangIcon, Lightbulb, ListChecks, Lock, MessagesSquare, Mic, Newspaper,
  PencilLine, Play, Quote, RotateCcw, Sparkles, Trophy, Volume2, XCircle,
} from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { Button, Card, Chip, EmptyState, Progress, Skeleton } from '@/components/ui'
import { faNum, faError } from '@/lib/utils'
import { LESSON_SECTIONS } from '@/lib/constants'
import type { ExerciseItem, LessonContent } from '@/services/types'
import { AudioPlayer, AudioQueue, ClipPlayButton } from '@/components/app/AudioPlayer'
import { clipsFor, persianClips, englishClips, clipForLine, clipForVocab, type AudioClip } from '@/lib/audio'

const ICONS: Record<string, any> = {
  Flame, BookOpen: BookOpenCheck, Languages: LangIcon, Blocks: Sparkles, Quote, Headphones,
  MessagesSquare, Mic, Newspaper, PencilLine, ListChecks, Sparkles,
}

export default function LessonDetail() {
  const { lessonId = '' } = useParams()
  const { api, membership, toast, languages, refreshProfile, media } = useApp()
  const nav = useNavigate()
  const [sectionIdx, setSectionIdx] = useState(0)
  const [saved, setSaved] = useState<Set<string>>(new Set())
  const [completed, setCompleted] = useState(false)
  const [quizScore, setQuizScore] = useState<number | null>(null)
  const [starting, setStarting] = useState(false)

  const { data, loading, error } = useAsync(async () => {
    if (!api) return null
    const [lesson, progress, catalog] = await Promise.all([api.lesson(lessonId), api.myProgress(), api.catalog()])
    return {
      lesson,
      progress: progress.find((p) => p.lesson_id === lessonId) ?? null,
      meta: catalog.find((c) => c.id === lessonId) ?? null,
    }
  }, [api, lessonId])

  const lesson = data?.lesson ?? null
  const initialDone = useMemo(() => new Set(data?.progress?.sections_done ?? []), [data?.progress])

  const doneSet = useMemo(() => new Set([...initialDone, ...saved]), [initialDone, saved])
  const pct = Math.round((doneSet.size / LESSON_SECTIONS.length) * 100)
  const current = LESSON_SECTIONS[sectionIdx]
  const langMeta = languages.find((l) => l.code === lesson?.language_code)

  const persist = async (patch: { section?: string; score?: number | null; complete?: boolean }) => {
    if (!api || !lesson) return
    const next = new Set(doneSet)
    if (patch.section) next.add(patch.section)
    setSaved(next)
    const isDone = patch.complete || next.size >= LESSON_SECTIONS.length
    try {
      await api.saveProgress({
        lesson_id: lesson.id,
        status: isDone ? 'completed' : 'started',
        last_section: patch.section ?? current.key,
        sections_done: [...next],
        score: patch.score ?? quizScore ?? null,
        time_spent_sec: next.size * 90,
      })
      if (isDone) { setCompleted(true); toast('درس کامل شد! آفرین 🎉', 'success') }
    } catch (e) {
      toast(faError(e, 'ذخیره پیشرفت ناموفق بود'), 'error')
    }
  }

  const startAiPractice = async () => {
    if (!api || !lesson) return
    if (!membership.premium) { toast('AI Tutor برای کاربران Premium فعال است.', 'info'); nav('/app/subscription'); return }
    setStarting(true)
    try {
      const conv = await api.createConversation({
        mode: 'tutor',
        lesson_id: lesson.id,
        title: `تمرین: ${lesson.title}`,
      })
      await refreshProfile()
      nav(`/app/tutor/${conv.id}`)
    } catch (e) {
      toast(faError(e, 'شروع تمرین ناموفق بود'), 'error')
    } finally { setStarting(false) }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-9 w-64" />
        <div className="card-surface space-y-4 p-6"><Skeleton className="h-6 w-1/2" /><Skeleton className="h-40 w-full" /></div>
      </div>
    )
  }

  // A locked lesson is a real product state (premium gate), never an error page.
  const locked = !!data?.meta?.locked && !membership.premium
  if (locked) {
    return (
      <div className="grid items-center gap-8 py-6 lg:grid-cols-2">
        <div>
          <Chip tone="warn"><Lock className="size-3" /> بخشی از اشتراک Premium</Chip>
          <h1 className="mt-4 text-2xl font-extrabold leading-9">{data?.meta?.title ?? 'این درس'}</h1>
          <p className="mt-3 text-[13px] leading-8 text-ink-muted">
            این درس یکی از درس‌های کامل LINGU است که با اشتراک فعال می‌شود. دو درس رایگان هر زبان همیشه در دسترس تو باقی می‌ماند.
          </p>
          <ul className="mt-5 space-y-2.5 text-[12px] text-ink-muted">
            {['همه درس‌های منتشرشده سه زبان', 'AI Tutor برای هر بخش', 'Conversation Partner بدون محدودیت پیام', 'پیگیری کامل پیشرفت'].map((t) => (
              <li key={t} className="flex items-center gap-2"><CheckCircle2 className="size-3.5 text-success" /> {t}</li>
            ))}
          </ul>
          <div className="mt-6 flex gap-3">
            <Link to="/app/subscription"><Button size="lg"><Crown className="size-4" /> دیدن پلن‌ها</Button></Link>
            <Link to="/app/lessons"><Button size="lg" variant="outline">درس‌های رایگان</Button></Link>
          </div>
        </div>
        <img src={media.premium?.url} alt="" className="mx-auto w-full max-w-md rounded-4xl border border-line/70 shadow-soft" />
      </div>
    )
  }

  if (error || !lesson) {
    return (
      <EmptyState
        icon={<BookOpenCheck className="size-6" />}
        title="درس پیدا نشد"
        body="ممکن است این درس حذف، منتشر نشده یا هنوز آماده نباشد."
        action={<Link to="/app/lessons"><Button variant="outline">بازگشت به درس‌ها</Button></Link>}
      />
    )
  }

  const content: LessonContent = lesson.content ?? {}

  return (
    <div className="space-y-6">
      {/* ------------------------------- header ------------------------------- */}
      <div>
        <Link to="/app/lessons" className="mb-4 inline-flex items-center gap-1.5 text-xs font-bold text-ink-muted hover:text-ink">
          <ArrowRight className="size-3.5" /> همه درس‌ها
        </Link>
        <Card className="relative overflow-hidden !p-6">
          <div className={`absolute inset-x-0 -top-24 h-40 bg-gradient-to-br ${langMeta?.gradient ?? 'from-indigo-500 to-cyan-400'} opacity-[0.16] blur-3xl`} />
          <div className="relative">
            <div className="flex flex-wrap items-center gap-2">
              <Chip><span>{langMeta?.flag}</span> {langMeta?.name_fa}</Chip>
              <Chip>سطح {lesson.level}</Chip>
              <Chip>درس {faNum(lesson.order_index)}</Chip>
              <Chip><Clock className="size-3" /> {faNum(lesson.estimated_minutes)} دقیقه</Chip>
              {lesson.is_free && <Chip tone="success">رایگان</Chip>}
              {completed && <Chip tone="success"><CheckCircle2 className="size-3" /> کامل شد</Chip>}
            </div>
            <h1 className="mt-4 text-2xl font-extrabold leading-9 sm:text-3xl">{lesson.title}</h1>
            {lesson.subtitle && <p className="mt-2 text-sm leading-7 text-ink-muted">{lesson.subtitle}</p>}

            <div className="mt-6 flex flex-wrap items-center gap-4">
              <div className="min-w-[220px] flex-1">
                <div className="mb-2 flex items-center justify-between text-[11px] font-bold text-ink-muted">
                  <span>{faNum(doneSet.size)} از {faNum(LESSON_SECTIONS.length)} بخش</span>
                  <span>{faNum(pct)}٪</span>
                </div>
                <Progress value={pct} />
              </div>
              <Button variant="outline" size="sm" onClick={() => persist({ complete: true })} disabled={completed}>
                <Trophy className="size-3.5" /> علامت‌گذاری به‌عنوان کامل‌شده
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* --------------------------- section navigator --------------------------- */}
      <div className="no-scrollbar -mx-4 flex w-[calc(100%+2rem)] min-w-0 gap-2 overflow-x-auto px-4 pb-1 sm:w-full sm:mx-0 sm:px-0">
        {LESSON_SECTIONS.map((s, i) => {
          const Icon = ICONS[s.icon] ?? BookOpenCheck
          const isDone = doneSet.has(s.key)
          const active = i === sectionIdx
          return (
            <button key={s.key} onClick={() => setSectionIdx(i)}
              className={`flex shrink-0 items-center gap-2 rounded-2xl border px-3.5 py-2.5 text-xs font-bold transition-all ${
                active ? 'border-primary/45 bg-brand-soft text-ink' : 'border-line/80 bg-card/40 text-ink-muted hover:text-ink'}`}>
              {isDone ? <CheckCircle2 className="size-3.5 text-success" /> : <Icon className="size-3.5" />}
              {s.title_fa}
            </button>
          )
        })}
      </div>

      {/* ------------------------------- section ------------------------------- */}
      <AnimatePresence mode="wait">
        <motion.div key={current.key}
          initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}>
          <Card className="!p-6 sm:!p-7">
            <div className="mb-5 flex items-center gap-3">
              <span className="grid size-11 place-items-center rounded-2xl bg-brand-grad text-white">
                {(() => { const Icon = ICONS[current.icon] ?? BookOpenCheck; return <Icon className="size-5" /> })()}
              </span>
              <div>
                <h2 className="text-lg font-extrabold">{current.title_fa}</h2>
                <p className="text-[11px] text-ink-faint">بخش {faNum(sectionIdx + 1)} از {faNum(LESSON_SECTIONS.length)}</p>
              </div>
            </div>

            <SectionBody
              sectionKey={current.key}
              content={content}
              onQuizScore={(s) => setQuizScore(s)}
            />

            {/* AI practice call to action lives inside its section, handled above */}

            <div className="mt-8 flex flex-wrap items-center justify-between gap-3 border-t border-line/60 pt-5">
              <Button variant="ghost" size="sm" onClick={() => setSectionIdx((i) => Math.max(0, i - 1))} disabled={sectionIdx === 0}>
                <ArrowRight className="size-3.5" /> بخش قبلی
              </Button>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => persist({ section: current.key })}>
                  <CheckCircle2 className="size-3.5" /> این بخش را تمام کردم
                </Button>
                {sectionIdx < LESSON_SECTIONS.length - 1 ? (
                  <Button size="sm" onClick={() => { persist({ section: current.key }); setSectionIdx((i) => i + 1) }}>
                    بخش بعدی <ArrowLeft className="size-3.5" />
                  </Button>
                ) : (
                  <Button size="sm" onClick={() => persist({ section: current.key, complete: true })}>
                    <Trophy className="size-3.5" /> پایان درس
                  </Button>
                )}
              </div>
            </div>
          </Card>
        </motion.div>
      </AnimatePresence>

      {completed && (
        <Card className="relative overflow-hidden !p-7 text-center">
          <div className="absolute inset-0 bg-mesh opacity-70" />
          <div className="relative">
            <span className="mx-auto grid size-14 place-items-center rounded-3xl bg-success/15 text-success"><Trophy className="size-7" /></span>
            <h2 className="mt-5 text-2xl font-extrabold">درس را کامل کردی! 🎉</h2>
            <p className="mx-auto mt-3 max-w-lg text-sm leading-7 text-ink-muted">
              پیشرفتت ذخیره شد. برای تثبیت، یک دور سریع با AI Tutor بزن یا به درس بعدی برو.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Button onClick={startAiPractice} loading={starting} disabled={!membership.premium}>
                <GraduationCap className="size-4" /> تمرین با AI Tutor
              </Button>
              <Link to="/app/lessons"><Button variant="outline"><Play className="size-4" /> درس بعدی</Button></Link>
            </div>
            {!membership.premium && (
              <p className="mt-4 text-[11px] text-ink-faint">AI Tutor برای کاربران Premium در دسترس است.</p>
            )}
          </div>
        </Card>
      )}
    </div>
  )
}

/* ============================== section renderer ============================== */
function SectionBody({ sectionKey, content, onQuizScore }: { sectionKey: string; content: LessonContent; onQuizScore: (s: number) => void }) {
  const c = content as Record<string, any>

  /* ------------------------------ صداهای این بخش ------------------------------ */
  /* لایهٔ فارسی («توضیح فارسی») همیشه اول و جدا پخش می‌شود؛ محتوای انگلیسی همان بخش
     در جای طبیعی خودش می‌نشیند. هر کلیپ متنِ خودش را نشان می‌دهد — نه ترجمه. */
  const sectionClips = clipsFor(content, sectionKey)
  const coach = persianClips(sectionClips)
  const english = englishClips(sectionClips)
  const coachPlayer = coach.length > 0 ? (
    <AudioPlayer clips={coach} variant={coach.length > 1 ? 'full' : 'inline'} title="توضیح فارسی این بخش" />
  ) : null
  /** بدنهٔ بخش + (اختیاری) صدا + لایهٔ فارسی بالای آن */
  const wrap = (body: React.ReactNode, extra?: React.ReactNode) => (
    <div className="space-y-4">{coachPlayer}{extra}{body}</div>
  )
  /** مثل wrap، ولی بدنه داخل AudioQueue می‌نشیند تا خط‌های دیالوگ و واژه‌ها
      بتوانند همان پخش‌کنندهٔ واحد را کنترل کنند (هیچ دو صدایی روی هم نمی‌افتد). */
  const wrapQueue = (body: React.ReactNode, clips: AudioClip[], title: string) => (
    <div className="space-y-4">
      {coachPlayer}
      {clips.length > 0 ? <AudioQueue clips={clips} variant="inline" title={title}>{body}</AudioQueue> : body}
    </div>
  )

  switch (sectionKey) {
    case 'warmup':
      return wrap(
        <div className="space-y-4">
          <p className="text-sm leading-8 text-ink-muted">{c.warmup?.prompt_fa}</p>
          <div className="grid gap-3">
            {(c.warmup?.questions ?? []).map((q: any, i: number) => (
              <div key={i} className="rounded-2xl border border-line/70 bg-bg-soft/50 p-4">
                <p className="text-sm font-bold"><Flame className="mb-1 inline size-3.5 text-warn" /> {q.q}</p>
                {q.hint_fa && <p className="mt-2 text-[11px] text-ink-faint">راهنما: {q.hint_fa}</p>}
              </div>
            ))}
          </div>
        </div>
      )

    case 'explanation':
      return wrap(
        <div className="space-y-4">
          <p className="whitespace-pre-line text-sm leading-8 text-ink">{c.explanation?.body_fa}</p>
          {!!c.explanation?.key_points?.length && (
            <div className="rounded-2xl border border-primary/25 bg-primary/8 p-4">
              <p className="mb-2 flex items-center gap-2 text-xs font-extrabold text-primary-soft"><Lightbulb className="size-3.5" /> نکته‌های کلیدی</p>
              <ul className="space-y-2">
                {c.explanation.key_points.map((k: string, i: number) => (
                  <li key={i} className="flex items-start gap-2 text-[13px] leading-7 text-ink-muted"><CheckCircle2 className="mt-1 size-3.5 shrink-0 text-success" /> {k}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )

    case 'vocabulary': {
      const list = (c.vocabulary?.items ?? []).map((v: any, i: number) => {
        const clip = clipForVocab(english, String(v.term))
        return (
          <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i, 8) * 0.04 }}
            className="rounded-2xl border border-line/70 bg-bg-soft/50 p-4 transition-all hover:border-primary/35">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-start gap-2">
                {clip && <ClipPlayButton id={clip.id} className="mt-0.5" />}
                <div>
                  <p className="ltr text-base font-extrabold" style={{ fontFamily: 'Sora, Vazirmatn, sans-serif' }}>{v.term}</p>
                  {v.ipa && <p className="ltr text-[11px] text-ink-faint">{v.ipa}</p>}
                </div>
              </div>
              {v.tag && <Chip className="!px-2 !py-0.5 !text-[10px]">{v.tag}</Chip>}
            </div>
            <p className="mt-2.5 text-sm font-bold text-primary-soft">{v.translation_fa}</p>
            <p className="ltr mt-3 text-[12px] leading-6 text-ink-muted">{v.example}</p>
            {v.example_fa && <p className="mt-1 text-[11px] leading-6 text-ink-faint">{v.example_fa}</p>}
          </motion.div>
        )
      })
      const grid = <div className="grid gap-3 sm:grid-cols-2">{list}</div>
      return english.length > 0
        ? wrapQueue(grid, english, 'تلفظ واژه‌ها و مثال‌ها')
        : wrap(grid)
    }

    case 'grammar':
      return wrap(
        <div className="space-y-4">
          <h3 className="text-base font-extrabold">{c.grammar?.title}</h3>
          {english.length > 0 && <AudioPlayer clips={english} variant="inline" title="شنیدن مثال‌های گرامر" />}
          <p className="whitespace-pre-line text-sm leading-8 text-ink-muted">{c.grammar?.explanation_fa}</p>
          {c.grammar?.pattern && (
            <div className="rounded-2xl border border-accent/30 bg-accent/8 p-4">
              <p className="text-[11px] font-extrabold text-accent">الگوی جمله</p>
              <p className="ltr mt-2 text-sm font-bold">{c.grammar.pattern}</p>
            </div>
          )}
          {c.grammar?.table && (
            <div className="overflow-hidden rounded-2xl border border-line/70">
              <table className="w-full text-sm">
                <thead className="bg-card-soft/60">
                  <tr>{c.grammar.table.headers.map((h: string, i: number) => <th key={i} className="px-4 py-3 text-right text-xs font-extrabold">{h}</th>)}</tr>
                </thead>
                <tbody>
                  {c.grammar.table.rows.map((r: string[], i: number) => (
                    <tr key={i} className="border-t border-line/60">
                      {r.map((cell, k) => <td key={k} className={`px-4 py-3 text-[13px] ${k === 0 ? 'font-bold' : 'text-ink-muted'}`}>{cell}</td>)}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {!!c.grammar?.pitfalls_fa?.length && (
            <div className="rounded-2xl border border-warn/30 bg-warn/10 p-4">
              <p className="mb-2 flex items-center gap-2 text-xs font-extrabold text-warn"><XCircle className="size-3.5" /> اشتباه‌های رایج</p>
              <ul className="space-y-1.5">
                {c.grammar.pitfalls_fa.map((p: string, i: number) => <li key={i} className="text-[12px] leading-7 text-ink-muted">• {p}</li>)}
              </ul>
            </div>
          )}
        </div>
      )

    case 'examples':
      return (
        <div className="space-y-3">
          {(c.examples?.items ?? []).map((e: any, i: number) => (
            <div key={i} className="rounded-2xl border border-line/70 bg-bg-soft/50 p-4">
              <p className="ltr text-sm font-bold leading-7">{e.target}</p>
              <p className="mt-2 text-[13px] leading-7 text-ink-muted">{e.fa}</p>
              {e.note_fa && <p className="mt-2 flex items-start gap-1.5 text-[11px] leading-6 text-ink-faint"><Lightbulb className="mt-0.5 size-3 shrink-0" /> {e.note_fa}</p>}
            </div>
          ))}
        </div>
      )

    case 'listening':
      return wrap(
        <div className="space-y-4">
          {english.length > 0 && <AudioPlayer clips={english} variant="inline" title="فایل شنیداری این درس" />}
          <div className="rounded-2xl border border-line/70 bg-bg-soft/50 p-5">
            <p className="mb-3 flex items-center gap-2 text-xs font-extrabold text-ink-muted"><Volume2 className="size-3.5 text-primary-soft" /> {c.listening?.title_fa}</p>
            <p className="ltr whitespace-pre-line text-[13px] leading-8">{c.listening?.script}</p>
            {c.listening?.script_fa && <p className="mt-3 border-t border-line/60 pt-3 text-[12px] leading-7 text-ink-faint">{c.listening.script_fa}</p>}
          </div>
          <div className="rounded-2xl border border-primary/25 bg-primary/8 p-4">
            <p className="text-[13px] font-bold">{c.listening?.question_fa}</p>
            <details className="mt-3">
              <summary className="cursor-pointer text-[11px] font-extrabold text-primary-soft">دیدن پاسخ</summary>
              <p className="ltr mt-2 text-sm">{c.listening?.answer}</p>
            </details>
          </div>
        </div>
      )

    case 'dialogue': {
      const lines = (c.dialogue?.lines ?? []).map((l: any, i: number) => {
        const clip = clipForLine(english, i)
        return (
            <motion.div key={i} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: Math.min(i, 10) * 0.05 }}
              className={`flex gap-3 ${i % 2 ? 'flex-row-reverse' : ''}`}>
              <span className="grid size-9 shrink-0 place-items-center rounded-2xl bg-brand-soft text-[10px] font-extrabold text-primary-soft">{l.speaker}</span>
              <div className={`max-w-[85%] rounded-2xl border border-line/70 bg-bg-soft/60 px-4 py-3 ${i % 2 ? 'text-left' : ''}`}>
                <div className="flex items-center gap-2">
                  {clip && <ClipPlayButton id={clip.id} />}
                  <p className="ltr text-sm leading-7">{l.target}</p>
                </div>
                <p className="mt-1.5 text-[11px] leading-6 text-ink-faint">{l.fa}</p>
              </div>
            </motion.div>
        )
      })
      return english.length > 0
        ? wrapQueue(<div className="space-y-3">{lines}</div>, english, 'شنیدن گفت‌وگو (گویندهٔ A و B)')
        : wrap(<div className="space-y-3">{lines}</div>)
    }

    case 'speaking':
      return wrap(
        <div className="space-y-4">
          <div className="rounded-2xl border border-line/70 bg-bg-soft/50 p-5">
            <p className="flex items-center gap-2 text-xs font-extrabold text-ink-muted"><Mic className="size-3.5 text-primary-soft" /> تمرین گفت‌وگو</p>
            <p className="mt-3 text-sm leading-8">{c.speaking?.task_fa}</p>
            {c.speaking?.seconds ? <Chip className="mt-3"><Clock className="size-3" /> حدود {faNum(Math.round(c.speaking.seconds / 60))} دقیقه</Chip> : null}
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {(c.speaking?.useful_phrases ?? []).map((p: any, i: number) => (
              <div key={i} className="rounded-2xl border border-line/70 bg-card/50 p-3.5">
                <p className="ltr text-sm font-bold">{p.target}</p>
                <p className="mt-1 text-[11px] text-ink-faint">{p.fa}</p>
              </div>
            ))}
          </div>
          <p className="rounded-2xl border border-warn/25 bg-warn/10 p-4 text-[11px] leading-6 text-warn">
            این تمرین بدون ضبط صدا است: بلند تمرین کن و بعد در Conversation Partner همان موقعیت را اجرا کن.
          </p>
        </div>
      )

    case 'reading':
      return wrap(
        <div className="space-y-4">
          <h3 className="text-base font-extrabold">{c.reading?.title}</h3>
          {english.length > 0 && <AudioPlayer clips={english} variant="inline" title="شنیدن متن خواندن" />}
          <div className="rounded-2xl border border-line/70 bg-bg-soft/50 p-5">
            <p className="ltr whitespace-pre-line text-[13px] leading-8">{c.reading?.text}</p>
          </div>
          {!!c.reading?.glossary?.length && (
            <div className="flex flex-wrap gap-2">
              {c.reading.glossary.map((g: any, i: number) => (
                <Chip key={i}><span className="ltr font-extrabold">{g.term}</span> — {g.fa}</Chip>
              ))}
            </div>
          )}
          <div className="space-y-3">
            {(c.reading?.questions ?? []).map((q: any, i: number) => (
              <details key={i} className="rounded-2xl border border-line/70 bg-card/50 p-4">
                <summary className="cursor-pointer text-[13px] font-bold">{q.q_fa}</summary>
                <p className="ltr mt-3 text-sm text-ink-muted">{q.a}</p>
              </details>
            ))}
          </div>
        </div>
      )

    case 'exercises':
      return wrap(<ExerciseList items={c.exercises?.items ?? []} />)

    case 'quiz':
      return wrap(<Quiz items={c.quiz?.items ?? []} onScore={onQuizScore} />)

    case 'ai_practice':
      return wrap(
        <div className="space-y-4">
          <p className="text-sm leading-8 text-ink-muted">{c.ai_practice?.task_fa}</p>
          {!!c.ai_practice?.focus?.length && (
            <div className="flex flex-wrap gap-2">{c.ai_practice.focus.map((f: string, i: number) => <Chip key={i} tone="primary">{f}</Chip>)}</div>
          )}
          <div className="rounded-2xl border border-primary/25 bg-primary/8 p-4">
            <p className="mb-2 flex items-center gap-2 text-xs font-extrabold text-primary-soft"><Sparkles className="size-3.5" /> نمونه درخواست‌ها</p>
            <ul className="space-y-1.5">
              {(c.ai_practice?.suggested_prompts ?? []).map((p: string, i: number) => (
                <li key={i} className="text-[12px] leading-7 text-ink-muted">• {p}</li>
              ))}
            </ul>
          </div>
          <p className="text-[11px] text-ink-faint">برای شروع این تمرین، دکمه «تمرین با AI Tutor» در پایین همین صفحه استفاده کن.</p>
        </div>
      )

    default:
      return <p className="text-sm leading-8 text-ink-muted">محتوای این بخش در دسترس نیست.</p>
  }
}

/* ============================== interactives ============================== */
function ExerciseList({ items }: { items: ExerciseItem[] }) {
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [checked, setChecked] = useState<Record<number, boolean>>({})
  const [resetKey, setResetKey] = useState(0)

  const isCorrect = (item: ExerciseItem, value: string) => {
    const target = Array.isArray(item.answer) ? item.answer.map((a) => a.toLowerCase().trim()) : [String(item.answer).toLowerCase().trim()]
    return target.includes(value.toLowerCase().trim())
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-xs font-bold text-ink-muted">{faNum(items.length)} تمرین — پاسخ‌ها همان‌جا بررسی می‌شوند.</p>
        <Button variant="ghost" size="sm" onClick={() => { setAnswers({}); setChecked({}); setResetKey((k) => k + 1) }}>
          <RotateCcw className="size-3.5" /> شروع دوباره
        </Button>
      </div>

      {items.map((item, i) => (
        <div key={`${resetKey}-${i}`} className="rounded-2xl border border-line/70 bg-bg-soft/50 p-4">
          {item.prompt_fa && <p className="mb-2 text-[11px] text-ink-faint">{item.prompt_fa}</p>}
          <p className="text-sm font-bold leading-7">{item.question}</p>

          {item.type === 'mcq' || item.type === 'truefalse' ? (
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {(item.options ?? (item.type === 'truefalse' ? ['True', 'False'] : [])).map((opt) => {
                const picked = answers[i] === opt
                const state = checked[i] ? (isCorrect(item, opt) ? 'ok' : picked ? 'bad' : 'idle') : picked ? 'picked' : 'idle'
                return (
                  <button key={opt} onClick={() => { setAnswers((a) => ({ ...a, [i]: opt })); setChecked((c) => ({ ...c, [i]: true })) }}
                    className={`flex items-center justify-between gap-2 rounded-2xl border px-4 py-3 text-right text-[13px] font-bold transition-all ${
                      state === 'ok' ? 'border-success/50 bg-success/10 text-success'
                      : state === 'bad' ? 'border-danger/50 bg-danger/10 text-danger'
                      : state === 'picked' ? 'border-primary/45 bg-primary/10'
                      : 'border-line/80 bg-card/50 hover:border-primary/35'}`}>
                    <span className="ltr">{opt}</span>
                    {state === 'ok' && <CheckCircle2 className="size-4 shrink-0" />}
                    {state === 'bad' && <XCircle className="size-4 shrink-0" />}
                  </button>
                )
              })}
            </div>
          ) : (
            <div className="mt-3 flex gap-2">
              <input dir="ltr" value={answers[i] ?? ''} onChange={(e) => { setAnswers((a) => ({ ...a, [i]: e.target.value })); setChecked((c) => ({ ...c, [i]: false })) }}
                placeholder="پاسخ خود را بنویس…" className="input flex-1" />
              <Button size="sm" onClick={() => setChecked((c) => ({ ...c, [i]: true }))}>بررسی</Button>
            </div>
          )}

          <AnimatePresence>
            {checked[i] && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                <div className={`mt-3 rounded-xl border p-3 text-[12px] leading-7 ${
                  isCorrect(item, answers[i] ?? '') ? 'border-success/40 bg-success/10 text-success' : 'border-warn/40 bg-warn/10 text-warn'}`}>
                  {isCorrect(item, answers[i] ?? '') ? 'درست است! ✓' : <>پاسخ درست: <span className="ltr font-extrabold">{Array.isArray(item.answer) ? item.answer.join(' / ') : item.answer}</span></>}
                  {item.explanation_fa && <p className="mt-1.5 text-ink-muted">{item.explanation_fa}</p>}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  )
}

function Quiz({ items, onScore }: { items: ExerciseItem[]; onScore: (s: number) => void }) {
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [submitted, setSubmitted] = useState(false)
  const score = useMemo(() => {
    let ok = 0
    items.forEach((item, i) => {
      const target = Array.isArray(item.answer) ? item.answer : [String(item.answer)]
      if (target.map((t) => t.toLowerCase().trim()).includes((answers[i] ?? '').toLowerCase().trim())) ok++
    })
    return items.length ? Math.round((ok / items.length) * 100) : 0
  }, [answers, items])

  if (items.length === 0) return <p className="text-sm text-ink-muted">آزمون این درس هنوز آماده نیست.</p>

  return (
    <div className="space-y-4">
      <p className="text-xs font-bold text-ink-muted">{faNum(items.length)} سؤال — برای دیدن نتیجه همه را پاسخ بده و ثبت کن.</p>
      {items.map((item, i) => (
        <div key={i} className="rounded-2xl border border-line/70 bg-bg-soft/50 p-4">
          <p className="text-sm font-bold leading-7">{faNum(i + 1)}. {item.question}</p>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            {(item.options ?? []).map((opt) => {
              const picked = answers[i] === opt
              const correct = submitted && (Array.isArray(item.answer) ? item.answer : [item.answer]).some((a) => a.toLowerCase() === opt.toLowerCase())
              return (
                <button key={opt} disabled={submitted}
                  onClick={() => setAnswers((a) => ({ ...a, [i]: opt }))}
                  className={`rounded-2xl border px-4 py-3 text-right text-[13px] font-bold transition-all ${
                    correct ? 'border-success/50 bg-success/10 text-success'
                    : picked ? (submitted ? 'border-danger/50 bg-danger/10 text-danger' : 'border-primary/45 bg-primary/10')
                    : 'border-line/80 bg-card/50 hover:border-primary/35'}`}>
                  <span className="ltr">{opt}</span>
                </button>
              )
            })}
          </div>
          {submitted && item.explanation_fa && <p className="mt-3 text-[11px] leading-6 text-ink-faint">{item.explanation_fa}</p>}
        </div>
      ))}

      {!submitted ? (
        <Button onClick={() => { setSubmitted(true); onScore(score) }} disabled={Object.keys(answers).length < items.length}>
          <ListChecks className="size-4" /> ثبت پاسخ‌ها ({faNum(Object.keys(answers).length)}/{faNum(items.length)})
        </Button>
      ) : (
        <div className="rounded-2xl border border-primary/30 bg-primary/8 p-5 text-center">
          <p className="text-xs font-bold text-ink-muted">نتیجه آزمون</p>
          <p className="mt-2 text-3xl font-extrabold">{faNum(score)}٪</p>
          <p className="mt-1 text-[11px] text-ink-faint">{score >= 80 ? 'عالی! درس را خوب یاد گرفتی.' : score >= 50 ? 'خوب بود — بخش‌های اشتباه را یک دور مرور کن.' : 'نگران نباش؛ دوباره مرور کن و آزمون را تکرار کن.'}</p>
          <Button variant="outline" size="sm" className="mt-4" onClick={() => { setSubmitted(false); setAnswers({}) }}>
            <RotateCcw className="size-3.5" /> تلاش دوباره
          </Button>
        </div>
      )}
    </div>
  )
}
