import { motion } from 'motion/react'
import { useMemo } from 'react'
import { Link } from 'react-router-dom'
import {
  Award, BarChart3, BookOpenCheck, CalendarDays, CheckCircle2, Clock, Crown, Flame, Lock,
  Route, Target, TrendingUp, Trophy,
} from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { Button, Card, Chip, EmptyState, ErrorState, Progress, Ring, SectionTitle, Skeleton, StatCard } from '@/components/ui'
import { cn, faDate, faNum } from '@/lib/utils'
import { GOAL_FA, LESSON_SECTIONS, LEVELS } from '@/lib/constants'

export default function ProgressPage() {
  const { api, profile, membership, languages } = useApp()

  const { data, loading, error, reload } = useAsync(async () => {
    if (!api) return { catalog: [], progress: [], quiz: [] }
    const [catalog, progress] = await Promise.all([api.catalog(), api.myProgress()])
    return { catalog, progress, quiz: progress.filter((p) => typeof p.score === 'number') }
  }, [api])

  const catalog = data?.catalog ?? []
  const progress = data?.progress ?? []
  const completedIds = useMemo(() => new Set(progress.filter((p) => p.status === 'completed').map((p) => p.lesson_id)), [progress])
  const completedLessons = catalog.filter((l) => completedIds.has(l.id))
  const totalMinutes = Math.round(progress.reduce((s, p) => s + (p.time_spent_sec || 0), 0) / 60)
  const avgScore = useMemo(() => {
    const scores = progress.filter((p) => typeof p.score === 'number').map((p) => p.score as number)
    return scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null
  }, [progress])

  const streak = useMemo(() => {
    const days = new Set(activityDays(progress))
    let n = 0; const cursor = new Date()
    while (days.has(cursor.toDateString())) { n++; cursor.setDate(cursor.getDate() - 1) }
    return n
  }, [progress])

  const activity = useMemo(() => buildActivity(progress, 14), [progress])
  const maxDay = Math.max(1, ...activity.map((a) => a.count))

  const levelStats = useMemo(() => LEVELS.map((lv) => {
    const list = catalog.filter((l) => l.level === lv)
    const done = list.filter((l) => completedIds.has(l.id)).length
    return { level: lv, total: list.length, done }
  }).filter((s) => s.total > 0), [catalog, completedIds])

  if (loading) return <div className="space-y-4"><Skeleton className="h-32" /><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-28" />)}</div><Skeleton className="h-56" /></div>
  if (error) return <ErrorState onRetry={reload} />

  const hasAnything = progress.length > 0

  return (
    <div className="space-y-7">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Chip><Route className="size-3" /> پیشرفت من</Chip>
          <h1 className="mt-3 text-2xl font-extrabold">مسیر یادگیری‌ات</h1>
          <p className="mt-2 max-w-2xl text-[13px] leading-7 text-ink-muted">
            همه اعداد این صفحه از فعالیت واقعی خودت محاسبه می‌شود — هیچ عدد نمایشی در LINGU وجود ندارد.
          </p>
          {profile?.goal && <p className="mt-2 flex items-center gap-1.5 text-[11.5px] text-ink-faint"><Target className="size-3.5" /> هدف: {GOAL_FA[profile.goal] ?? profile.goal}</p>}
        </div>
        <Link to="/app/lessons"><Button variant="outline">ادامه یادگیری</Button></Link>
      </header>

      {!hasAnything ? (
        <EmptyState
          icon={<BarChart3 className="size-6" />}
          title="هنوز پیشرفتی ثبت نشده"
          body="به‌محض باز کردن اولین درس، درصد تکمیل، زمان یادگیری، امتیاز آزمون‌ها و نمودار فعالیت اینجا ساخته می‌شود."
          action={<Link to="/app/lessons"><Button>شروع یادگیری</Button></Link>}
        />
      ) : (
        <>
          <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard title="درس کامل‌شده" value={completedLessons.length} icon={<Trophy className="size-4" />} hint={`از ${faNum(catalog.length)} درس منتشرشده`} />
            <StatCard title="دقیقه یادگیری" value={totalMinutes} icon={<Clock className="size-4" />} hint="مجموع زمان ثبت‌شده" tone="success" />
            <StatCard title="امتیاز آزمون‌ها" value={avgScore === null ? '—' : `${faNum(avgScore)}٪`} icon={<Award className="size-4" />} hint={avgScore === null ? 'هنوز آزمونی ثبت نشده' : 'میانگین امتیاز واقعی'} />
            <StatCard title="روز پیوسته" value={streak} icon={<Flame className="size-4" />} hint={streak ? 'زنجیره فعال یادگیری' : 'امروز شروع کن'} tone={streak ? 'warn' : 'primary'} />
          </section>

          <section className="grid gap-5 lg:grid-cols-[1.5fr_1fr]">
            <Card className="!p-6">
              <SectionTitle title="فعالیت ۱۴ روز گذشته" subtitle="هر میله، روزهایی است که واقعاً درس خوانده‌ای." />
              <div className="mt-6 flex h-40 items-end justify-between gap-1.5">
                {activity.map((d) => (
                  <div key={d.key} className="group flex flex-1 flex-col items-center gap-2">
                    <motion.div initial={{ height: 0 }} animate={{ height: `${d.count ? Math.max(10, (d.count / maxDay) * 100) : 3}%` }}
                      transition={{ duration: 0.5, delay: 0.03 * activity.indexOf(d), ease: [0.22, 1, 0.36, 1] }}
                      className={cn('w-full rounded-t-lg', d.count ? 'bg-brand-grad' : 'bg-line/60')}
                      title={`${d.label}: ${faNum(d.count)} فعالیت`} />
                    <span className="text-[9px] text-ink-faint">{d.label}</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 flex items-center justify-between border-t border-line/60 pt-4 text-[11px] text-ink-faint">
                <span className="flex items-center gap-1.5"><CalendarDays className="size-3.5" /> مجموع فعالیت ثبت‌شده: {faNum(progress.length)}</span>
                <span className="flex items-center gap-1.5"><TrendingUp className="size-3.5" /> بیشینه روزانه: {faNum(maxDay)}</span>
              </div>
            </Card>

            <Card className="!p-6">
              <SectionTitle title="نگاه کلی" />
              <div className="mt-6 flex flex-wrap items-center justify-center gap-6">
                <Ring value={catalog.length ? Math.round((completedLessons.length / catalog.length) * 100) : 0} label="تکمیل کتابخانه" />
              </div>
              <div className="mt-6 space-y-3">
                {languages.map((l) => {
                  const list = catalog.filter((c) => c.language_code === l.code)
                  const done = list.filter((c) => completedIds.has(c.id)).length
                  const pct = list.length ? Math.round((done / list.length) * 100) : 0
                  return (
                    <div key={l.code}>
                      <div className="mb-1.5 flex items-center justify-between text-[11px] font-bold text-ink-muted">
                        <span>{l.flag} {l.name_fa}</span><span>{faNum(done)}/{faNum(list.length)} · {faNum(pct)}٪</span>
                      </div>
                      <Progress value={pct} />
                    </div>
                  )
                })}
              </div>
            </Card>
          </section>

          {levelStats.length > 0 && (
            <section>
              <SectionTitle title="پیشرفت بر اساس سطح" subtitle="بر پایه درس‌های منتشرشده در هر سطح." />
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                {levelStats.map((s) => (
                  <Card key={s.level} className="!p-4">
                    <div className="flex items-center justify-between">
                      <span className="text-[13px] font-extrabold">{s.level}</span>
                      <span className="text-[10px] text-ink-faint">{faNum(s.done)}/{faNum(s.total)}</span>
                    </div>
                    <Progress className="mt-3" value={Math.round((s.done / s.total) * 100)} />
                  </Card>
                ))}
              </div>
            </section>
          )}

          <section>
            <SectionTitle title="درس‌های من" subtitle="فهرست واقعی با وضعیت هر درس." />
            <div className="space-y-3">
              {completedLessons.map((l) => (
                <Card key={l.id} className="flex flex-wrap items-center justify-between gap-3 !p-4">
                  <div className="flex items-center gap-3">
                    <span className="grid size-10 place-items-center rounded-2xl bg-success/15 text-success"><CheckCircle2 className="size-5" /></span>
                    <div>
                      <p className="text-[12.5px] font-extrabold">{l.title}</p>
                      <p className="mt-0.5 text-[10.5px] text-ink-faint">
                        {languages.find((x) => x.code === l.language_code)?.name_fa} · سطح {l.level} · {faNum(l.estimated_minutes)} دقیقه
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[10.5px] text-ink-faint">{faDate(lastActivityAt(progress, l.id))}</span>
                    <Link to={`/app/lessons/${l.id}`}><Button size="sm" variant="outline">مرور</Button></Link>
                  </div>
                </Card>
              ))}

              {progress.filter((p) => p.status !== 'completed').map((p) => {
                const l = catalog.find((c) => c.id === p.lesson_id)
                if (!l) return null
                const pct = Math.min(95, Math.round(((p.sections_done?.length ?? 0) / LESSON_SECTIONS.length) * 100))
                return (
                  <Card key={p.lesson_id} className="flex flex-wrap items-center justify-between gap-3 !p-4">
                    <div className="flex items-center gap-3">
                      <span className="grid size-10 place-items-center rounded-2xl bg-brand-soft text-primary-soft"><BookOpenCheck className="size-5" /></span>
                      <div className="min-w-[200px]">
                        <p className="text-[12.5px] font-extrabold">{l.title}</p>
                        <p className="mt-0.5 text-[10.5px] text-ink-faint">در حال یادگیری · {faNum(pct)}٪ · بخش {p.last_section ?? '—'}</p>
                      </div>
                    </div>
                    <Link to={`/app/lessons/${l.id}`}><Button size="sm">ادامه</Button></Link>
                  </Card>
                )
              })}

              {catalog.filter((l) => l.locked && !completedIds.has(l.id)).length > 0 && !membership.premium && (
                <Card className="relative overflow-hidden !p-5">
                  <div className="absolute inset-0 bg-brand-soft opacity-25" />
                  <div className="relative flex flex-wrap items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <span className="grid size-10 place-items-center rounded-2xl bg-warn/15 text-warn"><Lock className="size-4" /></span>
                      <div>
                        <p className="text-[12.5px] font-extrabold">
                          {faNum(catalog.filter((l) => l.locked && !completedIds.has(l.id)).length)} درس دیگر با اشتراک باز می‌شود
                        </p>
                        <p className="mt-0.5 text-[11px] text-ink-muted">درس‌های رایگان و پیشرفت فعلی‌ات همیشه محفوظ می‌ماند.</p>
                      </div>
                    </div>
                    <Link to="/app/subscription"><Button size="sm"><Crown className="size-4" /> دیدن پلن‌ها</Button></Link>
                  </div>
                </Card>
              )}
            </div>
          </section>
        </>
      )}
    </div>
  )
}

/* helpers */
function activityDays(progress: { started_at: string; completed_at: string | null }[]) {
  return progress.map((p) => new Date(p.completed_at || p.started_at).toDateString())
}

function buildActivity(progress: { started_at: string; completed_at: string | null }[], days: number) {
  const out: { key: string; label: string; count: number }[] = []
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i)
    const key = d.toDateString()
    out.push({
      key,
      label: faNum(Number(new Intl.DateTimeFormat('fa-IR-u-ca-persian', { day: 'numeric' }).format(d))),
      count: progress.filter((p) => new Date(p.completed_at || p.started_at).toDateString() === key).length,
    })
  }
  return out
}

const lastActivityAt = (progress: { lesson_id: string; started_at: string; completed_at: string | null }[], lessonId: string) => {
  const p = progress.find((x) => x.lesson_id === lessonId)
  return p?.completed_at || p?.started_at || new Date().toISOString()
}
