import { motion } from 'motion/react'
import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import {
  ArrowLeft, BookOpen, CheckCircle2, Clock, Crown, Filter, Layers, Lock, PlayCircle, Search, Sparkles,
} from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { Button, Card, Chip, EmptyState, ErrorState, Progress, Skeleton, StaggerGroup, staggerItem } from '@/components/ui'
import { cn, faNum } from '@/lib/utils'
import { LEVELS, LESSON_SECTIONS } from '@/lib/constants'

export default function Lessons() {
  const { api, languages, membership, settings } = useApp()
  const nav = useNavigate()
  const [lang, setLang] = useState<string>('all')
  const [level, setLevel] = useState<string>('all')
  const [access, setAccess] = useState<'all' | 'free' | 'premium'>('all')
  const [q, setQ] = useState('')

  const { data, loading, error, reload } = useAsync(async () => {
    if (!api) return { catalog: [], progress: [] }
    const [catalog, progress] = await Promise.all([api.catalog(), api.myProgress()])
    return { catalog, progress }
  }, [api])

  const catalog = data?.catalog ?? []
  const progress = data?.progress ?? []
  const completedIds = useMemo(() => new Set(progress.filter((p) => p.status === 'completed').map((p) => p.lesson_id)), [progress])
  const freePerLanguage = Number(settings.learning?.free_lessons_per_language ?? 2)

  const filtered = useMemo(() => catalog.filter((l) => {
    if (lang !== 'all' && l.language_code !== lang) return false
    if (level !== 'all' && l.level !== level) return false
    if (access === 'free' && l.locked) return false
    if (access === 'premium' && !l.locked) return false
    if (q.trim() && !(l.title + ' ' + (l.subtitle ?? '')).toLowerCase().includes(q.trim().toLowerCase())) return false
    return true
  }), [catalog, lang, level, access, q])

  const counts = useMemo(() => Object.fromEntries(languages.map((l) => [
    l.code, catalog.filter((c) => c.language_code === l.code).length,
  ])), [catalog, languages])

  const nextToContinue = useMemo(() => {
    const started = progress.find((p) => p.status === 'started')
    return started ? catalog.find((c) => c.id === started.lesson_id) ?? null : null
  }, [catalog, progress])

  return (
    <div className="space-y-7">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Chip><BookOpen className="size-3" /> کتابخانه درس‌ها</Chip>
          <h1 className="mt-3 text-2xl font-extrabold">درس‌ها</h1>
          <p className="mt-2 max-w-2xl text-[13px] leading-7 text-ink-muted">
            هر درس {faNum(LESSON_SECTIONS.length)} بخش دارد: گرم‌کردن، توضیح، واژگان، گرامر، مثال، شنیداری، دیالوگ، گفت‌وگو، خواندن، تمرین، آزمون و تمرین با AI.
          </p>
        </div>
        {nextToContinue && (
          <Button onClick={() => nav(`/app/lessons/${nextToContinue.id}`)}>
            <PlayCircle className="size-4" /> ادامه {nextToContinue.title}
          </Button>
        )}
      </header>

      {/* filters */}
      <Card className="!p-4">
        <div className="flex flex-wrap items-center gap-3">
          <span className="flex items-center gap-1.5 text-[11px] font-bold text-ink-faint"><Filter className="size-3.5" /> فیلترها</span>

          <div className="flex flex-wrap gap-2">
            <FilterPill active={lang === 'all'} onClick={() => setLang('all')}>همه زبان‌ها ({faNum(catalog.length)})</FilterPill>
            {languages.map((l) => (
              <FilterPill key={l.code} active={lang === l.code} onClick={() => setLang(l.code)}>
                {l.flag} {l.name_fa} ({faNum(counts[l.code] ?? 0)})
              </FilterPill>
            ))}
          </div>

          <div className="mx-1 hidden h-6 w-px bg-line/80 sm:block" />

          <div className="flex flex-wrap gap-2">
            <FilterPill active={level === 'all'} onClick={() => setLevel('all')}>همه سطوح</FilterPill>
            {LEVELS.map((l) => <FilterPill key={l} active={level === l} onClick={() => setLevel(l)}>{l}</FilterPill>)}
          </div>

          <div className="mx-1 hidden h-6 w-px bg-line/80 sm:block" />

          <div className="flex flex-wrap gap-2">
            <FilterPill active={access === 'all'} onClick={() => setAccess('all')}>همه</FilterPill>
            <FilterPill active={access === 'free'} onClick={() => setAccess('free')}>رایگان</FilterPill>
            <FilterPill active={access === 'premium'} onClick={() => setAccess('premium')}>Premium</FilterPill>
          </div>

          <label className="mr-auto flex h-10 min-w-[190px] flex-1 items-center gap-2 rounded-2xl border border-line/80 bg-bg-soft/50 px-3 sm:flex-none">
            <Search className="size-3.5 text-ink-faint" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجو در درس‌ها…"
              className="w-full bg-transparent text-[11.5px] outline-none placeholder:text-ink-faint" />
          </label>
        </div>
      </Card>

      {loading && <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{[0, 1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-44" />)}</div>}

      {error && <ErrorState body={error} onRetry={reload} />}

      {!loading && !error && catalog.length === 0 && (
        <EmptyState
          icon={<Layers className="size-6" />}
          title="هنوز درسی منتشر نشده"
          body="محتوای درس‌ها از Content Factory در پنل مدیریت تولید و منتشر می‌شود. پس از انتشار، همین‌جا فهرست کامل را می‌بینی."
          action={<Link to="/app"><Button variant="outline">بازگشت به داشبورد</Button></Link>}
        />
      )}

      {!loading && !error && catalog.length > 0 && filtered.length === 0 && (
        <EmptyState
          icon={<Search className="size-6" />}
          title="با این فیلترها درسی پیدا نشد"
          body="فیلتر زبان، سطح یا جستجو را تغییر بده تا درس‌های موجود را ببینی."
          action={<Button variant="outline" onClick={() => { setLang('all'); setLevel('all'); setAccess('all'); setQ('') }}>پاک کردن فیلترها</Button>}
        />
      )}

      {filtered.length > 0 && (
        <StaggerGroup className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((l) => {
            const done = completedIds.has(l.id)
            const p = progress.find((x) => x.lesson_id === l.id)
            const pct = done ? 100 : p ? Math.min(95, Math.round(((p.sections_done?.length ?? 0) / LESSON_SECTIONS.length) * 100)) : 0
            const langMeta = languages.find((x) => x.code === l.language_code)
            return (
              <motion.div key={l.id} variants={staggerItem}>
                <Link to={`/app/lessons/${l.id}`}>
                  <motion.div whileHover={{ y: -5 }} transition={{ type: 'spring', stiffness: 300, damping: 24 }} className="h-full">
                    <Card className={cn('flex h-full flex-col !p-0 overflow-hidden', done && 'border-success/35')}>
                      <div className={cn('h-1.5 w-full bg-gradient-to-l', langMeta?.gradient ?? 'from-primary to-secondary')} />
                      <div className="flex flex-1 flex-col p-5">
                        <div className="flex items-center justify-between gap-2">
                          <span className="flex items-center gap-2 text-[10.5px] font-bold text-ink-faint">
                            <span className="rounded-lg border border-line/80 px-2 py-0.5">{l.level}</span>
                            <span>{langMeta?.flag} {langMeta?.name_fa}</span>
                          </span>
                          {done
                            ? <Chip tone="success" className="!px-2 !py-0.5 !text-[10px]"><CheckCircle2 className="size-3" /> کامل</Chip>
                            : l.locked
                              ? <Chip tone="warn" className="!px-2 !py-0.5 !text-[10px]"><Lock className="size-3" /> Premium</Chip>
                              : <Chip tone="primary" className="!px-2 !py-0.5 !text-[10px]"><Sparkles className="size-3" /> رایگان</Chip>}
                        </div>

                        <p className="mt-3 text-[10px] font-bold text-ink-faint">درس {faNum(l.order_index)}</p>
                        <h3 className="mt-1 text-[15px] font-extrabold leading-7">{l.title}</h3>
                        <p className="mt-1.5 flex-1 text-[11.5px] leading-6 text-ink-muted">{l.subtitle}</p>

                        <div className="mt-4">
                          {pct > 0 && <Progress value={pct} className="mb-2.5" />}
                          <div className="flex items-center justify-between text-[10.5px] text-ink-faint">
                            <span className="flex items-center gap-1"><Clock className="size-3" /> {faNum(l.estimated_minutes)} دقیقه</span>
                            <span className="flex items-center gap-1"><Layers className="size-3" /> {faNum(LESSON_SECTIONS.length)} بخش</span>
                            {pct > 0 && <span className="font-bold text-primary-soft">{faNum(pct)}٪</span>}
                          </div>
                        </div>

                        <span className="mt-4 inline-flex items-center gap-1.5 text-[11.5px] font-extrabold text-primary-soft">
                          {done ? 'مرور دوباره' : pct > 0 ? 'ادامه درس' : l.locked && !membership.premium ? 'نیازمند اشتراک' : 'شروع درس'}
                          <ArrowLeft className="size-3.5" />
                        </span>
                      </div>
                    </Card>
                  </motion.div>
                </Link>
              </motion.div>
            )
          })}
        </StaggerGroup>
      )}

      {!membership.premium && catalog.some((l) => l.locked) && (
        <Card className="relative overflow-hidden !p-6">
          <div className="absolute inset-0 bg-brand-soft opacity-30" />
          <div className="relative flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <span className="grid size-11 place-items-center rounded-2xl bg-brand-grad text-white"><Crown className="size-5" /></span>
              <div>
                <h3 className="text-[13.5px] font-extrabold">درس‌های Premium قفل هستند</h3>
                <p className="mt-1 max-w-xl text-[11.5px] leading-7 text-ink-muted">
                  {faNum(freePerLanguage)} درس کامل از هر زبان برای همیشه رایگان است. با اشتراک، همه درس‌های منتشرشده و ابزارهای AI باز می‌شوند.
                </p>
              </div>
            </div>
            <Link to="/app/subscription"><Button><Crown className="size-4" /> دیدن پلن‌ها</Button></Link>
          </div>
        </Card>
      )}
    </div>
  )
}

function FilterPill({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick}
      className={cn('rounded-2xl border px-3 py-1.5 text-[11px] font-bold transition-all',
        active ? 'border-primary/45 bg-primary/10 text-primary-soft' : 'border-line/80 text-ink-muted hover:border-primary/35 hover:text-ink')}>
      {children}
    </button>
  )
}
