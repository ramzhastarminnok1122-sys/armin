import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft, ArrowRight, Check, LayoutDashboard, Rocket, Sparkles, Target, Globe2 } from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { Button, Chip } from '@/components/ui'
import { Logo } from '@/components/layout/Brand'
import { cn, faNum } from '@/lib/utils'
import { GOALS } from '@/lib/constants'

const STEPS = ['خوش آمدی', 'انتخاب زبان', 'هدف تو', 'داشبورد تو'] as const

export default function Onboarding() {
  const { profile, languages, media, completeOnboarding, toast } = useApp()
  const nav = useNavigate()
  const [step, setStep] = useState(0)
  const [lang, setLang] = useState<string>(profile?.target_language ?? 'en')
  const [goal, setGoal] = useState<string>(profile?.goal ?? '')
  const [saving, setSaving] = useState(false)

  useEffect(() => { document.title = 'خوش آمدی · LINGU' }, [])

  const canNext = step === 0 || (step === 1 && !!lang) || (step === 2 && !!goal) || step === 3

  const finish = async () => {
    setSaving(true)
    try {
      await completeOnboarding({ target_language: lang, goal: goal || 'personal' })
      toast('خوش آمدی به LINGU! مسیر یادگیری‌ات آماده است.', 'success')
      nav('/app', { replace: true })
    } catch {
      toast('ذخیره انتخاب‌ها انجام نشد. دوباره تلاش کن.', 'error')
    } finally { setSaving(false) }
  }

  const next = () => (step < 3 ? setStep((s) => s + 1) : finish())

  return (
    <div className="relative min-h-[100dvh] overflow-hidden bg-bg">
      <div className="pointer-events-none absolute inset-0 opacity-70">
        <div className="absolute -right-24 -top-24 size-[420px] rounded-full bg-primary/20 blur-3xl" />
        <div className="absolute -left-16 bottom-0 size-[360px] rounded-full bg-accent/15 blur-3xl" />
      </div>

      <div className="relative mx-auto flex min-h-[100dvh] w-full max-w-4xl flex-col px-5 py-7">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5"><Logo size={34} /><span className="text-lg font-extrabold">LINGU</span></div>
          <button onClick={finish} className="text-[11.5px] font-bold text-ink-faint hover:text-ink">رد کردن</button>
        </div>

        {/* progress */}
        <div className="mt-7 flex items-center gap-2">
          {STEPS.map((s, i) => (
            <div key={s} className="flex flex-1 items-center gap-2">
              <span className={cn('grid size-7 shrink-0 place-items-center rounded-full text-[11px] font-extrabold transition-all',
                i < step ? 'bg-success text-white' : i === step ? 'bg-brand-grad text-white' : 'bg-card-soft text-ink-faint')}>
                {i < step ? <Check className="size-3.5" /> : faNum(i + 1)}
              </span>
              <span className={cn('hidden text-[11px] font-bold sm:block', i === step ? 'text-ink' : 'text-ink-faint')}>{s}</span>
              {i < STEPS.length - 1 && <span className={cn('h-px flex-1 rounded', i < step ? 'bg-success/50' : 'bg-line')} />}
            </div>
          ))}
        </div>

        <div className="relative mt-8 flex-1">
          <AnimatePresence mode="wait">
            <motion.div key={step}
              initial={{ opacity: 0, x: -40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 40 }}
              transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}>
              {step === 0 && (
                <div className="grid items-center gap-8 lg:grid-cols-2">
                  <div>
                    <Chip tone="primary"><Sparkles className="size-3" /> قدم ۱ از ۴</Chip>
                    <h1 className="mt-4 text-3xl font-extrabold leading-[1.35]">خوش آمدی به LINGU 👋</h1>
                    <p className="mt-4 text-[13.5px] leading-8 text-ink-muted">
                      اینجا زبان را فقط نمی‌خوانی؛ با درس‌های ۱۲ بخشی، مربی هوشمند و هم‌صحبت نقش‌محور
                      <span className="mx-1 font-bold text-ink">واقعاً یاد می‌گیری</span>.
                      سه سؤال کوتاه می‌پرسیم تا مسیر تو را بچینیم.
                    </p>
                    <div className="mt-6 flex flex-wrap gap-2">
                      <Chip><Globe2 className="size-3" /> سه زبان</Chip>
                      <Chip><Rocket className="size-3" /> ۱۲ بخش در هر درس</Chip>
                      <Chip><Check className="size-3" /> ۲ درس رایگان هر زبان</Chip>
                    </div>
                  </div>
                  <img src={media.onboarding?.url} alt="" className="mx-auto w-full max-w-sm rounded-4xl border border-line/70 shadow-soft" />
                </div>
              )}

              {step === 1 && (
                <div>
                  <h2 className="text-2xl font-extrabold">کدام زبان را یاد می‌گیری؟</h2>
                  <p className="mt-2 text-[12.5px] leading-7 text-ink-muted">می‌توانی بعداً از تنظیمات تغییر دهی یا هر سه را موازی پیش ببری.</p>
                  <div className="mt-6 grid gap-4 sm:grid-cols-3">
                    {languages.map((l) => (
                      <motion.button key={l.code} onClick={() => setLang(l.code)} whileHover={{ y: -5 }} whileTap={{ scale: 0.98 }}
                        transition={{ type: 'spring', stiffness: 300, damping: 24 }} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
                        className={cn('overflow-hidden rounded-4xl border bg-card/80 p-0 text-right transition-all',
                          lang === l.code ? 'border-primary ring-2 ring-primary/35' : 'border-line/70 hover:border-primary/45')}>
                        <img src={media[`lang_${l.code}`]?.url} alt="" className="h-28 w-full object-cover" />
                        <div className="p-4">
                          <div className="flex items-center justify-between">
                            <span className="text-[13px] font-extrabold">{l.flag} {l.name_fa}</span>
                            {lang === l.code && <span className="grid size-5 place-items-center rounded-full bg-brand-grad text-white"><Check className="size-3" /></span>}
                          </div>
                          <p className="mt-1.5 text-[10.5px] leading-5 text-ink-faint">{l.description}</p>
                        </div>
                      </motion.button>
                    ))}
                  </div>
                </div>
              )}

              {step === 2 && (
                <div>
                  <h2 className="text-2xl font-extrabold">هدفت از یادگیری چیست؟</h2>
                  <p className="mt-2 text-[12.5px] leading-7 text-ink-muted">با هدف تو، پیشنهادها و تمرین‌های برنامه مناسب‌تر می‌شوند.</p>
                  <div className="mt-6 grid gap-4 sm:grid-cols-2">
                    {GOALS.map((g, i) => (
                      <motion.button key={g.id} onClick={() => setGoal(g.id)} whileHover={{ y: -4 }} whileTap={{ scale: 0.98 }}
                        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
                        className={cn('flex items-start gap-3.5 rounded-4xl border bg-card/80 p-5 text-right transition-all',
                          goal === g.id ? 'border-primary ring-2 ring-primary/35' : 'border-line/70 hover:border-primary/45')}>
                        <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-brand-soft text-xl">{g.emoji}</span>
                        <span className="min-w-0">
                          <span className="flex items-center gap-2 text-[13.5px] font-extrabold">
                            <Target className="size-3.5 text-primary-soft" /> {g.label_fa}
                            {goal === g.id && <Check className="size-3.5 text-success" />}
                          </span>
                          <span className="mt-1 block text-[11.5px] leading-6 text-ink-muted">{g.desc_fa}</span>
                        </span>
                      </motion.button>
                    ))}
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="grid items-center gap-8 lg:grid-cols-2">
                  <div>
                    <Chip tone="success"><LayoutDashboard className="size-3" /> آخرین قدم</Chip>
                    <h2 className="mt-4 text-2xl font-extrabold">با داشبورد یادگیری‌ات آشنا شو</h2>
                    <ul className="mt-5 space-y-3.5">
                      {[
                        ['ادامه یادگیری', 'هر بار از همان بخشی که مانده بودی ادامه می‌دهی.'],
                        ['زبان‌ها و پیشرفت', 'مسیر هر زبان جداگانه ذخیره و نمایش داده می‌شود.'],
                        ['AI Tutor و Conversation Partner', 'هم توضیح می‌گیری، هم در موقعیت‌های واقعی مکالمه تمرین می‌کنی.'],
                      ].map(([t, b]) => (
                        <li key={t} className="flex gap-3">
                          <span className="mt-1 grid size-5 shrink-0 place-items-center rounded-full bg-success/15 text-success"><Check className="size-3" /></span>
                          <span><span className="block text-[12.5px] font-extrabold">{t}</span><span className="text-[11.5px] leading-6 text-ink-muted">{b}</span></span>
                        </li>
                      ))}
                    </ul>
                    <p className="mt-6 rounded-3xl border border-line/70 bg-card/70 p-4 text-[11.5px] leading-7 text-ink-muted">
                      انتخاب‌های تو: زبان <b className="text-ink">{languages.find((l) => l.code === lang)?.name_fa}</b> ·
                      هدف <b className="text-ink">{GOALS.find((g) => g.id === goal)?.label_fa ?? 'انتخاب‌نشده'}</b>
                    </p>
                  </div>
                  <img src={media.onboarding?.url} alt="" className="mx-auto w-full max-w-sm rounded-4xl border border-line/70 shadow-soft" />
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="mt-8 flex items-center justify-between gap-3 border-t border-line/60 pt-5">
          <Button variant="ghost" onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0}>
            <ArrowRight className="size-4" /> قبلی
          </Button>
          <div className="flex items-center gap-2">
            {step < 3 && <button onClick={finish} className="text-[11.5px] font-bold text-ink-faint hover:text-ink">رد کردن</button>}
            <Button onClick={next} disabled={!canNext} loading={saving} size="lg">
              {step === 3 ? 'شروع یادگیری' : 'بعدی'} <ArrowLeft className="size-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
