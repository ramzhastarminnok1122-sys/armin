import { motion } from 'motion/react'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import {
  BadgeCheck, BookOpen, Check, CheckCircle2, Crown, Gem, Info, Infinity as InfinityIcon, Minus, Smartphone,
  Sparkles, Star, Timer, TrendingUp, X,
} from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { Button, Card, Chip, Modal, Progress, SectionTitle, Skeleton } from '@/components/ui'
import { faDate, faNum, faPrice } from '@/lib/utils'
import type { Plan } from '@/services/types'

const COMPARE: { label: string; free: string | boolean; premium: string | boolean }[] = [
  { label: 'درس کامل در English', free: '۲ درس', premium: 'همه درس‌ها' },
  { label: 'درس کامل در French', free: '۲ درس', premium: 'همه درس‌ها' },
  { label: 'درس کامل در Spanish', free: '۲ درس', premium: 'همه درس‌ها' },
  { label: 'AI Tutor', free: false, premium: true },
  { label: 'Conversation Partner', free: '۲ پیام همیشگی', premium: 'بدون محدودیت' },
  { label: 'ثبت پیشرفت', free: 'درس‌های رایگان', premium: 'همه درس‌ها' },
  { label: 'درس‌های جدید هفتگی', free: false, premium: true },
]

export default function Subscription() {
  const { plans, membership, session, languages } = useApp()
  const [selected, setSelected] = useState<Plan | null>(null)
  const [busyPlan, setBusyPlan] = useState<string | null>(null)

  const freePlan = plans.find((p) => p.code === 'free')
  const premiumPlans = plans.filter((p) => p.code !== 'free').sort((a, b) => a.sort_order - b.sort_order)

  const startPurchase = (plan: Plan) => {
    setBusyPlan(plan.id)
    window.setTimeout(() => { setBusyPlan(null); setSelected(plan) }, 350)
  }

  return (
    <div className="space-y-6">
      {/* ------------------------------- header ------------------------------- */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Chip tone="primary"><Crown className="size-3" /> اشتراک</Chip>
          <h1 className="mt-3 text-2xl font-extrabold sm:text-3xl">پلن‌ها و دسترسی</h1>
          <p className="mt-2 max-w-2xl text-sm leading-7 text-ink-muted">
            حساب رایگان برای همیشه رایگان است — بدون دوره آزمایشی و بدون محدودیت زمانی. اشتراک فقط دسترسی تو را بازتر می‌کند.
          </p>
        </div>
        {membership.premium && (
          <Chip tone="success" className="!text-xs"><BadgeCheck className="size-3.5" /> اشتراک فعال — {membership.plan?.title_fa}</Chip>
        )}
      </div>

      {/* --------------------------- current status card --------------------------- */}
      <Card className="relative overflow-hidden !p-6">
        <div className="absolute inset-0 bg-mesh opacity-60" />
        <div className="relative grid gap-6 lg:grid-cols-[1.3fr_1fr]">
          <div>
            <div className="flex items-center gap-3">
              <span className="grid size-12 place-items-center rounded-2xl bg-brand-grad text-white shadow-glow">
                {membership.premium ? <Gem className="size-6" /> : <Sparkles className="size-6" />}
              </span>
              <div>
                <p className="text-[11px] font-bold text-ink-faint">وضعیت فعلی حساب</p>
                <h2 className="text-xl font-extrabold">{membership.premium ? 'Premium فعال' : 'حساب رایگان (همیشه رایگان)'}</h2>
              </div>
            </div>
            <p className="mt-4 text-sm leading-8 text-ink-muted">
              {membership.premium
                ? <>اشتراک تو تا <b className="text-ink">{faDate(membership.subscription?.end_date)}</b> فعال است. همه درس‌ها، AI Tutor و Conversation Partner در دسترس تو هستند.</>
                : <>در حساب رایگان {faNum(2)} درس کامل در هر زبان و {faNum(2)} پیام Conversation Partner داری — برای همیشه، بدون انقضا.</>}
            </p>
            {membership.premium && membership.days_left !== null && (
              <div className="mt-5 max-w-md">
                <div className="mb-2 flex items-center justify-between text-[11px] font-bold text-ink-muted">
                  <span>باقی‌مانده اشتراک</span><span>{faNum(membership.days_left)} روز</span>
                </div>
                <Progress value={Math.min(100, (membership.days_left / 30) * 100)} />
              </div>
            )}
          </div>

          <div className="rounded-3xl border border-line/70 bg-card/50 p-5">
            <p className="text-xs font-extrabold">دسترسی فعلی تو</p>
            <div className="mt-4 space-y-2.5 text-[11px]">
              <AccessRow label="زبان‌ها" value={membership.premium ? `${faNum(languages.length)} زبان کامل` : `${faNum(languages.length)} زبان · ${faNum(2)} درس هر کدام`} ok />
              <AccessRow label="AI Tutor" value={membership.premium ? 'فعال' : 'نیازمند اشتراک'} ok={membership.premium} />
              <AccessRow label="Conversation Partner" value={membership.premium ? 'بدون محدودیت' : '۲ پیام رایگان'} ok={membership.premium} />
              <AccessRow label="پیشرفت" value={membership.premium ? 'همه درس‌ها' : 'درس‌های رایگان'} ok />
            </div>
          </div>
        </div>
      </Card>

      {/* --------------------------- promo headline --------------------------- */}
      {(() => {
        const promo = premiumPlans.find((p) => p.promo_active && p.promo_price)
        if (!promo) return null
        return (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
            <Card className="relative overflow-hidden border-warn/35 !p-5">
              <div className="absolute inset-0 bg-warn/8" />
              <div className="relative flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <span className="grid size-11 place-items-center rounded-2xl bg-warn/20 text-warn"><Sparkles className="size-5" /></span>
                  <div>
                    <h3 className="text-[14px] font-extrabold">{promo.promo_label ?? 'پیشنهاد ویژه'}</h3>
                    <p className="mt-1 text-[11.5px] leading-6 text-ink-muted">
                      اشتراک {promo.title_fa} با قیمت {faNum(promo.original_price)} تومان به {faNum(promo.promo_price)} تومان کاهش یافته است
                      {promo.promo_ends_at ? <> تا <b className="text-ink">{faDate(promo.promo_ends_at)}</b></> : null}.
                    </p>
                  </div>
                </div>
                <Button onClick={() => startPurchase(promo)} loading={busyPlan === promo.id}>استفاده از پیشنهاد</Button>
              </div>
            </Card>
          </motion.div>
        )
      })()}

      {/* ------------------------------- plans ------------------------------- */}
      {plans.length === 0 ? (
        <div className="grid gap-4 lg:grid-cols-4">{[0, 1, 2, 3].map((i) => <div key={i} className="card-surface h-72 p-5"><Skeleton className="h-6 w-1/2" /></div>)}</div>
      ) : (
        <div className="grid gap-5 lg:grid-cols-4">
          {freePlan && (
            <Card className="flex h-full flex-col !p-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-extrabold">{freePlan.title_fa}</h3>
                <Chip>فعلی</Chip>
              </div>
              <p className="mt-1 text-[11px] leading-6 text-ink-muted">{freePlan.subtitle_fa}</p>
              <p className="mt-5 text-3xl font-extrabold">۰ <span className="text-sm font-bold text-ink-faint">ریال</span></p>
              <p className="mt-1 text-[11px] text-ink-faint">برای همیشه</p>
              <ul className="mt-5 flex-1 space-y-2.5 text-[12px]">
                {freePlan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-ink-muted"><Check className="mt-0.5 size-3.5 shrink-0 text-success" /> {f}</li>
                ))}
              </ul>
              <Button variant="outline" className="mt-6 w-full" disabled>پلن فعلی توست</Button>
            </Card>
          )}

          {premiumPlans.map((p, i) => {
            const isCurrent = membership.premium && membership.plan?.id === p.id
            return (
              <motion.div key={p.id} initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07, duration: 0.4 }}>
                <Card className={`flex h-full flex-col !p-6 ${p.is_recommended ? 'border-primary/45 shadow-glow' : ''}`}>
                  {p.is_recommended && (
                    <div className="absolute -top-3 right-6">
                      <Chip tone="primary" className="!bg-brand-grad !text-white !border-transparent"><Star className="size-3" /> پیشنهاد LINGU</Chip>
                    </div>
                  )}
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-extrabold">{p.title_fa}</h3>
                    {p.badge && <Chip tone="warn" className="!px-2 !py-0.5 !text-[10px]">{p.badge}</Chip>}
                  </div>
                  <p className="mt-1 text-[11px] leading-6 text-ink-muted">{p.subtitle_fa}</p>

                  {p.promo_active && p.promo_price ? (
                    <div className="mt-5">
                      {p.promo_label && <Chip tone="warn" className="mb-2 !px-2 !py-0.5 !text-[10px]"><Sparkles className="size-3" /> {p.promo_label}</Chip>}
                      <p className="flex items-end gap-2 text-2xl font-extrabold leading-tight">
                        {faNum(p.promo_price)} <span className="text-[11px] font-bold text-ink-faint">تومان</span>
                        <span className="text-[12px] font-bold text-ink-faint line-through">{faNum(p.original_price)}</span>
                      </p>
                      <p className="mt-1 text-[10.5px] font-bold text-warn">
                        {faNum(Math.round((1 - p.promo_price / Math.max(1, p.original_price)) * 100))}٪ تخفیف
                        {p.promo_ends_at ? ` · تا ${faDate(p.promo_ends_at)}` : ''}
                      </p>
                    </div>
                  ) : (
                    <p className="mt-5 text-2xl font-extrabold leading-tight">
                      {p.original_price ? <>{faNum(p.original_price)} <span className="text-[11px] font-bold text-ink-faint">تومان</span></>
                        : faPrice(p.display_price, p.price_label)}
                    </p>
                  )}
                  <p className="mt-1 flex items-center gap-1.5 text-[11px] text-ink-faint"><Timer className="size-3" /> {faNum(p.duration_days)} روز دسترسی کامل</p>

                  <ul className="mt-5 flex-1 space-y-2.5 text-[12px]">
                    {p.features.slice(0, 5).map((f) => (
                      <li key={f} className="flex items-start gap-2 text-ink-muted"><Check className="mt-0.5 size-3.5 shrink-0 text-success" /> {f}</li>
                    ))}
                  </ul>

                  <Button className="mt-6 w-full" disabled={isCurrent} loading={busyPlan === p.id} onClick={() => startPurchase(p)}>
                    {isCurrent ? <><CheckCircle2 className="size-4" /> اشتراک فعال</> : <><Crown className="size-4" /> انتخاب این پلن</>}
                  </Button>
                  <p className="mt-2 text-center text-[10px] text-ink-faint">
                    {faNum(p.duration_days)} روز دسترسی کامل · بدون تمدید خودکار
                  </p>
                </Card>
              </motion.div>
            )
          })}
        </div>
      )}

      {/* ---------------------------- compare table ---------------------------- */}
      <Card>
        <SectionTitle title="مقایسه دقیق رایگان و Premium" subtitle="بدون شرط پنهان — هرچه می‌گیری همین‌جاست." />
        <div className="overflow-x-auto">
          <table className="w-full min-w-[520px] text-sm">
            <thead>
              <tr className="border-b border-line/60 text-[11px] text-ink-faint">
                <th className="px-3 py-3 text-right font-bold">امکانات</th>
                <th className="px-3 py-3 text-center font-bold">رایگان</th>
                <th className="px-3 py-3 text-center font-bold text-primary-soft">Premium</th>
              </tr>
            </thead>
            <tbody>
              {COMPARE.map((row) => (
                <tr key={row.label} className="border-b border-line/40">
                  <td className="px-3 py-3.5 text-[13px] font-bold">{row.label}</td>
                  <td className="px-3 py-3.5 text-center text-[12px] text-ink-muted">{renderCell(row.free)}</td>
                  <td className="px-3 py-3.5 text-center text-[12px] font-bold text-ink">{renderCell(row.premium)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* --------------------------- why + how to buy --------------------------- */}
      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <SectionTitle title="چرا اشتراک؟" subtitle="چون محتوا هر هفته بزرگ‌تر می‌شود و دسترسی کامل، یادگیری را پیوسته نگه می‌دارد." />
          <ul className="space-y-3 text-[13px]">
            {[
              'دسترسی به همه درس‌های منتشرشده در English، French و Spanish',
              'AI Tutor برای هر بخش درس',
              'Conversation Partner با سناریوهای واقعی و بدون سقف پیام',
              'ثبت پیشرفت، ادامه یادگیری و دسترسی از هر دستگاه',
            ].map((t) => (
              <li key={t} className="flex items-start gap-2 text-ink-muted"><InfinityIcon className="mt-0.5 size-4 shrink-0 text-primary-soft" /> {t}</li>
            ))}
          </ul>
        </Card>

        <Card>
          <SectionTitle title="فعال‌سازی اشتراک" subtitle="اشتراک از داخل اپلیکیشن LINGU فعال می‌شود و بلافاصله روی همین حساب باز می‌گردد." />
          <ol className="space-y-3 text-[13px] text-ink-muted">
            <li className="flex items-start gap-3"><Step n={1} /> با همین حساب در اپلیکیشن LINGU وارد شو.</li>
            <li className="flex items-start gap-3"><Step n={2} /> در صفحه «اشتراک»، پلن دلخواه را انتخاب کن.</li>
            <li className="flex items-start gap-3"><Step n={3} /> پس از تأیید، دسترسی Premium همان لحظه برای این حساب فعال می‌شود.</li>
          </ol>
          <div className="mt-5 flex items-stretch gap-3 rounded-2xl border border-line/70 bg-bg-soft/50 p-4">
            <Smartphone className="mt-0.5 size-4 shrink-0 text-primary-soft" />
            <p className="text-[11px] leading-6 text-ink-muted">
              پرداخت در نسخه اندروید LINGU انجام می‌شود تا امن و قابل پیگیری باشد؛ در همین صفحه نتیجه را می‌بینی.
            </p>
          </div>
        </Card>
      </div>

      {!membership.premium && (
        <Card className="relative overflow-hidden !p-7 text-center">
          <div className="absolute inset-0 bg-brand-soft opacity-40" />
          <div className="relative mx-auto max-w-xl">
            <TrendingUp className="mx-auto size-7 text-primary-soft" />
            <h2 className="mt-4 text-2xl font-extrabold">آماده‌ی مسیر کامل هستی؟</h2>
            <p className="mt-3 text-sm leading-7 text-ink-muted">همه درس‌ها، AI Tutor و مکالمه بدون محدودیت — با یک‌بار فعال‌سازی اشتراک.</p>
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              <Button onClick={() => premiumPlans[0] && startPurchase(premiumPlans[0])} disabled={!premiumPlans.length}>
                <Crown className="size-4" /> انتخاب پلن
              </Button>
              <Link to="/app/lessons"><Button variant="outline">اول درس رایگان را ببینم</Button></Link>
            </div>
          </div>
        </Card>
      )}

      {/* ------------------------------ purchase modal ------------------------------ */}
      <Modal open={Boolean(selected)} onClose={() => setSelected(null)} title="فعال‌سازی اشتراک">
        {selected && (
          <div className="space-y-5">
            <div className="rounded-3xl border border-line/70 bg-bg-soft/60 p-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-extrabold">{selected.title_fa}</p>
                  <p className="mt-1 text-[11px] text-ink-faint">{selected.subtitle_fa}</p>
                </div>
                <div className="text-left">
                  <p className="text-lg font-extrabold">{faPrice(selected.display_price, selected.price_label)}</p>
                  <p className="text-[10px] text-ink-faint">{faNum(selected.duration_days)} روز</p>
                </div>
              </div>
              <div className="mt-4 space-y-2 border-t border-line/60 pt-4 text-[11px]">
                <Row label="بازه دسترسی" value={`${faNum(selected.duration_days)} روز Premium`} />
                <Row label="زبان‌ها" value="انگلیسی، فرانسه، اسپانیایی" />
                <Row label="فعال‌سازی" value="داخل اپلیکیشن LINGU" />
              </div>
            </div>

            <div className="rounded-2xl border border-primary/25 bg-primary/8 p-4">
              <p className="flex items-start gap-2 text-[12px] leading-7 text-ink-muted">
                <Info className="mt-1 size-3.5 shrink-0 text-primary-soft" />
                فعال‌سازی اشتراک در اپلیکیشن LINGU انجام می‌شود و بعد از تأیید، همان لحظه روی همین حساب باز می‌شود. صفحه «اشتراک» همیشه وضعیت واقعی حساب تو را نشان می‌دهد.
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <Link to="/app/lessons"><Button><BookOpen className="size-4" /> ادامه یادگیری با حساب رایگان</Button></Link>
              <Link to="/app/profile"><Button variant="outline">مشاهده وضعیت اشتراک</Button></Link>
              <Button variant="ghost" onClick={() => setSelected(null)}>بستن</Button>
            </div>

            {session && (
              <p className="text-[10px] leading-6 text-ink-faint">
                نکته: برای فعال شدن خودکار، با همان حسابی که در اپلیکیشن وارد شده‌ای خرید کن.
              </p>
            )}
          </div>
        )}
      </Modal>
    </div>
  )
}

const renderCell = (v: string | boolean) =>
  typeof v === 'boolean'
    ? v ? <CheckCircle2 className="mx-auto size-4 text-success" /> : <X className="mx-auto size-4 text-ink-faint" />
    : v

function AccessRow({ label, value, ok }: { label: string; value: string; ok: boolean }) {
  return (
    <div className="flex items-center justify-between gap-2 rounded-xl border border-line/60 bg-bg-soft/40 px-3 py-2">
      <span className="text-ink-muted">{label}</span>
      <span className={`flex items-center gap-1 font-extrabold ${ok ? 'text-success' : 'text-warn'}`}>
        {ok ? <CheckCircle2 className="size-3" /> : <Minus className="size-3" />} {value}
      </span>
    </div>
  )
}

const Step = ({ n }: { n: number }) => (
  <span className="grid size-6 shrink-0 place-items-center rounded-xl bg-brand-soft text-[10px] font-extrabold text-primary-soft">{faNum(n)}</span>
)

function Row({ label, value, ltr }: { label: string; value: string; ltr?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-ink-faint">{label}</span>
      <span className={`font-bold ${ltr ? 'ltr' : ''}`}>{value}</span>
    </div>
  )
}
