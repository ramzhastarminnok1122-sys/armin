import { motion } from 'motion/react'
import { useMemo } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import {
  ArrowLeft, BadgeCheck, BookOpenCheck, CheckCircle2, Clock, Crown, Flame, GraduationCap,
  Lock, MessageSquareHeart, Play, Route, Sparkles, Target, TrendingUp, Trophy, Zap,
} from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { Button, Card, Chip, EmptyState, Progress, Reveal, SectionTitle, Skeleton } from '@/components/ui'
import { faNum, faRelative } from '@/lib/utils'
import { GOAL_FA, LESSON_SECTIONS } from '@/lib/constants'
import type { LessonMeta, Progress as LessonProgress } from '@/services/types'

const DAILY_SECTIONS = LESSON_SECTIONS.length

export default function Dashboard() {
  const { api, profile, membership, quota, languages, media, settings } = useApp()
  const nav = useNavigate()

  const { data, loading } = useAsync(async () => {
    if (!api) return { catalog: [] as LessonMeta[], progress: [] as LessonProgress[], banners: [] as any[] }
    const [catalog, progress, content] = await Promise.all([api.catalog(), api.myProgress(), api.publicContent()])
    return { catalog, progress, banners: content.banners }
  }, [api])

  const catalog = data?.catalog ?? []
  const progress = data?.progress ?? []
  const banners = (data?.banners ?? []).filter((b: any) => b.placement === 'user_home' || b.placement === 'all')

  const completedIds = useMemo(() => new Set(progress.filter((p) => p.status === 'completed').map((p) => p.lesson_id)), [progress])
  const completed = catalog.filter((l) => completedIds.has(l.id))
  const totalMinutes = Math.round(progress.reduce((s, p) => s + (p.time_spent_sec || 0), 0) / 60)

  const continueLesson = pickContinue(catalog, progress)
  const nextUp = pickNext(catalog, progress)
  const partnerRemaining = quota?.premium ? null : quota?.partner_remaining ?? null
  const freePerLanguage = Number(settings.learning?.free_lessons_per_language ?? 2)

  // real activity: distinct days with any progress event, ending today
  const streak = useMemo(() => {
    const days = new Set(progress.map((p) => new Date(p.completed_at || p.started_at).toDateString()))
    let count = 0
    const cursor = new Date()
    while (days.has(cursor.toDateString())) { count++; cursor.setDate(cursor.getDate() - 1) }
    return count
  }, [progress])
  const activeDays14 = useMemo(() => {
    const days = new Set(progress.filter((p) => Date.now() - new Date(p.completed_at || p.started_at).getTime() < 14 * 864e5)
      .map((p) => new Date(p.completed_at || p.started_at).toDateString()))
    return days.size
  }, [progress])

  const perLanguage = languages.map((l) => {
    const list = catalog.filter((c) => c.language_code === l.code)
    const done = list.filter((c) => completedIds.has(c.id)).length
    const current = list.find((c) => !completedIds.has(c.id) && !c.locked) ?? list[0]
    return { lang: l, total: list.length, done, pct: list.length ? Math.round((done / list.length) * 100) : 0, current }
  })

  const greeting = greetingFor()
  const statusLine = useMemo(() => {
    if (!catalog.length) return 'مسیر یادگیری‌ات آماده است؛ به‌محض انتشار درس‌ها می‌توانی شروع کنی.'
    if (continueLesson) return 'یک درس نیمه‌تمام داری — چند دقیقه وقت بگذار و تمامش کن.'
    if (completed.length === 0) return 'اولین درس تو منتظر است. با یک درس کوتاه شروع کن.'
    return `تا حالا ${faNum(completed.length)} درس کامل کرده‌ای. ادامه بده!`
  }, [catalog.length, continueLesson, completed.length])

  return (
    <div className="space-y-7">
      {/* ───────────── greeting ───────────── */}
      <Reveal>
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <Chip tone="primary"><Sparkles className="size-3" /> {greeting}</Chip>
            <h1 className="mt-3 text-2xl font-extrabold sm:text-[28px]">
              سلام {profile?.display_name || 'دوست من'} 👋
            </h1>
            <p className="mt-2 max-w-2xl text-[13px] leading-7 text-ink-muted">{statusLine}</p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {profile?.goal && <Chip><Target className="size-3" /> هدف: {GOAL_FA[profile.goal] ?? profile.goal}</Chip>}
              {profile?.target_language && <Chip>{languages.find((l) => l.code === profile.target_language)?.flag} {languages.find((l) => l.code === profile.target_language)?.name_fa}</Chip>}
            </div>
          </div>
          <div className="flex gap-2">
            <Link to="/app/lessons"><Button><BookOpenCheck className="size-4" /> درس‌ها</Button></Link>
            {!membership.premium && <Link to="/app/subscription"><Button variant="outline"><Crown className="size-4" /> Premium</Button></Link>}
          </div>
        </div>
      </Reveal>

      {/* ───────────── banners (real, admin-managed) ───────────── */}
      {banners.map((b: any, i: number) => (
        <Reveal key={b.id} delay={i * 0.05}>
          <Card className="relative overflow-hidden border-primary/30 !p-5">
            <div className="absolute inset-0 bg-brand-soft opacity-40" />
            <div className="relative flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <span className="grid size-10 shrink-0 place-items-center rounded-2xl bg-brand-grad text-white"><Sparkles className="size-4" /></span>
                <div>
                  <h3 className="text-[13px] font-extrabold">{b.title}</h3>
                  {b.body && <p className="mt-1 text-[12px] leading-6 text-ink-muted">{b.body}</p>}
                </div>
              </div>
              {b.cta_label && b.cta_url && <Link to={b.cta_url}><Button size="sm">{b.cta_label}</Button></Link>}
            </div>
          </Card>
        </Reveal>
      ))}

      {/* ───────────── continue learning ───────────── */}
      <section>
        <SectionTitle title="ادامه یادگیری" subtitle="از همان‌جایی که مانده بودی." />
        {loading && <Card className="!p-6"><Skeleton className="h-5 w-1/3" /><Skeleton className="mt-3 h-24 w-full" /></Card>}

        {!loading && catalog.length === 0 && (
          <EmptyState
            icon={<BookOpenCheck className="size-6" />}
            title="هنوز درسی منتشر نشده"
            body="به‌محض انتشار اولین درس‌ها (از Content Factory در پنل مدیریت)، همین‌جا می‌توانی یادگیری را شروع کنی."
            action={<Link to="/app/subscription"><Button variant="outline">آشنایی با پلن‌ها</Button></Link>}
          />
        )}

        {!loading && catalog.length > 0 && continueLesson && (
          <Card className="relative overflow-hidden !p-6">
            <div className="absolute -left-14 -top-14 size-44 rounded-full bg-primary/15 blur-3xl" />
            <div className="relative flex flex-wrap items-start justify-between gap-5">
              <div className="min-w-[260px] flex-1">
                <div className="flex items-center gap-2">
                  <Chip tone="primary"><Play className="size-3" /> ادامه یادگیری</Chip>
                  <span className="text-[10px] text-ink-faint">آخرین فعالیت {faRelative(latestActivity(progress))}</span>
                </div>
                <h3 className="mt-4 text-xl font-extrabold">{continueLesson.title}</h3>
                <p className="mt-1.5 text-[12px] text-ink-muted">
                  {languages.find((l) => l.code === continueLesson.language_code)?.name_fa} · سطح {continueLesson.level} · {faNum(continueLesson.estimated_minutes)} دقیقه
                </p>
                <div className="mt-4 max-w-md">
                  <Progress value={pctOf(continueLesson.id, progress)} showLabel />
                  <p className="mt-2 text-[10.5px] text-ink-faint">
                    {faNum(sectionsDone(continueLesson.id, progress))} از {faNum(DAILY_SECTIONS)} بخش این درس انجام شده
                  </p>
                </div>
              </div>
              <Button size="lg" onClick={() => nav(`/app/lessons/${continueLesson.id}`)}>
                ادامه بده <ArrowLeft className="size-4" />
              </Button>
            </div>
          </Card>
        )}

        {!loading && catalog.length > 0 && !continueLesson && nextUp && (
          <Card className="relative overflow-hidden !p-6">
            <div className="absolute inset-0 bg-brand-soft opacity-25" />
            <div className="relative flex flex-wrap items-center justify-between gap-5">
              <div>
                <Chip tone="primary"><Target className="size-3" /> {progress.length === 0 ? 'اولین قدم تو' : 'درس بعدی تو'}</Chip>
                <h3 className="mt-4 text-xl font-extrabold">
                  {progress.length === 0 ? 'هنوز اولین درس خودت را شروع نکرده‌ای.' : nextUp.title}
                </h3>
                <p className="mt-1.5 max-w-xl text-[12px] leading-6 text-ink-muted">
                  {progress.length === 0
                    ? <>پیشنهاد ما برای شروع: <b className="text-ink">{nextUp.title}</b> · {languages.find((l) => l.code === nextUp.language_code)?.name_fa} · سطح {nextUp.level} · {faNum(nextUp.estimated_minutes)} دقیقه</>
                    : <>{languages.find((l) => l.code === nextUp.language_code)?.name_fa} · سطح {nextUp.level} · {faNum(nextUp.estimated_minutes)} دقیقه</>}
                </p>
              </div>
              <Button size="lg" onClick={() => nav(`/app/lessons/${nextUp.id}`)}>
                {progress.length === 0 ? 'شروع یادگیری' : 'شروع درس'} <ArrowLeft className="size-4" />
              </Button>
            </div>
          </Card>
        )}

        {!loading && catalog.length > 0 && !continueLesson && !nextUp && (
          <EmptyState
            icon={<Trophy className="size-6" />}
            title="همه درس‌های منتشرشده را کامل کرده‌ای! 🎉"
            body="درس‌های تازه به‌سرعت اضافه می‌شوند. از AI Tutor استفاده کن تا آموخته‌هایت را تثبیت کنی."
            action={<Link to="/app/tutor"><Button>تمرین با AI Tutor</Button></Link>}
          />
        )}
      </section>

      {/* ───────────── language hub ───────────── */}
      <section>
        <SectionTitle title="زبان‌های من" subtitle="مسیر هر زبان جداگانه ذخیره می‌شود." actions={<Link to="/app/lessons"><Button size="sm" variant="ghost">همه درس‌ها <ArrowLeft className="size-3.5" /></Button></Link>} />
        <div className="grid gap-5 md:grid-cols-3">
          {perLanguage.map(({ lang, total, done, pct, current }, i) => (
            <Reveal key={lang.code} delay={i * 0.07}>
              <motion.div whileHover={{ y: -5 }} transition={{ type: 'spring', stiffness: 300, damping: 24 }} className="h-full">
                <Card className="relative flex h-full flex-col overflow-hidden !p-0">
                  <div className="relative h-32 overflow-hidden">
                    <img src={media[`lang_${lang.code}`]?.url} alt={lang.name_fa} loading="lazy" decoding="async"
                      className="size-full object-cover" />
                    <div className={`absolute inset-0 bg-gradient-to-t ${lang.gradient} opacity-45 mix-blend-multiply`} />
                    <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-4">
                      <span className="text-3xl drop-shadow">{lang.flag}</span>
                      <span className="glass-tag">{faNum(total)} درس منتشرشده</span>
                    </div>
                  </div>
                  <div className="flex flex-1 flex-col p-5">
                    <h3 className="text-lg font-extrabold">{lang.name_fa}</h3>
                    <p className="mt-0.5 text-[11px] text-ink-faint">سطح فعلی: {current?.level ?? '—'} · هدف: {faNum(lang.target_lessons)} درس</p>
                    <div className="mt-4">
                      <div className="mb-1.5 flex items-center justify-between text-[11px] font-bold text-ink-muted">
                        <span>پیشرفت</span><span>{faNum(pct)}٪ · {faNum(done)} درس</span>
                      </div>
                      <Progress value={pct} />
                    </div>
                    <div className="mt-auto pt-5">
                      {current ? (
                        <Link to={`/app/lessons/${current.id}`}><Button className="w-full" size="sm">
                          {done > 0 ? 'ادامه بده' : 'شروع کن'} <ArrowLeft className="size-3.5" />
                        </Button></Link>
                      ) : (
                        <Button className="w-full" size="sm" variant="outline" disabled>به‌زودی</Button>
                      )}
                    </div>
                  </div>
                </Card>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ───────────── AI hub ───────────── */}
      <section>
        <SectionTitle title="همراهان هوشمند تو" subtitle="یکی توضیح می‌دهد، یکی هم‌صحبت می‌شود." />
        <div className="grid gap-5 lg:grid-cols-2">
          <Reveal>
            <motion.div whileHover={{ y: -5 }} whileTap={{ scale: 0.99 }} transition={{ type: 'spring', stiffness: 300, damping: 24 }} className="h-full">
              <Link to="/app/tutor" className="block h-full">
                <Card className="relative h-full overflow-hidden !p-0">
                  <div className="flex h-full flex-col sm:flex-row">
                    <div className="relative h-40 shrink-0 sm:h-auto sm:w-44">
                      <img src={media.ai_tutor?.url} alt="" loading="lazy" decoding="async" className="size-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-l from-primary/35 to-transparent" />
                    </div>
                    <div className="flex flex-1 flex-col p-5">
                      <div className="flex items-center gap-2">
                        <span className="grid size-9 place-items-center rounded-2xl bg-brand-grad text-white"><GraduationCap className="size-4" /></span>
                        <h3 className="text-base font-extrabold">AI Tutor</h3>
                        {!membership.premium && <Chip tone="warn" className="!px-2 !py-0.5 !text-[10px]"><Lock className="size-2.5" /> Premium</Chip>}
                      </div>
                      <p className="mt-3 flex-1 text-[12.5px] leading-7 text-ink-muted">
                        «هر چیزی که در یادگیری برایت مبهم است بپرس.» توضیح ساده‌تر، مثال تازه و تمرین اضافه — بر اساس همان درسی که در آن هستی.
                      </p>
                      <span className="mt-4 inline-flex items-center gap-1.5 text-[11.5px] font-extrabold text-primary-soft">
                        {membership.premium ? 'شروع گفت‌وگو' : 'فعال‌سازی با اشتراک'} <ArrowLeft className="size-3.5" />
                      </span>
                    </div>
                  </div>
                </Card>
              </Link>
            </motion.div>
          </Reveal>

          <Reveal delay={0.08}>
            <motion.div whileHover={{ y: -5 }} whileTap={{ scale: 0.99 }} transition={{ type: 'spring', stiffness: 300, damping: 24 }} className="h-full">
              <Link to="/app/conversation" className="block h-full">
                <Card className="relative h-full overflow-hidden !p-0">
                  <div className="flex h-full flex-col sm:flex-row">
                    <div className="relative h-40 shrink-0 sm:h-auto sm:w-44">
                      <img src={media.conversation?.url} alt="" loading="lazy" decoding="async" className="size-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-l from-accent/35 to-transparent" />
                    </div>
                    <div className="flex flex-1 flex-col p-5">
                      <div className="flex items-center gap-2">
                        <span className="grid size-9 place-items-center rounded-2xl bg-gradient-to-br from-emerald-400 to-cyan-500 text-white"><MessageSquareHeart className="size-4" /></span>
                        <h3 className="text-base font-extrabold">Conversation Partner</h3>
                        {!membership.premium && <Chip className="!px-2 !py-0.5 !text-[10px]">
                          {partnerRemaining === null ? '—' : `${faNum(partnerRemaining)} پیام رایگان`}
                        </Chip>}
                      </div>
                      <p className="mt-3 flex-1 text-[12.5px] leading-7 text-ink-muted">
                        «در موقعیت‌های واقعی تمرین کن.» نقش انتخاب کن — کافه، فرودگاه، مصاحبه کاری — و مکالمه را ادامه بده.
                      </p>
                      <span className="mt-4 inline-flex items-center gap-1.5 text-[11.5px] font-extrabold text-primary-soft">
                        انتخاب سناریو <ArrowLeft className="size-3.5" />
                      </span>
                    </div>
                  </div>
                </Card>
              </Link>
            </motion.div>
          </Reveal>
        </div>
      </section>

      {/* ───────────── daily activity (real data only) ───────────── */}
      <section>
        <SectionTitle title="فعالیت من" subtitle="همه اعداد از فعالیت واقعی تو محاسبه می‌شوند." />
        {loading ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{[0, 1, 2, 3].map((i) => <Card key={i} className="!p-5"><Skeleton className="h-16" /></Card>)}</div>
        ) : progress.length === 0 ? (
          <Card className="!p-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <span className="grid size-11 place-items-center rounded-2xl bg-brand-soft text-primary-soft"><TrendingUp className="size-5" /></span>
                <div>
                  <h3 className="text-[13px] font-extrabold">هنوز فعالیتی ثبت نشده</h3>
                  <p className="mt-1 text-[11.5px] leading-6 text-ink-muted">
                    با باز کردن اولین درس، پیشرفت، زمان یادگیری و زنجیره روزانه‌ات همین‌جا ساخته می‌شود.
                  </p>
                </div>
              </div>
              <Link to="/app/lessons"><Button size="sm">شروع یادگیری</Button></Link>
            </div>
          </Card>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <ActivityTile icon={<Trophy className="size-4" />} value={completed.length} label="درس کامل‌شده" />
            <ActivityTile icon={<Flame className="size-4" />} value={streak} label="روز پیوسته" suffix={streak === 0 ? 'امروز شروع کن' : undefined} />
            <ActivityTile icon={<Clock className="size-4" />} value={totalMinutes} label="دقیقه یادگیری" />
            <ActivityTile icon={<TrendingUp className="size-4" />} value={activeDays14} label="روز فعال (۱۴ روز)" />
          </div>
        )}
      </section>

      {/* ───────────── premium area ───────────── */}
      <section>
        {membership.premium ? (
          <Card className="relative overflow-hidden !p-6">
            <div className="absolute inset-0 bg-brand-soft opacity-30" />
            <div className="relative flex flex-wrap items-center justify-between gap-5">
              <div className="flex items-start gap-4">
                <span className="grid size-12 place-items-center rounded-3xl bg-brand-grad text-white"><BadgeCheck className="size-6" /></span>
                <div>
                  <h3 className="text-[15px] font-extrabold">اشتراک Premium تو فعال است</h3>
                  <p className="mt-1 text-[12px] leading-7 text-ink-muted">
                    {membership.days_left !== null ? `${faNum(membership.days_left)} روز باقی‌مانده` : 'دسترسی کامل'} · همه درس‌ها، AI Tutor و Conversation Partner بدون محدودیت.
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <Link to="/app/tutor"><Button size="sm">پرسیدن از AI Tutor</Button></Link>
                <Link to="/app/subscription"><Button size="sm" variant="outline">جزئیات اشتراک</Button></Link>
              </div>
            </div>
          </Card>
        ) : (
          <Card className="relative overflow-hidden !p-0">
            <div className="grid lg:grid-cols-[1.15fr_1fr]">
              <div className="p-7">
                <Chip tone="warn"><Crown className="size-3" /> دسترسی کامل LINGU</Chip>
                <h3 className="mt-4 text-2xl font-extrabold leading-relaxed">کل مسیر یادگیری LINGU را باز کن</h3>
                <p className="mt-3 max-w-lg text-[13px] leading-8 text-ink-muted">
                  با یک اشتراک، همه درس‌های سه زبان، AI Tutor برای هر بخش و Conversation Partner بدون سقف پیام در اختیار توست.
                  حساب رایگان هم همیشه فعال می‌ماند؛ فقط دسترسی‌ات بازتر می‌شود.
                </p>
                <ul className="mt-5 grid gap-2.5 sm:grid-cols-2">
                  {[
                    'همه درس‌های منتشرشده (English · French · Spanish)',
                    'AI Tutor برای هر بخش درس',
                    'Conversation Partner بدون محدودیت پیام',
                    'دسترسی به درس‌های تازه هر هفته',
                  ].map((t) => (
                    <li key={t} className="flex items-start gap-2 text-[12px] leading-6 text-ink-muted">
                      <CheckCircle2 className="mt-0.5 size-3.5 shrink-0 text-success" /> {t}
                    </li>
                  ))}
                </ul>
                <div className="mt-6 flex flex-wrap items-center gap-3">
                  <Link to="/app/subscription"><Button size="lg"><Crown className="size-4" /> دیدن پلن‌ها و قیمت‌ها</Button></Link>
                  <span className="text-[11px] text-ink-faint">
                    {faNum(freePerLanguage)} درس رایگان در هر زبان، بدون محدودیت زمانی
                  </span>
                </div>
              </div>
              <div className="relative min-h-[220px]">
                <img src={media.premium?.url} alt="" loading="lazy" decoding="async" className="absolute inset-0 size-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-l from-transparent to-card/70 lg:bg-gradient-to-r" />
              </div>
            </div>
          </Card>
        )}
      </section>

      {/* ───────────── shortcuts ───────────── */}
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Shortcut to="/app/progress" icon={<Route className="size-4" />} title="پیشرفت من" body="نمودار و جزئیات درس‌ها" />
        <Shortcut to="/app/conversation" icon={<MessageSquareHeart className="size-4" />} title="تمرین مکالمه" body="۹ سناریوی واقعی" />
        <Shortcut to="/app/subscription" icon={<Crown className="size-4" />} title="اشتراک" body="پلن‌ها و مزایا" />
        <Shortcut to="/app/help" icon={<Zap className="size-4" />} title="راهنما" body="کار با برنامه در ۲ دقیقه" />
      </section>

      {loading && <div className="sr-only" role="status">در حال بارگذاری داشبورد</div>}
    </div>
  )
}

/* ─────────────────────────── pieces ─────────────────────────── */

function ActivityTile({ icon, value, label, suffix }: { icon: React.ReactNode; value: number; label: string; suffix?: string }) {
  return (
    <Card className="!p-5">
      <span className="grid size-9 place-items-center rounded-2xl bg-brand-soft text-primary-soft">{icon}</span>
      <p className="mt-3 text-2xl font-extrabold">{faNum(value)}</p>
      <p className="text-[11px] text-ink-faint">{label}</p>
      {suffix && <p className="mt-1 text-[10px] text-warn">{suffix}</p>}
    </Card>
  )
}

function Shortcut({ to, icon, title, body }: { to: string; icon: React.ReactNode; title: string; body: string }) {
  return (
    <Link to={to}>
      <motion.div whileHover={{ y: -4 }} transition={{ type: 'spring', stiffness: 320, damping: 26 }}>
        <Card className="flex h-full items-center gap-3 !p-4">
          <span className="grid size-10 place-items-center rounded-2xl bg-brand-soft text-primary-soft">{icon}</span>
          <span className="min-w-0">
            <span className="block text-[12.5px] font-extrabold">{title}</span>
            <span className="block text-[10.5px] text-ink-faint">{body}</span>
          </span>
          <ArrowLeft className="mr-auto size-3.5 text-ink-faint" />
        </Card>
      </motion.div>
    </Link>
  )
}

/* ─────────────────────────── helpers ─────────────────────────── */

const greetingFor = () => {
  const h = new Date().getHours()
  if (h < 5) return 'شب بخیر'
  if (h < 12) return 'صبح بخیر'
  if (h < 17) return 'وقت بخیر'
  if (h < 20) return 'عصر بخیر'
  return 'شب بخیر'
}

const sectionsDone = (lessonId: string, progress: LessonProgress[]) =>
  progress.find((p) => p.lesson_id === lessonId)?.sections_done?.length ?? 0

function pctOf(lessonId: string, progress: LessonProgress[]) {
  const p = progress.find((x) => x.lesson_id === lessonId)
  if (!p) return 0
  if (p.status === 'completed') return 100
  return Math.min(95, Math.round(((p.sections_done?.length ?? 0) / DAILY_SECTIONS) * 100))
}

const latestActivity = (progress: LessonProgress[]) =>
  progress.map((p) => p.completed_at || p.started_at).sort().reverse()[0] ?? null

function pickContinue(catalog: LessonMeta[], progress: LessonProgress[]): LessonMeta | null {
  const inProgress = progress.filter((p) => p.status === 'started')
    .sort((a, b) => new Date(b.started_at).getTime() - new Date(a.started_at).getTime())
  for (const p of inProgress) {
    const found = catalog.find((c) => c.id === p.lesson_id)
    if (found) return found
  }
  return null
}

function pickNext(catalog: LessonMeta[], progress: LessonProgress[]): LessonMeta | null {
  const started = new Set(progress.map((p) => p.lesson_id))
  return catalog.find((l) => !l.locked && !started.has(l.id)) ?? catalog.find((l) => !l.locked) ?? null
}
