import { motion } from 'motion/react'
import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import {
  ArrowLeft, ArrowRight, BadgeCheck, Crown, Gauge, History, Lock, MessageSquareHeart, RotateCcw, Sparkles, Trash2, Users,
} from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { Button, Card, Chip, Confirmed, Skeleton, StaggerGroup, staggerItem } from '@/components/ui'
import { ChatPanel, PARTNER_LIMIT_TEXT } from '@/components/chat/ChatPanel'
import { PARTNER_SCENARIOS } from '@/lib/constants'
import { SCENARIO_SLOT } from '@/lib/assets'
import { cn, faNum, faRelative } from '@/lib/utils'

export default function Conversation() {
  const { conversationId, scenarioId } = useParams()
  const { api, quota, membership, media, toast } = useApp()
  const nav = useNavigate()
  const [refreshKey, setRefreshKey] = useState(0)
  const [tab, setTab] = useState<'scenarios' | 'history'>('scenarios')

  const { data: conversations, loading } = useAsync(async () => (api ? api.conversations('partner') : []), [api, refreshKey])
  const remaining = membership.premium ? null : quota?.partner_remaining ?? null
  const exhausted = !membership.premium && remaining !== null && remaining <= 0

  const activeConv = (conversations ?? []).find((c) => c.id === conversationId) ?? null
  const activeScenario = PARTNER_SCENARIOS.find((s) => s.id === activeConv?.scenario) ?? null
  const scenarioImage = (id: string) => media[SCENARIO_SLOT[id] ?? 'conversation']?.url ?? media.conversation?.url ?? ''

  const startScenario = async (scenarioId: string) => {
    if (!api) return
    if (exhausted) { toast(PARTNER_LIMIT_TEXT, 'info'); nav('/app/subscription'); return }
    nav(`/app/conversation/new/${scenarioId}`)
  }

  /* ─────────── 1) scenario chosen, conversation not created yet ─────────── */
  const pendingId = scenarioId && scenarioId !== 'new' ? scenarioId : null
  const pendingScenario = pendingId ? PARTNER_SCENARIOS.find((x) => x.id === pendingId) ?? null : null
  if (pendingScenario) {
    const s = pendingScenario
    return (
      <div className="space-y-5">
        <button onClick={() => nav('/app/conversation')} className="inline-flex items-center gap-1.5 text-[11.5px] font-bold text-ink-muted hover:text-ink">
          <ArrowRight className="size-3.5" /> همه سناریوها
        </button>
        <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
          <div className="space-y-4">
            {exhausted && <Gate />}
            <ChatPanel
              key={s.id}
              mode="partner"
              conversationId={null}
              scenario={s.id}
              scenarioFa={s.title_fa}
              suggestions={['Hello!', "I'd like to order, please.", 'Could you repeat that?']}
              onConversationCreated={(id) => { nav(`/app/conversation/${id}`, { replace: true }); setRefreshKey((k) => k + 1) }}
            />
          </div>
          <div className="space-y-4">
            <Card className="!p-0 overflow-hidden">
              <img src={scenarioImage(s.id)} alt="" className="h-36 w-full object-cover" />
              <div className="p-4">
                <div className="flex items-center gap-2 text-[14px] font-extrabold">{s.emoji} {s.title_fa}</div>
                <p className="ltr mt-1 text-[11px] text-ink-faint">{s.title_en}</p>
                <p className="mt-3 text-[11.5px] leading-7 text-ink-muted">{s.what_fa}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Chip><Gauge className="size-3" /> سطح {s.level}</Chip>
                  <Chip><Users className="size-3" /> {s.role_fa}</Chip>
                </div>
              </div>
            </Card>
            <Card className="!p-4">
              <p className="text-[11px] font-extrabold text-ink-faint">شروع مکالمه</p>
              <div className="ltr mt-3 rounded-2xl border border-line/70 bg-bg-soft/60 p-3 text-[11.5px] leading-6">“{s.opener_en}”</div>
              <p className="mt-3 text-[10.5px] leading-6 text-ink-faint">
                هم‌صحبت با همین جمله شروع می‌کند. جواب بده و مکالمه را ادامه بده؛ اگر گیر کردی، می‌توانی پیشنهادهای بالای کادر پیام را بزنی.
              </p>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  if (conversationId && conversationId !== 'new' && !pendingScenario) {
    const scenarioMeta = activeScenario ?? PARTNER_SCENARIOS.find((s) => s.id === 'daily')!
    return (
      <div className="space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button onClick={() => nav('/app/conversation')} className="icon-btn" aria-label="بازگشت به سناریوها"><ArrowRight className="size-4" /></button>
            <div className="flex items-center gap-3">
              <span className={cn('grid size-11 place-items-center rounded-2xl bg-gradient-to-br text-xl text-white', scenarioMeta.gradient)}>{scenarioMeta.emoji}</span>
              <div>
                <h1 className="text-[15px] font-extrabold">{scenarioMeta.title_fa}</h1>
                <p className="text-[10.5px] text-ink-faint">هم‌صحبت: {scenarioMeta.role_fa} · سطح {scenarioMeta.level}</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {membership.premium
              ? <Chip tone="success"><Crown className="size-3" /> بدون محدودیت پیام</Chip>
              : <Chip tone={exhausted ? 'warn' : 'default'}>{remaining === null ? '—' : `${faNum(remaining)} از ${faNum(quota?.free_partner_limit ?? 2)} پیام رایگان`}</Chip>}
            <Button variant="outline" size="sm" onClick={() => nav('/app/conversation')}><Users className="size-3.5" /> سناریوی دیگر</Button>
          </div>
        </div>

        {exhausted && <Gate />}

        <ChatPanel
          mode="partner"
          conversationId={conversationId}
          scenario={scenarioMeta.id}
          scenarioFa={scenarioMeta.title_fa}
          suggestions={['Hello!', "I'd like to order, please.", 'Could you repeat that?']}
          onConversationCreated={(id) => { nav(`/app/conversation/${id}`, { replace: true }); setRefreshKey((k) => k + 1) }}
        />
        <p className="text-center text-[10.5px] text-ink-faint">
          هم‌صحبت در نقش خودش می‌ماند و با سؤال‌های تازه مکالمه را جلو می‌برد. اگر اشتباه کوچکی داشتی، در همان مکالمه راهنمایی می‌کند.
        </p>
      </div>
    )
  }

  /* ─────────── 3) flagship scenario selection ─────────── */
  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Chip tone="primary"><MessageSquareHeart className="size-3" /> Conversation Partner</Chip>
          <h1 className="mt-3 text-2xl font-extrabold">در موقعیت‌های واقعی تمرین کن</h1>
          <p className="mt-2 max-w-2xl text-[13px] leading-7 text-ink-muted">
            یک موقعیت انتخاب کن؛ هم‌صحبت تو نقش واقعی‌اش را بازی می‌کند، سؤال می‌پرسد، مکالمه را جلو می‌برد و در سطح خودت حرف می‌زند.
          </p>
        </div>
        {membership.premium
          ? <Chip tone="success"><Crown className="size-3" /> اشتراک فعال — بدون محدودیت</Chip>
          : <Chip tone={exhausted ? 'warn' : 'default'}>
              {remaining === null ? '—' : <>{faNum(remaining)} از {faNum(quota?.free_partner_limit ?? 2)} پیام رایگان</>}
            </Chip>}
      </header>

      {exhausted && <Gate />}

      <div className="flex gap-2">
        <TabBtn active={tab === 'scenarios'} onClick={() => setTab('scenarios')} icon={<Sparkles className="size-3.5" />} label="سناریوها" />
        <TabBtn active={tab === 'history'} onClick={() => setTab('history')} icon={<History className="size-3.5" />} label={`مکالمه‌های من${conversations?.length ? ` (${faNum(conversations.length)})` : ''}`} />
      </div>

      {tab === 'scenarios' && (
        <StaggerGroup className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {PARTNER_SCENARIOS.map((s) => (
            <motion.div key={s.id} variants={staggerItem}>
              <motion.button whileHover={{ y: -6 }} whileTap={{ scale: 0.99 }} transition={{ type: 'spring', stiffness: 300, damping: 24 }}
                onClick={() => startScenario(s.id)} className="block h-full w-full text-right">
                <Card className="flex h-full flex-col !p-0 overflow-hidden">
                  <div className="relative h-36">
                    <img src={scenarioImage(s.id)} alt="" loading="lazy" decoding="async" className="size-full object-cover" />
                    <div className={cn('absolute inset-0 bg-gradient-to-t opacity-60 mix-blend-multiply', s.gradient)} />
                    <span className="absolute right-4 top-4 grid size-11 place-items-center rounded-2xl bg-white/15 text-xl backdrop-blur-md">{s.emoji}</span>
                    <span className="absolute bottom-3 left-4 glass-tag">سطح {s.level}</span>
                  </div>
                  <div className="flex flex-1 flex-col p-5">
                    <h3 className="text-[15px] font-extrabold">{s.title_fa}</h3>
                    <p className="ltr mt-0.5 text-[10.5px] text-ink-faint">{s.title_en}</p>
                    <p className="mt-3 flex-1 text-[11.5px] leading-7 text-ink-muted">{s.what_fa}</p>
                    <div className="mt-4 flex items-center justify-between border-t border-line/60 pt-3.5">
                      <span className="flex items-center gap-1.5 text-[10.5px] text-ink-faint"><Users className="size-3" /> {s.role_fa}</span>
                      <span className="inline-flex items-center gap-1.5 text-[11.5px] font-extrabold text-primary-soft">
                        شروع مکالمه <ArrowLeft className="size-3.5" />
                      </span>
                    </div>
                  </div>
                </Card>
              </motion.button>
            </motion.div>
          ))}
        </StaggerGroup>
      )}

      {tab === 'history' && (
        <div className="space-y-3">
          {loading && <><Skeleton className="h-20" /><Skeleton className="h-20" /></>}
          {!loading && (conversations ?? []).length === 0 && (
            <Card className="!p-8 text-center">
              <History className="mx-auto size-6 text-ink-faint" />
              <p className="mt-3 text-[12.5px] font-extrabold">هنوز مکالمه‌ای نداری</p>
              <p className="mx-auto mt-1 max-w-md text-[11.5px] leading-6 text-ink-faint">
                یک سناریو را شروع کن؛ همه مکالمه‌های واقعی‌ات اینجا ذخیره می‌شوند و می‌توانی ادامه‌شان بدهی.
              </p>
              <Button className="mt-4" size="sm" onClick={() => setTab('scenarios')}>دیدن سناریوها</Button>
            </Card>
          )}
          {(conversations ?? []).map((c) => {
            const meta = PARTNER_SCENARIOS.find((s) => s.id === c.scenario)
            return (
              <Card key={c.id} className="flex flex-wrap items-center justify-between gap-3 !p-4">
                <div className="flex items-center gap-3">
                  <span className={cn('grid size-10 place-items-center rounded-2xl bg-gradient-to-br text-lg text-white', meta?.gradient ?? 'from-primary to-secondary')}>{meta?.emoji ?? '💬'}</span>
                  <div>
                    <p className="text-[12.5px] font-extrabold">{meta?.title_fa ?? c.scenario_fa ?? c.title ?? 'مکالمه'}</p>
                    <p className="mt-0.5 text-[10px] text-ink-faint">{faRelative(c.updated_at)} · {faNum(c.message_count)} پیام</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="outline" onClick={() => nav(`/app/conversation/${c.id}`)}><ArrowLeft className="size-3.5" /> ادامه</Button>
                  <Confirmed label={<Trash2 className="size-3.5" />} confirmLabel="پاک شود؟"
                    onConfirm={async () => { await api?.deleteConversation(c.id); setRefreshKey((k) => k + 1); toast('مکالمه پاک شد.', 'success') }} />
                </div>
              </Card>
            )
          })}
        </div>
      )}

      <Card className="!p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <span className="grid size-10 place-items-center rounded-2xl bg-brand-soft text-primary-soft"><BadgeCheck className="size-4" /></span>
            <div>
              <p className="text-[12.5px] font-extrabold">چطور بهترین نتیجه را بگیرم؟</p>
              <p className="mt-1 max-w-2xl text-[11px] leading-6 text-ink-muted">
                نقش را عوض نکن، حتی اگر مکالمه سخت شد. اگر واژه‌ای را نمی‌دانی، به فارسی اشاره کن؛ هم‌صحبت کمکت می‌کند و همان مکالمه ادامه پیدا می‌کند.
              </p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={() => { setRefreshKey((k) => k + 1); toast('فهرست مکالمه‌ها به‌روز شد.', 'success') }}>
            <RotateCcw className="size-3.5" /> به‌روزرسانی
          </Button>
        </div>
      </Card>
    </div>
  )
}

function TabBtn({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button onClick={onClick}
      className={cn('inline-flex items-center gap-2 rounded-2xl border px-4 py-2.5 text-[11.5px] font-bold transition-all',
        active ? 'border-primary/45 bg-brand-soft text-ink' : 'border-line/80 text-ink-muted hover:text-ink')}>
      {icon} {label}
    </button>
  )
}

function Gate() {
  const nav = useNavigate()
  const { media } = useApp()
  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
      <Card className="relative overflow-hidden !p-0">
        <div className="grid lg:grid-cols-[1.2fr_1fr]">
          <div className="p-6">
            <Chip tone="warn"><Lock className="size-3" /> سقف پیام رایگان</Chip>
            <h3 className="mt-4 text-xl font-extrabold leading-8">{PARTNER_LIMIT_TEXT}</h3>
            <p className="mt-3 max-w-lg text-[12.5px] leading-8 text-ink-muted">
              با اشتراک، Conversation Partner بدون محدودیت پیام فعال می‌شود و می‌توانی هر ۹ سناریو را تمرین کنی — درست وقتی که دوست داری، نه وقتی که سهمیه اجازه می‌دهد.
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <Button onClick={() => nav('/app/subscription')}><Crown className="size-4" /> دیدن پلن‌ها</Button>
              <Button variant="outline" onClick={() => nav('/app/lessons')}>ادامه درس‌های رایگان</Button>
            </div>
          </div>
          <div className="relative min-h-[180px]">
            <img src={media.premium?.url} alt="" className="absolute inset-0 size-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-l from-transparent to-card/70 lg:bg-gradient-to-r" />
          </div>
        </div>
      </Card>
    </motion.div>
  )
}
