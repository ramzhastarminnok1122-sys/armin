import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { Crown, GraduationCap, Plus, Sparkles } from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { Button, Card, Chip, Skeleton } from '@/components/ui'
import { ChatPanel } from '@/components/chat/ChatPanel'
import { faNum, faRelative } from '@/lib/utils'

const QUICK = [
  'این بخش را ساده‌تر توضیح بده',
  'برای این موضوع مثال بزن',
  'از من تمرین بگیر',
  'با من انگلیسی تمرین کن',
]

export default function Tutor() {
  const { conversationId } = useParams()
  const { api, membership, quota } = useApp()
  const nav = useNavigate()
  const [refreshKey, setRefreshKey] = useState(0)

  const { data: conversations, loading } = useAsync(async () => (api ? api.conversations('tutor') : []), [api, refreshKey])

  if (!membership.premium) {
    return (
      <div className="space-y-6">
        <HeaderBlock />
        <Card className="relative overflow-hidden !p-7">
          <div className="absolute inset-0 bg-brand-soft opacity-30" />
          <div className="relative flex flex-col items-start gap-4">
            <Chip tone="warn"><Crown className="size-3" /> ویژه Premium</Chip>
            <h2 className="text-2xl font-extrabold">AI Tutor همراه همیشگی درس‌هاست</h2>
            <p className="max-w-2xl text-sm leading-8 text-ink-muted">
              Tutor همان بخشی را که در آن هستی توضیح می‌دهد: گرامر را ساده می‌کند، برای واژه‌های تازه مثال می‌سازد، تمرین اضافه می‌دهد و به سؤال‌هایت بر اساس محتوای درس جواب می‌دهد.
            </p>
            <ul className="grid gap-2 text-sm text-ink-muted sm:grid-cols-2">
              {['توضیح دوباره هر بخش درس', 'ساخت مثال تازه برای قواعد', 'تمرین اضافه برای تقویت', 'پاسخ به سؤال‌هایت در همان لحظه'].map((t) => (
                <li key={t} className="flex items-center gap-2"><Sparkles className="size-3.5 text-primary-soft" /> {t}</li>
              ))}
            </ul>
            <div className="mt-2 flex flex-wrap gap-2">
              <Link to="/app/subscription"><Button><Crown className="size-4" /> تهیه اشتراک Premium</Button></Link>
              <Link to="/app/conversation"><Button variant="outline">۲ پیام رایگان Conversation را امتحان کن</Button></Link>
            </div>
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <HeaderBlock
        action={
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => { setRefreshKey((k) => k + 1); nav('/app/tutor') }}>
              <Plus className="size-3.5" /> گفت‌وگوی جدید
            </Button>
          </div>
        }
      />

      <div className="grid gap-5 lg:grid-cols-[1fr_320px]">
        <ChatPanel
          mode="tutor"
          conversationId={conversationId ?? null}
          suggestions={QUICK}
          onConversationCreated={(id) => { nav(`/app/tutor/${id}`, { replace: true }); setRefreshKey((k) => k + 1) }}
        />

        <div className="space-y-5">
        <Card className="!p-4">
          <p className="text-[11px] font-extrabold text-ink-faint">وضعیت دسترسی AI</p>
          <div className="mt-3 space-y-2 text-[11px]">
            <div className="flex items-center justify-between"><span className="text-ink-faint">پلن</span>
              <span className="font-bold">{membership.premium ? 'Premium' : 'رایگان'}</span></div>
            <div className="flex items-center justify-between"><span className="text-ink-faint">سقف روزانه</span>
              <span className="font-bold">{membership.premium
                ? (typeof quota?.tutor_remaining === 'number' ? `${faNum(quota.tutor_remaining)} پیام باقی‌مانده امروز` : 'بدون محدودیت مؤثر')
                : 'Tutor ویژه Premium'}</span></div>
            <div className="flex items-center justify-between"><span className="text-ink-faint">وضعیت سرویس</span>
              <span className={quota?.ai_enabled === false ? 'font-bold text-danger' : 'font-bold text-success'}>
                {quota?.ai_enabled === false ? 'غیرفعال' : 'فعال'}
              </span></div>
          </div>
          <p className="mt-3 text-[10.5px] leading-6 text-ink-faint">
            سقف پیام‌های تو هر روز شمرده می‌شود؛ بستن صفحه یا خروج از حساب آن را باز نمی‌کند.
          </p>
        </Card>

        <Card className="!p-3">
          <p className="px-2 py-2 text-[11px] font-extrabold text-ink-faint">گفت‌وگوهای من</p>
          {loading && <div className="space-y-2 p-2"><Skeleton className="h-12" /><Skeleton className="h-12" /></div>}
          {!loading && (conversations ?? []).length === 0 && (
            <p className="px-2 py-4 text-[11px] leading-6 text-ink-faint">هنوز گفت‌وگویی نساخته‌ای. از دکمه «گفت‌وگوی جدید» شروع کن یا از داخل هر درس، تمرین با AI را بزن.</p>
          )}
          <div className="max-h-[380px] space-y-1.5 overflow-y-auto">
            {(conversations ?? []).map((c) => (
              <button key={c.id} onClick={() => nav(`/app/tutor/${c.id}`)}
                className={`w-full rounded-2xl border px-3 py-3 text-right transition-all ${conversationId === c.id ? 'border-primary/45 bg-brand-soft' : 'border-line/70 bg-card/40 hover:border-primary/30'}`}>
                <p className="truncate text-xs font-extrabold">{c.title || 'گفت‌وگو با AI Tutor'}</p>
                <p className="mt-1 text-[10px] text-ink-faint">{faRelative(c.updated_at)} · {c.message_count} پیام</p>
              </button>
            ))}
          </div>
        </Card>
        </div>
      </div>
    </div>
  )
}

function HeaderBlock({ action }: { action?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div>
        <Chip tone="primary"><GraduationCap className="size-3" /> AI Tutor</Chip>
        <h1 className="mt-3 text-2xl font-extrabold sm:text-3xl">مربی شخصی LINGU</h1>
        <p className="mt-2 max-w-2xl text-sm leading-7 text-ink-muted">
          هر بخش درس را ساده‌تر توضیح می‌دهد، مثال می‌سازد، تمرین می‌دهد و به سؤال‌هایت بر اساس همان درس جواب می‌دهد.
        </p>
      </div>
      {action}
    </div>
  )
}
