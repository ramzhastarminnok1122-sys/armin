import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { BookOpen, ChevronDown, Crown, GraduationCap, LifeBuoy, Mail, MessageSquareHeart, Route, Sparkles } from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { Button, Card, Chip, ErrorState, Field, SectionTitle, Skeleton, Textarea } from '@/components/ui'
import { cn } from '@/lib/utils'

const FAQ_GROUPS = [
  { id: 'all', label: 'همه' },
  { id: 'general', label: 'عمومی' },
  { id: 'pricing', label: 'اشتراک و پرداخت' },
  { id: 'features', label: 'قابلیت‌ها' },
] as const

export default function Help() {
  const { api, settings, membership, toast } = useApp()
  void 0
  const [group, setGroup] = useState<(typeof FAQ_GROUPS)[number]['id']>('all')
  const [open, setOpen] = useState<string | null>(null)
  const [msg, setMsg] = useState('')
  const [sending, setSending] = useState(false)

  const { data: content, loading, error, reload } = useAsync(async () => (api ? api.publicContent() : null), [api])
  const faqs = content?.faqs ?? []
  const list = useMemo(() => faqs.filter((f: any) => f.is_published && (group === 'all' || f.category === group)), [faqs, group])
  const supportEmail = settings.general?.support_email || null

  const send = async () => {
    if (msg.trim().length < 5) { toast('متن پیام خیلی کوتاه است.', 'error'); return }
    setSending(true)
    try {
      await api?.supportRequest(msg.trim())
      setMsg('')
      toast('پیام تو ثبت شد. تیم پشتیبانی از طریق ایمیل پاسخ می‌دهد.', 'success')
    } catch { toast('ارسال پیام انجام نشد. بعداً تلاش کن.', 'error') }
    finally { setSending(false) }
  }

  const quickLinks = [
    { to: '/app/lessons', icon: <BookOpen className="size-4" />, title: 'درس‌ها', body: 'فیلتر زبان و سطح، ادامه از هر بخش' },
    { to: '/app/tutor', icon: <GraduationCap className="size-4" />, title: 'AI Tutor', body: 'توضیح ساده‌تر، مثال و تمرین' },
    { to: '/app/conversation', icon: <MessageSquareHeart className="size-4" />, title: 'Conversation Partner', body: '۹ سناریوی واقعی مکالمه' },
    { to: '/app/progress', icon: <Route className="size-4" />, title: 'پیشرفت', body: 'آمار واقعی یادگیری تو' },
    { to: '/app/subscription', icon: <Crown className="size-4" />, title: 'اشتراک', body: 'مقایسه رایگان و Premium' },
  ]

  return (
    <div className="space-y-7">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Chip><LifeBuoy className="size-3" /> پشتیبانی</Chip>
          <h1 className="mt-3 text-2xl font-extrabold">راهنما و پشتیبانی</h1>
          <p className="mt-2 max-w-2xl text-[13px] leading-7 text-ink-muted">
            پاسخ پرسش‌های رایج درباره یادگیری، اشتراک و قابلیت‌های برنامه — و اگر چیزی پیدا نکردی، همان‌جا پیام بگذار.
          </p>
        </div>
        {supportEmail && (
          <a href={`mailto:${supportEmail}`}><Button variant="outline"><Mail className="size-4" /> {supportEmail}</Button></a>
        )}
      </header>

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {quickLinks.map((q) => (
          <Link key={q.to} to={q.to}>
            <Card className="h-full !p-4 transition-all hover:-translate-y-1 hover:border-primary/40">
              <span className="grid size-10 place-items-center rounded-2xl bg-brand-soft text-primary-soft">{q.icon}</span>
              <p className="mt-3 text-[12.5px] font-extrabold">{q.title}</p>
              <p className="mt-0.5 text-[10.5px] leading-5 text-ink-faint">{q.body}</p>
            </Card>
          </Link>
        ))}
      </section>

      <section className="grid gap-5 lg:grid-cols-[1.5fr_1fr]">
        <Card className="!p-6">
          <SectionTitle title="پرسش‌های پرتکرار" subtitle="محتوای این بخش از پنل مدیریت قابل ویرایش است." />
          <div className="mt-4 flex flex-wrap gap-2">
            {FAQ_GROUPS.map((g) => (
              <button key={g.id} onClick={() => setGroup(g.id)}
                className={cn('rounded-2xl border px-3.5 py-1.5 text-[11px] font-bold transition-colors',
                  group === g.id ? 'border-primary/45 bg-primary/10 text-primary-soft' : 'border-line/80 text-ink-muted hover:text-ink')}>
                {g.label}
              </button>
            ))}
          </div>

          {loading && <div className="mt-5 space-y-3">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-14" />)}</div>}
          {error && <div className="mt-5"><ErrorState body={error} onRetry={reload} /></div>}
          {!loading && !error && list.length === 0 && (
            <div className="mt-5 rounded-3xl border border-line/70 bg-bg-soft/40 p-6 text-center">
              <p className="text-[12px] font-bold">در این دسته پرسشی ثبت نشده</p>
              <p className="mt-1 text-[11px] text-ink-faint">دسته دیگری را انتخاب کن یا پیام خودت را برای پشتیبانی بفرست.</p>
            </div>
          )}

          <div className="mt-5 divide-y divide-line/60">
            {list.map((f) => (
              <div key={f.id}>
                <button onClick={() => setOpen(open === f.id ? null : f.id)}
                  className="flex w-full items-center justify-between gap-3 py-4 text-right">
                  <span className="text-[12.5px] font-extrabold">{f.question}</span>
                  <ChevronDown className={cn('size-4 shrink-0 text-ink-faint transition-transform', open === f.id && 'rotate-180')} />
                </button>
                {open === f.id && <p className="pb-4 text-[12px] leading-7 text-ink-muted">{f.answer}</p>}
              </div>
            ))}
          </div>
        </Card>

        <div className="space-y-5">
          <Card className="!p-6">
            <SectionTitle title="پیام به پشتیبانی" subtitle="پرسش یا مشکلت را بنویس؛ در پنل مدیریت ثبت می‌شود." />
            <div className="mt-4">
              <Field label="متن پیام" required hint="اگر درباره یک درس خاص است، نام درس را هم بنویس.">
                <Textarea rows={5} value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="مثلاً: در درس «سفارش در کافه» بخش آزمون باز نمی‌شود…" />
              </Field>
              <div className="mt-4 flex justify-end"><Button onClick={send} loading={sending}>ارسال پیام</Button></div>
            </div>
          </Card>

          <Card className="!p-6">
            <SectionTitle title="وضعیت دسترسی تو" />
            <div className="mt-4 space-y-2.5 text-[11.5px]">
              <Line label="وضعیت حساب" value={membership.premium ? 'Premium فعال' : 'رایگان (برای همیشه)'} />
              <Line label="دسترسی درس‌ها" value={membership.premium ? 'همه درس‌ها' : '۲ درس رایگان در هر زبان'} />
              <Line label="AI Tutor" value={membership.premium ? 'فعال' : 'با اشتراک فعال می‌شود'} />
              <Line label="Conversation Partner" value={membership.premium ? 'بدون محدودیت' : '۲ پیام رایگان'} />
            </div>
            {!membership.premium && (
              <Link to="/app/subscription" className="mt-5 block">
                <Button className="w-full"><Sparkles className="size-4" /> ارتقا به Premium</Button>
              </Link>
            )}
          </Card>
        </div>
      </section>
    </div>
  )
}

function Line({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-line/50 pb-2.5 last:border-0 last:pb-0">
      <span className="text-ink-faint">{label}</span>
      <span className="font-bold text-ink">{value}</span>
    </div>
  )
}
