import { useState } from 'react'
import {
  AlertTriangle, BadgeCheck, BookOpenCheck, CheckCircle2, Copy, Factory, GraduationCap,
  Layers, ListChecks, Plus, RefreshCw, Rocket, Send, Sparkles, Trash2, Wand2,
} from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import {
  Button, Card, Chip, Confirmed, EmptyState, Field, Input, Modal, PageHeader, Progress,
  SectionTitle, Select, Skeleton, StatCard, Textarea,
} from '@/components/ui'
import { faNum, faRelative } from '@/lib/utils'
import { LEVELS, LEVEL_FA } from '@/lib/constants'
import type { Batch, Curriculum, LessonPlan } from '@/services/types'

type StepState = 'idle' | 'running' | 'done' | 'error'

export default function ContentFactory() {
  const { api, toast, languages } = useApp()
  const [lang, setLang] = useState('en')
  const [level, setLevel] = useState('A1')
  const [curriculumId, setCurriculumId] = useState<string>('')
  const [batchSize, setBatchSize] = useState(5)
  const [planCount, setPlanCount] = useState(10)
  const [busy, setBusy] = useState<string | null>(null)
  const [steps, setSteps] = useState<Record<string, StepState>>({})
  const [curriculumModal, setCurriculumModal] = useState(false)
  const [newCurriculum, setNewCurriculum] = useState({ title_fa: '', summary_fa: '', target_lessons: 40 })
  const [log, setLog] = useState<string[]>([])
  const [lastBatch, setLastBatch] = useState<Batch | null>(null)

  const curricula = useAsync(async () => (api ? api.curricula() : []), [api])
  const plans = useAsync(async () => (api ? api.plans(curriculumId || undefined) : []), [api, curriculumId])
  const batches = useAsync(async () => (api ? api.batches(12) : []), [api])
  const lessons = useAsync(async () => (api ? api.adminLessons({}) : []), [api])

  const allPlans = plans.data ?? []
  const allLessons = (lessons.data ?? []) as { id: string; status: string; language_code: string; title: string; order_index: number }[]
  const pendingPlans = allPlans.filter((p) => p.status === 'planned')
  const publishedLessons = allLessons.filter((l) => l.status === 'published')

  const push = (msg: string) => setLog((l) => [`${new Date().toLocaleTimeString('fa-IR')} — ${msg}`, ...l].slice(0, 40))

  const run = async (key: string, fn: () => Promise<string>) => {
    setBusy(key); setSteps((s) => ({ ...s, [key]: 'running' }))
    try {
      const msg = await fn()
      setSteps((s) => ({ ...s, [key]: 'done' }))
      push(msg)
    } catch (e) {
      setSteps((s) => ({ ...s, [key]: 'error' }))
      const msg = e instanceof Error ? e.message : 'خطای نامشخص'
      push(`خطا: ${msg}`)
      toast(msg, 'error')
    } finally { setBusy(null) }
  }

  /* ---------------------------- step 1: curriculum ---------------------------- */
  const createCurriculum = async () => {
    if (!api) return
    await api.createCurriculum({
      language_code: lang, level,
      title_fa: newCurriculum.title_fa || `مسیر ${languages.find((l) => l.code === lang)?.name_fa} — ${level}`,
      summary_fa: newCurriculum.summary_fa,
      target_lessons: newCurriculum.target_lessons,
    })
    toast('کرریکولوم ساخته شد.', 'success')
    setCurriculumModal(false)
    push(`کرریکولوم ${lang.toUpperCase()} ${level} ساخته شد.`)
    await curricula.reload()
  }

  /* --------------------------- step 2: lesson plans --------------------------- */
  const generatePlans = () => run('plans', async () => {
    if (!api) throw new Error('اتصال برقرار نیست')
    if (!curriculumId) throw new Error('اول یک کرریکولوم انتخاب یا بساز.')
    const res = await api.createPlans({ curriculum_id: curriculumId, count: planCount, start_order: allPlans.length + 1 })
    await Promise.all([plans.reload(), curricula.reload()])
    return `${faNum(res.created)} طرح درس ساخته شد.`
  })

  /* ------------------------- step 3: generate lessons ------------------------- */
  const generateNext = () => run('generate', async () => {
    if (!api) throw new Error('اتصال برقرار نیست')
    const target = curricula.data?.find((c) => c.id === curriculumId)
    const res = await api.generateNext({
      language_code: target?.language_code ?? lang,
      level: target?.level ?? level,
      size: batchSize,
      curriculum_id: curriculumId || undefined,
    })
    setLastBatch({
      id: res.batch_id, curriculum_id: curriculumId || null, language_code: lang, level,
      requested: batchSize, succeeded: res.succeeded, failed: res.failed,
      status: res.failed ? 'failed' : 'completed', model: null, last_error: res.errors?.join(' | ') ?? null,
      created_at: new Date().toISOString(), started_at: new Date().toISOString(), finished_at: new Date().toISOString(),
    })
    await Promise.all([plans.reload(), lessons.reload(), batches.reload()])
    return `Batch ${res.batch_id.slice(0, 8)} — ${faNum(res.succeeded)} درس ساخته شد${res.failed ? ` و ${faNum(res.failed)} ناموفق` : ''}.`
  })

  /* ------------------------------ validate / dedupe ------------------------------ */
  const validateAll = () => run('validate', async () => {
    if (!api) throw new Error('اتصال برقرار نیست')
    const targets = allLessons.filter((l) => l.status === 'generated' || l.status === 'draft').slice(0, 20)
    if (targets.length === 0) throw new Error('درسی برای اعتبارسنجی وجود ندارد.')
    let ok = 0, bad = 0
    for (const l of targets) {
      const res = await api.validateLesson(l.id)
      if (res.ok) { ok++; await api.adminSetLessonFlags(l.id, { status: 'validated' }) } else bad++
    }
    await lessons.reload()
    return `اعتبارسنجی: ${faNum(ok)} سالم، ${faNum(bad)} نیازمند بازبینی.`
  })

  const checkDuplicates = () => run('dup', async () => {
    if (!api) throw new Error('اتصال برقرار نیست')
    const res = await api.duplicateReport()
    if (res.duplicates.length === 0) return 'هیچ درس تکراری پیدا نشد.'
    return `${faNum(res.duplicates.length)} گروه تکراری پیدا شد: ` + res.duplicates.map((d) => d.titles.join(' / ')).join(' — ')
  })

  const publishAll = () => run('publish', async () => {
    if (!api) throw new Error('اتصال برقرار نیست')
    const ids = allLessons.filter((l) => l.status === 'validated').map((l) => l.id)
    if (ids.length === 0) throw new Error('درسی در وضعیت «اعتبارسنجی‌شده» نیست.')
    const res = await api.publishLessons(ids)
    await lessons.reload()
    return `${faNum(res.published)} درس منتشر شد.`
  })

  const retryFailed = (batchId: string) => run(`retry-${batchId}`, async () => {
    if (!api) throw new Error('اتصال برقرار نیست')
    const target = allLessons.find((l) => l.status === 'failed')
    if (!target) throw new Error('درس ناموفقی وجود ندارد.')
    const res = await api.generateNext({ language_code: target.language_code, level: 'A1', size: 1, rewrite_lesson_id: target.id })
    await Promise.all([lessons.reload(), batches.reload()])
    return `تولید دوباره انجام شد (${faNum(res.succeeded)} موفق).`
  })

  const counts = {
    draft: allLessons.filter((l) => l.status === 'draft').length,
    generated: allLessons.filter((l) => l.status === 'generated').length,
    validated: allLessons.filter((l) => l.status === 'validated').length,
    published: publishedLessons.length,
    failed: allLessons.filter((l) => l.status === 'failed').length,
  }

  const StepBadge = ({ state }: { state?: StepState }) => {
    if (state === 'running') return <Chip tone="primary"><RefreshCw className="size-3 animate-spin" /> در حال اجرا</Chip>
    if (state === 'done') return <Chip tone="success"><CheckCircle2 className="size-3" /> انجام شد</Chip>
    if (state === 'error') return <Chip tone="danger"><AlertTriangle className="size-3" /> خطا</Chip>
    return null
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Content Factory"
        subtitle="تولید درس‌ها به‌صورت مرحله‌به‌مرحله: کرریکولوم → طرح درس → تولید با AI → اعتبارسنجی → بررسی تکراری → انتشار. هر Batch کوچک است و اگر درسی خراب شود فقط همان درس دوباره تولید می‌شود."
        badge={<Chip tone="primary"><Factory className="size-3" /> کارخانه محتوا</Chip>}
        actions={
          <Button variant="outline" onClick={() => { lessons.reload(); plans.reload(); batches.reload(); curricula.reload(); toast('وضعیت‌ها به‌روز شد.', 'info') }}>
            <RefreshCw className="size-4" /> به‌روزرسانی وضعیت
          </Button>
        }
      />

      {/* ------------------------------ status board ------------------------------ */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <StatCard title="پیش‌نویس" value={counts.draft} icon={<Layers className="size-5" />} />
        <StatCard title="تولیدشده" value={counts.generated} icon={<Wand2 className="size-5" />} tone="primary" />
        <StatCard title="اعتبارسنجی‌شده" value={counts.validated} icon={<ListChecks className="size-5" />} tone="warn" />
        <StatCard title="منتشرشده" value={counts.published} icon={<BadgeCheck className="size-5" />} tone="success" />
        <StatCard title="ناموفق" value={counts.failed} icon={<AlertTriangle className="size-5" />} tone="danger" />
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.15fr_1fr]">
        {/* ------------------------------ pipeline ------------------------------ */}
        <div className="space-y-5">
          <Card>
            <SectionTitle title="۱) ساخت کرریکولوم" subtitle="مشخص کن برای کدام زبان و سطح، چند درس می‌خواهی." actions={<Button size="sm" onClick={() => setCurriculumModal(true)}><Plus className="size-3.5" /> کرریکولوم جدید</Button>} />
            {curricula.loading ? <Skeleton className="h-24" /> : (curricula.data ?? []).length === 0 ? (
              <EmptyState
                icon={<GraduationCap className="size-6" />}
                title="کرریکولومی ساخته نشده"
                body="برای شروع، یک کرریکولوم بساز: مثلاً «انگلیسی A1 — مکالمه روزمره» با هدف ۴۰ درس."
                action={<Button size="sm" onClick={() => setCurriculumModal(true)}>ساخت کرریکولوم</Button>}
              />
            ) : (
              <div className="space-y-3">
                <Field label="کرریکولوم فعال">
                  <Select value={curriculumId} onChange={(e) => setCurriculumId(e.target.value)}>
                    <option value="">— انتخاب کنید —</option>
                    {(curricula.data ?? []).map((c: Curriculum) => (
                      <option key={c.id} value={c.id}>{c.title_fa} · {c.language_code.toUpperCase()} {c.level}</option>
                    ))}
                  </Select>
                </Field>
                <div className="space-y-2">
                  {(curricula.data ?? []).map((c: Curriculum) => {
                    const done = allLessons.filter((l) => l.language_code === c.language_code && l.status === 'published').length
                    return (
                      <div key={c.id} className="flex items-center gap-3 rounded-2xl border border-line/70 bg-bg-soft/50 p-3">
                        <span className="text-lg">{languages.find((l) => l.code === c.language_code)?.flag}</span>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[12px] font-extrabold">{c.title_fa}</p>
                          <div className="mt-1.5">
                            <Progress value={Math.min(100, (done / Math.max(1, c.target_lessons)) * 100)} />
                          </div>
                          <p className="mt-1 text-[10px] text-ink-faint">{faNum(done)} از {faNum(c.target_lessons)} درس منتشرشده</p>
                        </div>
                        <Confirmed label={<Trash2 className="size-3.5" />} confirmLabel="حذف کن" onConfirm={async () => { await api?.deleteCurriculum(c.id); await curricula.reload() }} />
                      </div>
                    )
                  })}
                </div>
              </div>
            )}
          </Card>

          <Card>
            <SectionTitle title="۲) تولید طرح درس" subtitle="نقشه راه درس‌ها: عنوان، موضوع، اهداف، واژگان و گرامر هدف." />
            <div className="flex flex-wrap items-end gap-3">
              <Field label="تعداد طرح درس">
                <Select value={String(planCount)} onChange={(e) => setPlanCount(Number(e.target.value))} className="w-40">
                  {[5, 10, 20, 40].map((n) => <option key={n} value={n}>{faNum(n)} درس</option>)}
                </Select>
              </Field>
              <Button loading={busy === 'plans'} onClick={generatePlans} disabled={!curriculumId}><Wand2 className="size-4" /> Generate Lesson Plans</Button>
              <StepBadge state={steps.plans} />
            </div>
            {pendingPlans.length > 0 && (
              <p className="mt-3 text-[11px] text-ink-faint">{faNum(pendingPlans.length)} طرح درس در انتظار تولید هستند.</p>
            )}
          </Card>

          <Card>
            <SectionTitle title="۳) تولید درس‌ها" subtitle={`هر Batch کوچک است (${faNum(batchSize)} درس) تا اگر درسی خراب شد، فقط همان درس دوباره تولید شود.`} />
            <div className="flex flex-wrap items-end gap-3">
              <Field label="اندازه هر Batch">
                <Select value={String(batchSize)} onChange={(e) => setBatchSize(Number(e.target.value))} className="w-40">
                  {[3, 5, 10].map((n) => <option key={n} value={n}>{faNum(n)} درس</option>)}
                </Select>
              </Field>
              <Button loading={busy === 'generate'} onClick={generateNext}><Sparkles className="size-4" /> Generate Next {faNum(batchSize)} Lessons</Button>
              <StepBadge state={steps.generate} />
            </div>
            {lastBatch && (
              <div className="mt-4 rounded-2xl border border-line/70 bg-bg-soft/50 p-4 text-[11px]">
                <p className="font-extrabold">آخرین Batch: <span className="ltr">{lastBatch.id.slice(0, 8)}</span></p>
                <p className="mt-1 text-ink-muted">موفق: {faNum(lastBatch.succeeded)} · ناموفق: {faNum(lastBatch.failed)}</p>
                {lastBatch.last_error && <p className="mt-1 text-danger">{lastBatch.last_error}</p>}
              </div>
            )}
          </Card>

          <Card>
            <SectionTitle title="۴) کنترل کیفیت" subtitle="اعتبارسنجی ساختار درس و بررسی درس‌های تکراری پیش از انتشار." />
            <div className="flex flex-wrap items-center gap-3">
              <Button variant="outline" loading={busy === 'validate'} onClick={validateAll}><ListChecks className="size-4" /> Validate</Button>
              <Button variant="outline" loading={busy === 'dup'} onClick={checkDuplicates}><Copy className="size-4" /> Check Duplicates</Button>
              <StepBadge state={steps.validate} />
              <StepBadge state={steps.dup} />
            </div>
          </Card>

          <Card className="relative overflow-hidden">
            <div className="absolute inset-0 bg-brand-soft opacity-25" />
            <div className="relative">
              <SectionTitle title="۵) انتشار" subtitle="فقط درس‌های اعتبارسنجی‌شده منتشر می‌شوند تا کاربر محتوای ناقص نبیند." />
              <div className="flex flex-wrap items-center gap-3">
                <Button loading={busy === 'publish'} onClick={publishAll} disabled={counts.validated === 0}>
                  <Rocket className="size-4" /> Publish {counts.validated > 0 ? `(${faNum(counts.validated)})` : ''}
                </Button>
                <StepBadge state={steps.publish} />
              </div>
              <p className="mt-3 text-[11px] text-ink-faint">
                {counts.validated === 0
                  ? 'درسی در وضعیت اعتبارسنجی‌شده وجود ندارد. ابتدا تولید و اعتبارسنجی کن.'
                  : `${faNum(counts.validated)} درس آماده انتشار است.`}
              </p>
            </div>
          </Card>
        </div>

        {/* ------------------------------ side: batches + plans ------------------------------ */}
        <div className="space-y-5">
          <Card>
            <SectionTitle title="Batch ها" subtitle="وضعیت هر اجرا ذخیره می‌شود و بعد از Restart هم باقی می‌ماند." />
            {batches.loading ? <Skeleton className="h-24" /> : (batches.data ?? []).length === 0 ? (
              <p className="text-[11px] text-ink-faint">هنوز Batch ای اجرا نشده است.</p>
            ) : (
              <div className="space-y-2.5">
                {(batches.data ?? []).map((b: Batch) => (
                  <div key={b.id} className="rounded-2xl border border-line/70 bg-bg-soft/50 p-3.5">
                    <div className="flex items-center justify-between gap-2">
                      <p className="ltr text-[11px] font-extrabold">{b.id.slice(0, 8)} · {b.language_code.toUpperCase()} {b.level}</p>
                      <BatchStatus status={b.status} />
                    </div>
                    <p className="mt-1.5 text-[10px] text-ink-faint">
                      درخواست {faNum(b.requested)} · موفق {faNum(b.succeeded)} · ناموفق {faNum(b.failed)} · {faRelative(b.created_at)}
                    </p>
                    {b.last_error && <p className="ltr mt-1 line-clamp-2 text-[10px] text-danger">{b.last_error}</p>}
                    {b.failed > 0 && (
                      <Button size="sm" variant="outline" className="mt-2" loading={busy === `retry-${b.id}`} onClick={() => retryFailed(b.id)}>
                        <RefreshCw className="size-3.5" /> تولید دوباره درس‌های ناموفق
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card>
            <SectionTitle title="طرح درس‌های اخیر" subtitle={`${faNum(allPlans.length)} طرح درس`} />
            {plans.loading ? <Skeleton className="h-24" /> : allPlans.length === 0 ? (
              <p className="text-[11px] text-ink-faint">طرح درسی وجود ندارد. از مرحله ۲ شروع کن.</p>
            ) : (
              <div className="max-h-[420px] space-y-2 overflow-y-auto pl-1">
                {allPlans.slice(0, 40).map((p: LessonPlan) => (
                  <div key={p.id} className="flex items-center gap-3 rounded-2xl border border-line/70 bg-card/40 p-3">
                    <span className="grid size-8 shrink-0 place-items-center rounded-xl bg-brand-soft text-[10px] font-extrabold text-primary-soft">{faNum(p.order_index)}</span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12px] font-bold">{p.title}</p>
                      <p className="truncate text-[10px] text-ink-faint">{p.topic || p.grammar_focus || '—'}</p>
                    </div>
                    <PlanStatus status={p.status} />
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card>
            <SectionTitle title="گزارش عملیات" subtitle="سابقه اجراهای همین نشست." />
            {log.length === 0 ? (
              <p className="text-[11px] text-ink-faint">هنوز عملیاتی اجرا نشده است.</p>
            ) : (
              <div className="max-h-56 space-y-1.5 overflow-y-auto pl-1">
                {log.map((l, i) => (
                  <p key={i} className="rounded-xl border border-line/60 bg-bg-soft/50 px-3 py-2 text-[10px] leading-6 text-ink-muted">{l}</p>
                ))}
              </div>
            )}
          </Card>

          <Card className="!p-4">
            <p className="flex items-start gap-2 text-[11px] leading-6 text-ink-faint">
              <Send className="mt-0.5 size-3.5 shrink-0 text-primary-soft" />
              تمام تولید محتوا در سرور انجام می‌شود؛ کلید Groq در مرورگر نیست و درس‌ها فقط پس از اعتبارسنجی و انتشار برای کاربران نمایش داده می‌شوند.
            </p>
            <p className="mt-2 flex items-start gap-2 text-[11px] leading-6 text-ink-faint">
              <BookOpenCheck className="mt-0.5 size-3.5 shrink-0 text-primary-soft" />
              هدف نهایی {faNum(340)} درس برای هر زبان. برای انتشار اولیه لازم نیست همه آماده باشند؛ با ۵ تا ۱۰ درس Premium و ۶ درس رایگان شروع کن.
            </p>
          </Card>
        </div>
      </div>

      {/* ------------------------------ curriculum modal ------------------------------ */}
      <Modal open={curriculumModal} onClose={() => setCurriculumModal(false)} title="ساخت کرریکولوم جدید">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label="زبان">
              <Select value={lang} onChange={(e) => setLang(e.target.value)}>
                {languages.map((l) => <option key={l.code} value={l.code}>{l.flag} {l.name_fa}</option>)}
              </Select>
            </Field>
            <Field label="سطح">
              <Select value={level} onChange={(e) => setLevel(e.target.value)}>
                {LEVELS.map((lv) => <option key={lv} value={lv}>{lv} — {LEVEL_FA[lv]}</option>)}
              </Select>
            </Field>
          </div>
          <Field label="عنوان کرریکولوم">
            <Input value={newCurriculum.title_fa} placeholder="مثال: انگلیسی A1 — مکالمه روزمره" onChange={(e) => setNewCurriculum((c) => ({ ...c, title_fa: e.target.value }))} />
          </Field>
          <Field label="توضیح کوتاه">
            <Textarea value={newCurriculum.summary_fa} placeholder="این مسیر چه چیزی را پوشش می‌دهد؟" onChange={(e) => setNewCurriculum((c) => ({ ...c, summary_fa: e.target.value }))} />
          </Field>
          <Field label="تعداد درس هدف">
            <Input type="number" value={String(newCurriculum.target_lessons)} onChange={(e) => setNewCurriculum((c) => ({ ...c, target_lessons: Number(e.target.value) }))} />
          </Field>
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setCurriculumModal(false)}>انصراف</Button>
            <Button onClick={createCurriculum}><Plus className="size-4" /> ساخت</Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

function BatchStatus({ status }: { status: Batch['status'] }) {
  const map: Record<string, { label: string; tone: 'default' | 'primary' | 'success' | 'warn' | 'danger' }> = {
    idle: { label: 'آماده', tone: 'default' },
    planning: { label: 'طرح‌ریزی', tone: 'warn' },
    generating: { label: 'در حال تولید', tone: 'primary' },
    validating: { label: 'اعتبارسنجی', tone: 'warn' },
    completed: { label: 'کامل', tone: 'success' },
    failed: { label: 'ناقص', tone: 'danger' },
    cancelled: { label: 'لغوشده', tone: 'default' },
  }
  const m = map[status] ?? map.idle
  return <Chip tone={m.tone} className="!px-2 !py-0.5 !text-[10px]">{m.label}</Chip>
}

function PlanStatus({ status }: { status: LessonPlan['status'] }) {
  const map: Record<string, { label: string; tone: 'default' | 'primary' | 'success' | 'danger' }> = {
    planned: { label: 'در انتظار تولید', tone: 'default' },
    generating: { label: 'در حال تولید', tone: 'primary' },
    generated: { label: 'تولیدشده', tone: 'success' },
    failed: { label: 'ناموفق', tone: 'danger' },
  }
  const m = map[status] ?? map.planned
  return <Chip tone={m.tone} className="!px-2 !py-0.5 !text-[10px]">{m.label}</Chip>
}

