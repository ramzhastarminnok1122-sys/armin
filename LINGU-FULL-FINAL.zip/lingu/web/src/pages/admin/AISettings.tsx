import { useState } from 'react'
import { Activity, AlertTriangle, Brain, CheckCircle2, Eye, EyeOff, KeyRound, Save, Sparkles, Zap } from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { Button, Card, Chip, Field, Input, PageHeader, Progress, SectionTitle, Select, Skeleton, StatCard, Switch, Textarea } from '@/components/ui'
import { faDateTime, faNum } from '@/lib/utils'
import type { AiSettings as AiSettingsType } from '@/services/types'

const MODELS = [
  { value: 'openai/gpt-oss-120b', label: 'gpt-oss-120b — کیفیت بالا (پیشنهادی)' },
  { value: 'openai/gpt-oss-20b', label: 'gpt-oss-20b — سریع و سبک' },
  { value: 'qwen/qwen3.8-27b', label: 'qwen3.8-27b — جایگزین' },
  { value: 'openai/gpt-oss-120b', label: 'openai/gpt-oss-120b' },
  { value: 'openai/gpt-oss-20b', label: 'openai/gpt-oss-20b' },
  { value: 'qwen/qwen3-32b', label: 'qwen/qwen3-32b' },
  { value: 'moonshotai/kimi-k2-instruct', label: 'moonshotai/kimi-k2-instruct' },
]

export default function AISettings() {
  const { api, toast, session } = useApp()
  const [key, setKey] = useState('')
  const [showKey, setShowKey] = useState(false)
  const [keyBusy, setKeyBusy] = useState(false)
  const [testBusy, setTestBusy] = useState(false)
  const [testResult, setTestResult] = useState<{ ok: boolean; reply?: string; error?: string; latency_ms?: number; model?: string } | null>(null)
  const [draft, setDraft] = useState<Partial<AiSettingsType> | null>(null)

  const { data, loading, reload } = useAsync(async () => {
    if (!api) return null
    const { supabase, hasBackend } = await import('@/lib/supabase')
    // Design preview has no database: show the real screen shell, never fake values.
    if (!hasBackend) return { settings: null, usage: [] }
    const { data: row } = await supabase.from('ai_settings').select('*').eq('id', 1).maybeSingle()
    const { data: usage } = await supabase.from('ai_usage').select('*').order('created_at', { ascending: false }).limit(120)
    return { settings: row as AiSettingsType | null, usage: usage ?? [] }
  }, [api])

  const s = { ...(data?.settings ?? {}), ...(draft ?? {}) } as AiSettingsType & { key_hint?: string | null }
  const previewOnly = data !== null && data?.settings === null
  const usage = data?.usage ?? []
  const okCalls = usage.filter((u) => u.ok).length
  const tokens = usage.reduce((a, u) => a + (u.prompt_tokens ?? 0) + (u.completion_tokens ?? 0), 0)
  const avgLatency = usage.filter((u) => u.latency_ms).length
    ? Math.round(usage.reduce((a, u) => a + (u.latency_ms ?? 0), 0) / usage.filter((u) => u.latency_ms).length)
    : null

  const saveKey = async () => {
    if (!api || key.trim().length < 20) { toast('کلید Groq معتبر به نظر نمی‌رسد.', 'error'); return }
    setKeyBusy(true)
    try {
      const res = await api.saveGroqKey(key.trim())
      toast(`کلید ذخیره شد (${res.hint}). فقط روی سرور نگه‌داری می‌شود.`, 'success')
      setKey(''); await reload()
    } catch (e) { toast(e instanceof Error ? e.message : 'ذخیره کلید ناموفق بود', 'error') }
    finally { setKeyBusy(false) }
  }

  const test = async () => {
    setTestBusy(true); setTestResult(null)
    try {
      const res = await api?.testAi('یک جمله کوتاه انگلیسی برای تمرین مکالمه کافه بنویس و ترجمه فارسی‌اش را بده.')
      setTestResult(res as any)
    } catch (e) { setTestResult({ ok: false, error: e instanceof Error ? e.message : 'تست ناموفق بود' }) }
    finally { setTestBusy(false) }
  }

  const saveSettings = async () => {
    if (!api || !draft) { toast('تغییری برای ذخیره نیست.', 'info'); return }
    try {
      await api.saveAiSettings(draft)
      toast('تنظیمات AI ذخیره شد.', 'success')
      setDraft(null); await reload()
    } catch (e) { toast(e instanceof Error ? e.message : 'ذخیره ناموفق بود', 'error') }
  }

  const update = (patch: Partial<AiSettingsType>) => setDraft((d) => ({ ...(d ?? {}), ...patch }))

  if (loading) return <div className="space-y-4"><Skeleton className="h-9 w-56" /><div className="card-surface h-64 p-5"><Skeleton className="h-6 w-1/3" /></div></div>

  // Preview (no database connected): keep the layout, state clearly that values come from the real project.
  if (previewOnly) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="تنظیمات AI"
          subtitle="اتصال امن به Groq، انتخاب مدل، پرامپت‌های سیستمی و سقف پیام‌های کاربران. کلید فقط روی سرور ذخیره می‌شود و هرگز به مرورگر یا اپ فرستاده نمی‌شود."
          badge={<Chip tone="primary"><Sparkles className="size-3" /> هوش مصنوعی</Chip>}
        />
        <Card className="!p-6">
          <div className="flex items-start gap-3">
            <span className="grid size-11 place-items-center rounded-2xl bg-warn/15 text-warn"><AlertTriangle className="size-5" /></span>
            <div>
              <h3 className="text-[14px] font-extrabold">این صفحه پس از اتصال پروژه Supabase فعال می‌شود</h3>
              <p className="mt-2 max-w-2xl text-[12px] leading-7 text-ink-muted">
                در پیش‌نمایش طراحی، دیتابیس متصل نیست؛ بنابراین هیچ مقدار ساختگی نمایش داده نمی‌شود. پس از اجرای SETUP.sql در پروژه
                Supabase و ورود با حساب مدیر، همین صفحه وضعیت واقعی کلید Groq، مدل فعال، سقف پیام‌ها و مصرف واقعی AI را نشان می‌دهد
                و امکان ذخیره کلید و اجرای تست اتصال را می‌دهد.
              </p>
              <ul className="mt-4 space-y-2 text-[11.5px] text-ink-muted">
                {['ذخیره کلید Groq روی سرور (بدون افشا در فرانت‌اند)', 'انتخاب مدل و مدل جایگزین', 'پرامپت سیستمی Tutor و Partner', 'سقف پیام رایگان و سقف روزانه Premium', 'گزارش مصرف و خطاهای ۲۴ ساعت گذشته'].map((t) => (
                  <li key={t} className="flex items-center gap-2">• {t}</li>
                ))}
              </ul>
            </div>
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="تنظیمات AI"
        subtitle="اتصال امن به Groq، انتخاب مدل، پرامپت‌های سیستمی و سقف پیام‌های کاربران. کلید فقط روی سرور ذخیره می‌شود و هرگز به مرورگر یا اپ فرستاده نمی‌شود."
        badge={<Chip tone="primary"><Sparkles className="size-3" /> هوش مصنوعی</Chip>}
        actions={<Button onClick={saveSettings} disabled={!draft}><Save className="size-4" /> ذخیره تنظیمات</Button>}
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard title="تماس‌های AI (نمونه اخیر)" value={usage.length} icon={<Activity className="size-5" />} />
        <StatCard title="موفق" value={okCalls} hint={usage.length ? `${faNum(Math.round((okCalls / usage.length) * 100))}٪ موفق` : 'بدون داده'} icon={<CheckCircle2 className="size-5" />} tone="success" />
        <StatCard title="توکن مصرفی" value={tokens} icon={<Brain className="size-5" />} tone="warn" />
        <StatCard title="میانگین تأخیر" value={avgLatency ? `${faNum(avgLatency)}` : '—'} suffix={avgLatency ? ' ms' : ''} icon={<Zap className="size-5" />} />
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <SectionTitle title="کلید Groq" subtitle="کلید را از console.groq.com بگیر و همین‌جا وارد کن." />
          <div className="flex flex-col gap-3 sm:flex-row">
            <div className="relative flex-1">
              <KeyRound className="pointer-events-none absolute right-4 top-1/2 size-4 -translate-y-1/2 text-ink-faint" />
              <Input dir="ltr" type={showKey ? 'text' : 'password'} className="pr-11 pl-11" placeholder="gsk_..." value={key} onChange={(e) => setKey(e.target.value)} />
              <button onClick={() => setShowKey((v) => !v)} className="absolute left-3 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-ink-faint hover:text-ink" type="button">
                {showKey ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            </div>
            <Button onClick={saveKey} loading={keyBusy} className="sm:w-40">ذخیره کلید</Button>
          </div>
          <div className="mt-4 space-y-2 text-[11px]">
            <div className="flex items-center justify-between rounded-2xl border border-line/70 bg-bg-soft/50 px-3 py-2.5">
              <span className="text-ink-faint">وضعیت کلید</span>
              <span className={`font-extrabold ${s?.has_key ? 'text-success' : 'text-warn'}`}>{s?.has_key ? `ثبت شده (${s.key_hint ?? '—'})` : 'ثبت نشده'}</span>
            </div>
            <p className="flex items-start gap-2 leading-6 text-ink-faint">
              <AlertTriangle className="mt-0.5 size-3.5 shrink-0 text-warn" />
              کلید در جدول امن سرور نگه‌داری می‌شود، از دسترس مرورگر خارج است و در GitHub قرار نمی‌گیرد.
            </p>
          </div>
        </Card>

        <Card>
          <SectionTitle title="تست اتصال" subtitle="یک درخواست واقعی به Groq با همین تنظیمات." />
          <Button onClick={test} loading={testBusy} variant="outline"><Zap className="size-4" /> تست AI</Button>
          {testResult && (
            <div className={`mt-4 rounded-2xl border p-4 text-[12px] leading-7 ${testResult.ok ? 'border-success/40 bg-success/10' : 'border-danger/40 bg-danger/10'}`}>
              {testResult.ok ? (
                <>
                  <p className="flex items-center gap-2 font-extrabold text-success"><CheckCircle2 className="size-4" /> پاسخ از {testResult.model} {testResult.latency_ms ? `· ${faNum(testResult.latency_ms)} ms` : ''}</p>
                  <p className="mt-2 whitespace-pre-line text-ink">{testResult.reply}</p>
                </>
              ) : (
                <p className="flex items-start gap-2 font-bold text-danger"><AlertTriangle className="mt-0.5 size-4 shrink-0" /> {testResult.error}</p>
              )}
            </div>
          )}
          {!session && <p className="mt-3 text-[11px] text-ink-faint">برای تست، باید با حساب مدیر وارد شده باشی.</p>}
        </Card>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <SectionTitle title="مدل و پارامترها" />
          <div className="space-y-4">
            <Field label="مدل اصلی">
              <Select value={s?.model ?? ''} onChange={(e) => update({ model: e.target.value })}>
                {MODELS.map((m) => <option key={m.value} value={m.value}>{m.label}</option>)}
              </Select>
            </Field>
            <Field label="مدل جایگزین (در صورت خطا)" hint="اگر مدل اصلی خطا داد، این مدل امتحان می‌شود.">
              <Select value={s?.fallback_model ?? ''} onChange={(e) => update({ fallback_model: e.target.value })}>
                {MODELS.map((m) => <option key={m.value} value={m.value}>{m.label}</option>)}
              </Select>
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="دمای مدل (۰ تا ۱)" hint="عدد کمتر = پاسخ‌های دقیق‌تر">
                <Input type="number" step="0.05" min="0" max="1" value={String(s?.temperature ?? 0.7)} onChange={(e) => update({ temperature: Number(e.target.value) })} />
              </Field>
              <Field label="حداکثر توکن پاسخ">
                <Input type="number" value={String(s?.max_tokens ?? 1200)} onChange={(e) => update({ max_tokens: Number(e.target.value) })} />
              </Field>
            </div>
            <div className="flex items-center justify-between rounded-2xl border border-line/70 bg-bg-soft/50 px-4 py-3">
              <span className="text-xs font-bold">دستیار AI فعال باشد</span>
              <Switch checked={Boolean(s?.is_ai_enabled)} onChange={(v) => update({ is_ai_enabled: v })} />
            </div>
          </div>
        </Card>

        <Card>
          <SectionTitle title="سقف مصرف" subtitle="این اعداد در سرور اعمال می‌شوند، نه در مرورگر." />
          <div className="space-y-4">
            <Field label="پیام رایگان Conversation Partner (برای همیشه)" hint="پیش‌فرض ۲ پیام — پس از آن پیام محترمانه اشتراک نمایش داده می‌شود.">
              <Input type="number" min="0" value={String(s?.free_partner_messages ?? 2)} onChange={(e) => update({ free_partner_messages: Number(e.target.value) })} />
            </Field>
            <Field label="سقف روزانه پیام Conversation (کاربر Premium)">
              <Input type="number" min="1" value={String(s?.premium_daily_messages ?? 200)} onChange={(e) => update({ premium_daily_messages: Number(e.target.value) })} />
            </Field>
            <Field label="سقف روزانه AI Tutor (کاربر Premium)">
              <Input type="number" min="1" value={String(s?.premium_daily_tutor ?? 200)} onChange={(e) => update({ premium_daily_tutor: Number(e.target.value) })} />
            </Field>
            <p className="text-[11px] leading-6 text-ink-faint">سقف روزانه فقط برای جلوگیری از مصرف ناگهانی است؛ کاربر Premium در عمل بدون محدودیت محسوس کار می‌کند.</p>
          </div>
        </Card>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <SectionTitle title="پرامپت AI Tutor" subtitle="شخصیت و قواعد مربی آموزشی LINGU." />
          <Textarea className="min-h-[200px]" value={s?.tutor_system_prompt ?? ''} onChange={(e) => update({ tutor_system_prompt: e.target.value })} />
        </Card>
        <Card>
          <SectionTitle title="پرامپت Conversation Partner" subtitle="شخصیت و قواعد هم‌صحبت نقش‌محور." />
          <Textarea className="min-h-[200px]" value={s?.partner_system_prompt ?? ''} onChange={(e) => update({ partner_system_prompt: e.target.value })} />
        </Card>
      </div>

      <Card>
        <SectionTitle title="آخرین تماس‌ها" subtitle="برای بررسی سلامت اتصال و هزینه مصرف." />
        {usage.length === 0 ? (
          <p className="text-[12px] text-ink-faint">هنوز تماس AI ثبت نشده است. پس از اولین استفاده کاربران، اینجا نمایش داده می‌شود.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[600px] text-sm">
              <thead className="bg-card-soft/40">
                <tr className="text-[11px] text-ink-faint">
                  <th className="px-4 py-3 text-right font-bold">زمان</th>
                  <th className="px-4 py-3 text-right font-bold">قابلیت</th>
                  <th className="px-4 py-3 text-right font-bold">مدل</th>
                  <th className="px-4 py-3 text-right font-bold">توکن</th>
                  <th className="px-4 py-3 text-right font-bold">تأخیر</th>
                  <th className="px-4 py-3 text-right font-bold">وضعیت</th>
                </tr>
              </thead>
              <tbody>
                {usage.slice(0, 25).map((u) => (
                  <tr key={u.id} className="border-t border-line/50">
                    <td className="px-4 py-2.5 text-[11px] text-ink-faint">{faDateTime(u.created_at)}</td>
                    <td className="px-4 py-2.5 text-[11px]">{u.feature === 'tutor' ? 'AI Tutor' : 'Conversation'}</td>
                    <td className="ltr px-4 py-2.5 text-[11px] text-ink-muted">{u.model ?? '—'}</td>
                    <td className="px-4 py-2.5 text-[11px]">{faNum((u.prompt_tokens ?? 0) + (u.completion_tokens ?? 0))}</td>
                    <td className="px-4 py-2.5 text-[11px]">{u.latency_ms ? `${faNum(u.latency_ms)} ms` : '—'}</td>
                    <td className="px-4 py-2.5">
                      {u.ok ? <Chip tone="success" className="!px-2 !py-0.5 !text-[10px]">موفق</Chip> : <Chip tone="danger" className="!px-2 !py-0.5 !text-[10px]">خطا</Chip>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="mt-5">
          <p className="mb-2 text-[11px] font-bold text-ink-faint">نرخ موفقیت در نمونه اخیر</p>
          <Progress value={usage.length ? (okCalls / usage.length) * 100 : 0} showLabel />
        </div>
      </Card>
    </div>
  )
}
