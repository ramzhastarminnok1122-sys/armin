import { useEffect, useRef, useState } from 'react'
import {
  Check, Eye, ImageIcon, Info, Pencil, Plus, RefreshCw, Trash2, Upload, Wand2,
} from 'lucide-react'
import { useApp } from '@/context/AppContext'
import {
  Button, Card, Chip, Confirmed, EmptyState, Field, Input, Modal, Select, Skeleton, Switch,
} from '@/components/ui'
import { cn, faDateTime } from '@/lib/utils'
import { MEDIA_CATEGORIES, MEDIA_SLOTS } from '@/lib/constants'
import type { MediaAsset } from '@/services/types'

type Draft = Partial<MediaAsset> & { slot: string; name: string; url: string }

const SLOT_LABEL: Record<string, string> = Object.fromEntries(MEDIA_SLOTS.map((s) => [s.slot, s.label]))
const SLOT_WHERE: Record<string, string> = Object.fromEntries(MEDIA_SLOTS.map((s) => [s.slot, s.where]))
void SLOT_WHERE

export default function MediaLibrary() {
  const { api, toast, refreshMedia } = useApp()
  const [rows, setRows] = useState<MediaAsset[] | null>(null)
  const [editing, setEditing] = useState<Draft | null>(null)
  const [saving, setSaving] = useState(false)
  const [busySlot, setBusySlot] = useState<string | null>(null)
  const [preview, setPreview] = useState<MediaAsset | null>(null)
  const fileRefs = useRef<Record<string, HTMLInputElement | null>>({})

  const load = async () => {
    if (!api) return
    try { setRows(await api.adminMedia()) } catch (e: any) { toast(e?.message ?? 'بارگذاری رسانه‌ها ناموفق بود', 'error'); setRows([]) }
  }

  useEffect(() => { if (rows === null && api) void load() }, [api]) // eslint-disable-line react-hooks/exhaustive-deps


  const save = async (patch?: Partial<Draft>) => {
    const payload = { ...(editing ?? {}), ...(patch ?? {}) } as Draft
    if (!api || !payload.slot) return
    setSaving(true)
    try {
      await api.saveMediaAsset({
        slot: payload.slot,
        name: payload.name || SLOT_LABEL[payload.slot] || payload.slot,
        category: payload.category ?? 'hero',
        url: payload.url,
        storage_path: payload.storage_path ?? null,
        alt_fa: payload.alt_fa ?? null,
        used_in: payload.used_in ?? [],
        is_active: payload.is_active ?? true,
        sort_order: payload.sort_order ?? 99,
      } as any)
      await load(); await refreshMedia()
      setEditing(null)
      toast('تصویر ذخیره و در سایت اعمال شد.', 'success')
    } catch (e: any) { toast(e?.message ?? 'ذخیره تصویر ناموفق بود', 'error') }
    finally { setSaving(false) }
  }

  const upload = async (file: File, slot: string, existing?: MediaAsset) => {
    if (!api) return
    setBusySlot(slot)
    try {
      const { url, path } = await api.uploadMedia(file, slot)
      await api.saveMediaAsset({
        slot,
        name: existing?.name ?? SLOT_LABEL[slot] ?? slot,
        category: existing?.category ?? 'hero',
        url, storage_path: path,
        alt_fa: existing?.alt_fa ?? null,
        used_in: existing?.used_in ?? [],
        is_active: true,
        sort_order: existing?.sort_order ?? 99,
      } as any)
      await load(); await refreshMedia()
      toast('فایل بارگذاری و جای‌گذاری شد.', 'success')
    } catch (e: any) { toast(e?.message ?? 'بارگذاری فایل ناموفق بود', 'error') }
    finally { setBusySlot(null) }
  }

  const remove = async (row: MediaAsset) => {
    if (!api) return
    try { await api.deleteMediaAsset(row.id, row.storage_path); await load(); await refreshMedia(); toast('حذف شد.', 'success') }
    catch (e: any) { toast(e?.message ?? 'حذف ناموفق بود', 'error') }
  }

  const toggleActive = async (row: MediaAsset) => {
    if (!api) return
    try {
      await api.saveMediaAsset({ ...row, is_active: !row.is_active } as any)
      await load(); await refreshMedia()
      toast(row.is_active ? 'تصویر غیرفعال شد؛ نسخه پیش‌فرض نمایش داده می‌شود.' : 'تصویر فعال شد.', 'success')
    } catch (e: any) { toast(e?.message ?? 'تغییر وضعیت ناموفق بود', 'error') }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Chip tone="primary"><ImageIcon className="size-3" /> رسانه</Chip>
          <h1 className="mt-3 text-2xl font-extrabold">کتابخانه تصاویر</h1>
          <p className="mt-2 max-w-2xl text-sm leading-7 text-ink-muted">
            هر تصویر مهم سایت و برنامه از اینجا قابل تغییر است: جای‌گذاری، بارگذاری فایل جدید، فعال/غیرفعال کردن و پیش‌نمایش — بدون نیاز به تغییر کد.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => load()}><RefreshCw className="size-4" /> به‌روزرسانی</Button>
          <Button onClick={() => setEditing({ slot: '', name: '', url: '', category: 'hero', is_active: true, sort_order: 99 })}>
            <Plus className="size-4" /> جایگاه تصویر جدید
          </Button>
        </div>
      </div>

      <Card className="!p-4">
        <p className="flex items-start gap-2 text-[11.5px] leading-7 text-ink-muted">
          <Info className="mt-1 size-3.5 shrink-0 text-primary-soft" />
          تصاویر پیش‌فرض همراه برنامه منتشر می‌شوند؛ اگر تصویری را غیرفعال کنی یا فایل آن را جایگزین کنی، شکل ظاهری سایت و برنامه بی‌درنگ (بدون انتشار نسخه جدید) تغییر می‌کند.
        </p>
      </Card>

      {rows === null && <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-64" />)}</div>}

      {rows !== null && rows.length === 0 && (
        <EmptyState
          icon={<ImageIcon className="size-6" />}
          title="هنوز تصویری ثبت نشده"
          body="با «جایگاه تصویر جدید» اولین تصویر را اضافه کن؛ یا در دیتابیس تابع مهاجرت را اجرا کن تا تصاویر پیش‌فرض ثبت شوند."
        />
      )}

      {rows !== null && rows.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {rows.map((row) => (
            <Card key={row.id} className={cn('flex flex-col !p-0 overflow-hidden', !row.is_active && 'opacity-60')}>
              <div className="relative h-40 bg-bg-soft">
                <img src={row.url} alt={row.alt_fa ?? row.name} loading="lazy" className="size-full object-cover" />
                <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-2 bg-gradient-to-t from-black/55 to-transparent p-3">
                  <Chip className="!border-white/25 !bg-white/15 !text-white !backdrop-blur-md !px-2 !py-0.5 !text-[10px]">{row.category}</Chip>
                  {row.is_active
                    ? <Chip tone="success" className="!px-2 !py-0.5 !text-[10px]"><Check className="size-2.5" /> فعال</Chip>
                    : <Chip className="!px-2 !py-0.5 !text-[10px]">غیرفعال</Chip>}
                </div>
              </div>

              <div className="flex flex-1 flex-col p-4">
                <p className="text-[13px] font-extrabold">{row.name}</p>
                <p className="ltr mt-0.5 truncate text-[10px] text-ink-faint">{row.slot}</p>
                {row.used_in?.length > 0 && (
                  <p className="mt-2 text-[10.5px] leading-5 text-ink-muted">استفاده در: {row.used_in.join(' · ')}</p>
                )}
                <p className="mt-1 text-[10px] text-ink-faint">آخرین تغییر: {faDateTime(row.created_at)}</p>

                <div className="mt-4 flex flex-wrap items-center gap-2">
                  <Button size="sm" variant="outline" onClick={() => setPreview(row)}><Eye className="size-3.5" /> پیش‌نمایش</Button>
                  <Button size="sm" variant="outline" loading={busySlot === row.slot} onClick={() => fileRefs.current[row.slot]?.click()}>
                    <Upload className="size-3.5" /> جایگزینی
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setEditing({ ...row } as any)}><Pencil className="size-3.5" /></Button>
                  <Confirmed label={<Trash2 className="size-3.5" />} ariaLabel="حذف تصویر" confirmLabel="حذف شود؟" onConfirm={() => remove(row)} />
                  <input ref={(el) => { fileRefs.current[row.slot] = el }} type="file" accept="image/*" className="hidden"
                    onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f, row.slot, row); e.target.value = '' }} />
                </div>

                <div className="mt-3 flex items-center justify-between border-t border-line/60 pt-3">
                  <span className="text-[11px] text-ink-muted">نمایش در سایت</span>
                  <Switch checked={row.is_active} onChange={() => toggleActive(row)} />
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* ------------------------------- edit modal ------------------------------- */}
      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? 'ویرایش تصویر' : 'افزودن تصویر'} wide>
        {editing && (
          <div className="space-y-4">
            <Field label="جایگاه (Slot)" required hint="کلید یکتا؛ اگر جایگاه موجودی را انتخاب کنی، همان جایگاه به‌روزرسانی می‌شود.">
              <Select value={editing.slot} onChange={(e) => setEditing({ ...editing, slot: e.target.value, name: editing.name || SLOT_LABEL[e.target.value] || '' })}>
                <option value="">انتخاب جایگاه…</option>
                {MEDIA_SLOTS.map((s) => <option key={s.slot} value={s.slot}>{s.label} — {s.where}</option>)}
                <option value="custom">جایگاه سفارشی…</option>
              </Select>
            </Field>
            {editing.slot === 'custom' && (
              <Field label="کلید جایگاه سفارشی" required hint="مثلاً scenario_cafe یا banner_ramadan">
                <Input value={editing.slot === 'custom' ? '' : editing.slot} onChange={(e) => setEditing({ ...editing, slot: e.target.value })} placeholder="scenario_cafe" />
              </Field>
            )}
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="نام نمایشی" required><Input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></Field>
              <Field label="دسته">
                <Select value={editing.category ?? 'hero'} onChange={(e) => setEditing({ ...editing, category: e.target.value })}>
                  {MEDIA_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                </Select>
              </Field>
            </div>
            <Field label="آدرس تصویر (URL)" required hint="می‌توانی آدرس فایل بارگذاری‌شده در Storage یا هر آدرس https معتبر را وارد کنی.">
              <Input value={editing.url} onChange={(e) => setEditing({ ...editing, url: e.target.value })} placeholder="/art/hero-aurora.webp" className="ltr" />
            </Field>
            <Field label="متن جانشین (alt)"><Input value={editing.alt_fa ?? ''} onChange={(e) => setEditing({ ...editing, alt_fa: e.target.value })} /></Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="ترتیب نمایش"><Input type="number" value={editing.sort_order ?? 99} onChange={(e) => setEditing({ ...editing, sort_order: Number(e.target.value) })} /></Field>
              <div className="flex items-end">
                <div className="flex w-full items-center justify-between rounded-2xl border border-line/70 bg-bg-soft/50 px-4 py-3">
                  <span className="text-[12px] font-bold">فعال باشد</span>
                  <Switch checked={editing.is_active ?? true} onChange={(v) => setEditing({ ...editing, is_active: v })} />
                </div>
              </div>
            </div>

            {editing.url && (
              <div className="flex items-center gap-3 rounded-3xl border border-line/70 bg-bg-soft/40 p-3">
                <img src={editing.url} alt="" className="size-20 rounded-2xl object-cover" />
                <div className="text-[11px] leading-6 text-ink-muted">
                  پیش‌نمایش تصویر جدید.<br />پس از ذخیره، سایت و برنامه فوراً همین تصویر را نشان می‌دهند.
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-1">
              <Button variant="ghost" onClick={() => setEditing(null)}>انصراف</Button>
              <Button loading={saving} onClick={() => save()}><Wand2 className="size-4" /> ذخیره و اعمال</Button>
            </div>
          </div>
        )}
      </Modal>

      {/* ------------------------------ preview modal ------------------------------ */}
      <Modal open={!!preview} onClose={() => setPreview(null)} title={preview?.name ?? 'پیش‌نمایش'} wide>
        {preview && (
          <div className="space-y-4">
            <img src={preview.url} alt="" className="max-h-[52vh] w-full rounded-3xl object-contain" />
            <div className="grid gap-2 text-[11.5px] sm:grid-cols-2">
              <Row label="جایگاه" value={preview.slot} />
              <Row label="دسته" value={preview.category} />
              <Row label="استفاده در" value={preview.used_in?.join(' · ') || '—'} />
              <Row label="وضعیت" value={preview.is_active ? 'فعال' : 'غیرفعال'} />
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl border border-line/60 bg-bg-soft/40 px-3 py-2">
      <span className="text-ink-faint">{label}</span><span className="ltr font-bold text-ink">{value}</span>
    </div>
  )
}

