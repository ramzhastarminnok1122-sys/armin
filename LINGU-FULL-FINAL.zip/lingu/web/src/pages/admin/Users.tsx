import { useMemo, useState } from 'react'
import { BadgeCheck, Ban, Crown, Search, ShieldCheck, UserRound, Users as UsersIcon } from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { Button, Card, Chip, Confirmed, EmptyState, Input, Modal, PageHeader, Skeleton, StatCard, Switch, Tabs } from '@/components/ui'
import { faDate, faDateTime, faNum, faRelative } from '@/lib/utils'
import type { AdminUserRow } from '@/services/types'

export default function Users() {
  const { api, toast, profile: me } = useApp()
  const [q, setQ] = useState('')
  const [tab, setTab] = useState<'all' | 'premium' | 'free' | 'blocked'>('all')
  const [detail, setDetail] = useState<AdminUserRow | null>(null)
  const [busy, setBusy] = useState<string | null>(null)
  const { data, loading, reload } = useAsync(async () => (api ? api.adminUsers(q) : []), [api, q])

  const users = data ?? []
  const filtered = useMemo(() => users.filter((u) => {
    if (tab === 'premium') return u.premium
    if (tab === 'free') return !u.premium
    if (tab === 'blocked') return !u.is_active
    return true
  }), [users, tab])

  const toggleActive = async (u: AdminUserRow) => {
    if (!api) return
    setBusy(u.id)
    try {
      await api.adminSetUserActive(u.id, !u.is_active)
      toast(u.is_active ? 'حساب کاربر غیرفعال شد.' : 'حساب کاربر فعال شد.', 'success')
      await reload(); setDetail(null)
    } catch (e) { toast(e instanceof Error ? e.message : 'عملیات ناموفق بود', 'error') }
    finally { setBusy(null) }
  }

  const toggleRole = async (u: AdminUserRow) => {
    if (!api) return
    if (u.id === me?.id) { toast('نمی‌توانی نقش خودت را تغییر بدهی.', 'error'); return }
    setBusy(u.id)
    try {
      await api.adminSetUserRole(u.id, u.role === 'admin' ? 'user' : 'admin')
      toast('نقش کاربر تغییر کرد.', 'success')
      await reload(); setDetail(null)
    } catch (e) { toast(e instanceof Error ? e.message : 'عملیات ناموفق بود', 'error') }
    finally { setBusy(null) }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="کاربران"
        subtitle="جستجو، مشاهده وضعیت اشتراک، مصرف AI و فعال/غیرفعال کردن حساب‌ها."
        badge={<Chip tone="primary"><UsersIcon className="size-3" /> مدیریت کاربران</Chip>}
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard title="کل کاربران" value={users.length} icon={<UsersIcon className="size-5" />} />
        <StatCard title="Premium" value={users.filter((u) => u.premium).length} icon={<BadgeCheck className="size-5" />} tone="success" />
        <StatCard title="غیرفعال" value={users.filter((u) => !u.is_active).length} icon={<Ban className="size-5" />} tone="danger" />
      </div>

      <Card className="!p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <Tabs
            value={tab} onChange={setTab}
            tabs={[
              { id: 'all', label: 'همه', count: users.length },
              { id: 'premium', label: 'Premium', count: users.filter((u) => u.premium).length },
              { id: 'free', label: 'رایگان', count: users.filter((u) => !u.premium).length },
              { id: 'blocked', label: 'غیرفعال', count: users.filter((u) => !u.is_active).length },
            ]} />
          <div className="relative lg:w-72">
            <Search className="pointer-events-none absolute right-3.5 top-1/2 size-4 -translate-y-1/2 text-ink-faint" />
            <Input className="pr-10" placeholder="جستجو بر اساس نام یا شناسه…" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
        </div>
      </Card>

      <Card className="!p-0 overflow-hidden">
        {loading && <div className="space-y-3 p-5">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12" />)}</div>}

        {!loading && filtered.length === 0 && (
          <div className="p-5">
            <EmptyState icon={<UserRound className="size-6" />} title="کاربری پیدا نشد" body={q ? 'عبارت جستجو را تغییر بده.' : 'هنوز کاربری در این دسته وجود ندارد.'} />
          </div>
        )}

        {!loading && filtered.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[860px] text-sm">
              <thead className="bg-card-soft/40">
                <tr className="text-[11px] text-ink-faint">
                  <th className="px-4 py-3 text-right font-bold">کاربر</th>
                  <th className="px-4 py-3 text-right font-bold">نقش</th>
                  <th className="px-4 py-3 text-right font-bold">Premium</th>
                  <th className="px-4 py-3 text-right font-bold">مصرف AI</th>
                  <th className="px-4 py-3 text-right font-bold">درس کامل</th>
                  <th className="px-4 py-3 text-right font-bold">آخرین فعالیت</th>
                  <th className="px-4 py-3 text-right font-bold">وضعیت</th>
                  <th className="px-4 py-3 text-right font-bold">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((u) => (
                  <tr key={u.id} className="border-t border-line/50 transition-colors hover:bg-card-soft/25">
                    <td className="px-4 py-3">
                      <button onClick={() => setDetail(u)} className="text-right">
                        <span className="block text-[13px] font-extrabold hover:text-primary-soft">{u.display_name || 'بدون نام'}</span>
                        <span className="ltr block text-[10px] text-ink-faint">{u.id.slice(0, 18)}…</span>
                      </button>
                    </td>
                    <td className="px-4 py-3 text-[11px] text-ink-muted">{u.role === 'admin' ? 'مدیر' : 'کاربر'}</td>
                    <td className="px-4 py-3">
                      {u.premium
                        ? <Chip tone="success" className="!px-2 !py-0.5 !text-[10px]"><Crown className="size-3" /> تا {faDate(u.premium_until)}</Chip>
                        : <Chip className="!px-2 !py-0.5 !text-[10px]">رایگان</Chip>}
                    </td>
                    <td className="px-4 py-3 text-[11px] text-ink-muted">{faNum(u.ai_messages)} تماس</td>
                    <td className="px-4 py-3 text-[11px] text-ink-muted">{faNum(u.lessons_completed)}</td>
                    <td className="px-4 py-3 text-[11px] text-ink-faint">{faRelative(u.last_seen_at || u.created_at)}</td>
                    <td className="px-4 py-3">
                      {u.is_active ? <Chip tone="success" className="!px-2 !py-0.5 !text-[10px]">فعال</Chip> : <Chip tone="danger" className="!px-2 !py-0.5 !text-[10px]">غیرفعال</Chip>}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1.5">
                        <Button size="sm" variant="ghost" onClick={() => setDetail(u)}>جزئیات</Button>
                        {u.id !== me?.id && (
                          <Confirmed
                            variant={u.is_active ? 'outline' : 'primary'}
                            label={u.is_active ? 'غیرفعال' : 'فعال‌سازی'}
                            confirmLabel="تأیید غیرفعال‌سازی"
                            onConfirm={() => toggleActive(u)} />
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal open={Boolean(detail)} onClose={() => setDetail(null)} title="جزئیات کاربر" wide>
        {detail && (
          <div className="space-y-5">
            <div className="flex flex-wrap items-center gap-4">
              <span className="grid size-14 place-items-center rounded-3xl bg-brand-grad text-lg font-extrabold text-white">{(detail.display_name || '?').slice(0, 2)}</span>
              <div>
                <p className="text-lg font-extrabold">{detail.display_name || 'بدون نام'}</p>
                <p className="ltr text-[11px] text-ink-faint">{detail.id}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                {detail.role === 'admin' && <Chip tone="primary"><ShieldCheck className="size-3" /> مدیر</Chip>}
                {detail.premium ? <Chip tone="success"><BadgeCheck className="size-3" /> Premium</Chip> : <Chip>رایگان</Chip>}
                {!detail.is_active && <Chip tone="danger"><Ban className="size-3" /> غیرفعال</Chip>}
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <InfoBox label="تاریخ عضویت" value={faDateTime(detail.created_at)} />
              <InfoBox label="آخرین فعالیت" value={faDateTime(detail.last_seen_at)} />
              <InfoBox label="پایان اشتراک" value={detail.premium_until ? faDateTime(detail.premium_until) : '—'} />
              <InfoBox label="پلن فعال" value={detail.plan_title || '—'} />
              <InfoBox label="مصرف AI (کل)" value={`${faNum(detail.ai_messages)} تماس`} />
              <InfoBox label="آخرین تماس AI" value={detail.last_ai_at ? faDateTime(detail.last_ai_at) : '—'} />
              <InfoBox label="درس‌های کامل‌شده" value={faNum(detail.lessons_completed)} />
              <InfoBox label="وضعیت تور آموزشی" value={detail.tour_done ? 'دیده‌شده' : 'دیده‌نشده'} />
            </div>

            <div className="divider" />

            <div className="flex flex-wrap items-center justify-between gap-3">
              <Switch checked={detail.is_active} label="حساب فعال باشد" onChange={() => toggleActive(detail)} />
              <Button variant="outline" size="sm" loading={busy === detail.id} onClick={() => toggleRole(detail)}>
                <ShieldCheck className="size-3.5" /> {detail.role === 'admin' ? 'تبدیل به کاربر عادی' : 'ارتقا به مدیر'}
              </Button>
            </div>
            <p className="text-[10px] leading-6 text-ink-faint">
              وضعیت Premium فقط از طریق خرید واقعی مایکت تغییر می‌کند. برای لغو اشتراک به بخش «اشتراک‌ها» برو.
            </p>
          </div>
        )}
      </Modal>
    </div>
  )
}

function InfoBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-line/70 bg-bg-soft/50 p-3">
      <p className="text-[10px] font-bold text-ink-faint">{label}</p>
      <p className="mt-1 text-[12px] font-bold">{value}</p>
    </div>
  )
}

