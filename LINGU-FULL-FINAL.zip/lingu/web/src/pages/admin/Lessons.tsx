import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { BookOpenCheck, CheckCircle2, ExternalLink, Eye, Filter, Layers, Lock, Search, Trash2, Unlock } from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { Button, Card, Chip, Confirmed, EmptyState, Input, PageHeader, Select, Skeleton, StatCard, Tabs } from '@/components/ui'
import { faDateTime, faNum } from '@/lib/utils'

type Row = {
  id: string; language_code: string; level: string; order_index: number; title: string
  subtitle: string | null; estimated_minutes: number; is_free: boolean; status: string
  fingerprint: string | null; created_at: string
}

export default function Lessons() {
  const { api, toast, languages } = useApp()
  const [lang, setLang] = useState('all')
  const [status, setStatus] = useState<'all' | 'published' | 'draft' | 'validated' | 'generated' | 'failed'>('all')
  const [q, setQ] = useState('')
  const [busy, setBusy] = useState<string | null>(null)
  const [selected, setSelected] = useState<Set<string>>(new Set())

  const { data, loading, reload } = useAsync(async () => {
    if (!api) return []
    return await api.adminLessons({ language: lang === 'all' ? undefined : lang, status: status === 'all' ? undefined : status, q })
  }, [api, lang, status, q]) as { data: Row[] | null; loading: boolean; reload: () => Promise<unknown> }

  const rows = data ?? []
  const counts = useMemo(() => ({
    total: rows.length,
    published: rows.filter((r) => r.status === 'published').length,
    free: rows.filter((r) => r.is_free).length,
    failed: rows.filter((r) => r.status === 'failed').length,
  }), [rows])

  const setFlag = async (row: Row, patch: { status?: string; is_free?: boolean }) => {
    if (!api) return
    setBusy(row.id)
    try {
      await api.adminSetLessonFlags(row.id, patch)
      toast(patch.status === 'published' ? 'درس منتشر شد.' : patch.status === 'draft' ? 'درس از انتشار خارج شد.' : 'تغییر ذخیره شد.', 'success')
      await reload()
    } catch (e) { toast(e instanceof Error ? e.message : 'عملیات ناموفق بود', 'error') }
    finally { setBusy(null) }
  }

  const remove = async (id: string) => {
    if (!api) return
    try { await api.adminDeleteLesson(id); toast('درس حذف شد.', 'success'); await reload() }
    catch (e) { toast(e instanceof Error ? e.message : 'حذف ناموفق بود', 'error') }
  }

  const bulkPublish = async () => {
    if (!api || selected.size === 0) return
    setBusy('bulk')
    try {
      for (const id of selected) await api.adminSetLessonFlags(id, { status: 'published' })
      toast(`${faNum(selected.size)} درس منتشر شد.`, 'success')
      setSelected(new Set()); await reload()
    } catch (e) { toast(e instanceof Error ? e.message : 'انتشار گروهی ناموفق بود', 'error') }
    finally { setBusy(null) }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="درس‌ها"
        subtitle="همه درس‌های تولیدشده را ببین، وضعیت را تغییر بده، درس‌های رایگان را مشخص کن و منتشر یا از انتشار خارج کن."
        badge={<Chip tone="primary"><BookOpenCheck className="size-3" /> مدیریت محتوا</Chip>}
        actions={<>
          {selected.size > 0 && <Button loading={busy === 'bulk'} onClick={bulkPublish}><CheckCircle2 className="size-4" /> انتشار {faNum(selected.size)} درس انتخابی</Button>}
          <Link to="/admin/content-factory"><Button variant="outline"><Layers className="size-4" /> ساخت درس جدید</Button></Link>
        </>}
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard title="درس‌های فهرست" value={counts.total} icon={<BookOpenCheck className="size-5" />} />
        <StatCard title="منتشرشده" value={counts.published} icon={<CheckCircle2 className="size-5" />} tone="success" />
        <StatCard title="رایگان" value={counts.free} hint="برای تجربه کاربر رایگان" icon={<Unlock className="size-5" />} tone="primary" />
        <StatCard title="ناموفق" value={counts.failed} icon={<Lock className="size-5" />} tone="danger" />
      </div>

      <Card className="!p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-2">
            <Select className="w-36" value={lang} onChange={(e) => setLang(e.target.value)}>
              <option value="all">همه زبان‌ها</option>
              {languages.map((l) => <option key={l.code} value={l.code}>{l.name_fa}</option>)}
            </Select>
            <div className="relative lg:w-64">
              <Search className="pointer-events-none absolute right-3.5 top-1/2 size-4 -translate-y-1/2 text-ink-faint" />
              <Input className="pr-10" placeholder="جستجوی عنوان درس…" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
          </div>
          <Tabs value={status} onChange={setStatus} tabs={[
            { id: 'all', label: 'همه' },
            { id: 'published', label: 'منتشرشده' },
            { id: 'validated', label: 'اعتبارسنجی‌شده' },
            { id: 'generated', label: 'تولیدشده' },
            { id: 'draft', label: 'پیش‌نویس' },
            { id: 'failed', label: 'ناموفق' },
          ]} />
        </div>
      </Card>

      <Card className="!p-0 overflow-hidden">
        {loading && <div className="space-y-3 p-5">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-12" />)}</div>}

        {!loading && rows.length === 0 && (
          <div className="p-5">
            <EmptyState
              icon={<BookOpenCheck className="size-6" />}
              title="درسی پیدا نشد"
              body="برای ساخت درس‌ها به Content Factory برو: کرریکولوم بساز، درس‌ها را تولید کن، اعتبارسنجی کن و منتشر کن."
              action={<Link to="/admin/content-factory"><Button size="sm">رفتن به Content Factory</Button></Link>}
            />
          </div>
        )}

        {!loading && rows.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px] text-sm">
              <thead className="bg-card-soft/40">
                <tr className="text-[11px] text-ink-faint">
                  <th className="px-4 py-3 text-right font-bold">
                    <input type="checkbox" className="size-4 accent-[rgb(var(--c-primary))]"
                      checked={selected.size === rows.length && rows.length > 0}
                      onChange={(e) => setSelected(e.target.checked ? new Set(rows.map((r) => r.id)) : new Set())} />
                  </th>
                  <th className="px-4 py-3 text-right font-bold">درس</th>
                  <th className="px-4 py-3 text-right font-bold">زبان/سطح</th>
                  <th className="px-4 py-3 text-right font-bold">وضعیت</th>
                  <th className="px-4 py-3 text-right font-bold">دسترسی</th>
                  <th className="px-4 py-3 text-right font-bold">ساخته‌شده</th>
                  <th className="px-4 py-3 text-right font-bold">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="border-t border-line/50 transition-colors hover:bg-card-soft/25">
                    <td className="px-4 py-3">
                      <input type="checkbox" className="size-4 accent-[rgb(var(--c-primary))]"
                        checked={selected.has(r.id)}
                        onChange={(e) => setSelected((s) => { const n = new Set(s); e.target.checked ? n.add(r.id) : n.delete(r.id); return n })} />
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-[13px] font-extrabold">{r.order_index}. {r.title}</p>
                      <p className="text-[10px] text-ink-faint">{r.subtitle || '—'} · {faNum(r.estimated_minutes)} دقیقه</p>
                    </td>
                    <td className="px-4 py-3 text-[11px] text-ink-muted">{languages.find((l) => l.code === r.language_code)?.name_fa ?? r.language_code} · {r.level}</td>
                    <td className="px-4 py-3"><StatusChip status={r.status} /></td>
                    <td className="px-4 py-3">
                      {r.is_free ? <Chip tone="success" className="!px-2 !py-0.5 !text-[10px]">رایگان</Chip> : <Chip className="!px-2 !py-0.5 !text-[10px]">Premium</Chip>}
                    </td>
                    <td className="px-4 py-3 text-[10px] text-ink-faint">{faDateTime(r.created_at)}</td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1.5">
                        {r.status === 'published' ? (
                          <Button size="sm" variant="outline" loading={busy === r.id} onClick={() => setFlag(r, { status: 'draft' })}>خروج از انتشار</Button>
                        ) : (
                          <Button size="sm" loading={busy === r.id} onClick={() => setFlag(r, { status: 'published' })}>انتشار</Button>
                        )}
                        <Button size="sm" variant="ghost" onClick={() => setFlag(r, { is_free: !r.is_free })}>
                          {r.is_free ? 'Premium کن' : 'رایگان کن'}
                        </Button>
                        <Link to={`/app/lessons/${r.id}`} target="_blank"><Button size="sm" variant="ghost"><ExternalLink className="size-3.5" /></Button></Link>
                        <Confirmed label={<Trash2 className="size-3.5" />} confirmLabel="حذف کن" onConfirm={() => remove(r.id)} />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Card className="!p-4">
        <p className="flex items-center gap-2 text-[11px] text-ink-faint">
          <Filter className="size-3.5" /> وضعیت‌ها: پیش‌نویس → تولیدشده → اعتبارسنجی‌شده → منتشرشده. درس‌های ناموفق فقط با تولید دوباره (Retry) اصلاح می‌شوند.
        </p>
        <p className="mt-2 flex items-center gap-2 text-[11px] text-ink-faint">
          <Eye className="size-3.5" /> برای دیدن ظاهر درس از دید کاربر، دکمه «مشاهده» را بزن.
        </p>
      </Card>
    </div>
  )
}

export function StatusChip({ status }: { status: string }) {
  const map: Record<string, { label: string; tone: 'default' | 'primary' | 'success' | 'warn' | 'danger' }> = {
    draft: { label: 'پیش‌نویس', tone: 'default' },
    generated: { label: 'تولیدشده', tone: 'primary' },
    validated: { label: 'اعتبارسنجی‌شده', tone: 'warn' },
    published: { label: 'منتشرشده', tone: 'success' },
    failed: { label: 'ناموفق', tone: 'danger' },
  }
  const m = map[status] ?? { label: status, tone: 'default' as const }
  return <Chip tone={m.tone} className="!px-2 !py-0.5 !text-[10px]">{m.label}</Chip>
}

