import { HelpCircle } from 'lucide-react'
import { AdminCrud } from '@/components/admin/Crud'
import { Chip, PageHeader } from '@/components/ui'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { faNum } from '@/lib/utils'
import type { Faq } from '@/services/types'

export default function FaqAdmin() {
  const { api, toast } = useApp()
  const { data, loading, reload } = useAsync(async () => {
    if (!api) return []
    const { faqs } = await api.publicContent()
    const { data: all } = await (await import('@/lib/supabase')).supabase.from('faqs').select('*').order('sort_order')
    return (all ?? faqs) as Faq[]
  }, [api])

  const save = async (row: Faq) => {
    if (!api) return
    const payload: Record<string, unknown> = { ...row }
    if (!payload.id) delete payload.id
    await api.saveFaq(payload as any)
    toast('سؤال ذخیره شد.', 'success'); await reload()
  }
  const remove = async (id: string) => {
    if (!api) return
    await api.deleteRow('faqs', id); toast('حذف شد.', 'success'); await reload()
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="سؤالات متداول"
        subtitle="این سؤالات در صفحه عمومی «سؤالات متداول» و بخشی از آن در صفحه اصلی نمایش داده می‌شوند."
        badge={<Chip tone="primary"><HelpCircle className="size-3" /> محتوای عمومی</Chip>}
      />
      <AdminCrud
        rows={data ?? []}
        loading={loading}
        fields={[
          { name: 'question', label: 'سؤال', type: 'text' },
          { name: 'answer', label: 'پاسخ', type: 'textarea' },
          { name: 'category', label: 'دسته', type: 'select', half: true, options: [
            { value: 'general', label: 'عمومی' }, { value: 'pricing', label: 'رایگان و اشتراک' },
            { value: 'features', label: 'امکانات' }, { value: 'languages', label: 'زبان‌ها' },
          ] },
          { name: 'sort_order', label: 'ترتیب', type: 'number', half: true },
          { name: 'is_published', label: 'منتشر شده', type: 'switch', half: true },
        ]}
        title="فهرست سؤالات"
        subtitle={`${faNum((data ?? []).length)} سؤال`}
        emptyTitle="سؤالی ثبت نشده"
        defaults={{ question: '', answer: '', category: 'general', sort_order: 10, is_published: true } as any}
        onSave={save as any}
        onDelete={remove}
        columns={[
          { key: 'question', label: 'سؤال', render: (r) => <span className="text-[13px] font-bold">{r.question}</span> },
          { key: 'category', label: 'دسته', render: (r) => <Chip className="!px-2 !py-0.5 !text-[10px]">{r.category}</Chip> },
          { key: 'is_published', label: 'وضعیت', render: (r) => r.is_published ? <Chip tone="success" className="!px-2 !py-0.5 !text-[10px]">منتشرشده</Chip> : <Chip className="!px-2 !py-0.5 !text-[10px]">پیش‌نویس</Chip> },
        ]}
      />
    </div>
  )
}
