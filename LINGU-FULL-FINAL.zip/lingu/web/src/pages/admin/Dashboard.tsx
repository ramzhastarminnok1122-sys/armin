import { motion } from 'motion/react'
import { Link } from 'react-router-dom'
import {
  Activity, AlertTriangle, BadgeCheck, BookOpenCheck, Brain, CheckCircle2, CreditCard, Factory,
  Layers, MessagesSquare, Sparkles, UserPlus, Users as UsersIcon,
} from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { Button, Card, Chip, PageHeader, Progress, SectionTitle, Skeleton, StatCard } from '@/components/ui'
import { faNum, faRelative } from '@/lib/utils'

export default function Dashboard() {
  const { api } = useApp()
  const { data, loading, error } = useAsync(async () => (api ? api.adminDashboard() : null), [api])

  if (loading) {
    return (
      <div className="space-y-5">
        <Skeleton className="h-9 w-64" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{Array.from({ length: 8 }).map((_, i) => <div key={i} className="card-surface h-32 p-5"><Skeleton className="h-5 w-1/2" /></div>)}</div>
      </div>
    )
  }

  if (error || !data) {
    return (
      <Card className="border-danger/40">
        <div className="flex items-start gap-3">
          <AlertTriangle className="mt-0.5 size-5 text-danger" />
          <div>
            <h2 className="text-sm font-extrabold text-danger">خواندن آمار داشبورد ناموفق بود</h2>
            <p className="mt-1 text-[12px] leading-7 text-ink-muted">{error ?? 'خطای نامشخص'}</p>
          </div>
        </div>
      </Card>
    )
  }

  const maxSignup = Math.max(1, ...(data.signups_14d ?? []).map((s) => s.count))

  return (
    <div className="space-y-6">
      <PageHeader
        title="داشبورد"
        subtitle="همه اعداد این صفحه مستقیم از دیتابیس خوانده می‌شوند — هیچ داده ساختگی وجود ندارد."
        badge={<Chip tone="primary"><Activity className="size-3" /> نمای کلی LINGU</Chip>}
        actions={<>
          <Link to="/admin/content-factory"><Button><Factory className="size-4" /> Content Factory</Button></Link>
          <Link to="/admin/lessons"><Button variant="outline"><BookOpenCheck className="size-4" /> درس‌ها</Button></Link>
        </>}
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard title="کاربران" value={data.users_total} hint={`${faNum(data.users_new_7d)} کاربر جدید در ۷ روز`} icon={<UsersIcon className="size-5" />} />
        <StatCard title="کاربران Premium" value={data.premium_users} hint={`${faNum(data.active_subs)} اشتراک فعال`} icon={<BadgeCheck className="size-5" />} tone="success" />
        <StatCard title="درس‌های منتشرشده" value={data.lessons_published} hint={`${faNum(data.lessons_total)} درس در کل`} icon={<BookOpenCheck className="size-5" />} tone="primary" />
        <StatCard title="تماس‌های AI (۲۴ ساعت)" value={data.ai_calls_24h} hint={`${faNum(data.ai_tokens_24h)} توکن مصرفی`} icon={<Brain className="size-5" />} tone="warn" />
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard title="کاربران فعال (۷ روز)" value={data.users_active_7d} icon={<Activity className="size-5" />} />
        <StatCard title="درس‌های در انتظار انتشار" value={data.lessons_draft} icon={<Layers className="size-5" />} tone="warn" />
        <StatCard title="درس‌های ناموفق" value={data.lessons_failed} hint={`${faNum(data.plans_failed)} پلن ناموفق`} icon={<AlertTriangle className="size-5" />} tone="danger" />
        <StatCard title="خطاهای AI (۲۴ ساعت)" value={data.ai_errors_24h} hint={`${faNum(data.ai_calls_total)} تماس در کل`} icon={<Sparkles className="size-5" />} tone="danger" />
        <StatCard title="مکالمه‌های Partner" value={data.conversations_total ?? 0} hint={`${faNum(data.partner_messages_24h ?? 0)} پیام در ۲۴ ساعت`} icon={<MessagesSquare className="size-5" />} tone="primary" />
        <StatCard title="پیام‌های AI (کل)" value={data.messages_total ?? 0} hint={`${faNum(data.tutor_calls_24h ?? 0)} تماس Tutor در ۲۴ ساعت`} icon={<Sparkles className="size-5" />} />
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.4fr_1fr]">
        <Card>
          <SectionTitle title="ثبت‌نام ۱۴ روز گذشته" subtitle="تعداد کاربران جدید در هر روز." />
          <div className="flex h-44 items-end justify-between gap-1.5">
            {(data.signups_14d ?? []).map((s, i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-2">
                <motion.div initial={{ height: 0 }} animate={{ height: `${(s.count / maxSignup) * 100}%` }}
                  transition={{ duration: 0.6, delay: i * 0.03 }}
                  className={`w-full rounded-t-xl ${s.count ? 'bg-brand-grad' : 'bg-card-soft'}`}
                  style={{ minHeight: s.count ? 12 : 5 }}
                  title={`${s.day} — ${s.count}`} />
                <span className="text-[9px] text-ink-faint">{faNum(new Date(s.day).getDate())}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <SectionTitle title="درس‌ها به تفکیک زبان" />
          {Object.keys(data.lessons_by_language ?? {}).length === 0 ? (
            <p className="text-[12px] text-ink-faint">هنوز درسی ساخته نشده است. از Content Factory شروع کن.</p>
          ) : (
            <div className="space-y-4">
              {Object.entries(data.lessons_by_language).map(([code, count]) => (
                <div key={code}>
                  <div className="mb-1.5 flex items-center justify-between text-[11px] font-bold">
                    <span className="ltr">{code.toUpperCase()}</span>
                    <span className="text-ink-faint">{faNum(count)} درس</span>
                  </div>
                  <Progress value={Math.min(100, (Number(count) / 340) * 100)} />
                </div>
              ))}
              <p className="pt-1 text-[10px] text-ink-faint">هدف نهایی: {faNum(340)} درس برای هر زبان</p>
            </div>
          )}
        </Card>
      </div>

      <Card>
        <SectionTitle title="کاربران تازه" subtitle="آخرین حساب‌های ساخته‌شده." actions={<Link to="/admin/users"><Button size="sm" variant="outline">همه کاربران</Button></Link>} />
        {data.recent_users.length === 0 ? (
          <p className="text-[12px] text-ink-faint">هنوز کاربری ثبت‌نام نکرده است.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[520px] text-sm">
              <thead>
                <tr className="border-b border-line/60 text-[11px] text-ink-faint">
                  <th className="px-3 py-2.5 text-right font-bold">کاربر</th>
                  <th className="px-3 py-2.5 text-right font-bold">نقش</th>
                  <th className="px-3 py-2.5 text-right font-bold">وضعیت</th>
                  <th className="px-3 py-2.5 text-right font-bold">تاریخ عضویت</th>
                </tr>
              </thead>
              <tbody>
                {data.recent_users.map((u) => (
                  <tr key={u.id} className="border-b border-line/40">
                    <td className="px-3 py-3 font-bold">{u.display_name || 'بدون نام'}</td>
                    <td className="px-3 py-3 text-[12px] text-ink-muted">{u.role === 'admin' ? 'مدیر' : 'کاربر'}</td>
                    <td className="px-3 py-3">
                      {u.premium ? <Chip tone="success" className="!px-2 !py-0.5 !text-[10px]"><CheckCircle2 className="size-3" /> Premium</Chip> : <Chip className="!px-2 !py-0.5 !text-[10px]">رایگان</Chip>}
                    </td>
                    <td className="px-3 py-3 text-[11px] text-ink-faint">{faRelative(u.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <div className="grid gap-4 sm:grid-cols-3">
        <QuickLink to="/admin/ai" icon={<Sparkles className="size-4" />} title="تنظیمات AI" body="کلید Groq، مدل و تست اتصال" />
        <QuickLink to="/admin/theme" icon={<BadgeCheck className="size-4" />} title="ظاهر و تم" body="تغییر رنگ‌ها بدون انتشار جدید" />
        <QuickLink to="/admin/subscriptions" icon={<CreditCard className="size-4" />} title="اشتراک‌ها" body="مشاهده و مدیریت خریدها" />
      </div>
      <p className="text-[10px] text-ink-faint"><UserPlus className="inline size-3" /> برای ساخت کاربر بیشتر، لینک ثبت‌نام سایت را به مخاطبت بده.</p>
    </div>
  )
}

function QuickLink({ to, icon, title, body }: { to: string; icon: React.ReactNode; title: string; body: string }) {
  return (
    <Link to={to}>
      <Card className="hover-lift !p-4">
        <div className="flex items-center gap-3">
          <span className="grid size-10 place-items-center rounded-2xl bg-brand-soft text-primary-soft">{icon}</span>
          <div className="min-w-0">
            <p className="text-xs font-extrabold">{title}</p>
            <p className="text-[10px] text-ink-faint">{body}</p>
          </div>
        </div>
      </Card>
    </Link>
  )
}
