import { Image as ImageIcon } from 'lucide-react'
import { AdminCrud } from '@/components/admin/Crud'
import { Card, Chip, PageHeader, SectionTitle, Switch } from '@/components/ui'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { faNum } from '@/lib/utils'
import type { Banner } from '@/services/types'

export default function Banners() {
  const { api, toast, settings, refreshCatalogData } = useApp()
  const showBanners = settings.general?.show_banners !== false

  const { data, loading, reload } = useAsync(async () => {
    if (!api) return []
    const { data: all } = await (await import('@/lib/supabase')).supabase.from('banners').select('*').order('sort_order')
    return (all ?? []) as Banner[]
  }, [api])

  const save = async (row: Banner) => {
    if (!api) return
    const payload: Record<string, unknown> = { ...row }
    if (!payload.id) delete payload.id
    await api.saveBanner(payload as any)
    toast('بنر ذخیره شد.', 'success'); await reload()
  }
  const remove = async (id: string) => { if (!api) return; await api.deleteRow('banners', id); await reload() }

  const toggleGlobal = async (v: boolean) => {
    if (!api) return
    const general = { ...(settings.general ?? {}), show_banners: v }
    await api.saveAppSetting('general', general)
    toast(v ? 'نمایش بنرها روشن شد.' : 'نمایش بنرها خاموش شد.', 'success')
    await refreshCatalogData()
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="بنرها"
        subtitle="پیام‌های کوتاه بالای صفحه خانه کاربران. برای اعلان‌های مهم یا معرفی قابلیت تازه استفاده کن."
        badge={<Chip tone="primary"><ImageIcon className="size-3" /> اعلان‌ها</Chip>}
      />

      <Card className="!p-5">
        <SectionTitle title="کنترل کلی" subtitle="می‌توانی همه بنرها را با یک کلید خاموش کنی." />
        <Switch checked={showBanners} label="نمایش بنرها در برنامه کاربر" onChange={toggleGlobal} />
      </Card>

      <AdminCrud
        rows={data ?? []}
        loading={loading}
        fields={[
          { name: 'title', label: 'عنوان', type: 'text' },
          { name: 'body', label: 'متن', type: 'textarea' },
          { name: 'cta_label', label: 'متن دکمه (اختیاری)', type: 'text', half: true },
          { name: 'cta_url', label: 'لینک دکمه', type: 'text', half: true, hint: 'مثال: /app/subscription' },
          { name: 'image_url', label: 'آدرس تصویر (اختیاری)', type: 'text' },
          { name: 'placement', label: 'محل نمایش', type: 'select', half: true, options: [
            { value: 'user_home', label: 'خانه کاربر' }, { value: 'lessons', label: 'صفحه درس‌ها' },
            { value: 'subscription', label: 'صفحه اشتراک' }, { value: 'all', label: 'همه‌جا' },
          ] },
          { name: 'tone', label: 'رنگ', type: 'select', half: true, options: [
            { value: 'primary', label: 'اصلی' }, { value: 'success', label: 'موفقیت' }, { value: 'warn', label: 'هشدار' },
          ] },
          { name: 'sort_order', label: 'ترتیب', type: 'number', half: true },
          { name: 'is_active', label: 'فعال', type: 'switch', half: true },
        ]}
        title="فهرست بنرها"
        subtitle={`${faNum((data ?? []).length)} بنر`}
        emptyTitle="بنری ثبت نشده"
        emptyBody="برای اطلاع‌رسانی درباره درس‌های تازه یا قابلیت‌های جدید از بنر استفاده کن."
        defaults={{ title: '', body: '', cta_label: '', cta_url: '', placement: 'user_home', tone: 'primary', sort_order: 10, is_active: true } as any}
        onSave={save as any}
        onDelete={remove}
        columns={[
          { key: 'title', label: 'بنر', render: (r) => <div><p className="text-[13px] font-extrabold">{r.title}</p><p className="line-clamp-1 text-[10px] text-ink-faint">{r.body}</p></div> },
          { key: 'placement', label: 'محل', render: (r) => <Chip className="!px-2 !py-0.5 !text-[10px]">{r.placement}</Chip> },
          { key: 'is_active', label: 'وضعیت', render: (r) => r.is_active ? <Chip tone="success" className="!px-2 !py-0.5 !text-[10px]">فعال</Chip> : <Chip className="!px-2 !py-0.5 !text-[10px]">غیرفعال</Chip> },
        ]}
      />
    </div>
  )
}
