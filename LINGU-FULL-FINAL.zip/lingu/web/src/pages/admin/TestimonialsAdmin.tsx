import { MessageSquareQuote, Star } from 'lucide-react'
import { AdminCrud } from '@/components/admin/Crud'
import { Chip, PageHeader } from '@/components/ui'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { faNum } from '@/lib/utils'
import type { Testimonial } from '@/services/types'

export default function TestimonialsAdmin() {
  const { api, toast } = useApp()
  const { data, loading, reload } = useAsync(async () => {
    if (!api) return []
    const { data: all } = await (await import('@/lib/supabase')).supabase.from('testimonials').select('*').order('sort_order')
    return (all ?? []) as Testimonial[]
  }, [api])

  const save = async (row: Testimonial) => {
    if (!api) return
    const payload: Record<string, unknown> = { ...row }
    if (!payload.id) delete payload.id
    await api.saveTestimonial(payload as any)
    toast('نظر ذخیره شد.', 'success'); await reload()
  }
  const remove = async (id: string) => { if (!api) return; await api.deleteRow('testimonials', id); await reload() }

  return (
    <div className="space-y-6">
      <PageHeader
        title="نظرات کاربران"
        subtitle="نظراتی که در صفحه اصلی سایت نمایش داده می‌شوند. فقط نظرات واقعی کاربران را وارد کن."
        badge={<Chip tone="primary"><MessageSquareQuote className="size-3" /> اعتماد کاربران</Chip>}
      />
      <AdminCrud
        rows={data ?? []}
        loading={loading}
        fields={[
          { name: 'name', label: 'نام', type: 'text', half: true },
          { name: 'role', label: 'عنوان/شغل', type: 'text', half: true },
          { name: 'quote', label: 'متن نظر', type: 'textarea' },
          { name: 'avatar_url', label: 'آدرس تصویر (اختیاری)', type: 'text' },
          { name: 'rating', label: 'امتیاز (۱ تا ۵)', type: 'number', half: true },
          { name: 'sort_order', label: 'ترتیب', type: 'number', half: true },
          { name: 'is_published', label: 'منتشر شده', type: 'switch', half: true },
        ]}
        title="فهرست نظرات"
        subtitle={`${faNum((data ?? []).length)} نظر`}
        emptyTitle="نظری ثبت نشده"
        defaults={{ name: '', role: '', quote: '', avatar_url: '', rating: 5, sort_order: 10, is_published: true } as any}
        onSave={save as any}
        onDelete={remove}
        columns={[
          { key: 'name', label: 'کاربر', render: (r) => <div><p className="text-[13px] font-extrabold">{r.name}</p><p className="text-[10px] text-ink-faint">{r.role}</p></div> },
          { key: 'quote', label: 'نظر', render: (r) => <span className="line-clamp-2 text-[12px] text-ink-muted">{r.quote}</span> },
          { key: 'rating', label: 'امتیاز', render: (r) => <span className="flex gap-0.5">{Array.from({ length: r.rating }).map((_, i) => <Star key={i} className="size-3 fill-warn text-warn" />)}</span> },
          { key: 'is_published', label: 'وضعیت', render: (r) => r.is_published ? <Chip tone="success" className="!px-2 !py-0.5 !text-[10px]">منتشرشده</Chip> : <Chip className="!px-2 !py-0.5 !text-[10px]">پیش‌نویس</Chip> },
        ]}
      />
    </div>
  )
}
