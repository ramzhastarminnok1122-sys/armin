import { Crown, Gem } from 'lucide-react'
import { AdminCrud, type FieldDef } from '@/components/admin/Crud'
import { Card, Chip, PageHeader, SectionTitle } from '@/components/ui'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { faNum } from '@/lib/utils'
import type { Plan } from '@/services/types'

const FIELDS: FieldDef<Plan & { featuresText?: string }>[] = [
  { name: 'code', label: 'کد پلن', type: 'text', half: true, hint: 'مثال: monthly — پس از ساخت قابل تغییر نیست.' },
  { name: 'title_fa', label: 'عنوان فارسی', type: 'text', half: true },
  { name: 'subtitle_fa', label: 'زیرعنوان', type: 'text', half: true },
  { name: 'badge', label: 'برچسب نمایشی', type: 'text', half: true, hint: 'مثال: محبوب / بهترین ارزش' },
  { name: 'sku', label: 'کد محصول مایکت (SKU)', type: 'text', half: true, hint: 'باید دقیقاً با SKU ساخته‌شده در پنل مایکت یکسان باشد.' },
  { name: 'duration_days', label: 'مدت (روز)', type: 'number', half: true, hint: 'این عدد تعیین می‌کند خرید چند روز Premium بدهد.' },
  { name: 'display_price', label: 'قیمت نمایشی (ریال)', type: 'number', half: true, hint: 'فقط برای نمایش در سایت و اپ؛ قیمت واقعی از مایکت خوانده می‌شود.' },
  { name: 'price_label', label: 'برچسب قیمت (اختیاری)', type: 'text', half: true },
  { name: 'original_price', label: 'قیمت اصلی (تومان)', type: 'number', half: true, hint: 'قیمت کامل بدون تخفیف؛ مبنای نمایش خط‌خورده.' },
  { name: 'promo_price', label: 'قیمت پیشنهادی (تومان)', type: 'number', half: true, hint: 'اگر خالی باشد، قیمت اصلی نمایش داده می‌شود.' },
  { name: 'promo_label', label: 'برچسب پیشنهاد', type: 'text', half: true, hint: 'مثلاً: پیشنهاد ویژه ماه مهر' },
  { name: 'promo_active', label: 'پیشنهاد ویژه فعال باشد', type: 'switch', half: true },
  { name: 'promo_ends_at', label: 'پایان پیشنهاد (تاریخ/زمان)', type: 'text', half: true, hint: 'اختیاری — ISO یا خالی.' },
  { name: 'show_on_marketing', label: 'نمایش در سایت عمومی', type: 'switch', half: true },
  { name: 'description_fa', label: 'توضیح', type: 'textarea' },
  { name: 'featuresText', label: 'ویژگی‌ها (هر خط یک ویژگی)', type: 'textarea', hint: 'هر ویژگی را در یک خط جدا بنویس.' },
  { name: 'sort_order', label: 'ترتیب نمایش', type: 'number', half: true },
  { name: 'is_active', label: 'فعال باشد', type: 'switch', half: true },
  { name: 'is_recommended', label: 'پیشنهاد ویژه', type: 'switch', half: true },
]

export default function Plans() {
  const { api, toast } = useApp()
  const { data, loading, reload } = useAsync(async () => {
    if (!api) return []
    const { plans } = await api.bootstrap()
    const all = await api.bootstrap()
    return (all.plans.length ? all.plans : plans) as Plan[]
  }, [api])

  const save = async (row: Plan & { featuresText?: string }) => {
    if (!api) return
    const payload: Record<string, unknown> = { ...row }
    if (typeof row.featuresText === 'string') {
      payload.features = row.featuresText.split('\n').map((s) => s.trim()).filter(Boolean)
    }
    delete payload.featuresText
    if (!payload.id) delete payload.id
    await api.savePlan(payload as any)
    toast('پلن ذخیره شد.', 'success')
    await reload()
  }

  const remove = async (id: string) => {
    if (!api) return
    try {
      await api.deleteRow('plans', id)
      toast('پلن حذف شد.', 'success')
      await reload()
    } catch (e) { toast(e instanceof Error ? e.message : 'حذف ممکن نبود — ممکن است اشتراکی به این پلن وصل باشد.', 'error') }
  }

  const rows = (data ?? []).map((p) => ({ ...p, featuresText: (p.features ?? []).join('\n') }))

  return (
    <div className="space-y-6">
      <PageHeader
        title="پلن‌ها"
        subtitle="عنوان، توضیح، SKU، مدت، قیمت نمایشی و فعال/غیرفعال بودن هر پلن را از همین‌جا تغییر بده. مدت Premium خریدها از فیلد «مدت» همین‌جا تعیین می‌شود."
        badge={<Chip tone="primary"><Crown className="size-3" /> پلن‌های اشتراک</Chip>}
      />

      <Card className="!p-5">
        <SectionTitle title="منطق قیمت‌گذاری" subtitle="LINGU قیمت واقعی را از فروشگاه مایکت می‌گیرد." />
        <ul className="space-y-2 text-[12px] leading-7 text-ink-muted">
          <li className="flex items-start gap-2"><Gem className="mt-1 size-3.5 shrink-0 text-primary-soft" /> قیمت واقعی خرید همان قیمت محصول در پنل مایکت است؛ اینجا فقط قیمت نمایشی را برای سایت و اپ تنظیم می‌کنی.</li>
          <li className="flex items-start gap-2"><Gem className="mt-1 size-3.5 shrink-0 text-primary-soft" /> هیچ قیمت دلخواهی در لحظه به مایکت ارسال نمی‌شود؛ فقط SKU ارسال می‌شود.</li>
          <li className="flex items-start gap-2"><Gem className="mt-1 size-3.5 shrink-0 text-primary-soft" /> «مدت» هر SKU در دیتابیس نگه‌داری می‌شود و پس از خرید تأییدشده، همان مدت به کاربر اضافه می‌گردد.</li>
        </ul>
      </Card>

      <AdminCrud
        rows={rows}
        loading={loading}
        fields={FIELDS}
        title="پلن‌ها"
        subtitle={`${faNum(rows.length)} پلن ثبت شده`}
        emptyTitle="پلنی ثبت نشده"
        emptyBody="پلن رایگان و پلن‌های اشتراک را اینجا بساز."
        defaults={{ code: '', title_fa: '', subtitle_fa: '', description_fa: '', sku: '', duration_days: 30, display_price: 0, badge: null, features: [], featuresText: '', is_active: true, is_recommended: false, sort_order: 10, original_price: 0, promo_price: null, promo_label: null, promo_active: false, promo_ends_at: null, show_on_marketing: false } as any}
        onSave={save as any}
        onDelete={remove}
        columns={[
          { key: 'title_fa', label: 'پلن', render: (r) => (
            <div>
              <p className="text-[13px] font-extrabold">{r.title_fa} {r.is_recommended && <Chip tone="primary" className="!px-2 !py-0 !text-[9px]">پیشنهاد</Chip>}</p>
              <p className="ltr text-[10px] text-ink-faint">{r.code} · {r.sku || 'بدون SKU'}</p>
            </div>
          ) },
          { key: 'duration_days', label: 'مدت', render: (r) => <span className="text-[12px]">{r.code === 'free' ? 'همیشگی' : `${faNum(r.duration_days)} روز`}</span> },
          { key: 'display_price', label: 'قیمت', render: (r) => (
            <span className="text-[12px]">
              {r.code === 'free' ? 'رایگان'
                : r.promo_active && r.promo_price
                  ? <span className="flex items-center gap-2">
                      <b>{faNum(r.promo_price)}</b>
                      <span className="text-ink-faint line-through">{faNum(r.original_price)}</span>
                      {r.promo_label && <Chip tone="warn" className="!px-1.5 !py-0 !text-[9px]">{r.promo_label}</Chip>}
                    </span>
                  : faNum(r.original_price || r.display_price)}
            </span>
          ) },
          { key: 'is_active', label: 'وضعیت', render: (r) => r.is_active ? <Chip tone="success" className="!px-2 !py-0.5 !text-[10px]">فعال</Chip> : <Chip className="!px-2 !py-0.5 !text-[10px]">غیرفعال</Chip> },
        ]}
      />
    </div>
  )
}
