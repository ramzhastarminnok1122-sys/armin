import { useEffect, useState } from 'react'
import { CheckCircle2, Palette, RotateCcw, Save, Sparkles, Zap } from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { DEFAULT_THEME, useTheme, type ThemeRow } from '@/context/ThemeContext'
import { Button, Card, Chip, Field, Input, PageHeader, SectionTitle } from '@/components/ui'
import { faNum } from '@/lib/utils'

const PRESETS: { name: string; theme: Partial<ThemeRow> }[] = [
  { name: 'LINGU روشن (پیش‌فرض)', theme: { mode: 'light', primary: '#6D5BFF', secondary: '#8B5CF6', accent: '#0EA5C6', background: '#FAF9FF', background_soft: '#F3F0FF', card: '#FFFFFF', card_soft: '#F6F3FF', text: '#191436', text_muted: '#5B5688', line: '#E7E2F8' } },
  { name: 'بنفش شبانه', theme: { mode: 'dark', primary: '#7C6CFF', secondary: '#5B8CFF', accent: '#22D3EE', background: '#0A0B14', background_soft: '#101223', card: '#151731', card_soft: '#1B1E3D', text: '#F4F5FF', text_muted: '#A7ACD4', line: '#282C52' } },
  { name: 'لایلک ملایم', theme: { mode: 'light', primary: '#7C5CFC', secondary: '#B18CFF', accent: '#2BB3C0', background: '#FCFBFF', background_soft: '#F5F1FF', card: '#FFFFFF', card_soft: '#F3EEFF', text: '#241E4A', text_muted: '#6C6693', line: '#EBE4FB' } },
  { name: 'اقیانوس روشن', theme: { mode: 'light', primary: '#0EA5E9', secondary: '#6366F1', accent: '#14B8A6', background: '#F7FBFF', background_soft: '#EEF6FF', card: '#FFFFFF', card_soft: '#F1F7FF', text: '#0F2436', text_muted: '#4B6B85', line: '#DCEAF7' } },
]

const FIELDS: { key: keyof ThemeRow; label: string; hint?: string }[] = [
  { key: 'primary', label: 'رنگ اصلی', hint: 'دکمه‌ها، لینک‌ها و گرادیان اصلی' },
  { key: 'secondary', label: 'رنگ دوم', hint: 'مکمل گرادیان برند' },
  { key: 'accent', label: 'رنگ تأکیدی (Accent)', hint: 'نکته‌ها و برجسته‌سازی‌ها' },
  { key: 'background', label: 'پس‌زمینه' },
  { key: 'background_soft', label: 'پس‌زمینه ملایم', hint: 'نوار کناری و بخش‌های ثانویه' },
  { key: 'card', label: 'کارت' },
  { key: 'card_soft', label: 'کارت ملایم', hint: 'حالت هاور و لایه‌های داخلی' },
  { key: 'text', label: 'متن اصلی' },
  { key: 'text_muted', label: 'متن کم‌رنگ' },
  { key: 'line', label: 'خطوط و حاشیه‌ها' },
  { key: 'success', label: 'رنگ موفقیت', hint: 'پیام‌ها و وضعیت‌های موفق' },
  { key: 'warning', label: 'رنگ هشدار', hint: 'هشدارها، پیشنهاد ویژه و محدودیت‌ها' },
  { key: 'danger', label: 'رنگ خطا', hint: 'خطاها و اقدام‌های حساس' },
]

export default function ThemeSettings() {
  const { api, toast } = useApp()
  const { theme, setTheme, reload } = useTheme()
  const [draft, setDraft] = useState<ThemeRow>(theme)
  const [busy, setBusy] = useState(false)

  useEffect(() => { setDraft(theme) }, [theme])
  useEffect(() => { setTheme(draft) /* live preview */ }, [draft]) // eslint-disable-line react-hooks/exhaustive-deps

  const save = async () => {
    if (!api) return
    setBusy(true)
    try {
      await api.saveTheme(draft as unknown as Record<string, unknown>)
      await reload()
      toast('تم ذخیره شد و همین حالا روی سایت اعمال شد — بدون انتشار نسخه جدید.', 'success')
    } catch (e) { toast(e instanceof Error ? e.message : 'ذخیره تم ناموفق بود', 'error') }
    finally { setBusy(false) }
  }

  const applyPreset = (p: Partial<ThemeRow>) => setDraft((d) => ({ ...d, ...p }))

  return (
    <div className="space-y-6">
      <PageHeader
        title="ظاهر و تم"
        subtitle="رنگ‌ها را از همین‌جا تغییر بده؛ بلافاصله روی سایت و اپ اعمال می‌شوند و نیازی به انتشار نسخه جدید نیست."
        badge={<Chip tone="primary"><Palette className="size-3" /> تم پویا</Chip>}
        actions={<>
          <Button variant="outline" onClick={() => setDraft({ ...DEFAULT_THEME })}><RotateCcw className="size-4" /> بازگردانی پیش‌فرض</Button>
          <Button onClick={save} loading={busy}><Save className="size-4" /> ذخیره تم</Button>
        </>}
      />

      <div className="grid gap-5 lg:grid-cols-[1fr_1.1fr]">
        <div className="space-y-5">
          <Card>
            <SectionTitle title="پالت‌های آماده" subtitle="یک کلیک برای تغییر کامل حس بصری." />
            <div className="grid grid-cols-2 gap-3">
              {PRESETS.map((p) => (
                <button key={p.name} onClick={() => applyPreset(p.theme)}
                  className="rounded-2xl border border-line/70 bg-bg-soft/50 p-3 text-right transition-all hover:-translate-y-0.5 hover:border-primary/40">
                  <div className="flex gap-1.5">
                    {[p.theme.primary, p.theme.secondary, p.theme.accent].map((c, i) => (
                      <span key={i} className="size-6 rounded-lg" style={{ background: c }} />
                    ))}
                  </div>
                  <p className="mt-2 text-[11px] font-extrabold">{p.name}</p>
                </button>
              ))}
            </div>
          </Card>

          <Card>
            <SectionTitle title="گردی گوشه‌ها" subtitle={`مقدار فعلی: ${faNum(draft.radius)} پیکسل`} />
            <input type="range" min={6} max={34} value={draft.radius} onChange={(e) => setDraft((d) => ({ ...d, radius: Number(e.target.value) }))}
              className="w-full accent-[rgb(var(--c-primary))]" />
          </Card>

          <Card>
            <SectionTitle title="رنگ‌ها" subtitle="برای هر مورد، رنگ دقیق را انتخاب کن." />
            <div className="grid gap-4 sm:grid-cols-2">
              {FIELDS.map((f) => (
                <Field key={f.key} label={f.label} hint={f.hint}>
                  <div className="flex gap-2">
                    <input type="color" value={String(draft[f.key])} onChange={(e) => setDraft((d) => ({ ...d, [f.key]: e.target.value }))}
                      className="h-12 w-14 shrink-0 cursor-pointer rounded-2xl border border-line bg-transparent" />
                    <Input dir="ltr" value={String(draft[f.key])} onChange={(e) => setDraft((d) => ({ ...d, [f.key]: e.target.value }))} />
                  </div>
                </Field>
              ))}
            </div>
          </Card>
        </div>

        {/* live preview */}
        <div className="space-y-5">
          <Card className="sticky top-6">
            <SectionTitle title="پیش‌نمایش زنده" subtitle="همین حالا روی کل سایت اعمال شده است." />
            <div className="space-y-4">
              <div className="rounded-3xl border border-line/70 bg-bg-soft/50 p-5">
                <div className="flex items-center gap-3">
                  <span className="grid size-11 place-items-center rounded-2xl bg-brand-grad text-white"><Sparkles className="size-5" /></span>
                  <div>
                    <p className="text-sm font-extrabold">کارت نمونه درس</p>
                    <p className="text-[10px] text-ink-faint">English · A1 · درس ۳</p>
                  </div>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  <Chip tone="primary">رایگان</Chip>
                  <Chip tone="success"><CheckCircle2 className="size-3" /> کامل‌شده</Chip>
                  <Chip tone="warn">Premium</Chip>
                </div>
                <div className="mt-4 h-2.5 overflow-hidden rounded-full bg-card-soft">
                  <div className="h-full w-2/3 rounded-full bg-brand-grad" />
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button size="sm">دکمه اصلی</Button>
                <Button size="sm" variant="outline">دکمه ثانویه</Button>
                <Button size="sm" variant="ghost">دکمه ساده</Button>
              </div>

              <div className="rounded-2xl border border-line/70 bg-card/60 p-4">
                <p className="text-[12px] leading-7 text-ink">متن اصلی روی کارت — خوانا و با کنتراست مناسب.</p>
                <p className="mt-1 text-[11px] leading-6 text-ink-muted">متن کم‌رنگ برای توضیحات و راهنما.</p>
                <p className="mt-1 text-[10px] text-ink-faint">متن خیلی کم‌رنگ برای نکته‌های فرعی.</p>
              </div>

              <div className="rounded-2xl border border-primary/25 bg-primary/8 p-4">
                <p className="flex items-center gap-2 text-[11px] font-extrabold text-primary-soft"><Zap className="size-3.5" /> نکته هوشمند</p>
                <p className="mt-1.5 text-[11px] leading-6 text-ink-muted">نمونه پیام راهنما با رنگ اصلی تم.</p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
