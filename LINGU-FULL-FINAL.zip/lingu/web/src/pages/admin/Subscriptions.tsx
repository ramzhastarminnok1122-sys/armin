import { BadgeCheck, Crown, CreditCard, Search, ShieldOff, Timer } from 'lucide-react'
import { useState } from 'react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { Card, Chip, Confirmed, EmptyState, Input, PageHeader, Skeleton, StatCard } from '@/components/ui'
import { faDate, faDateTime, faNum } from '@/lib/utils'

type SubRow = {
  id: string; user_id: string; sku: string; status: string; start_date: string; end_date: string
  purchase_token: string | null; provider: string; created_at: string
  display_name: string | null; plan_title: string | null
}

export default function Subscriptions() {
  const { api, toast } = useApp()
  const [q, setQ] = useState('')
  const { data, loading, reload } = useAsync(async () => {
    if (!api) return []
    return await api.adminSubscriptions() as unknown as SubRow[]
  }, [api])

  const rows = (data ?? []).filter((r) =>
    !q.trim() || (r.display_name ?? '').toLowerCase().includes(q.toLowerCase()) || r.sku.toLowerCase().includes(q.toLowerCase()))

  const active = rows.filter((r) => r.status === 'active' && new Date(r.end_date) > new Date())
  const expired = rows.filter((r) => new Date(r.end_date) <= new Date() || r.status === 'expired')

  const revoke = async (id: string) => {
    if (!api) return
    try { await api.adminRevokeSubscription(id); toast('اشتراک لغو شد.', 'success'); await reload() }
    catch (e) { toast(e instanceof Error ? e.message : 'لغو ناموفق بود — تابع سرور باید مستقر باشد.', 'error') }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="اشتراک‌ها"
        subtitle="وضعیت اشتراک کاربران بر اساس خریدهای واقعی مایکت. اشتراک فقط توسط سرور پس از تأیید خرید ثبت می‌شود."
        badge={<Chip tone="primary"><CreditCard className="size-3" /> پرداخت و اشتراک</Chip>}
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard title="اشتراک فعال" value={active.length} icon={<BadgeCheck className="size-5" />} tone="success" />
        <StatCard title="منقضی‌شده" value={expired.length} icon={<Timer className="size-5" />} />
        <StatCard title="کل رکوردها" value={rows.length} icon={<CreditCard className="size-5" />} />
      </div>

      <Card className="!p-4">
        <div className="relative lg:w-80">
          <Search className="pointer-events-none absolute right-3.5 top-1/2 size-4 -translate-y-1/2 text-ink-faint" />
          <Input className="pr-10" placeholder="جستجو بر اساس نام کاربر یا SKU…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </Card>

      <Card className="!p-0 overflow-hidden">
        {loading && <div className="space-y-3 p-5">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-12" />)}</div>}

        {!loading && rows.length === 0 && (
          <div className="p-5">
            <EmptyState
              icon={<Crown className="size-6" />}
              title="هنوز اشتراکی ثبت نشده"
              body="پس از اولین خرید موفق در اپلیکیشن، اشتراک کاربران اینجا نمایش داده می‌شود."
            />
          </div>
        )}

        {!loading && rows.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-sm">
              <thead className="bg-card-soft/40">
                <tr className="text-[11px] text-ink-faint">
                  <th className="px-4 py-3 text-right font-bold">کاربر</th>
                  <th className="px-4 py-3 text-right font-bold">SKU</th>
                  <th className="px-4 py-3 text-right font-bold">وضعیت</th>
                  <th className="px-4 py-3 text-right font-bold">شروع</th>
                  <th className="px-4 py-3 text-right font-bold">پایان</th>
                  <th className="px-4 py-3 text-right font-bold">توکن خرید</th>
                  <th className="px-4 py-3 text-right font-bold">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => {
                  const isActive = r.status === 'active' && new Date(r.end_date) > new Date()
                  return (
                    <tr key={r.id} className="border-t border-line/50">
                      <td className="px-4 py-3">
                        <p className="text-[13px] font-extrabold">{r.display_name || 'کاربر بدون نام'}</p>
                        <p className="ltr text-[10px] text-ink-faint">{r.user_id.slice(0, 18)}…</p>
                      </td>
                      <td className="ltr px-4 py-3 text-[11px] font-bold">{r.sku}</td>
                      <td className="px-4 py-3">
                        {isActive ? <Chip tone="success" className="!px-2 !py-0.5 !text-[10px]">فعال</Chip>
                          : <Chip className="!px-2 !py-0.5 !text-[10px]">{r.status === 'cancelled' ? 'لغوشده' : 'منقضی'}</Chip>}
                      </td>
                      <td className="px-4 py-3 text-[10px] text-ink-faint">{faDateTime(r.start_date)}</td>
                      <td className="px-4 py-3 text-[11px] font-bold">{faDate(r.end_date)}</td>
                      <td className="ltr px-4 py-3 text-[10px] text-ink-faint">{r.purchase_token ? `${r.purchase_token.slice(0, 14)}…` : '—'}</td>
                      <td className="px-4 py-3">
                        {isActive && (
                          <Confirmed label={<><ShieldOff className="size-3.5" /> لغو</>} confirmLabel="لغو کن" onConfirm={() => revoke(r.id)} />
                        )}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Card className="!p-4">
        <p className="text-[11px] leading-6 text-ink-faint">
          تعداد اشتراک‌های فعال: {faNum(active.length)} — برای تغییر مدت دسترسی هر SKU به بخش «پلن‌ها» برو. لغو اشتراک، دسترسی کاربر را فوراً قطع می‌کند و در سابقه ثبت می‌شود.
        </p>
      </Card>
    </div>
  )
}
