import { useEffect, useState } from 'react'
import { Building2, CreditCard, Info, Save, Settings2, ShoppingCart, Sparkles } from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { Button, Card, Chip, Field, Input, PageHeader, SectionTitle, Skeleton, Switch, Tabs, Textarea } from '@/components/ui'
import { faDateTime, faNum } from '@/lib/utils'

function SupportInbox() {
  const { api, toast } = useApp()
  const [rows, setRows] = useState<{ id: string; email: string | null; subject: string | null; body: string; status: string; created_at: string }[] | null>(null)

  const load = async () => {
    if (!api) return
    try { setRows(await api.adminSupport()) } catch { setRows([]) }
  }
  useEffect(() => { void load() }, [api]) // eslint-disable-line react-hooks/exhaustive-deps

  const setStatus = async (id: string, status: 'open' | 'answered' | 'closed') => {
    try { await api?.adminSupportStatus(id, status); await load(); toast('وضعیت پیام به‌روز شد.', 'success') }
    catch (e: any) { toast(e?.message ?? 'به‌روزرسانی ناموفق بود', 'error') }
  }

  return (
    <Card>
      <SectionTitle title="پیام‌های پشتیبانی" subtitle="پیام‌های واقعی کاربران از صفحه «راهنما» در برنامه." />
      {rows === null && <div className="mt-4 space-y-2"><Skeleton className="h-16" /><Skeleton className="h-16" /></div>}
      {rows !== null && rows.length === 0 && (
        <p className="mt-4 rounded-2xl border border-line/70 bg-bg-soft/40 p-5 text-center text-[11.5px] text-ink-faint">
          هنوز پیامی از کاربران ثبت نشده است. هر پیامی که در برنامه ارسال شود، همین‌جا نمایش داده می‌شود.
        </p>
      )}
      <div className="mt-4 space-y-3">
        {(rows ?? []).map((r) => (
          <div key={r.id} className="rounded-3xl border border-line/70 bg-bg-soft/40 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-[11px]">
                <Chip tone={r.status === 'open' ? 'warn' : r.status === 'answered' ? 'success' : 'default'} className="!px-2 !py-0.5 !text-[10px]">
                  {r.status === 'open' ? 'باز' : r.status === 'answered' ? 'پاسخ داده‌شده' : 'بسته'}
                </Chip>
                <span className="ltr text-ink-muted">{r.email ?? '—'}</span>
                <span className="text-ink-faint">{faDateTime(r.created_at)}</span>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="ghost" onClick={() => setStatus(r.id, 'answered')}>پاسخ داده شد</Button>
                <Button size="sm" variant="ghost" onClick={() => setStatus(r.id, 'closed')}>بستن</Button>
              </div>
            </div>
            <p className="mt-3 text-[12px] leading-7">{r.body}</p>
          </div>
        ))}
      </div>
    </Card>
  )
}

export default function AppSettings() {
  const { api, settings, refreshCatalogData, toast } = useApp()
  const [tab, setTab] = useState<'general' | 'marketing' | 'learning' | 'myket' | 'features'>('general')
  const [draft, setDraft] = useState<Record<string, any>>({})
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    setDraft({
      general: settings.general, learning: settings.learning, myket: settings.myket,
      features: settings.features, marketing: (settings as any).marketing,
    })
  }, [settings])

  const set = (group: string, key: string, value: unknown) => setDraft((d) => ({ ...d, [group]: { ...(d[group] ?? {}), [key]: value } }))

  const save = async () => {
    if (!api) return
    setBusy(true)
    try {
      for (const group of ['general', 'marketing', 'learning', 'myket', 'features'] as const) {
        if (draft[group]) await api.saveAppSetting(group, draft[group])
      }
      await refreshCatalogData()
      toast('تنظیمات ذخیره شد.', 'success')
    } catch (e) { toast(e instanceof Error ? e.message : 'ذخیره ناموفق بود', 'error') }
    finally { setBusy(false) }
  }

  const g = draft.general ?? {}
  const l = draft.learning ?? {}
  const m = draft.myket ?? {}
  const mk = draft.marketing ?? {}
  const f = draft.features ?? {}

  return (
    <div className="space-y-6">
      <PageHeader
        title="تنظیمات برنامه"
        subtitle="نام محصول، متن‌ها، قواعد دسترسی رایگان، اطلاعات مایکت و فعال/غیرفعال بودن قابلیت‌ها."
        badge={<Chip tone="primary"><Settings2 className="size-3" /> تنظیمات کلی</Chip>}
        actions={<Button onClick={save} loading={busy}><Save className="size-4" /> ذخیره تغییرات</Button>}
      />

      <Tabs value={tab} onChange={setTab} tabs={[
        { id: 'general', label: 'عمومی' },
        { id: 'marketing', label: 'صفحه اصلی (بازاریابی)' },
        { id: 'learning', label: 'دسترسی رایگان' },
        { id: 'myket', label: 'مایکت' },
        { id: 'features', label: 'قابلیت‌ها' },
      ]} />

      {tab === 'general' && (
        <Card>
          <SectionTitle title="اطلاعات عمومی" subtitle="این متن‌ها در سایت و اپ استفاده می‌شوند." />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="نام محصول"><Input value={g.app_name ?? ''} onChange={(e) => set('general', 'app_name', e.target.value)} /></Field>
            <Field label="شعار"><Input value={g.tagline ?? ''} onChange={(e) => set('general', 'tagline', e.target.value)} /></Field>
            <Field label="ایمیل پشتیبانی" hint="در صفحه تماس با ما نمایش داده می‌شود."><Input dir="ltr" value={g.support_email ?? ''} onChange={(e) => set('general', 'support_email', e.target.value)} /></Field>
            <div className="flex items-end">
              <div className="flex w-full items-center justify-between rounded-2xl border border-line/70 bg-bg-soft/50 px-4 py-3">
                <span className="text-xs font-bold">حالت تعمیر و نگهداری</span>
                <Switch checked={Boolean(g.maintenance_mode)} onChange={(v) => set('general', 'maintenance_mode', v)} />
              </div>
            </div>
            <div className="flex items-end sm:col-span-2">
              <div className="flex w-full items-center justify-between rounded-2xl border border-line/70 bg-bg-soft/50 px-4 py-3">
                <span className="flex items-center gap-2 text-xs font-bold"><Sparkles className="size-3.5 text-primary-soft" /> نمایش بنرها در برنامه کاربر</span>
                <Switch checked={g.show_banners !== false} onChange={(v) => set('general', 'show_banners', v)} />
              </div>
            </div>
          </div>
        </Card>
      )}

      {tab === 'marketing' && (
        <div className="grid gap-5 lg:grid-cols-2">
          <Card>
            <SectionTitle title="متن هیرو صفحه اصلی" subtitle="همین متن‌ها بلافاصله روی سایت عمومی نمایش داده می‌شوند." />
            <div className="mt-4 space-y-4">
              <Field label="عنوان اصلی هیرو" hint="برای شکستن خط، از «؛» بین دو بخش استفاده کن.">
                <Input value={mk.hero_title ?? ''} onChange={(e) => set('marketing', 'hero_title', e.target.value)} />
              </Field>
              <Field label="توضیح زیر عنوان"><Textarea rows={3} value={mk.hero_subtitle ?? ''} onChange={(e) => set('marketing', 'hero_subtitle', e.target.value)} /></Field>
              <div className="grid gap-4 sm:grid-cols-3">
                <Field label="دکمه اصلی (کاربر مهمان)"><Input value={mk.hero_cta ?? ''} onChange={(e) => set('marketing', 'hero_cta', e.target.value)} /></Field>
                <Field label="دکمه اصلی (کاربر وارد‌شده)"><Input value={mk.hero_cta_logged_in ?? ''} onChange={(e) => set('marketing', 'hero_cta_logged_in', e.target.value)} /></Field>
                <Field label="دکمه دوم"><Input value={mk.hero_secondary ?? ''} onChange={(e) => set('marketing', 'hero_secondary', e.target.value)} /></Field>
              </div>
            </div>
          </Card>
          <Card>
            <SectionTitle title="قیمت‌ها در سایت عمومی" subtitle="نمایش قیمت فقط وقتی فعال است که این گزینه روشن باشد." />
            <div className="mt-4 rounded-2xl border border-line/70 bg-bg-soft/50 px-4 py-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-extrabold">نمایش قیمت و پیشنهاد ویژه در صفحه اصلی</p>
                  <p className="mt-1 text-[10.5px] leading-5 text-ink-faint">قیمت‌ها از جدول پلن‌ها خوانده می‌شوند؛ هرگز در کد ثابت نیستند.</p>
                </div>
                <Switch checked={mk.show_pricing === true} onChange={(v) => set('marketing', 'show_pricing', v)} />
              </div>
            </div>
            <div className="mt-4 rounded-3xl border border-line/70 bg-card/50 p-4">
              <p className="text-[11px] font-extrabold text-ink-faint">پیش‌نمایش عنوان</p>
              <p className="mt-2 text-[13px] font-extrabold leading-7">
                {(mk.hero_title ?? 'زبان را فقط نخوان؛ واقعاً یاد بگیر.').split('؛').map((part: string, i: number) => (
                  <span key={i} className={i === 1 ? 'grad-text' : ''}>{part}{i === 0 ? '؛' : ''}</span>
                ))}
              </p>
            </div>
            <p className="mt-4 text-[11px] leading-6 text-ink-muted">
              تصویر پس‌زمینه هیرو از «کتابخانه رسانه» تغییر می‌کند (جایگاه hero_background و hero_background_mobile).
            </p>
          </Card>
        </div>
      )}

      {tab === 'learning' && (
        <Card>
          <SectionTitle title="قواعد دسترسی رایگان" subtitle="این اعداد در سرور اعمال می‌شوند." />
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="تعداد درس رایگان در هر زبان" hint="پیش‌فرض ۲ درس کامل برای هر زبان.">
              <Input type="number" min="0" value={String(l.free_lessons_per_language ?? 2)} onChange={(e) => set('learning', 'free_lessons_per_language', Number(e.target.value))} />
            </Field>
            <Field label="پیام رایگان Conversation Partner" hint="برای هر کاربر رایگان، در کل.">
              <Input type="number" min="0" value={String(l.free_conversation_messages ?? 2)} onChange={(e) => set('learning', 'free_conversation_messages', Number(e.target.value))} />
            </Field>
            <Field label="هدف درس برای هر زبان" hint="برای نمایش پیشرفت کل مسیر.">
              <Input type="number" min="1" value={String(l.target_lessons_per_language ?? 340)} onChange={(e) => set('learning', 'target_lessons_per_language', Number(e.target.value))} />
            </Field>
          </div>
          <div className="mt-5 rounded-2xl border border-line/70 bg-bg-soft/50 p-4 text-[11px] leading-7 text-ink-muted">
            <p>با این تنظیمات، هر کاربر رایگان <b className="text-ink">{faNum((l.free_lessons_per_language ?? 2) * 3)} درس کامل</b> (در سه زبان) و <b className="text-ink">{faNum(l.free_conversation_messages ?? 2)} پیام</b> Conversation Partner دارد.</p>
            <p className="mt-1 text-ink-faint">هیچ دوره آزمایشی وجود ندارد و حساب رایگان هرگز منقضی نمی‌شود.</p>
          </div>
        </Card>
      )}

      {tab === 'myket' && (
        <>
          <Card>
            <SectionTitle title="اتصال مایکت" subtitle="این اطلاعات از پنل توسعه‌دهندگان مایکت گرفته می‌شود." />
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="پکیج‌نیم اپلیکیشن" hint="مثال: ir.lingu.app">
                <Input dir="ltr" value={m.package_name ?? ''} onChange={(e) => set('myket', 'package_name', e.target.value)} />
              </Field>
              <Field label="کلید عمومی (RSA) — اختیاری" hint="اگر SDK به کلید نیاز داشت، اینجا وارد کن. کلید عمومی حساس نیست.">
                <Input dir="ltr" value={m.public_key ?? ''} onChange={(e) => set('myket', 'public_key', e.target.value)} />
              </Field>
              <div className="flex items-end sm:col-span-2">
                <div className="flex w-full items-center justify-between rounded-2xl border border-line/70 bg-bg-soft/50 px-4 py-3">
                  <span className="flex items-center gap-2 text-xs font-bold"><ShoppingCart className="size-3.5 text-primary-soft" /> پرداخت مایکت فعال باشد</span>
                  <Switch checked={Boolean(m.enabled)} onChange={(v) => set('myket', 'enabled', v)} />
                </div>
              </div>
            </div>
          </Card>

          <Card>
            <SectionTitle title="محصولات مایکت" subtitle="SKU های واقعی که در پنل مایکت ساخته‌ای." />
            <div className="overflow-x-auto">
              <table className="w-full min-w-[520px] text-sm">
                <thead className="bg-card-soft/40">
                  <tr className="text-[11px] text-ink-faint">
                    <th className="px-4 py-3 text-right font-bold">SKU</th>
                    <th className="px-4 py-3 text-right font-bold">عنوان</th>
                    <th className="px-4 py-3 text-right font-bold">مدت</th>
                  </tr>
                </thead>
                <tbody>
                  {[['LINGU_MONTHLY', 'اشتراک ماهانه', 30], ['LINGU_QUARTERLY', 'اشتراک سه‌ماهه', 90], ['LINGU_YEARLY', 'اشتراک سالانه', 365]].map(([sku, title, days]) => (
                    <tr key={String(sku)} className="border-t border-line/50">
                      <td className="ltr px-4 py-3 text-[12px] font-extrabold">{sku}</td>
                      <td className="px-4 py-3 text-[12px]">{title}</td>
                      <td className="px-4 py-3 text-[12px] text-ink-muted">{faNum(Number(days))} روز</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="mt-4 flex items-start gap-2 text-[11px] leading-6 text-ink-faint">
              <Info className="mt-0.5 size-3.5 shrink-0 text-primary-soft" />
              SKU و مدت هر محصول در بخش «پلن‌ها» قابل ویرایش است. قیمت واقعی از مایکت خوانده می‌شود.
            </p>
          </Card>
        </>
      )}

      {tab === 'features' && (
        <Card>
          <SectionTitle title="فعال/غیرفعال کردن قابلیت‌ها" subtitle="برای انتشار کنترل‌شده و مدیریت هزینه." />
          <div className="grid gap-3 sm:grid-cols-2">
            {[
              ['ai_tutor', 'AI Tutor', 'مربی آموزشی داخل برنامه'],
              ['conversation_partner', 'Conversation Partner', 'مکالمه نقش‌محور با AI'],
              ['progress', 'پیشرفت', 'ثبت و نمایش پیشرفت درس‌ها'],
              ['subscription', 'اشتراک', 'صفحه پلن‌ها و خرید'],
              ['certificates', 'گواهی پایان دوره', 'در نسخه فعلی غیرفعال است'],
            ].map(([key, label, body]) => (
              <div key={key} className="flex items-center justify-between rounded-2xl border border-line/70 bg-bg-soft/50 px-4 py-3">
                <div>
                  <p className="text-xs font-extrabold">{label}</p>
                  <p className="text-[10px] text-ink-faint">{body}</p>
                </div>
                <Switch checked={Boolean(f[key])} onChange={(v) => set('features', key, v)} />
              </div>
            ))}
          </div>
        </Card>
      )}

      {!settings.general && <Skeleton className="h-32" />}

      <SupportInbox />

      <Card className="!p-5">
        <div className="flex flex-wrap items-center gap-3">
          <Building2 className="size-4 text-primary-soft" />
          <p className="text-[11px] leading-6 text-ink-muted">این تنظیمات بدون نیاز به انتشار نسخه جدید اعمال می‌شوند؛ فقط ذخیره کن و صفحه را تازه کن.</p>
          <CreditCard className="size-4 text-primary-soft" />
          <p className="text-[11px] text-ink-muted">اطلاعات حساس مانند کلید Groq در این صفحه نیست و در بخش «تنظیمات AI» مدیریت می‌شود.</p>
        </div>
      </Card>
    </div>
  )
}
