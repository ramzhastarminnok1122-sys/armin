import { AnimatePresence, motion } from 'motion/react'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ChevronDown, HelpCircle, LifeBuoy } from 'lucide-react'
import { useAsync } from '@/lib/hooks'
import { getApi } from '@/services/api'
import { Button, Card, Chip, EmptyState, Skeleton } from '@/components/ui'
import { useApp } from '@/context/AppContext'
import { faNum } from '@/lib/utils'

const CATS: { id: string; label: string }[] = [
  { id: 'all', label: 'همه' },
  { id: 'general', label: 'عمومی' },
  { id: 'pricing', label: 'رایگان و اشتراک' },
  { id: 'features', label: 'امکانات' },
  { id: 'languages', label: 'زبان‌ها' },
]

export default function FAQ() {
  const { api } = useApp()
  const { data, loading } = useAsync(async () => (await getApi()).publicContent(), [])
  const [cat, setCat] = useState('all')
  const [open, setOpen] = useState<string | null>(null)
  const faqs = (data?.faqs ?? []).filter((f) => cat === 'all' || f.category === cat)

  return (
    <div className="container-x py-12 lg:py-20">
      <div className="mx-auto max-w-3xl text-center">
        <Chip tone="primary"><HelpCircle className="size-3" /> سؤالات متداول</Chip>
        <h1 className="mt-5 text-3xl sm:text-4xl lg:text-5xl">هر سؤالی داری، اینجا جواب دارد</h1>
        <p className="mt-5 text-sm leading-8 text-ink-muted">اگر جواب سوالت را پیدا نکردی، از AI Tutor داخل برنامه بپرس یا به پشتیبانی پیام بده.</p>
      </div>

      <div className="mx-auto mt-10 flex max-w-3xl flex-wrap justify-center gap-2">
        {CATS.map((c) => (
          <button key={c.id} onClick={() => setCat(c.id)}
            className={`rounded-2xl border px-4 py-2 text-xs font-bold transition-all ${cat === c.id ? 'border-primary/40 bg-brand-soft text-ink' : 'border-line/80 bg-card/40 text-ink-muted hover:text-ink'}`}>
            {c.label}
          </button>
        ))}
      </div>

      <div className="mx-auto mt-8 max-w-3xl space-y-3">
        {loading && Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="card-surface p-5"><Skeleton className="h-5 w-2/3" /></div>
        ))}

        {!loading && faqs.length === 0 && (
          <EmptyState title="سؤالی در این دسته ثبت نشده" body="به‌زودی سؤالات این بخش اضافه می‌شود." icon={<HelpCircle className="size-6" />} />
        )}

        {faqs.map((f) => (
          <Card key={f.id} className="!p-0 overflow-hidden">
            <button onClick={() => setOpen(open === f.id ? null : f.id)} className="flex w-full items-center gap-3 p-5 text-right">
              <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-brand-soft text-primary-soft"><HelpCircle className="size-4" /></span>
              <span className="flex-1 text-sm font-extrabold">{f.question}</span>
              <motion.span animate={{ rotate: open === f.id ? 180 : 0 }}><ChevronDown className="size-4 text-ink-faint" /></motion.span>
            </button>
            <AnimatePresence initial={false}>
              {open === f.id && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }} className="overflow-hidden">
                  <p className="border-t border-line/60 px-5 py-4 text-[13px] leading-8 text-ink-muted">{f.answer}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </Card>
        ))}
      </div>

      <Card className="mx-auto mt-12 flex max-w-3xl flex-wrap items-center justify-between gap-4 !p-6">
        <div className="flex items-center gap-3">
          <LifeBuoy className="size-5 text-primary-soft" />
          <p className="text-sm font-bold">جواب سوالت اینجا نبود؟</p>
        </div>
        <div className="flex gap-2">
          <Link to="/signup"><Button size="sm">ثبت‌نام و پرسیدن از AI Tutor</Button></Link>
          <Link to="/contact"><Button size="sm" variant="outline">تماس با ما</Button></Link>
        </div>
      </Card>
      {api?.mode === 'demo' && <p className="mt-4 text-center text-[11px] text-ink-faint">{faNum(faqs.length)} سؤال نمایشی (پیش‌نمایش طراحی)</p>}
    </div>
  )
}
