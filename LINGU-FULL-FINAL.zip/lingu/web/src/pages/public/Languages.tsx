import { motion } from 'motion/react'
import { Link } from 'react-router-dom'
import { ArrowLeft, CheckCircle2, Compass, GraduationCap, Route } from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { Button, Card, Chip, Progress } from '@/components/ui'
import { faNum } from '@/lib/utils'

const PATHS = [
  { level: 'A1 — مبتدی', body: 'پایه‌های زبان: معرفی خود، اعداد، زمان حال، مکالمه‌های روزمره (کافه، خرید، آدرس پرسیدن).', lessons: 60 },
  { level: 'A2 — پیش‌متوسط', body: 'زمان گذشته، برنامه‌ریزی، سفر، توصیف تجربه‌ها و مکالمه‌های اجتماعی.', lessons: 90 },
  { level: 'B1 — متوسط', body: 'بیان نظر، بحث درباره موضوعات روز، موقعیت‌های کاری و مکالمه‌های طولانی‌تر.', lessons: 100 },
  { level: 'B2 — متوسط بالا', body: 'مکالمه روان‌تر، اصطلاحات، متن‌های واقعی و آماده‌سازی برای موقعیت‌های حرفه‌ای.', lessons: 90 },
]

export default function Languages() {
  const { languages, session } = useApp()
  return (
    <div className="container-x py-12 lg:py-20">
      <div className="mx-auto max-w-3xl text-center">
        <Chip tone="primary"><Compass className="size-3" /> زبان‌ها</Chip>
        <h1 className="mt-5 text-3xl sm:text-4xl lg:text-5xl">سه زبان، با مسیر کامل و سطح‌بندی‌شده</h1>
        <p className="mt-5 text-sm leading-8 text-ink-muted sm:text-base">
          هدف ما {faNum(340)} درس برای هر زبان است؛ از A1 تا B2. نسخه اول با درس‌های رایگان کامل شروع می‌شود و درس‌های Premium هر هفته اضافه می‌شوند.
        </p>
      </div>

      <div className="mt-14 space-y-8">
        {languages.map((l, i) => (
          <motion.div key={l.code} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: i * 0.06 }}>
            <Card className="relative overflow-hidden !p-7">
              <div className={`absolute -left-16 -top-16 size-56 rounded-full bg-gradient-to-br ${l.gradient} opacity-20 blur-3xl`} />
              <div className="relative grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
                <div>
                  <div className="flex items-center gap-4">
                    <span className="text-5xl">{l.flag}</span>
                    <div>
                      <h2 className="text-2xl font-extrabold">{l.name_fa}</h2>
                      <p className="ltr text-xs text-ink-faint">{l.native_name} · {l.name_en}</p>
                    </div>
                  </div>
                  <p className="mt-5 text-sm leading-7 text-ink-muted">{l.description}</p>
                  <div className="mt-6 space-y-3">
                    <div className="flex items-center justify-between text-[11px] font-bold text-ink-faint">
                      <span>هدف نهایی</span><span>{faNum(l.target_lessons)} درس</span>
                    </div>
                    <Progress value={Math.round((4 / l.target_lessons) * 100)} />
                  </div>
                  <div className="mt-6 flex flex-wrap gap-2">
                    <Chip tone="success"><CheckCircle2 className="size-3" /> {faNum(2)} درس کامل رایگان</Chip>
                    <Chip><Route className="size-3" /> مسیر A1 تا B2</Chip>
                  </div>
                  <Link to={session ? '/app/lessons' : '/signup'} className="mt-6 inline-block">
                    <Button>شروع {l.name_fa} <ArrowLeft className="size-3.5" /></Button>
                  </Link>
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  {PATHS.map((p) => (
                    <div key={p.level} className="rounded-2xl border border-line/70 bg-bg-soft/50 p-4">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-extrabold">{p.level}</p>
                        <Chip className="!px-2 !py-0.5 !text-[10px]">{faNum(p.lessons)} درس</Chip>
                      </div>
                      <p className="mt-2 text-[11px] leading-6 text-ink-faint">{p.body}</p>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card className="mt-12 flex flex-wrap items-center justify-between gap-5 !p-7">
        <div className="flex items-center gap-4">
          <span className="grid size-12 place-items-center rounded-2xl bg-brand-grad text-white"><GraduationCap className="size-5" /></span>
          <div>
            <h3 className="text-lg font-extrabold">نمی‌دانی از کجا شروع کنی؟</h3>
            <p className="text-xs text-ink-muted">از انگلیسی A1 شروع کن — پرکاربردترین مسیر برای شروع.</p>
          </div>
        </div>
        <Link to={session ? '/app/lessons' : '/signup'}><Button>{session ? 'دیدن درس‌ها' : 'ثبت‌نام و شروع'}</Button></Link>
      </Card>
    </div>
  )
}
