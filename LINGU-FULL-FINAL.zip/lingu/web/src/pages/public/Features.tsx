import { motion } from 'motion/react'
import { Link } from 'react-router-dom'
import {
  BookOpenCheck, BrainCircuit, CheckCircle2, GraduationCap, LayoutDashboard, Languages,
  MessagesSquare, Route, ShieldCheck, Sparkles, Timer, Trophy,
} from 'lucide-react'
import { Button, Card, Chip, SectionTitle } from '@/components/ui'
import { useApp } from '@/context/AppContext'

const FEATURES = [
  { icon: BookOpenCheck, title: 'درس‌های ۱۲ بخشی', body: 'هر درس کامل است: گرم‌کردن، توضیح، واژگان، گرامر، مثال، شنیداری، دیالوگ، گفت‌وگو، خواندن، تمرین، آزمون و تمرین با AI. هیچ بخشی تشریفاتی نیست.' },
  { icon: GraduationCap, title: 'AI Tutor در لحظه', body: 'مربی LINGU همان درس را با زبان ساده‌تر توضیح می‌دهد، برای قاعده‌ها مثال تازه می‌سازد و پاسخ سؤال‌هایت را می‌دهد.' },
  { icon: MessagesSquare, title: 'Conversation Partner نقش‌محور', body: 'نقش واقعی انتخاب می‌کنی و مکالمه ادامه پیدا می‌کند؛ Partner واکنش می‌دهد، سؤال تازه می‌پرسد و در نقش می‌ماند.' },
  { icon: Route, title: 'پیشرفت شفاف', body: 'درصد تکمیل هر درس، بخش‌های انجام‌شده، درس‌های تمام‌شده و زمان یادگیری — همه واقعی و ذخیره‌شده.' },
  { icon: Languages, title: 'سه زبان، ساختار یکسان', body: 'English، French و Spanish با همان کیفیت و همان ترتیب آموزشی؛ جابه‌جایی بین زبان‌ها ساده است.' },
  { icon: BrainCircuit, title: 'محتوای تولیدشده با کنترل کیفیت', body: 'درس‌ها با Content Factory تولید و سپس اعتبارسنجی و بررسی تکراری می‌شوند؛ فقط درس‌های سالم منتشر می‌شوند.' },
  { icon: Timer, title: 'درس‌های کوتاه و مؤثر', body: 'هر درس حدود ۱۵ تا ۲۰ دقیقه است تا در برنامه روزانه‌ات جا شود.' },
  { icon: ShieldCheck, title: 'امنیت و حریم خصوصی', body: 'اطلاعات حساب و پیشرفت یادگیری‌ات محافظت‌شده نگهداری می‌شود و وضعیت اشتراک همیشه از سرور تأیید می‌گردد.' },
  { icon: Sparkles, title: 'بدون تبلیغ و حواس‌پرتی', body: 'محیط یادگیری تمیز است: فقط درس، تمرین و مکالمه — نه تبلیغ، نه محتوای پرت‌کننده.' },
]

export default function Features() {
  const { session } = useApp()
  return (
    <div className="container-x py-12 lg:py-20">
      <div className="mx-auto max-w-3xl text-center">
        <Chip tone="primary"><Sparkles className="size-3" /> امکانات</Chip>
        <h1 className="mt-5 text-3xl sm:text-4xl lg:text-5xl">هر چیزی که برای یادگیری واقعی لازم داری</h1>
        <p className="mt-5 text-sm leading-8 text-ink-muted sm:text-base">
          LINGU فقط یک مجموعه ویدیو یا فلش‌کارت نیست؛ یک مسیر آموزشی کامل است که با تمرین فعال، توضیح شخصی‌سازی‌شده و مکالمه واقعی جلو می‌رود.
        </p>
      </div>

      <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {FEATURES.map((f, i) => (
          <motion.div key={f.title}
            initial={{ opacity: 0, y: 22 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5, delay: (i % 4) * 0.06 }}>
            <Card className="h-full hover-lift">
              <span className="grid size-11 place-items-center rounded-2xl bg-brand-soft text-primary-soft"><f.icon className="size-5" /></span>
              <h3 className="mt-4 text-base font-extrabold">{f.title}</h3>
              <p className="mt-2 text-[13px] leading-7 text-ink-muted">{f.body}</p>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="mt-16 grid gap-6 lg:grid-cols-2">
        <Card className="!p-7">
          <SectionTitle title="برای شروع چه چیزی لازم است؟" subtitle="فقط یک ایمیل. نه کارت بانکی، نه نرم‌افزار خاص." />
          <ul className="space-y-3 text-sm">
            {['ثبت‌نام با ایمیل و گذرواژه', 'انتخاب زبان و سطح تقریبی', '۲ درس کامل رایگان در هر زبان', '۲ پیام Conversation Partner برای همیشه'].map((t) => (
              <li key={t} className="flex items-start gap-2 text-ink-muted"><CheckCircle2 className="mt-0.5 size-4 shrink-0 text-success" /> {t}</li>
            ))}
          </ul>
        </Card>
        <Card className="!p-7">
          <SectionTitle title="چه چیزی در LINGU نیست؟" subtitle="ما عمداً از قابلیت‌های حاشیه‌ای پرهیز کردیم تا کیفیت محتوا بالا بماند." />
          <ul className="space-y-3 text-sm">
            {['جدول امتیاز و رقابت بی‌هدف کاربران', 'نشان‌ها و سیستم وفاداری پیچیده', 'تصحیح تلفظ خودکار با امتیاز صوتی', 'آزمون تعیین سطح طولانی در شروع'].map((t) => (
              <li key={t} className="flex items-start gap-2 text-ink-muted"><Trophy className="mt-0.5 size-4 shrink-0 text-ink-faint" /> {t}</li>
            ))}
          </ul>
        </Card>
      </div>

      <Card className="mt-14 flex flex-col items-center gap-4 !rounded-4xl p-8 text-center lg:p-12">
        <LayoutDashboard className="size-8 text-primary-soft" />
        <h2 className="text-2xl font-extrabold">همین حالا اولین درس را باز کن</h2>
        <p className="max-w-xl text-sm leading-7 text-ink-muted">درس اول هر زبان رایگان است و کامل — با واژگان، گرامر، دیالوگ، آزمون و تمرین AI.</p>
        <div className="flex flex-wrap justify-center gap-3">
          <Link to={session ? '/app/lessons' : '/signup'}><Button size="lg">{session ? 'دیدن درس‌ها' : 'ثبت‌نام رایگان'}</Button></Link>
          <Link to="/how-it-works"><Button size="lg" variant="outline">چگونه کار می‌کند؟</Button></Link>
        </div>
      </Card>
    </div>
  )
}
