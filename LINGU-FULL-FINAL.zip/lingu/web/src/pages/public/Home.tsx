import { motion, useReducedMotion, useScroll, useTransform } from 'motion/react'
import { useRef } from 'react'
import { Link } from 'react-router-dom'
import {
  ArrowLeft, BadgeCheck, BookOpenCheck, CheckCircle2, Compass, Flame, GraduationCap, Headphones,
  Languages as LangIcon, ListChecks, MessagesSquare, Mic, Newspaper, PencilLine, Play, Quote,
  Route, Sparkles, Star, Target, Timer, Trophy,
} from 'lucide-react'
import { useApp } from '@/context/AppContext'
import { useAsync } from '@/lib/hooks'
import { Button, Card, Chip, Progress, SectionTitle, StaggerGroup, Reveal, staggerItem } from '@/components/ui'
import { faNum } from '@/lib/utils'
import { LESSON_SECTIONS } from '@/lib/constants'
import { mediaOf } from '@/lib/assets'
import type { Testimonial } from '@/services/types'

const SECTION_ICONS: Record<string, any> = {
  Flame, BookOpen: BookOpenCheck, Languages: LangIcon, Blocks: Sparkles, Quote, Headphones,
  MessagesSquare, Mic, Newspaper, PencilLine, ListChecks, Sparkles,
}

const SECTION_BLURB: Record<string, string> = {
  warmup: 'با چند سؤال کوتاه ذهنت را آماده می‌کنی.',
  explanation: 'توضیح روشن از هدف درس و کاربرد واقعی آن.',
  vocabulary: 'واژه‌های کلیدی با ترجمه، تلفظ و مثال.',
  grammar: 'قاعده گرامری با الگو و اشتباه‌های رایج.',
  examples: 'مثال‌های هدف با ترجمه و نکته کاربردی.',
  listening: 'قطعه شنیداری کوتاه با سؤال درک مطلب.',
  dialogue: 'گفت‌وگوی طبیعی با ترجمه خط‌به‌خط.',
  speaking: 'تمرین گفت‌وگو با عبارت‌های آماده.',
  reading: 'متن کوتاه با واژه‌نامه و تمرین.',
  exercises: 'چندگزینه‌ای، جای‌خالی و مرتب‌سازی.',
  quiz: 'آزمون پایان درس با بازخورد فوری.',
  ai_practice: 'تمرین تعاملی با AI در همان موضوع.',
}

export default function Home() {
  const { languages, settings, session, plans, media } = useApp()
  const { data: content } = useAsync(async () => (await (await import('@/services/api')).getApi()).publicContent(), [])
  const heroRef = useRef<HTMLDivElement>(null)
  const reduce = useReducedMotion()
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] })
  const y = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : 80])
  const fade = useTransform(scrollYProgress, [0, 0.85], [1, 0])

  const testimonials: Testimonial[] = content?.testimonials ?? []
  const faqs = (content?.faqs ?? []).slice(0, 4)
  const targetLessons = Number(settings.learning?.target_lessons_per_language ?? 340)
  const marketing = (settings.marketing ?? {}) as Record<string, any>
  const showPricing = marketing.show_pricing === true
  const promoPlan = plans.find((p) => p.code !== 'free' && p.promo_active && p.promo_price) ?? null
  const hero = [
    marketing.hero_title || 'زبان را فقط نخوان؛ واقعاً یاد بگیر.',
    marketing.hero_subtitle || 'درس‌های ۱۲ بخشی و ساختارمند در انگلیسی، فرانسه و اسپانیایی؛ همراه با AI Tutor که هر ابهام را توضیح می‌دهد و Conversation Partner که در موقعیت‌های واقعی هم‌صحبت تو می‌شود.',
    session ? (marketing.hero_cta_logged_in || 'ادامه یادگیری') : (marketing.hero_cta || 'شروع رایگان'),
    marketing.hero_secondary || 'دیدن امکانات',
  ] as const

  // hero title: the copy after «؛» is emphasised
  const [titleA, titleB] = hero[0].includes('؛') ? hero[0].split('؛') : [hero[0], '']

  return (
    <div className="overflow-hidden">
      {/* ══════════════════════ HERO ══════════════════════ */}
      <section ref={heroRef} className="relative">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <img src={mediaOf(media, 'hero_background').url} alt="" aria-hidden
            className="size-full object-cover object-center opacity-70" />
          <div className="absolute inset-0 bg-gradient-to-b from-bg/55 via-bg/80 to-bg" />
          <div className="absolute inset-0 bg-mesh opacity-60" />
        </div>

        <motion.div style={{ y, opacity: fade }} className="container-x relative grid items-center gap-12 pt-14 pb-16 lg:grid-cols-[1.05fr_0.95fr] lg:pt-20 lg:pb-24">
          <div>
            <Reveal>
              <Chip tone="primary" className="!text-[11px]">
                <Sparkles className="size-3" /> سه زبان · هدف {faNum(targetLessons)} درس برای هر زبان
              </Chip>
            </Reveal>

            <Reveal delay={0.06}>
              <h1 className="mt-5 text-[2rem] font-extrabold leading-[1.35] sm:text-5xl sm:leading-[1.3]">
                {titleA}{titleB && '؛'}<br />
                {titleB && <span className="grad-text animate-gradient-x bg-[length:200%_200%]">{titleB}</span>}
              </h1>
            </Reveal>

            <Reveal delay={0.12}>
              <p className="mt-5 max-w-xl text-[15px] leading-8 text-ink-muted sm:text-base">{hero[1]}</p>
            </Reveal>

            <Reveal delay={0.18}>
              <div className="mt-8 flex flex-wrap items-center gap-3">
                <Link to={session ? '/app' : '/signup'}>
                  <Button size="lg" className="shadow-glow"><Play className="size-4" /> {hero[2]}</Button>
                </Link>
                <Link to="/features">
                  <Button size="lg" variant="outline"><Compass className="size-4" /> {hero[3]}</Button>
                </Link>
              </div>
            </Reveal>

            <Reveal delay={0.24}>
              <div className="mt-7 flex flex-wrap items-center gap-x-6 gap-y-2 text-[12px] font-bold text-ink-muted">
                <span className="flex items-center gap-1.5"><CheckCircle2 className="size-4 text-success" /> ۶ درس کامل رایگان</span>
                <span className="flex items-center gap-1.5"><CheckCircle2 className="size-4 text-success" /> رایگان برای همیشه</span>
                <span className="flex items-center gap-1.5"><CheckCircle2 className="size-4 text-success" /> بدون کارت بانکی</span>
              </div>
            </Reveal>
          </div>

          {/* floating lesson preview — real product surface, not decoration */}
          <motion.div initial={{ opacity: 0, scale: 0.95, y: 26 }} animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: 0.12 }} className="relative">
            <div className="absolute -inset-6 rounded-[3rem] bg-brand-grad opacity-15 blur-3xl" />
            <div className="relative animate-float">
              <Card className="!rounded-4xl p-6">
                <div className="flex items-center justify-between">
                  <Chip><span className="text-base">🇬🇧</span> English · A1</Chip>
                  <Chip tone="primary"><Timer className="size-3" /> {faNum(18)} دقیقه</Chip>
                </div>
                <h3 className="mt-4 text-xl font-extrabold">Ordering at a Café</h3>
                <p className="mt-1 text-xs text-ink-muted">درس ۱ · مکالمه روزمره — سفارش دادن در کافه</p>

                <div className="mt-5 space-y-3">
                  {[
                    { label: 'Warmup', done: true },
                    { label: 'Vocabulary', done: true },
                    { label: 'Grammar', done: false },
                    { label: 'Dialogue', done: false },
                  ].map((s, i) => (
                    <div key={s.label} className="flex items-center gap-3">
                      <span className={`grid size-7 place-items-center rounded-xl text-[10px] font-extrabold ${s.done ? 'bg-success/15 text-success' : 'bg-card-soft text-ink-faint'}`}>
                        {s.done ? <CheckCircle2 className="size-3.5" /> : faNum(i + 1)}
                      </span>
                      <span className="flex-1 text-xs font-bold text-ink-muted">{s.label}</span>
                      {i === 2 && <span className="flex items-center gap-1 text-[10px] font-extrabold text-primary-soft"><Sparkles className="size-3" /> AI Tutor</span>}
                    </div>
                  ))}
                </div>

                <div className="mt-5">
                  <div className="mb-2 flex items-center justify-between text-[11px] font-bold text-ink-muted">
                    <span>پیشرفت درس</span><span>{faNum(50)}٪</span>
                  </div>
                  <Progress value={50} />
                </div>

                <div className="mt-5 rounded-2xl border border-line/70 bg-bg-soft/60 p-4">
                  <p className="flex items-center gap-2 text-[11px] font-extrabold text-ink-muted"><MessagesSquare className="size-3.5 text-primary-soft" /> Conversation Partner</p>
                  <p className="ltr mt-2 text-xs leading-6 text-ink">“Hi! Welcome in. What can I get for you today?”</p>
                  <p className="mt-1 text-[11px] text-ink-faint">سلام! خوش آمدی. امروز چه چیزی می‌خواهی سفارش بدهی؟</p>
                </div>
              </Card>

              <motion.div animate={reduce ? {} : { y: [0, -8, 0] }} transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
                className="glass-strong absolute -bottom-5 -right-3 hidden items-center gap-2 rounded-2xl px-4 py-3 sm:flex">
                <Trophy className="size-4 text-warn" />
                <div className="text-[11px] font-extrabold leading-4">۳ روز پیوسته<br /><span className="font-bold text-ink-faint">زنجیره یادگیری</span></div>
              </motion.div>
            </div>
          </motion.div>
        </motion.div>
      </section>

      {/* ══════════════════════ STATS ══════════════════════ */}
      <section className="container-x">
        <Reveal>
          <Card className="grid gap-6 !rounded-4xl p-7 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: LangIcon, label: 'زبان با درس کامل', value: '۳' },
              { icon: BookOpenCheck, label: 'بخش در هر درس', value: faNum(LESSON_SECTIONS.length) },
              { icon: Route, label: 'درس هدف (هر زبان)', value: faNum(targetLessons) },
              { icon: GraduationCap, label: 'AI Tutor در هر درس', value: '∞' },
            ].map((s) => (
              <div key={s.label} className="flex items-center gap-4">
                <span className="grid size-12 place-items-center rounded-2xl bg-brand-soft text-primary-soft"><s.icon className="size-5" /></span>
                <div>
                  <p className="text-2xl font-extrabold">{s.value}</p>
                  <p className="text-[11px] font-bold text-ink-faint">{s.label}</p>
                </div>
              </div>
            ))}
          </Card>
        </Reveal>
      </section>

      {/* ══════════════════════ HOW IT WORKS ══════════════════════ */}
      <section className="container-x py-16 lg:py-24">
        <SectionTitle title="چطور شروع می‌کنی؟" subtitle="سه قدم تا اولین مکالمه واقعی." />
        <StaggerGroup className="grid gap-5 md:grid-cols-3">
          {[
            { icon: Target, title: 'زبان و هدفت را انتخاب کن', body: 'در ثبت‌نام کوتاه، زبان و هدف یادگیری‌ات را مشخص می‌کنی؛ مسیر از همان‌جا چیده می‌شود.' },
            { icon: BookOpenCheck, title: 'درس‌ها را کامل کن', body: 'هر درس ۱۲ بخش دارد: از گرم‌کردن و واژگان تا دیالوگ، آزمون و تمرین با AI.' },
            { icon: Trophy, title: 'هر روز ادامه بده', body: 'پیشرفتت ذخیره می‌شود و همیشه می‌دانی قدم بعدی‌ات کدام است.' },
          ].map((s, i) => (
            <motion.div key={s.title} variants={staggerItem}>
              <Card className="relative h-full hover-lift">
                <span className="absolute left-5 top-5 text-5xl font-extrabold text-line">{faNum(i + 1)}</span>
                <span className="grid size-12 place-items-center rounded-2xl bg-brand-grad text-white"><s.icon className="size-5" /></span>
                <h3 className="mt-4 text-lg font-extrabold">{s.title}</h3>
                <p className="mt-2 text-[13px] leading-7 text-ink-muted">{s.body}</p>
              </Card>
            </motion.div>
          ))}
        </StaggerGroup>
      </section>

      {/* ══════════════════════ LESSON ANATOMY ══════════════════════ */}
      <section className="container-x pb-16 lg:pb-24">
        <SectionTitle title="هر درس، یک مسیر کامل یادگیری" subtitle="ساختار ثابت و حرفه‌ای؛ هیچ بخشی تزئینی نیست." />
        <StaggerGroup className="grid gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {LESSON_SECTIONS.map((s) => {
            const Icon = SECTION_ICONS[s.icon] ?? BookOpenCheck
            return (
              <motion.div key={s.key} variants={staggerItem}>
                <Card className="h-full hover-lift">
                  <span className="grid size-11 place-items-center rounded-2xl bg-brand-soft text-primary-soft"><Icon className="size-5" /></span>
                  <h3 className="mt-4 text-sm font-extrabold">{s.title_fa}</h3>
                  <p className="mt-1.5 text-[11px] leading-6 text-ink-faint">{SECTION_BLURB[s.key]}</p>
                </Card>
              </motion.div>
            )
          })}
        </StaggerGroup>
      </section>

      {/* ══════════════════════ LANGUAGES ══════════════════════ */}
      <section className="container-x pb-16 lg:pb-24">
        <SectionTitle title="سه زبان، یک تجربه" subtitle="هر زبان مسیر مستقل و سطح‌بندی‌شده دارد: A1 تا C1."
          actions={<Link to="/languages"><Button variant="ghost" size="sm">جزئیات زبان‌ها <ArrowLeft className="size-3.5" /></Button></Link>} />
        <StaggerGroup className="grid gap-5 md:grid-cols-3">
          {languages.map((l) => (
            <motion.div key={l.code} variants={staggerItem}>
              <Card className="group relative h-full overflow-hidden hover-lift !p-0">
                <div className="relative h-36 overflow-hidden">
                  <img src={mediaOf(media, `lang_${l.code}`).url} alt={l.name_fa} loading="lazy" decoding="async"
                    className="size-full object-cover transition-transform duration-700 group-hover:scale-105" />
                  <div className={`absolute inset-0 bg-gradient-to-t ${l.gradient} opacity-45 mix-blend-multiply`} />
                  <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-4">
                    <span className="text-4xl drop-shadow">{l.flag}</span>
                    <Chip className="!border-white/25 !bg-white/15 !text-white !backdrop-blur-md">۲ درس رایگان</Chip>
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="text-xl font-extrabold">{l.name_fa}</h3>
                  <p className="ltr mt-1 text-xs text-ink-faint">{l.native_name}</p>
                  <p className="mt-4 min-h-[72px] text-[13px] leading-7 text-ink-muted">{l.description}</p>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center justify-between text-[11px] font-bold text-ink-faint">
                      <span>مسیر کامل</span><span>{faNum(l.target_lessons)} درس</span>
                    </div>
                    <Progress value={6} />
                  </div>
                  <Link to={session ? '/app/lessons' : '/signup'} className="mt-5 block">
                    <Button variant="outline" className="w-full">شروع {l.name_fa} <ArrowLeft className="size-3.5" /></Button>
                  </Link>
                </div>
              </Card>
            </motion.div>
          ))}
        </StaggerGroup>
      </section>

      {/* ══════════════════════ AI ══════════════════════ */}
      <section className="container-x pb-16 lg:pb-24">
        <SectionTitle title="هوش مصنوعی، در خدمت یادگیری" subtitle="دو دستیار متفاوت: یکی توضیح می‌دهد، یکی هم‌صحبت می‌شود." />
        <div className="grid gap-5 lg:grid-cols-2">
          <Reveal>
            <Card className="group relative h-full overflow-hidden !p-0 hover-lift">
              <div className="relative h-44 overflow-hidden">
                <img src={mediaOf(media, 'ai_tutor').url} alt="" loading="lazy" decoding="async"
                  className="size-full object-cover transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />
              </div>
              <div className="p-7 pt-0">
                <Chip tone="primary"><GraduationCap className="size-3" /> AI Tutor</Chip>
                <h3 className="mt-4 text-2xl font-extrabold">هر جا گیر کردی، بپرس</h3>
                <p className="mt-3 text-sm leading-7 text-ink-muted">
                  «هر چیزی که در یادگیری برایت مبهم است بپرس.» Tutor همان بخشی را که در آن هستی ساده می‌کند، برای قواعد مثال تازه می‌سازد و تمرین اضافه می‌دهد.
                </p>
                <ul className="mt-5 grid gap-2.5 text-sm sm:grid-cols-2">
                  {['توضیح ساده‌تر هر بخش', 'ساخت مثال تازه برای قواعد', 'تمرین اضافه برای تقویت', 'گفت‌وگو بر اساس درس جاری'].map((t) => (
                    <li key={t} className="flex items-center gap-2 text-ink-muted"><CheckCircle2 className="size-4 shrink-0 text-success" /> {t}</li>
                  ))}
                </ul>
              </div>
            </Card>
          </Reveal>

          <Reveal delay={0.08}>
            <Card className="group relative h-full overflow-hidden !p-0 hover-lift">
              <div className="relative h-44 overflow-hidden">
                <img src={mediaOf(media, 'conversation').url} alt="" loading="lazy" decoding="async"
                  className="size-full object-cover transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />
              </div>
              <div className="p-7 pt-0">
                <Chip tone="primary"><MessagesSquare className="size-3" /> Conversation Partner</Chip>
                <h3 className="mt-4 text-2xl font-extrabold">در موقعیت‌های واقعی تمرین کن</h3>
                <p className="mt-3 text-sm leading-7 text-ink-muted">
                  «در موقعیت‌های واقعی تمرین کن.» نقش انتخاب کن — کافه، فرودگاه، رستوران، خرید، مصاحبه کاری، مدرسه، سفر، آشنایی و زندگی روزمره — و مکالمه را ادامه بده.
                </p>
                <div className="mt-5 flex flex-wrap gap-2">
                  {['☕ کافه', '✈️ فرودگاه', '💼 مصاحبه کاری', '🛍️ خرید', '🍽️ رستوران', '💬 روزمره'].map((s) => (
                    <Chip key={s} className="!bg-card-soft/80 !text-ink">{s}</Chip>
                  ))}
                </div>
                <p className="mt-5 rounded-2xl border border-line/70 bg-bg-soft/60 p-4 text-[12px] leading-7 text-ink-muted">
                  در نسخه رایگان <b className="text-ink">۲ پیام</b> برای همیشه — بعد از آن با اشتراک، بدون محدودیت مکالمه می‌کنی.
                </p>
              </div>
            </Card>
          </Reveal>
        </div>
      </section>

      {/* ══════════════════════ FREE vs PREMIUM ══════════════════════ */}
      <section className="container-x pb-16 lg:pb-24">
        <SectionTitle title="رایگان، برای همیشه رایگان" subtitle="بدون دوره آزمایشی و بدون محدودیت زمانی. حساب رایگان هیچ‌وقت منقضی نمی‌شود." />
        <StaggerGroup className="grid gap-5 lg:grid-cols-2">
          <motion.div variants={staggerItem}>
            <Card className="h-full">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-extrabold">حساب رایگان</h3>
                <Chip>همیشه فعال</Chip>
              </div>
              <p className="mt-2 text-sm text-ink-muted">شروع بدون هیچ هزینه‌ای، با محتوای کامل و باکیفیت.</p>
              <ul className="mt-5 space-y-3 text-sm">
                {['۲ درس کامل رایگان در انگلیسی', '۲ درس کامل رایگان در فرانسه', '۲ درس کامل رایگان در اسپانیایی', '۲ پیام Conversation Partner', 'ثبت پیشرفت درس‌های رایگان'].map((t) => (
                  <li key={t} className="flex items-start gap-2 text-ink-muted"><CheckCircle2 className="mt-0.5 size-4 shrink-0 text-success" /> {t}</li>
                ))}
              </ul>
              <Link to={session ? '/app' : '/signup'} className="mt-6 block"><Button variant="outline" className="w-full">شروع رایگان</Button></Link>
            </Card>
          </motion.div>

          <motion.div variants={staggerItem}>
            <Card className="relative h-full overflow-hidden border-primary/40 !p-6">
              <div className="absolute inset-0 bg-brand-soft opacity-40" />
              <div className="relative">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-extrabold">اشتراک Premium</h3>
                  <Chip tone="warn"><BadgeCheck className="size-3" /> دسترسی کامل</Chip>
                </div>
                <p className="mt-2 text-sm text-ink-muted">برای وقتی می‌خواهی جدی جلو بروی.</p>
                <ul className="mt-5 space-y-3 text-sm">
                  {['همه درس‌های منتشرشده در سه زبان', 'AI Tutor برای هر درس', 'Conversation Partner بدون محدودیت پیام', 'پیگیری کامل پیشرفت', 'دسترسی به درس‌های جدید'].map((t) => (
                    <li key={t} className="flex items-start gap-2 text-ink-muted"><Star className="mt-0.5 size-4 shrink-0 text-warn" /> {t}</li>
                  ))}
                </ul>
                {showPricing && promoPlan && (
                  <div className="mt-5 rounded-3xl border border-warn/35 bg-warn/8 p-4">
                    <Chip tone="warn" className="!px-2 !py-0.5 !text-[10px]"><Sparkles className="size-3" /> {promoPlan.promo_label ?? 'پیشنهاد ویژه'}</Chip>
                    <p className="mt-3 flex items-end gap-2 text-2xl font-extrabold">
                      {faNum(promoPlan.promo_price!)} <span className="text-[11px] font-bold text-ink-faint">تومان</span>
                      <span className="text-[12px] font-bold text-ink-faint line-through">{faNum(promoPlan.original_price)}</span>
                    </p>
                    <p className="mt-1 text-[10.5px] text-ink-faint">{promoPlan.title_fa} · {faNum(promoPlan.duration_days)} روز دسترسی کامل</p>
                  </div>
                )}
                <Link to={session ? '/app/subscription' : '/signup'} className="mt-6 block">
                  <Button className="w-full">{showPricing ? 'دیدن پلن‌ها و قیمت‌ها' : 'دیدن پلن‌ها'}</Button>
                </Link>
              </div>
            </Card>
          </motion.div>
        </StaggerGroup>
      </section>

      {/* ══════════════════════ TESTIMONIALS (real only) ══════════════════════ */}
      {testimonials.length > 0 && (
        <section className="container-x pb-16 lg:pb-24">
          <SectionTitle title="زبان‌آموزان LINGU چه می‌گویند" />
          <StaggerGroup className="grid gap-5 md:grid-cols-3">
            {testimonials.map((t) => (
              <motion.div key={t.id} variants={staggerItem}>
                <Card className="h-full hover-lift">
                  <div className="flex gap-0.5">{Array.from({ length: t.rating }).map((_, k) => <Star key={k} className="size-3.5 fill-warn text-warn" />)}</div>
                  <p className="mt-4 text-[13px] leading-7 text-ink-muted">«{t.quote}»</p>
                  <div className="mt-5 flex items-center gap-3">
                    {t.avatar_url
                      ? <img src={t.avatar_url} alt={t.name} className="size-9 rounded-2xl object-cover" />
                      : <span className="grid size-9 place-items-center rounded-2xl bg-brand-soft text-xs font-extrabold text-primary-soft">{t.name.slice(0, 2)}</span>}
                    <div><p className="text-xs font-extrabold">{t.name}</p>{t.role && <p className="text-[10px] text-ink-faint">{t.role}</p>}</div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </StaggerGroup>
        </section>
      )}

      {/* ══════════════════════ FAQ (real only) ══════════════════════ */}
      {faqs.length > 0 && (
        <section className="container-x pb-16 lg:pb-24">
          <SectionTitle title="سؤالات پرتکرار" actions={<Link to="/faq"><Button variant="ghost" size="sm">همه سؤالات <ArrowLeft className="size-3.5" /></Button></Link>} />
          <StaggerGroup className="grid gap-4 md:grid-cols-2">
            {faqs.map((f) => (
              <motion.div key={f.id} variants={staggerItem}>
                <Card className="h-full">
                  <h3 className="flex items-start gap-2 text-sm font-extrabold"><Quote className="mt-0.5 size-4 shrink-0 text-primary-soft" /> {f.question}</h3>
                  <p className="mt-2.5 text-[13px] leading-7 text-ink-muted">{f.answer}</p>
                </Card>
              </motion.div>
            ))}
          </StaggerGroup>
        </section>
      )}

      {/* ══════════════════════ FINAL CTA ══════════════════════ */}
      <section className="container-x pb-20">
        <Reveal>
          <Card className="relative overflow-hidden !rounded-4xl p-8 text-center lg:p-14">
            <div className="absolute inset-0 bg-mesh opacity-80" />
            <div className="relative mx-auto max-w-2xl">
              <span className="mx-auto grid size-14 place-items-center rounded-3xl bg-brand-grad text-white shadow-glow"><Sparkles className="size-6" /></span>
              <h2 className="mt-6 text-3xl font-extrabold sm:text-4xl">امروز اولین درس را شروع کن</h2>
              <p className="mx-auto mt-4 max-w-lg text-sm leading-8 text-ink-muted">
                ثبت‌نام کمتر از یک دقیقه طول می‌کشد. ۲ درس کامل در هر زبان، برای همیشه رایگان — بدون کارت بانکی.
              </p>
              <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
                <Link to={session ? '/app' : '/signup'}><Button size="lg"><Play className="size-4" /> {session ? 'ادامه یادگیری' : 'شروع رایگان'}</Button></Link>
                <Link to="/languages"><Button size="lg" variant="outline">دیدن زبان‌ها</Button></Link>
              </div>
            </div>
          </Card>
        </Reveal>
      </section>
    </div>
  )
}
