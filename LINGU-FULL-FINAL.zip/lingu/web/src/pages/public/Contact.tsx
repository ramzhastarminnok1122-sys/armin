import { Mail, MessageSquareHeart, ShieldQuestion } from 'lucide-react'
import { Card, Chip, SectionTitle } from '@/components/ui'
import { useApp } from '@/context/AppContext'

export default function Contact() {
  const { settings } = useApp()
  const email = settings.general?.support_email || 'support@lingu.app'
  return (
    <div className="container-x py-12 lg:py-20">
      <div className="mx-auto max-w-3xl text-center">
        <Chip tone="primary"><MessageSquareHeart className="size-3" /> تماس با ما</Chip>
        <h1 className="mt-5 text-3xl sm:text-4xl">در خدمتیم</h1>
        <p className="mt-5 text-sm leading-8 text-ink-muted">
          برای سؤال درباره محتوا، اشتراک یا گزارش مشکل با ما تماس بگیر. برای سؤال‌های آموزشی، سریع‌ترین راه AI Tutor داخل برنامه است.
        </p>
      </div>
      <div className="mx-auto mt-10 grid max-w-3xl gap-5 sm:grid-cols-2">
        <Card>
          <SectionTitle title="پشتیبانی" subtitle="پاسخ در اولین فرصت کاری." />
          <a href={`mailto:${email}`} className="inline-flex items-center gap-2 text-sm font-bold text-primary-soft hover:underline">
            <Mail className="size-4" /> <span className="ltr">{email}</span>
          </a>
        </Card>
        <Card>
          <SectionTitle title="حریم خصوصی و امنیت" subtitle="اطلاعات تو محافظت‌شده و قابل کنترل است." />
          <p className="flex items-center gap-2 text-xs leading-6 text-ink-muted">
            <ShieldQuestion className="size-4 shrink-0 text-primary-soft" />
            اطلاعات حساب تو فقط برای ارائه سرویس استفاده می‌شود؛ هیچ داده‌ای فروخته نمی‌شود و وضعیت اشتراک همیشه از سرور تأیید می‌گردد.
          </p>
        </Card>
      </div>
    </div>
  )
}
