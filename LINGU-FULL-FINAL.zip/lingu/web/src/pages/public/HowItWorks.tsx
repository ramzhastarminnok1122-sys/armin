import { motion } from 'motion/react'
import { Link } from 'react-router-dom'
import { BookOpenCheck, CheckCircle2, Crown, GraduationCap, MessagesSquare, Play, Route, Sparkles, UserPlus } from 'lucide-react'
import { Button, Card, Chip, SectionTitle } from '@/components/ui'
import { useApp } from '@/context/AppContext'

const STEPS = [
  { icon: UserPlus, title: 'ثبت‌نام در یک دقیقه', body: 'با ایمیل و گذرواژه ثبت‌نام می‌کنی؛ زبان و سطح تقریبی‌ات را انتخاب می‌کنی. حساب رایگان برای همیشه فعال می‌ماند.' },
  { icon: BookOpenCheck, title: 'درس را بخش‌به‌بخش پیش می‌روی', body: 'هر درس ۱۲ بخش دارد. هر بخش را که تمام کنی، پیشرفتت ذخیره می‌شود و می‌توانی هر زمان ادامه بدهی.' },
  { icon: GraduationCap, title: 'هر جا سؤال داشتی، بپرس', body: 'AI Tutor همان درس را ساده‌تر توضیح می‌دهد، مثال می‌سازد و تمرین اضافه می‌دهد — دقیقاً برای بخشی که در آن هستی.' },
  { icon: MessagesSquare, title: 'مکالمه واقعی تمرین کن', body: 'در Conversation Partner یک نقش انتخاب می‌کنی و مکالمه را زنده نگه می‌داری؛ مثل یک تمرین واقعی قبل از موقعیت واقعی.' },
  { icon: Route, title: 'پیشرفتت را ببین', body: 'درصد تکمیل، درس‌های تمام‌شده و زمان یادگیری در صفحه پیشرفت ثبت می‌شود تا بدانی کجای مسیر هستی.' },
]

export default function HowItWorks() {
  const { session } = useApp()
  return (
    <div className="container-x py-12 lg:py-20">
      <div className="mx-auto max-w-3xl text-center">
        <Chip tone="primary"><Sparkles className="size-3" /> چگونه کار می‌کند</Chip>
        <h1 className="mt-5 text-3xl sm:text-4xl lg:text-5xl">از ثبت‌نام تا اولین مکالمه</h1>
        <p className="mt-5 text-sm leading-8 text-ink-muted sm:text-base">روند LINGU ساده و قابل ادامه است: یاد بگیر، تمرین کن، بپرس، مکالمه کن — و پیشرفتت را ببین.</p>
      </div>

      <div className="relative mt-14 space-y-5">
        <div className="absolute bottom-6 right-[26px] top-6 hidden w-px bg-line/80 sm:block" />
        {STEPS.map((s, i) => (
          <motion.div key={s.title} initial={{ opacity: 0, x: 26 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: i * 0.06 }}
            className="relative flex gap-5">
            <span className="relative z-10 hidden size-13 shrink-0 place-items-center rounded-2xl bg-brand-grad text-white shadow-glow sm:grid" style={{ width: 53, height: 53 }}>
              <s.icon className="size-5" />
            </span>
            <Card className="flex-1 hover-lift">
              <div className="flex items-center gap-3">
                <span className="grid size-9 place-items-center rounded-xl bg-brand-soft text-primary-soft sm:hidden"><s.icon className="size-4" /></span>
                <Chip className="!px-2 !py-0.5 !text-[10px]">قدم {['۱', '۲', '۳', '۴', '۵'][i]}</Chip>
              </div>
              <h2 className="mt-3 text-lg font-extrabold">{s.title}</h2>
              <p className="mt-2 text-[13px] leading-7 text-ink-muted">{s.body}</p>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="mt-14 grid gap-5 lg:grid-cols-2">
        <Card className="!p-7">
          <SectionTitle title="رایگان چه چیزی می‌گیری؟" />
          <ul className="space-y-3 text-sm">
            {['۲ درس کامل در English', '۲ درس کامل در French', '۲ درس کامل در Spanish', '۲ پیام Conversation Partner (برای همیشه)', 'ثبت پیشرفت درس‌های رایگان'].map((t) => (
              <li key={t} className="flex items-start gap-2 text-ink-muted"><CheckCircle2 className="mt-0.5 size-4 shrink-0 text-success" /> {t}</li>
            ))}
          </ul>
          <Link to={session ? '/app/lessons' : '/signup'} className="mt-6 block"><Button className="w-full">شروع رایگان</Button></Link>
        </Card>
        <Card className="!p-7">
          <SectionTitle title="چه زمانی اشتراک بگیرم؟" subtitle="وقتی درس‌های رایگان را تمام کردی و خواستی بی‌وقفه ادامه بدهی." />
          <ul className="space-y-3 text-sm">
            {['همه درس‌های منتشرشده در سه زبان', 'AI Tutor برای همه بخش‌ها', 'Conversation Partner بدون سقف ۲ پیام', 'دسترسی به درس‌های تازه هر هفته'].map((t) => (
              <li key={t} className="flex items-start gap-2 text-ink-muted"><Crown className="mt-0.5 size-4 shrink-0 text-warn" /> {t}</li>
            ))}
          </ul>
          <Link to="/app/subscription" className="mt-6 block"><Button variant="outline" className="w-full">دیدن پلن‌ها</Button></Link>
        </Card>
      </div>

      <Card className="mt-12 flex flex-wrap items-center justify-between gap-5 !p-7">
        <div className="flex items-center gap-4">
          <span className="grid size-12 place-items-center rounded-2xl bg-brand-grad text-white"><Play className="size-5" /></span>
          <div>
            <h3 className="text-lg font-extrabold">آماده‌ای؟ اولین درس ۲ دقیقه بیشتر وقت نمی‌گیرد.</h3>
            <p className="text-xs text-ink-muted">ثبت‌نام رایگان است و کارت بانکی نمی‌خواهد.</p>
          </div>
        </div>
        <Link to={session ? '/app' : '/signup'}><Button size="lg">{session ? 'ادامه یادگیری' : 'ثبت‌نام رایگان'}</Button></Link>
      </Card>
    </div>
  )
}
