import { Link } from 'react-router-dom'
import { Compass, Home } from 'lucide-react'
import { Button, Card } from '@/components/ui'

export default function NotFound() {
  return (
    <div className="container-x flex min-h-[75dvh] items-center justify-center py-12">
      <Card className="max-w-lg text-center !rounded-4xl !p-10">
        <span className="mx-auto grid size-14 place-items-center rounded-3xl bg-brand-soft text-primary-soft"><Compass className="size-7" /></span>
        <h1 className="mt-5 text-4xl font-extrabold">۴۰۴</h1>
        <p className="mt-3 text-sm leading-7 text-ink-muted">این صفحه پیدا نشد. شاید آدرس تغییر کرده باشد.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link to="/"><Button><Home className="size-4" /> صفحه اصلی</Button></Link>
          <Link to="/app"><Button variant="outline">برنامه من</Button></Link>
        </div>
      </Card>
    </div>
  )
}
