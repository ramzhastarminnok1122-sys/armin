import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { supabase, hasBackend } from '@/lib/supabase'

export type ThemeRow = {
  mode: string
  primary: string; secondary: string; accent: string
  background: string; background_soft: string
  card: string; card_soft: string
  text: string; text_muted: string; line: string
  success: string; warning: string; danger: string
  radius: number
}

/** LINGU identity: purple on white/lavender. Dark purple is one stored theme away. */
export const DEFAULT_THEME: ThemeRow = {
  mode: 'light',
  primary: '#6D5BFF', secondary: '#8B5CF6', accent: '#0EA5C6',
  background: '#FAF9FF', background_soft: '#F2EFFF',
  card: '#FFFFFF', card_soft: '#F6F3FF',
  text: '#1A1638', text_muted: '#5C5788', line: '#E7E1FA',
  success: '#15803D', warning: '#B45309', danger: '#DC2626',
  radius: 22,
}

export const THEME_PRESETS: { id: string; name: string; theme: ThemeRow }[] = [
  {
    id: 'lavender', name: 'بنفش روشن (پیش‌فرض)',
    theme: DEFAULT_THEME,
  },
  {
    id: 'violet-deep', name: 'بنفش عمیق (Dark)',
    theme: { mode: 'dark', primary: '#8B7CFF', secondary: '#7C5CFC', accent: '#31D5F0', background: '#0B0A1C', background_soft: '#141130', card: '#171338', card_soft: '#1F1A46', text: '#F5F3FF', text_muted: '#ABA6D6', line: '#2C2755', success: '#4ADE80', warning: '#FBBF24', danger: '#FB7185', radius: 22 },
  },
  {
    id: 'midnight-ai', name: 'شب هوش مصنوعی',
    theme: { mode: 'dark', primary: '#22D3EE', secondary: '#6366F1', accent: '#A78BFA', background: '#070B18', background_soft: '#0D1428', card: '#111A33', card_soft: '#16213F', text: '#EAF2FF', text_muted: '#9FB0D0', line: '#22304F', success: '#34D399', warning: '#FBBF24', danger: '#F87171', radius: 18 },
  },
  {
    id: 'soft-lilac', name: 'یاسی ملایم',
    theme: { mode: 'light', primary: '#7C5CFC', secondary: '#B18CFF', accent: '#2BB3C0', background: '#FCFBFF', background_soft: '#F6F2FF', card: '#FFFFFF', card_soft: '#F4EFFF', text: '#241E4A', text_muted: '#6C6693', line: '#EBE4FB', success: '#15803D', warning: '#B45309', danger: '#DC2626', radius: 26 },
  },
]

/** Blends two "r g b" strings — used to derive readable secondary tokens from the DB theme. */
const mix = (a: string, b: string, t: number) => {
  const A = a.split(/\s+/).map(Number), B = b.split(/\s+/).map(Number)
  return A.map((v, i) => Math.round(v + (B[i] - v) * t)).join(' ')
}

const hexToRgb = (hex: string) => {
  const h = hex.replace('#', '').trim()
  const full = h.length === 3 ? h.split('').map((c) => c + c).join('') : h
  const n = parseInt(full || '000000', 16)
  return `${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255}`
}

export function applyThemeVars(t: ThemeRow) {
  const r = document.documentElement.style
  r.setProperty('--c-primary', hexToRgb(t.primary))
  r.setProperty('--c-primary-soft', hexToRgb(t.primary))
  r.setProperty('--c-secondary', hexToRgb(t.secondary))
  r.setProperty('--c-accent', hexToRgb(t.accent))
  r.setProperty('--c-bg', hexToRgb(t.background))
  r.setProperty('--c-bg-soft', hexToRgb(t.background_soft))
  r.setProperty('--c-card', hexToRgb(t.card))
  r.setProperty('--c-card-soft', hexToRgb(t.card_soft))
  r.setProperty('--c-text', hexToRgb(t.text))
  r.setProperty('--c-text-muted', hexToRgb(t.text_muted))
  r.setProperty('--c-text-faint', hexToRgb(t.text_muted))
  r.setProperty('--c-line', hexToRgb(t.line))
  r.setProperty('--c-text-faint', mix(hexToRgb(t.text_muted), hexToRgb(t.line), 0.45))
  r.setProperty('--c-success', hexToRgb(t.success ?? DEFAULT_THEME.success))
  r.setProperty('--c-warning', hexToRgb(t.warning ?? DEFAULT_THEME.warning))
  r.setProperty('--c-danger', hexToRgb(t.danger ?? DEFAULT_THEME.danger))
  r.setProperty('--radius', `${t.radius}px`)
  document.documentElement.setAttribute('data-mode', t.mode || 'light')
  const meta = document.querySelector('meta[name="theme-color"]')
  if (meta) meta.setAttribute('content', t.background)
}

type ThemeCtx = { theme: ThemeRow; setTheme: (t: ThemeRow) => void; reload: () => Promise<void> }
const Ctx = createContext<ThemeCtx>({ theme: DEFAULT_THEME, setTheme: () => {}, reload: async () => {} })

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<ThemeRow>(DEFAULT_THEME)

  const setTheme = (t: ThemeRow) => { setThemeState(t); applyThemeVars(t) }

  const reload = async () => {
    if (!hasBackend) return // design preview: bundled identity only, no network
    const { data } = await supabase.rpc('theme_public')
    if (data) setTheme({ ...DEFAULT_THEME, ...(data as Partial<ThemeRow>) })
  }

  // instant first paint with defaults, then real values from DB
  useEffect(() => {
    applyThemeVars(DEFAULT_THEME)
    reload()
    if (!hasBackend) return
    // live updates: if an admin changes the theme, every open site repaints with no redeploy
    const channel = supabase
      .channel('theme-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'theme_settings' }, (p) => {
        const row = p.new as Partial<ThemeRow>
        if (row?.primary) setTheme({ ...DEFAULT_THEME, ...row } as ThemeRow)
      })
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [])

  const value = useMemo(() => ({ theme, setTheme, reload }), [theme])
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}
export const useTheme = () => useContext(Ctx)
