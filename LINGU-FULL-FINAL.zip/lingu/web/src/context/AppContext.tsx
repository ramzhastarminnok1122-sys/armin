import {
  createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode,
} from 'react'
import { supabase } from '@/lib/supabase'
import { getApi, backendConfigured, type LanguApi } from '@/services/api'
import { buildMediaMap, type MediaMap } from '@/lib/assets'
import type { AiQuota, AppNotification, Language, Membership, Plan, Profile, SearchHit } from '@/services/types'

type Toast = { id: number; kind: 'success' | 'error' | 'info'; text: string }

/** Design-preview session marker (dev runs only — a production build never enters demo mode). */
const PREVIEW_KEY = 'lingu.preview.session'

type AppState = {
  ready: boolean
  api: LanguApi | null
  backendReady: boolean
  languages: Language[]
  plans: Plan[]
  settings: Record<string, any>
  session: { userId: string; email: string | null } | null
  profile: Profile | null
  membership: Membership
  quota: AiQuota | null
  isAdmin: boolean
  media: MediaMap
  notifications: AppNotification[]
  unreadCount: number
  refreshMedia: () => Promise<void>
  refreshNotifications: () => Promise<void>
  markAllRead: () => Promise<void>
  search: (q: string) => Promise<SearchHit[]>
  completeOnboarding: (data: { target_language: string; goal: string; level?: string }) => Promise<void>
  toasts: Toast[]
  toast: (text: string, kind?: Toast['kind']) => void
  dismissToast: (id: number) => void
  refreshProfile: () => Promise<void>
  refreshMembership: () => Promise<void>
  refreshQuota: () => Promise<void>
  refreshCatalogData: () => Promise<void>
  signIn: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string, name: string) => Promise<{ needsConfirm: boolean }>
  signOut: () => Promise<void>
  startPreview: () => void
  resetPassword: (email: string) => Promise<void>
  updatePassword: (password: string) => Promise<void>
  finishTour: () => Promise<void>
  setTour: (done: boolean) => Promise<void>
  tourReplay: boolean
  startTourReplay: () => void
  stopTourReplay: () => void
}

const Ctx = createContext<AppState | null>(null)

export function AppProvider({ children }: { children: ReactNode }) {
  const [api, setApi] = useState<LanguApi | null>(null)
  const [ready, setReady] = useState(false)
  const [languages, setLanguages] = useState<Language[]>([])
  const [plans, setPlans] = useState<Plan[]>([])
  const [settings, setSettings] = useState<Record<string, any>>({})
  const [session, setSession] = useState<{ userId: string; email: string | null } | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [membership, setMembership] = useState<Membership>({ premium: false, subscription: null, plan: null, days_left: null })
  const [quota, setQuota] = useState<AiQuota | null>(null)
  const [media, setMedia] = useState<MediaMap>(buildMediaMap([]))
  const [notifications, setNotifications] = useState<AppNotification[]>([])
  const [tourReplay, setTourReplay] = useState(false)
  const refreshProfileRef = useRef<null | (() => Promise<void>)>(null)
  const [toasts, setToasts] = useState<Toast[]>([])
  const toastSeq = useRef(1)

  const toast = useCallback((text: string, kind: Toast['kind'] = 'info') => {
    const id = toastSeq.current++
    setToasts((t) => [...t, { id, kind, text }])
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 5200)
  }, [])
  const dismissToast = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), [])

  const loadBootstrap = useCallback(async (instance: LanguApi) => {
    try {
      const { languages: langs, plans: pl, settings: st } = await instance.bootstrap()
      setLanguages(langs)
      setPlans(pl)
      setSettings(st)
    } catch (e) {
      console.error('[LINGU] bootstrap failed', e)
    }
  }, [])

  const refreshMedia = useCallback(async () => {
    if (!api) return
    try { setMedia(buildMediaMap(await api.media())) } catch (e) { console.error('[LINGU] media', e) }
  }, [api])

  const refreshNotifications = useCallback(async () => {
    if (!api || !session) { setNotifications([]); return }
    try { setNotifications(await api.notifications(30)) } catch (e) { console.error('[LINGU] notifications', e) }
  }, [api, session])

  const markAllRead = useCallback(async () => {
    if (!api) return
    try {
      await api.markNotificationsRead()
      setNotifications((list) => list.map((n) => (n.read_at ? n : { ...n, read_at: new Date().toISOString() })))
    } catch (e) { console.error(e) }
  }, [api])

  const search = useCallback(async (q: string) => (api ? api.search(q) : []), [api])

  const completeOnboarding = useCallback(async (data: { target_language: string; goal: string; level?: string }) => {
    if (!api) return
    await api.updateProfile({
      target_language: data.target_language, goal: data.goal,
      preferred_level: data.level ?? 'A1', onboarding_done: true,
    } as any)
    await refreshProfileRef.current?.()
  }, [api])

  const refreshProfile = useCallback(async () => {
    if (!api) return
    try { setProfile(await api.profile()) } catch (e) { console.error(e) }
  }, [api])

  refreshProfileRef.current = refreshProfile

  const refreshMembership = useCallback(async () => {
    if (!api) return
    try { setMembership(await api.membership()) } catch (e) { console.error(e) }
  }, [api])

  const refreshQuota = useCallback(async () => {
    if (!api) return
    try { setQuota(await api.aiQuota()) } catch (e) { console.error(e) }
  }, [api])

  const refreshCatalogData = useCallback(async () => {
    if (!api) return
    await Promise.all([loadBootstrap(api), refreshProfile(), refreshMembership(), refreshQuota(), refreshMedia()])
  }, [api, loadBootstrap, refreshProfile, refreshMembership, refreshQuota, refreshMedia])

  // boot
  useEffect(() => {
    let alive = true
    ;(async () => {
      const instance = await getApi()
      if (!alive) return
      setApi(instance)
      // Catalogue, plans and theme media load in the background: the first paint must
      // never wait for the network. A slow or unreachable server shows the app with
      // honest empty states instead of a frozen splash screen.
      void loadBootstrap(instance)
      void instance.media().then((rows) => { if (alive) setMedia(buildMediaMap(rows)) }).catch(() => {})
      // A missing/unreachable server must never freeze the app on its splash screen:
      // after a short grace period we continue as an anonymous visitor, and any later
      // action reports a friendly connection error.
      const { data } = await Promise.race([
        supabase.auth.getSession(),
        new Promise<{ data: { session: null } }>((resolve) => window.setTimeout(() => resolve({ data: { session: null } }), 6000)),
      ])
      if (!alive) return
      // The design preview starts exactly like the real product: anonymous.
      // A reviewer can step into the app from the login page, and even then it is a
      // brand-new account (no name, no onboarding, no progress) — never a fake "ready" user.
      // Like the real product, that session survives a refresh (otherwise direct URLs
      // and the reload path could not be reviewed at all).
      const remembered = instance.mode === 'demo' && localStorage.getItem(PREVIEW_KEY) === '1'
      setSession(
        data.session ? { userId: data.session.user.id, email: data.session.user.email ?? null }
          : remembered ? { userId: 'demo-user', email: null } : null,
      )
      setReady(true)
      return
    })()
    return () => { alive = false }
  }, [loadBootstrap])

  // auth state
  useEffect(() => {
    if (!api) return
    const { data: sub } = supabase.auth.onAuthStateChange((evt, s) => {
      if (s) { setSession({ userId: s.user.id, email: s.user.email ?? null }); return }
      // In design-preview mode Supabase emits INITIAL_SESSION with null on every page load;
      // that must not kick the reviewer out of the app shell.
      if (api.mode === 'demo' && evt !== 'SIGNED_OUT') return
      setSession(null)
    })
    return () => sub.subscription.unsubscribe()
  }, [api])

  // load user data whenever the session changes
  useEffect(() => {
    if (!api) return
    if (!session) { setProfile(null); setMembership({ premium: false, subscription: null, plan: null, days_left: null }); setQuota(null); return }
    ;(async () => {
      await refreshProfile()
      await refreshMembership()
      await refreshQuota()
      await refreshNotifications()
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        const { data } = await supabase.from('profiles').select('is_active').eq('id', user.id).maybeSingle()
        if (data && data.is_active === false) {
          await supabase.auth.signOut()
          toast('حساب شما توسط مدیر غیرفعال شده است.', 'error')
        }
      }
    })()
  }, [api, session, refreshProfile, refreshMembership, refreshQuota, refreshNotifications, toast])

  useEffect(() => {
    if (!api || !session) return
    const key = `lingu_seen_${session.userId}`
    const last = Number(sessionStorage.getItem(key) ?? 0)
    if (Date.now() - last > 5 * 60 * 1000) {
      api.touchLastSeen().then(() => sessionStorage.setItem(key, String(Date.now()))).catch(() => {})
    }
  }, [api, session])

  const signIn = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) throw new Error(translateAuth(error.message))
  }, [])

  const signUp = useCallback(async (email: string, password: string, name: string) => {
    const { data, error } = await supabase.auth.signUp({
      email, password, options: { data: { display_name: name } },
    })
    if (error) throw new Error(translateAuth(error.message))
    return { needsConfirm: !data.session }
  }, [])

  const signOut = useCallback(async () => {
    // preview build: the session is local, so leaving the app is local too
    if (api?.mode === 'demo') {
      localStorage.removeItem(PREVIEW_KEY)
      setSession(null); setProfile(null); setQuota(null)
      setMembership({ premium: false, subscription: null, plan: null, days_left: null })
      return
    }
    await supabase.auth.signOut()
  }, [api])

  /** Design preview only (never present in a production build): step into the app as a fresh account. */
  const startPreview = useCallback(() => {
    if (api?.mode !== 'demo') return
    localStorage.setItem(PREVIEW_KEY, '1')
    setSession({ userId: 'demo-user', email: null })
  }, [api])

  const resetPassword = useCallback(async (email: string) => {
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${location.origin}/reset-password` })
    if (error) throw new Error(translateAuth(error.message))
  }, [])

  const updatePassword = useCallback(async (password: string) => {
    const { error } = await supabase.auth.updateUser({ password })
    if (error) throw new Error(translateAuth(error.message))
  }, [])

  const setTour = useCallback(async (done: boolean) => {
    if (!api) return
    try { await api.updateProfile({ tour_done: done }); await refreshProfile() } catch { /* ignore */ }
  }, [api, refreshProfile])

  const startTourReplay = useCallback(() => setTourReplay(true), [])
  const stopTourReplay = useCallback(() => setTourReplay(false), [])

  const finishTour = useCallback(async () => {
    if (!api) return
    try { await api.updateProfile({ tour_done: true }); await refreshProfile() }
    catch (e) { console.error(e) }
  }, [api, refreshProfile])

  const value = useMemo<AppState>(() => ({
    ready, api, backendReady: backendConfigured,
    languages, plans, settings,
    session, profile, membership, quota,
    isAdmin: profile?.role === 'admin',
    media, notifications, unreadCount: notifications.filter((n) => !n.read_at).length,
    refreshMedia, refreshNotifications, markAllRead, search, completeOnboarding,
    toasts, toast, dismissToast,
    refreshProfile, refreshMembership, refreshQuota, refreshCatalogData,
    signIn, signUp, signOut, startPreview, resetPassword, updatePassword, finishTour, setTour,
    tourReplay, startTourReplay, stopTourReplay,
  }), [ready, api, languages, plans, settings, session, profile, membership, quota, media, notifications,
       toasts, toast, dismissToast, refreshProfile, refreshMembership, refreshQuota, refreshCatalogData,
       refreshMedia, refreshNotifications, markAllRead, search, completeOnboarding,
       signIn, signUp, signOut, startPreview, resetPassword, updatePassword, finishTour, setTour,
       tourReplay, startTourReplay, stopTourReplay])

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

function translateAuth(msg: string) {
  const m = msg.toLowerCase()
  if (m.includes('failed to fetch') || m.includes('networkerror') || m.includes('network request failed')
      || m.includes('err_name_not_resolved') || m.includes('timeout') || m.includes('timed out'))
    return 'ارتباط برقرار نشد. اتصال اینترنت را بررسی کن و دوباره تلاش کن.'
  if (m.includes('not_authenticated')) return 'برای این کار باید وارد حساب خودت شوی.'
  if (m.includes('permission denied') || m.includes('row-level security')) return 'این عملیات برای حساب تو مجاز نیست.'
  if (m.includes('invalid login')) return 'ایمیل یا گذرواژه اشتباه است.'
  if (m.includes('already registered') || m.includes('already exists')) return 'این ایمیل قبلاً ثبت شده است. وارد شوید.'
  if (m.includes('password should be')) return 'گذرواژه باید حداقل ۶ کاراکتر باشد.'
  if (m.includes('unable to validate email')) return 'ایمیل معتبر نیست.'
  if (m.includes('email not confirmed')) return 'ایمیل شما هنوز تأیید نشده است. صندوق ایمیل را بررسی کنید.'
  if (m.includes('rate limit') || m.includes('too many')) return 'تلاش‌های زیاد. کمی بعد دوباره امتحان کنید.'
  // last resort: never surface a raw English server message to a Persian user
  return /[\u0600-\u06FF]/.test(msg) ? msg : 'عملیات انجام نشد. کمی بعد دوباره تلاش کن.'
}

export function useApp() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('useApp must be used inside AppProvider')
  return ctx
}
