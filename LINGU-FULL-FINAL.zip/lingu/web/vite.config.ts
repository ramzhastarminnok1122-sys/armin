import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'node:path'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const isProd = mode === 'production'

  // Safety guard: the design-preview fallback must NEVER exist in a production build.
  if (isProd && env.VITE_DEMO_MODE === 'true') {
    throw new Error('VITE_DEMO_MODE=true is not allowed in production build (LINGU policy: no mock data).')
  }

  return {
    plugins: [react()],
    resolve: { alias: { '@': path.resolve(__dirname, './src') } },
    server: {
      host: '0.0.0.0',
      port: Number(env.PORT || 5173),
      strictPort: false,
      allowedHosts: true,
      hmr: env.VITE_HMR_HTTPS === '1' ? { protocol: 'wss', clientPort: 443 } : undefined,
    },
    preview: { host: '0.0.0.0', port: Number(env.PORT || 4173), allowedHosts: true },
    build: {
      outDir: 'dist',
      sourcemap: false,
      target: 'es2020',
      rollupOptions: {
        output: {
          manualChunks: {
            react: ['react', 'react-dom', 'react-router-dom'],
            supabase: ['@supabase/supabase-js'],
            motion: ['motion'],
            icons: ['lucide-react'],
          },
        },
      },
    },
  }
})
