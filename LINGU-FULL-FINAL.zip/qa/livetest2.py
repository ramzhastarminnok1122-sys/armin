#!/usr/bin/env python3
"""
LINGU · live RLS / Storage verification with two real signed-in users.
Usage: livetest2.py <ref> <publishable-key> <uidA> <mailA> <uidB> <mailB> <password>
"""
import json, urllib.request, urllib.error, sys

REF, KEY, UID_A, MAIL_A, UID_B, MAIL_B, PW = sys.argv[1:8]
BASE = f"https://{REF}.supabase.co"
results = []
def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("✅ " if ok else "❌ ") + name + (f"   [{detail}]" if detail else ""))

def req(method, path, body=None, token=None, headers=None, raw=False, ctype="application/json"):
    data = (body if raw else json.dumps(body).encode()) if body is not None else None
    h = {"apikey": KEY}
    if token: h["Authorization"] = f"Bearer {token}"
    if data is not None: h["Content-Type"] = ctype
    h.update(headers or {})
    r = urllib.request.Request(BASE + path, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            ct = resp.headers.get("Content-Type", "")
            raw = resp.read()
            if "json" in ct:
                return resp.status, json.loads(raw.decode()) if raw else None
            if ct.startswith("text") or ct.startswith("application/xml"):
                return resp.status, raw.decode()
            return resp.status, f"<{len(raw)} bytes {ct}>"
    except urllib.error.HTTPError as e:
        t = e.read().decode()
        try: return e.code, json.loads(t)
        except Exception: return e.code, t

def login(mail):
    st, b = req("POST", "/auth/v1/token?grant_type=password", {"email": mail, "password": PW})
    return (b.get("access_token") if isinstance(b, dict) else None), st, b

tokA, stA, bodyA = login(MAIL_A)
tokB, stB, bodyB = login(MAIL_B)
check("ورود واقعی کاربر A با ایمیل/رمز", bool(tokA), f"HTTP {stA} {json.dumps(bodyA)[:80] if not tokA else ''}")
check("ورود واقعی کاربر B با ایمیل/رمز", bool(tokB), f"HTTP {stB}")

if not (tokA and tokB):
    sys.exit(1)

# توکن تازه‌سازی: نشان می‌دهد نشست در مرورگر قابل حفظ است
st, body = req("POST", "/auth/v1/token?grant_type=refresh_token",
               {"refresh_token": bodyA.get("refresh_token")})
check("رفرش نشست (حفظ ورود پس از رفرش صفحه)", st == 200 and bool(body.get("access_token")), f"HTTP {st}")

def rest(method, table, query="", body=None, token=None):
    return req(method, f"/rest/v1/{table}{query}", body, token,
               headers={"Prefer": "return=representation"})

st, rows = rest("GET", "profiles", f"?id=eq.{UID_A}&select=id,role,display_name", token=tokA)
roleA = rows[0]["role"] if isinstance(rows, list) and rows else None
check("A: پروفایل خودش را می‌خواند", st == 200 and bool(rows), f"HTTP {st}")
check("A: اولین کاربر خودکار «مدیر» شد", roleA == "admin", f"role={roleA}")
check("A: نام نمایشی از ثبت‌نام ساخته شد", bool(rows) and rows[0]["display_name"] == "QA A",
      str(rows[0]["display_name"]) if rows else "-")

st, rows = rest("GET", "profiles", f"?id=eq.{UID_A}&select=id", token=tokB)
check("B: پروفایل A را نمی‌بیند (جداسازی داده)", st == 200 and rows == [], f"HTTP {st}")

st, rows = rest("GET", "profiles", "?select=id", token=None)
check("ناشناس: هیچ پروفایلی نمی‌بیند", not (isinstance(rows, list) and rows), f"HTTP {st}")

st, rows = rest("GET", "user_progress", f"?user_id=eq.{UID_A}&select=id", token=tokB)
check("B: پیشرفت A را نمی‌بیند", not (isinstance(rows, list) and rows), f"HTTP {st}")

st, rows = rest("GET", "conversations", f"?user_id=eq.{UID_A}&select=id", token=tokB)
check("B: گفت‌وگوهای A را نمی‌بیند", not (isinstance(rows, list) and rows), f"HTTP {st}")

st, body = rest("PATCH", "profiles", f"?id=eq.{UID_B}", {"role": "admin"}, token=tokB)
st, after = rest("GET", "profiles", f"?id=eq.{UID_B}&select=role", token=tokA)
check("B: نمی‌تواند خودش را مدیر کند", bool(after) and after[0]["role"] != "admin",
      f"PATCH HTTP {st} → role={after[0]['role'] if after else '?'}")

st, body = rest("POST", "subscriptions",
                body={"user_id": UID_B, "plan_id": 1, "status": "active", "sku": "fake.sku"}, token=tokB)
check("B: نمی‌تواند اشتراک جعلی بسازد (Premium رایگان ممنوع)", st >= 400 or body == [], f"HTTP {st}")

st, body = rest("PATCH", "ai_settings", "?id=not.is.null", {"system_prompt": "hacked"}, token=tokB)
check("B: نمی‌تواند تنظیمات AI را عوض کند", st >= 400 or body == [], f"HTTP {st}")

st, body = rest("POST", "lessons", body={"language": "en", "level": "A1", "title": "hack"}, token=tokB)
check("B: نمی‌تواند درس بسازد", st >= 400 or body == [], f"HTTP {st}")

st, rows = rest("GET", "ai_secrets", "?select=id", token=tokB)
check("B: نمی‌تواند کلید AI را ببیند", st >= 400 or rows == [], f"HTTP {st}")

st, rows = rest("GET", "plans", "?select=code,title_fa,original_price,promo_price,is_active", token=None)
check("ناشناس: پلن‌ها و قیمت‌ها را می‌خواند", st == 200 and len(rows or []) >= 1, f"HTTP {st} rows={len(rows or [])}")

st, rows = rest("GET", "ai_usage_daily", "?select=*", token=tokB)
check("B: به جدول مصرف AI دسترسی نوشتن/خواندن ندارد", st >= 400 or rows == [], f"HTTP {st}")

# storage — a real 1x1 PNG, because the bucket only accepts image/png|jpeg|webp
PNG = bytes.fromhex("89504e470d0a1a0a0000000d494844520000000100000001080600000"
                    "01f15c4890000000d4944415478da63f8cfc0000003010100b8f0f9d60000000049454e44ae426082")
path = f"{UID_B}/check.png"
st, body = req("POST", f"/storage/v1/object/avatars/{path}", PNG, tokB,
               headers={"x-upsert": "true"}, raw=True, ctype="image/png")
check("B: آپلود تصویر در پوشهٔ آواتار خودش", st in (200, 201), f"HTTP {st} {str(body)[:60]}")

st, _ = req("POST", "/storage/v1/object/avatars/11111111-1111-1111-1111-111111111111/x.png",
            PNG, tokB, raw=True, ctype="image/png")
check("B: نمی‌تواند در پوشهٔ کاربر دیگر بنویسد", st >= 400, f"HTTP {st}")

st, _ = req("POST", "/storage/v1/object/media/evil.png", PNG, tokB, raw=True, ctype="image/png")
check("B: نمی‌تواند در باکت رسانهٔ مدیر بنویسد", st >= 400, f"HTTP {st}")

st, _ = req("GET", f"/storage/v1/object/avatars/{path}", token=tokB)
check("B: فایل خودش را می‌خواند", st == 200, f"HTTP {st}")

st, _ = req("DELETE", f"/storage/v1/object/avatars/{path}", token=tokB)
check("B: فایل خودش را پاک می‌کند", st in (200, 204), f"HTTP {st}")

bad = [r for r in results if not r[1]]
print(f"\nنتیجه: {len(results)-len(bad)}/{len(results)} پاس" + ("" if not bad else f"\nناموفق: {[b[0] for b in bad]}"))
