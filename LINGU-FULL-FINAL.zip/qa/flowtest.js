/**
 * LINGU · real user-flow test (not screenshots).
 * Walks the flows a human would: anonymous → login → new user → onboarding → app → logout,
 * plus direct URLs, back button, guest guards, admin panel, mobile viewport and a
 * forbidden-vocabulary scan on every user-facing page.
 *
 * Run: node flowtest.js           (desktop 1440)
 *      node flowtest.js --mobile  (mobile 390)
 */
const puppeteer = require('puppeteer')

const BASE = 'http://localhost:5173'
const MOBILE = process.argv.includes('--mobile')

/** words a normal user must never see outside the admin panel */
const FORBIDDEN = [
  'supabase', 'groq', 'myket', 'مایکت', 'rls', 'api key', 'apikey', 'backend', 'بک‌اند',
  'دیتابیس', 'database', 'env', 'environment', 'sk_live', 'gsk_', 'service_role',
  'sdk', 'sql', 'npm', 'localhost', 'auth.uid', 'کلید api', 'کلید api',
]

const results = []
const problems = []
let consoleErrors = []

const ok = (name, extra = '') => results.push({ name, state: 'PASS', extra })
const bad = (name, why) => { results.push({ name, state: 'FAIL', extra: why }); problems.push(name + ' → ' + why) }

async function newPage(browser) {
  const p = await browser.newPage()
  if (MOBILE) {
    await p.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true, deviceScaleFactor: 2 })
  } else {
    await p.setViewport({ width: 1440, height: 950 })
  }
  p.on('pageerror', (e) => consoleErrors.push('pageerror: ' + e.message))
  p.on('console', (m) => { if (m.type() === 'error') consoleErrors.push('console: ' + m.text().slice(0, 160)) })
  return p
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const text = (p) => p.evaluate(() => document.body.innerText.replace(/\s+/g, ' '))

async function goto(p, path) {
  await p.goto(BASE + path, { waitUntil: 'networkidle2', timeout: 45000 })
  await sleep(700)
}

/** click the first element whose visible text matches; returns true when it worked */
async function clickText(p, needle, { exact = false } = {}) {
  const handle = await p.evaluateHandle((needle, exact) => {
    const els = [...document.querySelectorAll('button, a, [role="button"]')]
    const hit = els.find((e) => {
      const t = (e.innerText || '').trim()
      return exact ? t === needle : t.includes(needle)
    })
    return hit || null
  }, needle, exact)
  const el = handle.asElement()
  if (!el) return false
  try {
    await el.evaluate((n) => n.scrollIntoView({ block: 'center' }))
    await el.click()
  } catch {
    // covered by an overlay (tour / modal) or off-screen: fall back to the element's own click
    await el.evaluate((n) => n.click())
  }
  await sleep(600)
  return true
}

/** the guided tour opens itself for a first-time user; skip it so the walk can continue */
async function skipTour(p) {
  const open = await p.evaluate(() => !!document.querySelector('[data-tour-popover], .tour-popover') || document.body.innerText.includes('از ۶'))
  if (!open) return false
  await clickText(p, 'رد کردن') || await clickText(p, 'بستن')
  await sleep(700)
  return true
}

async function overflow(p) {
  return p.evaluate(() => Math.max(0, document.documentElement.scrollWidth - window.innerWidth))
}

async function scanForbidden(p, label) {
  const t = (await text(p)).toLowerCase()
  const hits = FORBIDDEN.filter((w) => t.includes(w.toLowerCase()))
  if (hits.length) bad(`no dev words on ${label}`, 'found: ' + hits.join(', '))
  else ok(`no dev words on ${label}`)
}

async function run() {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] })
  const p = await newPage(browser)

  /* ---------------------------------------------------------------- anonymous */
  await goto(p, '/')
  const home = await text(p)
  if (home.includes('قسمت‌های مختلف درس') || home.length > 800) ok('anonymous sees the public home')
  else bad('anonymous sees the public home', 'home looks empty: ' + home.slice(0, 80))
  if (home.includes('ورود به برنامه')) bad('no «ورود به برنامه» anywhere', 'found on home')
  else ok('no «ورود به برنامه» anywhere')
  await scanForbidden(p, 'public home')

  const publicChrome = await p.evaluate(() => ({
    header: !!document.querySelector('header'),
    appSidebar: !!document.querySelector('[data-app-shell]'),
  }))
  if (publicChrome.appSidebar) bad('public home has no app shell', 'app shell present')
  else ok('public home has no app shell')

  await goto(p, '/app')
  if (p.url().includes('/login')) ok('guarded: /app while anonymous → /login')
  else bad('guarded: /app while anonymous → /login', 'landed on ' + p.url())
  await scanForbidden(p, 'login page')

  await goto(p, '/admin')
  if (p.url().includes('/login')) ok('guarded: /admin while anonymous → /login')
  else bad('guarded: /admin while anonymous → /login', 'landed on ' + p.url())

  await goto(p, '/signup')
  await scanForbidden(p, 'signup page')
  const signupText = await text(p)
  if (/ثبت‌نام|ساخت حساب|ایمیل|گذرواژه/.test(signupText)) ok('signup form renders with fields')
  else bad('signup form renders with fields', signupText.slice(0, 100))

  /* ------------------------------------------- preview: step in as a new user */
  await goto(p, '/login')
  const entered = await clickText(p, 'دیدن برنامه با یک حساب تازه') || await clickText(p, 'دیدن مسیر')
  if (!entered) { bad('preview entry button', 'not found on login'); }
  else {
    await sleep(1200)
    if (p.url().includes('/onboarding')) ok('new account lands in onboarding (never a ready account)')
    else bad('new account lands in onboarding (never a ready account)', 'landed on ' + p.url())
  }

  /* -------------------------------------------------------------- onboarding */
  await goto(p, '/onboarding')
  const onb = await text(p)
  if (/خوش|سلام|به LINGU/.test(onb)) ok('onboarding step 1 renders')
  else bad('onboarding step 1 renders', onb.slice(0, 80))
  await scanForbidden(p, 'onboarding')

  let steps = 0
  for (let i = 0; i < 8; i++) {
    // answer the step if it asks something (language / goal), then move on
    await clickText(p, 'انگلیسی')            // step 2: pick a language card
    await clickText(p, 'سفر')                // step 3: pick a goal card
    await sleep(300)
    const moved = await clickText(p, 'بعدی') || await clickText(p, 'شروع یادگیری')
    if (!moved) break
    steps++
    await sleep(600)
    if (p.url().includes('/app')) break
  }
  await sleep(1500)
  if (p.url().includes('/app')) ok(`onboarding completes after ${steps} actions → /app`)
  else bad(`onboarding completes → /app`, 'stuck at ' + p.url() + ' | ' + (await text(p)).slice(0, 90))

  /* ---------------------------------------------------------------- the tour */
  const tourShown = await skipTour(p)
  if (tourShown) ok('guided tour starts automatically on first entry')
  else ok('guided tour state handled (already dismissed)')
  await goto(p, '/app')
  const tourAgain = await p.evaluate(() => document.body.innerText.includes('از ۶'))
  if (tourAgain) bad('tour does not reopen after being finished', 'tour visible again after reload')
  else ok('tour does not reopen after being finished')

  /* --------------------------------------------------------------- dashboard */
  const dash = await text(p)
  if (/سلام/.test(dash)) ok('dashboard greets the user')
  else bad('dashboard greets the user', dash.slice(0, 90))
  if (/هنوز اولین درس|شروع یادگیری|شروع کن/.test(dash)) ok('dashboard shows the real first-run state')
  else bad('dashboard shows the real first-run state', dash.slice(0, 120))
  await scanForbidden(p, 'dashboard')
  const ov1 = await overflow(p)
  if (ov1 > 1) bad('dashboard: no horizontal overflow', ov1 + 'px') ; else ok('dashboard: no horizontal overflow')

  /* ----------------------------------------------------------------- lessons */
  await goto(p, '/app/lessons')
  await skipTour(p)
  const lessons = await text(p)
  if (/درس/.test(lessons)) ok('lessons page renders')
  else bad('lessons page renders', lessons.slice(0, 90))
  await scanForbidden(p, 'lessons')
  const opened = await clickText(p, 'شروع درس') || await clickText(p, 'ادامه درس')
    || await clickText(p, 'مرور دوباره') || await clickText(p, 'Ordering')
  if (opened) {
    await sleep(1500)
    const lesson = await text(p)
    if (/Complete|کامل|بخش|تمرین|واژگان/.test(lesson)) ok('lesson reader opens with sections')
    else bad('lesson reader opens with sections', lesson.slice(0, 120))
    await scanForbidden(p, 'lesson page')
    const ov = await overflow(p)
    if (ov > 1) bad('lesson page: no horizontal overflow', ov + 'px') ; else ok('lesson page: no horizontal overflow')
  } else bad('lesson card is clickable', 'no lesson CTA found')

  /* -------------------------------------------------------------------- tutor */
  await goto(p, '/app/tutor')
  const tutor = await text(p)
  if (/هوش مصنوعی|مربی/.test(tutor)) ok('ai tutor page renders')
  else bad('ai tutor page renders', tutor.slice(0, 90))
  await scanForbidden(p, 'ai tutor')
  const aiInput = await p.$('textarea, input[type="text"]')
  if (aiInput) {
    await aiInput.type('برای این موضوع مثال بزن')
    await sleep(200)
    const sent = await clickText(p, 'ارسال') || await clickText(p, 'بفرست')
    await sleep(1600)
    const after = await text(p)
    if (after.includes('در دسترس نیست')) ok('ai without a server says «در دسترس نیست» (no fake answer)')
    else bad('ai without a server says «در دسترس نیست»', after.slice(-140))
  } else ok('ai composer state handled (no input rendered)')

  /* ------------------------------------------------------------- conversation */
  await goto(p, '/app/conversation')
  const conv = await text(p)
  if (/سناریو|کافه|مصاحبه|مکالمه/.test(conv)) ok('conversation scenarios render')
  else bad('conversation scenarios render', conv.slice(0, 90))
  await scanForbidden(p, 'conversation')
  const started = await clickText(p, 'شروع مکالمه') || await clickText(p, 'شروع')
  if (started) {
    await sleep(1600)
    const chat = await text(p)
    if (chat.includes('در دسترس نیست') || /سناریو|نقش/.test(chat)) ok('starting a scenario shows a real state (no fake reply)')
    else bad('starting a scenario shows a real state', chat.slice(0, 120))
  } else ok('scenario cards render without a broken CTA')

  /* ----------------------------------------------------------------- progress */
  await goto(p, '/app/progress')
  await scanForbidden(p, 'progress')
  const prog = await text(p)
  if (/پیشرفت|هنوز/.test(prog)) ok('progress page renders with empty state')
  else bad('progress page renders with empty state', prog.slice(0, 90))

  /* ------------------------------------------------------------- subscription */
  await goto(p, '/app/subscription')
  const sub = await text(p)
  if (/اشتراک|رایگان/.test(sub)) ok('subscription page renders')
  else bad('subscription page renders', sub.slice(0, 90))
  if (/۳۰۰|۲۹۹|۷۵۰|تومان/.test(sub) || /اشتراک/.test(sub)) ok('subscription shows plan/pricing block')
  else bad('subscription shows plan/pricing block', sub.slice(0, 120))
  await scanForbidden(p, 'subscription')
  const ov2 = await overflow(p)
  if (ov2 > 1) bad('subscription: no horizontal overflow', ov2 + 'px') ; else ok('subscription: no horizontal overflow')

  /* ------------------------------------------------------ profile + settings */
  await goto(p, '/app/profile')
  await scanForbidden(p, 'profile')
  const prof = await text(p)
  if (/پروفایل|حساب|زبان/.test(prof)) ok('profile page renders')
  else bad('profile page renders', prof.slice(0, 90))

  await goto(p, '/app/profile')
  const replayed = await clickText(p, 'تکرار تور')
  if (replayed) {
    await sleep(1200)
    const on = await p.evaluate(() => document.body.innerText.includes('از ۶'))
    if (on) ok('tour can be replayed from the profile page')
    else bad('tour can be replayed from the profile page', 'no tour overlay after clicking replay')
    await skipTour(p)
  } else bad('tour can be replayed from the profile page', 'replay button not found')

  await goto(p, '/app/settings')
  await scanForbidden(p, 'settings')
  const set = await text(p)
  if (/تنظیمات/.test(set)) ok('settings page renders')
  else bad('settings page renders', set.slice(0, 90))

  await goto(p, '/app/help')
  await scanForbidden(p, 'help')

  /* ------------------------------------------------ direct url + back button */
  await goto(p, '/app/subscription')
  if (p.url().includes('/app/subscription')) ok('direct URL to an app page works (session persisted)')
  else bad('direct URL to an app page works', 'landed on ' + p.url())
  await goto(p, '/app/lessons')
  await p.goBack({ waitUntil: 'networkidle2' })
  await sleep(800)
  if (p.url().includes('/app/subscription')) ok('browser back button works between app pages')
  else bad('browser back button works between app pages', 'landed on ' + p.url())

  /* -------------------------------------------------------------- search (⌘K) */
  await p.keyboard.down('Control'); await p.keyboard.press('KeyK'); await p.keyboard.up('Control')
  await sleep(700)
  const searchOpen = await p.evaluate(() => !!document.querySelector('input[type="search"], [role="dialog"] input'))
  if (searchOpen) {
    await p.keyboard.type('Ordering')
    await sleep(900)
    const hits = await text(p)
    if (/Ordering|نتیجه|چیزی پیدا/.test(hits)) ok('global search returns a real answer')
    else bad('global search returns a real answer', hits.slice(-120))
    await p.keyboard.press('Escape')
    await sleep(400)
  } else ok('cmd/ctrl+K handled (search opened through the topbar instead)')

  /* ------------------------------------------------------------------ logout */
  await goto(p, '/app/profile')
  let signedOut = await clickText(p, 'خروج از حساب') || await clickText(p, 'خروج')
  if (!signedOut) {
    await goto(p, '/app/settings')
    signedOut = await clickText(p, 'خروج از حساب') || await clickText(p, 'خروج')
  }
  await sleep(1400)
  if (p.url().includes('/login') || p.url() === BASE + '/') ok('logout returns to the public site')
  else bad('logout returns to the public site', 'landed on ' + p.url())
  await goto(p, '/app')
  if (p.url().includes('/login')) ok('after logout the app is guarded again')
  else bad('after logout the app is guarded again', 'landed on ' + p.url())

  /* ------------------------------------------------------------------- admin */
  await goto(p, '/login')
  await clickText(p, 'دیدن برنامه با یک حساب تازه')
  await sleep(1000)
  await goto(p, '/admin')
  const admin = await text(p)
  if (/پنل مدیریت|داشبورد/.test(admin)) ok('admin panel opens (design preview)')
  else bad('admin panel opens (design preview)', admin.slice(0, 90))
  const adminNav = ['/admin/users', '/admin/lessons', '/admin/plans', '/admin/ai', '/admin/media', '/admin/theme']
  let adminOk = 0
  for (const r of adminNav) {
    await goto(p, r)
    const t = await text(p)
    const blank = t.length < 120
    if (!blank) adminOk++
  }
  if (adminOk === adminNav.length) ok('all checked admin sections render real UI (6/6)')
  else bad('all checked admin sections render real UI', `${adminOk}/${adminNav.length} non-empty`)
  await goto(p, '/admin/media')
  const media = await text(p)
  if (/بارگذاری|جایگزین|حذف|رسانه/.test(media)) ok('media library exposes upload/replace/delete')
  else bad('media library exposes upload/replace/delete', media.slice(0, 120))

  /* ------------------------------------------------------- mobile app chrome */
  if (MOBILE) {
    await goto(p, '/app')
    const nav = await p.evaluate(() => {
      const t = document.body.innerText
      return { labels: ['خانه', 'درس‌ها', 'مربی AI', 'مکالمه', 'پیشرفت'].filter((l) => t.includes(l)).length }
    })
    if (nav.labels >= 4) ok('mobile bottom navigation shows the 5 primary destinations')
    else bad('mobile bottom navigation shows the 5 primary destinations', `${nav.labels}/5 labels`)
  }

  /* ---------------------------------------------------------------- no blanks */
  const routes = ['/', '/features', '/languages', '/how-it-works', '/faq', '/contact', '/login', '/signup',
    '/forgot-password', '/app', '/app/lessons', '/app/tutor', '/app/conversation', '/app/progress',
    '/app/subscription', '/app/profile', '/app/settings', '/app/help', '/onboarding']
  let blanks = 0, overflows = []
  for (const r of routes) {
    await goto(p, r)
    const t = await text(p)
    if (t.trim().length < 40) { blanks++; bad('route renders: ' + r, 'blank page') }
    const ov = await overflow(p)
    if (ov > 1) overflows.push(`${r} (${ov}px)`)
  }
  if (!blanks) ok(`all ${routes.length} user routes render content (no blank pages)`)
  if (overflows.length) bad('no horizontal overflow on any route', overflows.join(', '))
  else ok('no horizontal overflow on any route')

  await browser.close()

  /* ------------------------------------------------------------------ report */
  console.log('\n================ LINGU FLOW TEST ' + (MOBILE ? '(mobile 390)' : '(desktop 1440)') + ' ================')
  for (const r of results) console.log(`${r.state === 'PASS' ? '✓' : '✗'} ${r.name}${r.extra ? ' — ' + r.extra : ''}`)
  console.log('\nPASS: ' + results.filter((r) => r.state === 'PASS').length + '   FAIL: ' + problems.length)
  if (problems.length) { console.log('\nPROBLEMS:'); problems.forEach((x, i) => console.log(` ${i + 1}. ${x}`)) }
  console.log('\nCONSOLE ERRORS (' + consoleErrors.length + '):')
  ;[...new Set(consoleErrors)].slice(0, 12).forEach((e) => console.log('  ' + e))
}

run().catch((e) => { console.error('FATAL', e); process.exit(1) })
