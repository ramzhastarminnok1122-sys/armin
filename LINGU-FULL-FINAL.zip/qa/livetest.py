#!/usr/bin/env python3
"""
LINGU · live backend verification against the REAL Supabase project.
Exercises the same HTTP endpoints the browser uses: GoTrue (auth),
PostgREST (RLS) and Storage (policies).  Creates two throwaway accounts and
deletes them at the end so the owner's signup still becomes the first admin.
"""
import json, urllib.request, urllib.error, sys, time

REF   = sys.argv[1] if len(sys.argv) > 1 else "wyzjdeqezbasuskkvhgd"
KEY   = sys.argv[2] if len(sys.argv) > 2 else ""
BASE  = f"https://{REF}.supabase.co"
STAMP = str(int(time.time()))[-6:]
A_MAIL = f"lingu.check.a.{STAMP}@example.com"
B_MAIL = f"lingu.check.b.{STAMP}@example.com"
PW     = "LinguCheck!2026"

results = []
def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("✅ " if ok else "❌ ") + name + (f"  [{detail}]" if detail else ""))

def req(method, path, body=None, token=None, headers=None, raw=False, ctype="application/json"):
    url = BASE + path
    data = None
    if body is not None:
        data = body if raw else json.dumps(body).encode()
    h = {"apikey": KEY}
    if token: h["Authorization"] = f"Bearer {token}"
    if data is not None: h["Content-Type"] = ctype
    h.update(headers or {})
    r = urllib.request.Request(url, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            txt = resp.read().decode()
            return resp.status, (json.loads(txt) if txt and ctype == "application/json" else txt)
    except urllib.error.HTTPError as e:
        txt = e.read().decode()
        try: return e.code, json.loads(txt)
        except Exception: return e.code, txt

# ---------------------------------------------------------------- signup
def signup(mail):
    st, body = req("POST", "/auth/v1/signup", {"email": mail, "password": PW})
    return st, body

def signin(mail):
    st, body = req("POST", "/auth/v1/token?grant_type=password", {"email": mail, "password": PW})
    return (body.get("access_token") if isinstance(body, dict) else None), st, body

print(f"── پروژه: {REF}")
print(f"── کاربر A: {A_MAIL}\n── کاربر B: {B_MAIL}\n")

stA, bodyA = signup(A_MAIL)
check("A: ثبت‌نام از طریق GoTrue", stA in (200, 201), f"HTTP {stA}")
uidA = bodyA.get("user", {}).get("id") if isinstance(bodyA, dict) else None
sessionA = bodyA.get("access_token") if isinstance(bodyA, dict) else None
check("A: شناسهٔ کاربر ساخته شد", bool(uidA), str(uidA)[:8] + "…")
check("A: جلسه بلافاصله صادر شد (تأیید ایمیل خاموش است)", bool(sessionA),
      "بدون جلسه → نیاز به تأیید ایمیل" if not sessionA else "دارد")

stB, bodyB = signup(B_MAIL)
uidB = bodyB.get("user", {}).get("id") if isinstance(bodyB, dict) else None
sessionB = bodyB.get("access_token") if isinstance(bodyB, dict) else None
check("B: ثبت‌نام کاربر دوم", bool(uidB), str(uidB)[:8] + "…")

print("\n__META__" + json.dumps({"uidA": uidA, "uidB": uidB, "sessionA": bool(sessionA),
                                 "sessionB": bool(sessionB), "mailA": A_MAIL, "mailB": B_MAIL}))

if not (uidA and uidB):
    print("\nبدون دو کاربر نمی‌توان ادامه داد."); sys.exit(1)

# token (اگر جلسه نبود، ورود می‌کنیم — برای کاربر تأییدشده)
tokA, st, body = signin(A_MAIL) if not sessionA else (sessionA, 200, bodyA)
tokB, st2, body2 = signin(B_MAIL) if not sessionB else (sessionB, 200, bodyB)
if not tokA: check("A: ورود با رمز", False, json.dumps(body)[:120])
if not tokB: check("B: ورود با رمز", False, json.dumps(body2)[:120])

def rest(method, table, query="", body=None, token=None):
    return req(method, f"/rest/v1/{table}{query}", body, token,
               headers={"Prefer": "return=representation"})

# ------------------------------------------------------------ data + RLS
if tokA and tokB:
    st, rows = rest("GET", "profiles", f"?id=eq.{uidA}&select=id,role,display_name", token=tokA)
    roleA = rows[0]["role"] if isinstance(rows, list) and rows else None
    check("A: پروفایل خودش را می‌خواند", st == 200 and bool(rows), f"HTTP {st}")
    check("A: اولین کاربر خودکار «مدیر» شد", roleA == "admin", f"role={roleA}")

    st, rows = rest("GET", "profiles", f"?id=eq.{uidA}&select=id,role", token=tokB)
    check("B: نمی‌تواند پروفایل A را ببیند", st == 200 and rows == [], f"HTTP {st} rows={len(rows or [])}")

    st, rows = rest("GET", "profiles", "?select=id,role,email", token=None)
    anon_rows = rows if isinstance(rows, list) else []
    check("ناشناس: هیچ پروفایلی نمی‌بیند", st in (200, 401) and not anon_rows, f"HTTP {st} rows={len(anon_rows)}")

    st, body = rest("PATCH", "profiles", f"?id=eq.{uidB}", {"role": "admin"}, token=tokB)
    st2, after = rest("GET", "profiles", f"?id=eq.{uidB}&select=role", token=tokA)
    escalated = bool(after) and after[0]["role"] == "admin"
    check("B: نمی‌تواند خودش را مدیر کند", not escalated, f"HTTP {st} → role={after[0]['role'] if after else '?'}")

    st, body = rest("POST", "subscriptions",
                    body={"user_id": uidB, "plan_id": 1, "status": "active", "sku": "fake.sku"}, token=tokB)
    check("B: نمی‌تواند اشتراک جعلی بسازد", st >= 400 or body == [], f"HTTP {st}")

    st, body = rest("PATCH", "ai_settings", "?id=not.is.null", {"system_prompt": "hacked"}, token=tokB)
    check("B: نمی‌تواند تنظیمات AI را عوض کند", st >= 400 or body == [], f"HTTP {st}")

    st, body = rest("POST", "lessons",
                    body={"language": "en", "level": "A1", "title": "hack", "status": "published"}, token=tokB)
    check("B: نمی‌تواند درس بسازد", st >= 400 or body == [], f"HTTP {st}")

    st, rows = rest("GET", "plans", "?select=code,price_toman", token=None)
    check("ناشناس: پلن‌ها و قیمت‌ها را می‌خواند (فقط خواندنی)", st == 200 and len(rows or []) >= 1, f"HTTP {st}")

# ---------------------------------------------------------------- storage
if tokB:
    path = f"{uidB}/check.txt"
    st, body = req("POST", f"/storage/v1/object/avatars/{path}", b"hello-lingu", tokB,
                   headers={"x-upsert": "true"}, raw=True, ctype="text/plain")
    check("B: آپلود در پوشهٔ آواتار خودش", st in (200, 201), f"HTTP {st}")

    st, body = req("POST", "/storage/v1/object/avatars/other-user/x.txt", b"nope", tokB,
                   raw=True, ctype="text/plain")
    check("B: نمی‌تواند در پوشهٔ کاربر دیگر بنویسد", st >= 400, f"HTTP {st}")

    st, body = req("POST", "/storage/v1/object/media/evil.png", b"nope", tokB,
                   raw=True, ctype="image/png")
    check("B (کاربر عادی): نمی‌تواند در باکت رسانهٔ مدیر بنویسد", st >= 400, f"HTTP {st}")

    st, body = req("GET", f"/storage/v1/object/avatars/{path}", token=tokB)
    check("B: فایل خودش را می‌خواند", st == 200, f"HTTP {st}")

# ---------------------------------------------------------------- cleanup
print("\n__CLEANUP__" + json.dumps({"uidB": uidB, "path": f"{uidB}/check.txt"}))
print()
bad = [r for r in results if not r[1]]
print(f"نتیجه: {len(results)-len(bad)}/{len(results)} پاس" + ("" if not bad else f" · ناموفق: {[b[0] for b in bad]}"))
sys.exit(0)
