#!/usr/bin/env bash
# Connects to the real Supabase project and applies SETUP.sql.
# Usage: bash connect_live.sh <project-ref> <db-password>
set -u
REF="${1:?project ref required}"
PW="${2:?db password required}"
export PGPASSWORD="$PW"

echo "▸ DNS lookup for db.$REF.supabase.co"
python3 - "$REF" <<'PY'
import socket, sys, json, urllib.request
ref = sys.argv[1]
host = f"db.{ref}.supabase.co"
try:
    infos = socket.getaddrinfo(host, 5432)
    print("  A/AAAA:", sorted({i[4][0] for i in infos}))
except Exception as e:
    print("  direct host failed:", e)
try:
    req = urllib.request.Request(f"https://cloudflare-dns.com/dns-query?name={host}&type=AAAA",
                                 headers={"accept": "application/dns-json"})
    d = json.load(urllib.request.urlopen(req, timeout=15))
    print("  DoH AAAA:", [a.get("data") for a in d.get("Answer", [])] or "none")
except Exception as e:
    print("  DoH failed:", e)
PY

try_conn () {
  echo "▸ trying $1"
  timeout 25 psql "$1" -tAc "select current_database(), current_user, version()" 2>&1 | head -2
}
try_conn "postgresql://postgres@db.$REF.supabase.co:5432/postgres?sslmode=require"
for R in eu-central-1 eu-west-1 us-east-1 ap-southeast-1; do
  for P in aws-0 aws-1; do
    try_conn "postgresql://postgres.$REF@$P-$R.pooler.supabase.com:5432/postgres?sslmode=require"
  done
done
