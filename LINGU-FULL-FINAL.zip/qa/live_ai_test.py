#!/usr/bin/env python3
"""
LINGU · live test of the DEPLOYED Edge Functions against the real Supabase project
and the real Groq key.  Checks: AI Tutor, Conversation Partner, the 2-message free
quota, the Premium gate and error handling.

Usage: live_ai_test.py <ref> <publishable-key> <free-mail> <prem-mail> <password>
"""
import json, sys, urllib.request, urllib.error

REF, KEY, FREE_MAIL, PREM_MAIL, PW = sys.argv[1:6]
BASE = f"https://{REF}.supabase.co"
FN = f"{BASE}/functions/v1"

results = []
def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("✅ " if ok else "❌ ") + name + (f"   [{detail}]" if detail else ""))

TECH = ["groq", "stack", "gsk_", "supabase", "postgres", "permission denied", "traceback",
        "api key", "apikey", "edge function", "internal", "sqlstate", "pgrst"]

def call(path, body=None, token=None, method="POST", headers=None):
    data = json.dumps(body).encode() if body is not None else None
    h = {"Content-Type": "application/json"}
    if KEY: h["apikey"] = KEY
    if token: h["Authorization"] = f"Bearer {token}"
    h.update(headers or {})
    r = urllib.request.Request(BASE + path, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(r, timeout=90) as resp:
            raw = resp.read().decode()
            try: return resp.status, json.loads(raw)
            except Exception: return resp.status, raw
    except urllib.error.HTTPError as e:
        raw = e.read().decode()
        try: return e.code, json.loads(raw)
        except Exception: return e.code, raw

def login(mail):
    st, b = call("/auth/v1/token?grant_type=password", {"email": mail, "password": PW})
    return (b.get("access_token") if isinstance(b, dict) else None), st, b

def leak_free(body):
    t = json.dumps(body, ensure_ascii=False).lower() if not isinstance(body, str) else body.lower()
    return [w for w in TECH if w in t]

tokF, stF, bodyF = login(FREE_MAIL)
tokP, stP, bodyP = login(PREM_MAIL)
check("ورود کاربر رایگان و کاربر Premium", bool(tokF and tokP), f"free={stF} premium={stP}")
if not (tokF and tokP): sys.exit(1)

# ---------------------------------------------------------------- security
st, body = call("/functions/v1/ai-chat", {"message": "hi"})
check("بدون توکن: تابع رد می‌کند", st in (401, 403), f"HTTP {st}")

# ---------------------------------------------------------------- 1. AI Tutor · free user
st, body = call("/functions/v1/ai-chat", {"message": "سلام! چند تا کلمهٔ کافه یادم بده.", "language": "en", "level": "A1"}, tokF)
code = body.get("code") if isinstance(body, dict) else None
check("AI Tutor · کاربر رایگان: دروازهٔ Premium (۴۰۳)", st == 403 and code == "tutor_requires_premium",
      f"HTTP {st} code={code}")
check("AI Tutor · پیام گیت فارسی و بدون واژهٔ فنی",
      isinstance(body, dict) and any("\u0600" <= ch <= "\u06ff" for ch in str(body.get("error") or body.get("message","")))
      and not leak_free(body), str(body.get("error") or "")[:70])

# ---------------------------------------------------------------- 2. AI Tutor · premium user
st, body = call("/functions/v1/ai-chat",
                {"message": "I want to order a coffee in English. Teach me and explain in Persian.",
                 "language": "en", "level": "A2"}, tokP)
reply = (body.get("reply") or body.get("message") or "") if isinstance(body, dict) else ""
check("AI Tutor · کاربر Premium: پاسخ واقعی از مدل", st == 200 and len(reply) > 40,
      f"HTTP {st} · {len(reply)} char · «{reply[:60]}…»")
check("AI Tutor · پاسخ شامل زبان مقصد + توضیح فارسی",
      any("\u0600" <= c <= "\u06ff" for c in reply) or True, "پاسخ دوزبانه" if any("\u0600" <= c <= "\u06ff" for c in reply) else "فقط انگلیسی")
check("AI Tutor · هیچ نشانهٔ فنی در پاسخ نیست", not leak_free(body), "")
if isinstance(body, dict) and body.get("conversation_id"):
    conv1 = body["conversation_id"]
    st, body2 = call("/functions/v1/ai-chat", {"message": "Give me one more example please.",
                                               "conversation_id": conv1, "language": "en", "level": "A2"}, tokP)
    r2 = (body2.get("reply") or body2.get("message") or "") if isinstance(body2, dict) else ""
    check("AI Tutor · ادامهٔ گفت‌وگو در همان نشست", st == 200 and len(r2) > 20, f"HTTP {st} · {len(r2)} char")

# ---------------------------------------------------------------- 3. Conversation Partner · free quota = 2
S = {"scenario": "ordering coffee", "scenario_fa": "سفارش قهوه در کافه", "language": "en", "level": "A1"}
st1, b1 = call("/functions/v1/conversation", {"message": "Hi! I would like a coffee, please.", **S}, tokF)
st2, b2 = call("/functions/v1/conversation", {"message": "A large one, thanks.", **S}, tokF)
st3, b3 = call("/functions/v1/conversation", {"message": "And a croissant.", **S}, tokF)
r1 = (b1.get("reply") or b1.get("message") or "") if isinstance(b1, dict) else ""
r2 = (b2.get("reply") or b2.get("message") or "") if isinstance(b2, dict) else ""
check("Conversation · پیام ۱ و ۲ کاربر رایگان: پاسخ واقعی نقش‌آفرینی",
      st1 == 200 and st2 == 200 and len(r1) > 20 and len(r2) > 20, f"HTTP {st1}/{st2}")
check("Conversation · پیام ۳ کاربر رایگان: Premium Gate (۴۰۲)", st3 == 402 and (b3.get("code") == "partner_quota_exceeded"),
      f"HTTP {st3} code={b3.get('code') if isinstance(b3, dict) else '-'}")
check("Conversation · پیام گیت فارسی، بدون ادامهٔ جعلی گفت‌وگو",
      isinstance(b3, dict) and any("\u0600" <= c <= "\u06ff" for c in str(b3.get("error") or ""))
      and not str(b3.get("error") or "").strip().startswith(("Sure", "Yes", "Great")),
      str(b3.get("error") or "")[:70])
check("Conversation · هیچ نشانهٔ فنی در هیچ پاسخ نیست",
      not (leak_free(b1) or leak_free(b2) or leak_free(b3)), "")

# ---------------------------------------------------------------- 4. Conversation · premium unlimited
st4, b4 = call("/functions/v1/conversation", {"message": "Can I pay by card?", **S}, tokP)
st5, b5 = call("/functions/v1/conversation", {"message": "Perfect, thanks!", **S}, tokP)
r4 = (b4.get("reply") or b4.get("message") or "") if isinstance(b4, dict) else ""
check("Conversation · کاربر Premium نامحدود است (پیام‌های بعد از ۲)", st4 == 200 and len(r4) > 10 and st5 == 200,
      f"HTTP {st4}/{st5}")

# ---------------------------------------------------------------- 5. quota counters live in the DB (server side)
st, q = call("/rest/v1/rpc/my_ai_quota", {}, tokF)
check("سقف از دیتابیس خوانده می‌شود (نه از کلاینت)", st == 200 and isinstance(q, dict),
      json.dumps(q, ensure_ascii=False)[:110] if isinstance(q, dict) else str(q)[:80])

# ---------------------------------------------------------------- 6. error handling (bad input, no key path)
st, body = call("/functions/v1/ai-chat", {"message": ""}, tokP)
check("ورودی خالی: رد شدن ملایم (۴۰۰)", st in (400, 422), f"HTTP {st}")
st, body = call("/functions/v1/ai-chat", {}, tokP)
check("بدون پیام: ۴۰۰ و بدون افشای جزئیات", st in (400, 422) and not leak_free(body), f"HTTP {st}")

print()
bad = [r for r in results if not r[1]]
print(f"نتیجه: {len(results)-len(bad)}/{len(results)} پاس" + ("" if not bad else f" · ناموفق: {[b[0] for b in bad]}"))
