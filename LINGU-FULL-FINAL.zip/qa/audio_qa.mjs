/**
 * LINGU · QA صدا — تست واقعی پخش‌کنندهٔ درس در مرورگر (دسکتاپ + موبایل)
 *
 * چه چیزی را می‌آزماید (برای هر بخش دارای صدا در ۴ درس):
 *   پخش · توقف · جابه‌جایی (seek) · سرعت ۱٫۵ · پخش دوباره · هم‌خوانی متن با فایل · تناسب با موبایل
 *   + در دیالوگ: هر خط با صدای گویندهٔ خودش (A/B) پخش شود
 *   + خطای شبکه / فایل گم‌شده: هیچ درخواست ناموفقی برای lesson-audio نباید باشد
 */
import fs from 'node:fs'
import puppeteer from 'puppeteer'

const BASE = process.env.BASE ?? 'http://127.0.0.1:4173'
const EMAIL = 'ops.audio@lingu.app'                // حساب آزمون (نقش مدیر: درس‌های منتشرنشده را می‌بیند)
const PASSWORD = fs.readFileSync('/tmp/ops_pw', 'utf8').trim()
const EXPECTED = JSON.parse(fs.readFileSync('/tmp/expected_audio.json', 'utf8'))
const SHOTS = '/home/user/qa/shots'
fs.mkdirSync(SHOTS, { recursive: true })

const SECTION_LABEL = {
  warmup: 'گرم‌کردن', explanation: 'توضیح درس', vocabulary: 'واژگان', grammar: 'گرامر',
  examples: 'مثال‌ها', listening: 'شنیداری', dialogue: 'دیالوگ', speaking: 'تمرین گفت‌وگو',
  reading: 'خواندن', exercises: 'تمرین‌ها', quiz: 'آزمون', ai_practice: 'تمرین با AI',
}
const results = [], problems = [], aborted = []
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function login(page) {
  await page.goto(`${BASE}/login`, { waitUntil: 'networkidle2' })
  await page.type('input[type="email"]', EMAIL)
  await page.type('input[type="password"]', PASSWORD)
  await Promise.all([
    page.waitForFunction(() => !location.pathname.startsWith('/login'), { timeout: 25000 }),
    page.click('button[type="submit"]'),
  ])
  await sleep(1200)
}

/** بخش را از نوار بخش‌ها باز کن و منتظر بمان تا محتوایش بیاید. */
async function openSection(page, label) {
  const ok = await page.evaluate((lbl) => {
    const btn = [...document.querySelectorAll('button')].find((b) => (b.textContent ?? '').trim() === lbl)
    if (!btn) return false
    btn.click()
    return true
  }, label)
  if (!ok) return false
  const shown = await page.waitForFunction((lbl) => {
    const heads = [...document.querySelectorAll('h1,h2,h3')]
    return heads.some((h) => (h.textContent ?? '').trim() === lbl)
  }, { timeout: 8000 }, label).then(() => true).catch(() => false)
  if (!shown) problems.push(`بخش «${label}» باز نشد (عنوان بخش در صفحه دیده نشد)`)
  await sleep(700)
  return true
}

/** وضعیت همهٔ پخش‌کننده‌های صفحه + بافت هر کدام. */
const playerState = () => {
  const audios = [...document.querySelectorAll('audio')]
  const first = audios[0] ?? null
  const wrapOf = (a) => a.closest('div[dir="rtl"]')
  const textsOf = (a) => {
    const w = wrapOf(a); if (!w) return []
    return [...w.querySelectorAll('p')].map((p) => (p.textContent ?? '').trim()).filter((t) => t.length > 1)
  }
  const badgeOf = (a) => {
    const w = wrapOf(a); if (!w) return ''
    return [...w.querySelectorAll('span')].map((s) => (s.textContent ?? '').trim()).find((t) => /مربی فارسی|راوی|گویندهٔ|انگلیسی|توضیح/.test(t)) || ''
  }
  return {
    count: audios.length,
    all: audios.map((a) => ({
      hash: ((a.currentSrc || a.src).match(/\/([0-9a-f]{8})\.mp3/) ?? [])[1] ?? '',
      texts: textsOf(a), badge: badgeOf(a), enabled: a.controls !== undefined,
    })),
    src: (first?.currentSrc || first?.src || ''),
    paused: first?.paused ?? true,
    time: first?.currentTime ?? 0,
    duration: first?.duration ?? 0,
    rate: first?.playbackRate ?? 1,
    texts: first ? textsOf(first) : [],
    badge: first ? badgeOf(first) : '',
  }
}

async function pressPlay(page) {
  return page.evaluate(async () => {
    const a = document.querySelector('audio')
    const wrap = a?.closest('div[dir="rtl"]') ?? null
    if (!a || !wrap) return false
    if (!a.paused) { wrap.querySelector('button[aria-label="توقف"]')?.click(); await new Promise((r) => setTimeout(r, 300)) }
    const btn = wrap.querySelector('button[aria-label="پخش"]')
    if (!btn) return false
    btn.click()
    await new Promise((r) => setTimeout(r, 1600))
    return !a.paused && a.currentTime > 0
  })
}

async function testLesson(page, title, viewport) {
  const exp = EXPECTED[title]
  const found = []
  await page.goto(`${BASE}/app/lessons/${exp.lessonId}`, { waitUntil: 'networkidle2' })
  await sleep(1800)
  if (/درس پیدا نشد/.test(await page.evaluate(() => document.body.innerText))) {
    problems.push(`[${viewport}] درس «${title}» باز نشد`)
    return { title, sectionsTested: [] }
  }

  for (const sec of Object.keys(exp.audio)) {
    const label = SECTION_LABEL[sec] ?? sec
    const refs = exp.audio[sec]
    if (!(await openSection(page, label))) { problems.push(`[${viewport}] ${title}: بخش «${label}» در نوار بخش‌ها نبود`); continue }

    // ۱) پخش
    const playing = await pressPlay(page)
    let st = await page.evaluate(playerState)
    const byHash = Object.fromEntries(refs.map((r) => [r.hash, r]))
    const playedHash = (st.src.match(/\/([0-9a-f]{8})\.mp3/) ?? [])[1] ?? ''
    const playedRef = byHash[playedHash]
    // هر پخش‌کنندهٔ این بخش باید متنِ همان فایلی را نشان دهد که پخش می‌کند
    const textMatch = st.all.length > 0 && st.all.every((p) => byHash[p.hash] && p.texts.includes(byHash[p.hash].text))
    const badgeOk = !!playedRef && (
      playedRef.lang === 'fa'
        ? /مربی فارسی/.test(st.badge)
        : (/گویندهٔ/.test(st.badge) || /راوی|واژگان|انگلیسی/.test(st.badge))
    )

    // ۲) توقف
    const pausedOk = await page.evaluate(async () => {
      const a = document.querySelector('audio')
      const wrap = a?.closest('div[dir="rtl"]') ?? null
      const btn = wrap?.querySelector('button[aria-label="توقف"]')
      if (!btn) return false
      btn.click(); await new Promise((r) => setTimeout(r, 400))
      return a.paused === true
    })

    // ۳) جابه‌جایی
    const seekOk = await page.evaluate(async () => {
      const a = document.querySelector('audio')
      const wrap = a?.closest('div[dir="rtl"]') ?? null
      const range = wrap?.querySelector('input[type="range"]')
      if (!a || !range || !Number.isFinite(a.duration) || a.duration < 1) return false
      const target = Math.max(0.5, a.duration * 0.6)
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set
      setter.call(range, String(target))
      range.dispatchEvent(new Event('input', { bubbles: true }))
      await new Promise((r) => setTimeout(r, 500))
      return Math.abs(a.currentTime - target) < 1.5
    })

    // ۴) سرعت (آخرین دکمه = ۱٫۵)
    const rateOk = await page.evaluate(async () => {
      const a = document.querySelector('audio')
      const wrap = a?.closest('div[dir="rtl"]') ?? null
      if (!a || !wrap) return false
      const rates = [...wrap.querySelectorAll('button')].filter((b) => (b.textContent ?? '').includes('×'))
      if (rates.length !== 4) return false
      const test = async (btn, want) => { btn.click(); await new Promise((r) => setTimeout(r, 450)); return Math.abs(a.playbackRate - want) < 0.001 }
      const ok15 = await test(rates[3], 1.5)
      const ok075 = await test(rates[0], 0.75)
      const ok1 = await test(rates[1], 1)
      return ok15 && ok075 && ok1
    })

    // ۵) پخش دوباره
    const replayOk = await page.evaluate(async () => {
      const a = document.querySelector('audio')
      const wrap = a?.closest('div[dir="rtl"]') ?? null
      const btn = wrap?.querySelector('button[aria-label="پخش دوباره"]')
      if (!a || !btn) return false
      btn.click(); await new Promise((r) => setTimeout(r, 900))
      return a.currentTime < 1.6
    })

    // ۶) جا شدن در عرض صفحه (موبایل)
    const fits = await page.evaluate(() => {
      const a = document.querySelector('audio')
      const wrap = a?.closest('div[dir="rtl"]') ?? null
      const btn = wrap?.querySelector('button[aria-label]')
      if (!btn) return false
      const r = btn.getBoundingClientRect()
      return r.width > 0 && r.right <= window.innerWidth + 1 && r.x >= -1
    })

    const row = {
      viewport, lesson: title, section: sec, clips: refs.length,
      playing, pausedOk, seekOk, rateOk, replayOk, textMatch, badgeOk, fits,
      file: (st.src.split('/').pop()) || '', duration: Number((st.duration || 0).toFixed(2)),
    }
    results.push(row)
    found.push(sec)
    if (!playing) problems.push(`[${viewport}] ${title} · ${label}: پخش نشد`)
    if (!playedRef) problems.push(`[${viewport}] ${title} · ${label}: فایل پخش‌شده در ارجاع‌های درس نیست (${row.file})`)
    if (!textMatch) problems.push(`[${viewport}] ${title} · ${label}: متن نمایشی با متن فایل یکی نیست (${row.file} | ${st.all.map((p) => p.hash + ':' + (p.texts[0] ?? '').slice(0, 24)).join(' ، ')})`)
    if (!badgeOk) problems.push(`[${viewport}] ${title} · ${label}: برچسب گوینده/نوع صدا نامناسب است («${st.badge}»)`)
    if (!pausedOk) problems.push(`[${viewport}] ${title} · ${label}: توقف کار نکرد`)
    if (!seekOk) problems.push(`[${viewport}] ${title} · ${label}: جابه‌جایی کار نکرد`)
    if (!rateOk) problems.push(`[${viewport}] ${title} · ${label}: تغییر سرعت کار نکرد`)
    if (!replayOk) problems.push(`[${viewport}] ${title} · ${label}: پخش دوباره کار نکرد`)
    if (!fits) problems.push(`[${viewport}] ${title} · ${label}: کنترل‌ها در عرض صفحه جا نمی‌شوند`)

    if (viewport === 'desktop') await page.screenshot({ path: `${SHOTS}/desktop-${exp.lessonId.slice(0, 8)}-${sec}.png` })
    if (viewport === 'mobile' && sec === found[0]) await page.screenshot({ path: `${SHOTS}/mobile-${exp.lessonId.slice(0, 8)}-${sec}.png` })
  }

  /* آزمون ویژهٔ دیالوگ: هر خط با صدای گویندهٔ خودش (A/B) */
  if (exp.audio.dialogue) {
    await openSection(page, SECTION_LABEL.dialogue)
    const lineCheck = await page.evaluate(async () => {
      const btns = [...document.querySelectorAll('button')].filter((b) => /این خط/.test(b.getAttribute('aria-label') ?? ''))
      const k = Math.min(1, btns.length - 1)
      if (k < 0) return { ok: false, reason: 'دکمهٔ خطوط دیالوگ نیست', count: 0, src: '', time: -1, k: -1 }
      document.querySelector('audio')?.pause()
      await new Promise((r) => setTimeout(r, 250))
      btns[k].click()                       // خط دوم اگر باشد (گویندهٔ B)، وگرنه خط اول
      await new Promise((r) => setTimeout(r, 1600))
      const a = document.querySelector('audio')
      return { ok: !(a?.paused ?? true), src: (a?.currentSrc || a?.src || ''), count: btns.length, time: a?.currentTime ?? -1, k }
    })
    const hash = ((lineCheck.src || '').match(/\/([0-9a-f]{8})\.mp3/) ?? [])[1] ?? ''
    const sorted = [...exp.audio.dialogue].sort((a, b) => (a.line ?? 0) - (b.line ?? 0))
    const want = sorted[lineCheck.k]
    const voiceOk = !!want && want.hash === hash
    results.push({ viewport, lesson: title, section: 'dialogue/line-btn', voiceOk, file: hash, buttons: lineCheck.count, wantLine: want?.line, wantSpeaker: want?.speaker })
    if (!lineCheck.ok || !voiceOk) problems.push(`[${viewport}] ${title} · دیالوگ: با کلیک روی خط (گویندهٔ ${want?.speaker ?? '?'}) صدای همان خط پخش نشد (${hash || 'بدون فایل'})`)
  }

  return { title, sectionsTested: found }
}

const browser = await puppeteer.launch({
  headless: true,
  args: ['--no-sandbox', '--disable-setuid-sandbox', '--mute-audio', '--autoplay-policy=no-user-gesture-required'],
})

async function run(viewport, width, height) {
  const page = await browser.newPage()
  await page.setViewport({ width, height, isMobile: viewport === 'mobile', hasTouch: viewport === 'mobile' })
  page.on('response', (res) => {
    if (/lesson-audio/.test(res.url()) && res.status() >= 400) problems.push(`[${viewport}] درخواست ناموفق: ${res.status()} ${res.url()}`)
  })
  page.on('requestfailed', (req) => {
    const t = req.failure()?.errorText ?? ''
    if (!/lesson-audio/.test(req.url())) return
    if (/ERR_ABORTED/.test(t)) { aborted.push(`${t} ${req.url().split('/').pop()}`); return }   // لغو طبیعی هنگام تغییر کلیپ/ترک صفحه
    problems.push(`[${viewport}] درخواست شکست‌خورده: ${t} ${req.url()}`)
  })
  page.on('console', (m) => { if (m.type() === 'error') problems.push(`[${viewport}] خطای کنسول: ${m.text().slice(0, 120)}`) })
  await login(page)
  console.log(`\n──── ${viewport} (${width}×${height}) ────`)
  for (const title of Object.keys(EXPECTED)) {
    const r = await testLesson(page, title, viewport)
    console.log(`  ${title}: ${r.sectionsTested.join(', ') || '—'}`)
  }
  await page.close()
}

/* ── یکپارچگی فایل‌ها: از داخل مرورگر (CORS واقعی) همهٔ فایل‌های رجیستری ── */
async function checkFiles() {
  const registry = JSON.parse(fs.readFileSync('/home/user/lingu/content/audio/registry.json', 'utf8'))
  const rows = Array.isArray(registry) ? registry : Object.values(registry.clips ?? registry.files ?? registry.rows ?? {})
  const page = await browser.newPage()
  await page.goto(`${BASE}/login`, { waitUntil: 'domcontentloaded' })
  const out = await page.evaluate(async (rows) => {
    const urls = rows.map((r) => r.public_url || r.publicUrl || r.url)
    const res = []
    for (const u of urls) {
      try {
        const r = await fetch(u)
        const buf = await r.arrayBuffer()
        res.push({ url: u, status: r.status, type: r.headers.get('content-type') ?? '', bytes: buf.byteLength })
      } catch (e) { res.push({ url: u, status: 0, type: '', bytes: 0, err: String(e).slice(0, 80) }) }
    }
    return res
  }, rows)
  await page.close()
  const byUrl = Object.fromEntries(rows.map((r) => [r.public_url || r.publicUrl || r.url, r]))
  for (const f of out) {
    const want = byUrl[f.url]?.bytes
    const ok = f.status === 200 && /audio\/mpeg/.test(f.type) && (!want || want === f.bytes)
    results.push({ section: 'file', file: f.url.split('/').pop(), status: f.status, type: f.type, bytes: f.bytes, ok })
    if (!ok) problems.push(`فایل صوتی مشکل دارد: ${f.url.split('/').pop()} → ${f.status} ${f.type} ${f.bytes}B (انتظار ${want}B)`)
  }
  console.log(`\n── یکپارچگی فایل‌ها: ${out.filter((f) => f.status === 200).length}/${out.length} سالم و کامل ──`)
}

await run('desktop', 1440, 900)
await run('mobile', 390, 844)
await checkFiles()
await browser.close()

fs.writeFileSync('/home/user/qa/audio_qa_report.json', JSON.stringify({ at: new Date().toISOString(), playersTested: results.length, problems, results }, null, 1))
console.log('\n════════════ نتیجهٔ QA ════════════')
console.log(`پخش‌کننده‌های آزمون‌شده: ${results.length}`)
for (const r of results) {
  const v = r.viewport === 'desktop' ? '🖥' : '📱'
  if (r.section === 'dialogue/line-btn') { console.log(`${v} ${r.lesson} · دکمهٔ خط دیالوگ ${r.wantLine} (گویندهٔ ${r.wantSpeaker}): ${r.voiceOk ? '✓' : '✗'} ${r.file} [${r.buttons} دکمه]`); continue }
  if (r.section === 'file') { continue }
  console.log(`${v} ${r.lesson} · ${r.section} · پخش=${r.playing ? '✓' : '✗'} توقف=${r.pausedOk ? '✓' : '✗'} seek=${r.seekOk ? '✓' : '✗'} سرعت=${r.rateOk ? '✓' : '✗'} دوباره=${r.replayOk ? '✓' : '✗'} متن=${r.textMatch ? '✓' : '✗'} گوینده=${r.badgeOk ? '✓' : '✗'} ${r.file}`)
}
console.log(`\nلغوهای طبیعی (ERR_ABORTED هنگام تغییر کلیپ/ترک صفحه): ${aborted.length}`)
console.log(problems.length ? `\n✗ مشکلات (${problems.length}):\n - ` + problems.join('\n - ') : '\n✅ همهٔ بررسی‌ها سبز')
process.exit(problems.length ? 1 : 0)
