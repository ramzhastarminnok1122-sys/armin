/**
 * LINGU · QA دسته — رندر واقعی درس‌های تازه در مرورگر
 * اجرا: node batch_qa.mjs                     (و از /tmp/qa_lessons.json می‌خواند)
 * پیش‌نیاز: سرور پیش‌نمایش روی 4173 + حساب آزمون با نقش مدیر (درس‌های منتشرنشده را می‌بیند)
 */
import fs from 'node:fs'
import puppeteer from 'puppeteer'

const BASE = 'http://127.0.0.1:4173'
const EMAIL = 'ops.audio@lingu.app'
const PASSWORD = fs.readFileSync('/tmp/ops_pw', 'utf8').trim()
const LESSONS = JSON.parse(fs.readFileSync('/tmp/qa_lessons.json', 'utf8'))   // [{n,title,id}]
const SHOTS = '/home/user/qa/shots'
fs.mkdirSync(SHOTS, { recursive: true })

const SECTION_LABELS = ['گرم‌کردن', 'توضیح درس', 'واژگان', 'گرامر', 'مثال‌ها', 'شنیداری', 'دیالوگ', 'تمرین گفت‌وگو', 'خواندن', 'تمرین‌ها', 'آزمون', 'تمرین با AI']
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const problems = [], rows = []

const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox', '--mute-audio'] })
const page = await browser.newPage()
await page.setViewport({ width: 1440, height: 900 })
page.on('console', (m) => { if (m.type() === 'error') problems.push(`خطای کنسول: ${m.text().slice(0, 130)}`) })
page.on('pageerror', (e) => problems.push(`خطای صفحه: ${String(e).slice(0, 130)}`))

await page.goto(`${BASE}/login`, { waitUntil: 'networkidle2' })
await page.type('input[type="email"]', EMAIL)
await page.type('input[type="password"]', PASSWORD)
await Promise.all([page.waitForFunction(() => !location.pathname.startsWith('/login'), { timeout: 25000 }), page.click('button[type="submit"]')])
await sleep(1200)

const openSection = async (label) => {
  const ok = await page.evaluate((lbl) => {
    const btn = [...document.querySelectorAll('button')].find((b) => (b.textContent ?? '').trim() === lbl)
    if (!btn) return false
    btn.click(); return true
  }, label)
  if (!ok) return false
  const shown = await page.waitForFunction((lbl) => [...document.querySelectorAll('h1,h2,h3')].some((h) => (h.textContent ?? '').trim() === lbl), { timeout: 7000 }, label).then(() => true).catch(() => false)
  await sleep(350)
  return shown
}

for (const L of LESSONS) {
  await page.goto(`${BASE}/app/lessons/${L.id}`, { waitUntil: 'networkidle2' })
  await sleep(1500)
  const body = await page.evaluate(() => document.body.innerText)
  if (/پیدا نشد|در دسترس نیست/.test(body.slice(0, 400))) { problems.push(`L${L.n}: صفحهٔ درس باز نشد`); continue }

  let opened = 0
  for (const label of SECTION_LABELS) {
    if (await openSection(label)) opened++
    else problems.push(`L${L.n} (${L.title}): بخش «${label}» باز نشد`)
  }

  // واژگان: شمارش کارت‌ها
  await openSection('واژگان')
  const vocab = await page.evaluate(() => document.querySelectorAll('p.ltr').length)
  // آزمون: شمارش پرسش‌ها
  await openSection('آزمون')
  const quiz = await page.evaluate(() => (document.body.innerText.match(/[۰-۹]+\s*از\s*[۰-۹]+/g) ?? []).slice(0, 3).join(' , '))
  const radios = await page.evaluate(() => document.querySelectorAll('input[type="radio"]').length)
  // تمرین‌ها: شمارش آیتم‌ها
  await openSection('تمرین‌ها')
  const exInputs = await page.evaluate(() => document.querySelectorAll('input[type="text"], input[type="radio"], select').length)

  rows.push({ n: L.n, title: L.title, sections: opened, vocabCards: vocab, quizCounter: quiz, quizRadios: radios, exerciseInputs: exInputs })
  console.log(`L${L.n} · ${L.title}: بخش ${opened}/12 · کارت واژگان ${vocab} · آزمون (${quiz}) radios=${radios} · ورودی تمرین ${exInputs}`)
  await page.screenshot({ path: `${SHOTS}/b2-L${String(L.n).padStart(3, '0')}.png` })
}

await browser.close()
fs.writeFileSync('/home/user/qa/batch_qa_report.json', JSON.stringify({ rows, problems }, null, 1))
console.log(problems.length ? `\n✗ مشکلات (${problems.length}):\n - ` + problems.join('\n - ') : '\n✅ رندر درس‌های آزمون‌شده سالم')
process.exit(problems.length ? 1 : 0)
