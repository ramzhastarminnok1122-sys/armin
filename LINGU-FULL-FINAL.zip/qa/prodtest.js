/** Smoke test of the REAL production build (no demo mode, no backend configured). */
const puppeteer=require('puppeteer'); const BASE='http://localhost:4173'
const sleep=(ms)=>new Promise(r=>setTimeout(r,ms))
const FORBIDDEN=['supabase','groq','myket','مایکت','rls','api key','backend','بک‌اند','دیتابیس','environment']
;(async()=>{
  const b=await puppeteer.launch({args:['--no-sandbox','--disable-dev-shm-usage']})
  const p=await b.newPage(); await p.setViewport({width:1440,height:950})
  const errs=[]; p.on('pageerror',e=>errs.push(String(e).slice(0,120)))
  p.on('console',m=>{ if(m.type()==='error') errs.push(m.text().slice(0,120)) })
  for (const r of ['/','/features','/languages','/faq','/login','/signup','/app','/admin','/onboarding','/nope-404']) {
    await p.goto(BASE+r,{waitUntil:'networkidle2',timeout:40000}).catch(()=>{})
    await sleep(r.startsWith('/app')||r.startsWith('/admin')||r.startsWith('/onboarding') ? 9000 : 900)
    const info=await p.evaluate(()=>({
      url:location.pathname,
      len:document.body.innerText.trim().length,
      t:document.body.innerText.replace(/\s+/g,' ').slice(0,150),
      ribbon:document.body.innerText.includes('پیش‌نمایش طراحی'),
      ov:Math.max(0,document.documentElement.scrollWidth-window.innerWidth),
    }))
    const devWords=FORBIDDEN.filter(w=>info.t.toLowerCase().includes(w))
    console.log(`${r.padEnd(12)} → ${info.url.padEnd(12)} chars:${String(info.len).padStart(4)} ribbon:${info.ribbon} ov:${info.ov} dev:${devWords.join(',')||'-'}`)
    if(info.len<40) console.log('    ⚠ almost blank:', info.t)
  }
  console.log('\nconsole errors:', errs.length? [...new Set(errs)].slice(0,6):'none')
  await b.close()
})()
