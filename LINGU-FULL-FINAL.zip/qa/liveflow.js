/**
 * LINGU · live browser flow test (real Supabase project, real Auth, real RLS)
 * Usage: node liveflow.js <emailA> <passA> <emailB> <passB>
 */
const puppeteer = require('puppeteer')
const BASE = 'http://localhost:5173'
const [MAIL_A, PW_A, MAIL_B, PW_B] = process.argv.slice(2)
const sleep = ms => new Promise(r => setTimeout(r, ms))

const TECH = ['supabase', 'groq', 'myket', 'api key', 'clé api', 'backend', 'database',
              'rls', 'edge function', 'environment variable', 'sk-', 'eyJ', 'postgres',
              'openai', 'schema', 'sql', 'localhost', 'vite', 'env']

let pass = 0, fail = 0
const ok = (n, c, d = '') => { c ? pass++ : fail++; console.log((c ? '✓ ' : '✗ ') + n + (d ? `   [${d}]` : '')) }

async function type(sel, text, page) {
  await page.waitForSelector(sel, { timeout: 15000 })
  await page.click(sel, { clickCount: 3 })
  await page.type(sel, text, { delay: 12 })
}

async function skipTour(page) {
  // first-run users get the guided tour on the dashboard; a real user skips it
  for (let i = 0; i < 6; i++) {
    const hit = await page.evaluate(() => {
      const b = [...document.querySelectorAll('button')].find(x => /رد کردن/.test(x.innerText) && /از ۶|تور/.test(document.body.innerText))
      if (b) { b.click(); return true }
      return false
    })
    if (!hit) return
    await sleep(1200)
  }
}

async function passOnboarding(page) {
  // a fresh account lands on /onboarding: wait for the guard, then walk it like a real user
  for (let i = 0; i < 12; i++) {
    if (page.url().includes('/onboarding') || page.url().includes('/app')) break
    await sleep(1000)
  }
  if (!page.url().includes('/onboarding')) return
  await sleep(2500)
  for (let i = 0; i < 8; i++) {
    const heading = await page.evaluate(() => document.body.innerText)
    let action = null
    if (heading.includes('کدام زبان')) {
      action = await page.evaluate(() => {
        const b = [...document.querySelectorAll('button')].find(x => /انگلیسی/.test(x.innerText))
        if (b) { b.click(); return 'lang' } return null
      })
    } else if (heading.includes('هدفت')) {
      action = await page.evaluate(() => {
        const skip = /قبلی|رد کردن|بعدی|شروع یادگیری/
        const b = [...document.querySelectorAll('button')].find(x => !skip.test(x.innerText) && x.innerText.trim().length > 1)
        if (b) { b.click(); return 'goal' } return null
      })
    }
    if (action) { await sleep(1200) }
    const moved = await page.evaluate(() => {
      const nxt = [...document.querySelectorAll('button')].find(x => /بعدی|شروع یادگیری/.test(x.innerText) && !x.disabled)
      if (nxt) { nxt.click(); return true } return false
    })
    await sleep(2200)
    if (!page.url().includes('/onboarding')) return
    if (!moved && !action) break
  }
  await skipTour(page)
  for (let i = 0; i < 12 && page.url().includes('/onboarding'); i++) {
    await sleep(1500)
    await page.evaluate(() => {
      const b = [...document.querySelectorAll('button')].find(x => /شروع یادگیری|بعدی/.test(x.innerText) && !x.disabled)
      if (b) b.click()
    })
  }
  await sleep(1500)
}

async function login(page, mail, pw) {
  await page.goto(BASE + '/login', { waitUntil: 'networkidle2' })
  await type('input[type=email]', mail, page)
  await type('input[type=password]', pw, page)
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 25000 }).catch(() => {}),
    page.evaluate(() => document.querySelector('form button[type=submit], form button').click()),
  ])
  await sleep(3000)
}

;(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] })
  const page = await browser.newPage()
  await page.setViewport({ width: 1440, height: 950 })
  const errors = []
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text().slice(0, 160)) })
  page.on('pageerror', e => errors.push('pageerror: ' + String(e).slice(0, 160)))

  // ---------- 1. anon visitor is blocked from the app
  await page.goto(BASE + '/app', { waitUntil: 'networkidle2' }); await sleep(2500)
  ok('ناشناس: /app به ورود هدایت می‌شود', page.url().includes('/login'), page.url().replace(BASE, ''))

  // ---------- 2. real login (admin user)
  await login(page, MAIL_A, PW_A)
  ok('ورود واقعی (کاربر تازه)', page.url().includes('/onboarding') || page.url().includes('/app'),
     page.url().replace(BASE, ''))
  await passOnboarding(page)
  ok('Onboarding → ورود به /app', page.url().includes('/app') && !page.url().includes('onboarding'),
     page.url().replace(BASE, ''))
  await skipTour(page)          // a real user dismisses the guided tour
  await sleep(1200)
  const hello = await page.evaluate(() => document.body.innerText)
  ok('داشبورد با نام کاربر واقعی پر شده', hello.includes('QA A') || hello.includes('سلام'), '')

  // ---------- 3. refresh keeps the session
  await page.reload({ waitUntil: 'networkidle2' }); await sleep(3000)
  ok('رفرش: نشست حفظ می‌شود', page.url().includes('/app'), page.url().replace(BASE, ''))

  // ---------- 4. deep link inside the app
  await page.goto(BASE + '/app/lessons', { waitUntil: 'networkidle2' }); await sleep(3000)
  const lessonsTxt = await page.evaluate(() => document.body.innerText)
  ok('مسیر داخلی درس‌ها باز می‌شود', page.url().includes('/app/lessons') && lessonsTxt.length > 200,
     page.url().replace(BASE, '') + ' | ' + lessonsTxt.replace(/\n+/g, ' ').slice(0, 70))

  // ---------- 5. admin panel for the admin account
  await page.goto(BASE + '/admin', { waitUntil: 'networkidle2' }); await sleep(3500)
  const adminText = await page.evaluate(() => document.body.innerText)
  ok('مدیر: پنل مدیریت باز می‌شود', page.url().includes('/admin') && adminText.includes('کاربر'),
     page.url().replace(BASE, ''))
  const adminUsers = await page.evaluate(async () => {
    const t = document.body.innerText
    return { hasQaB: t.includes('QA B') }
  })
  ok('مدیر: کاربر واقعی دوم را در لیست می‌بیند', adminUsers.hasQaB, '')

  // ---------- 6. AI with no key deployed → product sentence, never an error
  await page.goto(BASE + '/app/tutor', { waitUntil: 'networkidle2' }); await sleep(2500)
  const tutorText = await page.evaluate(() => document.body.innerText)
  const hinted = tutorText.includes('در دسترس نیست') || tutorText.includes('به‌زودی') ||
                 tutorText.includes('به زودی') || tutorText.includes('Premium')
  ok('مربی AI: پیام محصولی (بدون خطای فنی)', hinted,
     (tutorText.match(/[^\n]*(در دسترس نیست|Premium)[^\n]*/) || [''])[0].slice(0, 60))

  // ---------- 7. logout
  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button, a')].find(el => /خروج/.test(el.innerText))
    if (b) b.click()
  })
  await sleep(3500)
  ok('خروج → صفحهٔ ورود (/login)', page.url().includes('/login'),
     page.url().replace(BASE, ''))
  await page.goto(BASE + '/app', { waitUntil: 'networkidle2' }); await sleep(2500)
  ok('پس از خروج، /app دوباره قفل است', page.url().includes('/login'))

  // ---------- 8. second user (non-admin) must not reach /admin
  await login(page, MAIL_B, PW_B)
  await passOnboarding(page)
  ok('ورود کاربر دوم (عادی) → /app', page.url().includes('/app') && !page.url().includes('onboarding'), page.url().replace(BASE, ''))
  await page.goto(BASE + '/admin', { waitUntil: 'networkidle2' }); await sleep(3000)
  const bAdmin = await page.evaluate(() => document.body.innerText)
  ok('کاربر عادی: پنل مدیریت بسته است',
     bAdmin.includes('دسترسی به پنل مدیریت ندارید') || !page.url().includes('/admin'),
     bAdmin.includes('دسترسی به پنل مدیریت ندارید') ? 'صفحهٔ «دسترسی ندارید»' : page.url().replace(BASE, ''))

  // ---------- 9. data isolation in the UI
  await page.goto(BASE + '/app/progress', { waitUntil: 'networkidle2' }); await sleep(2500)
  const progB = await page.evaluate(() => document.body.innerText)
  ok('پیشرفت: صفحهٔ خالیِ درست (بدون دادهٔ کاربر دیگر)', !progB.includes('QA A'), '')

  // ---------- 10. no technical vocabulary anywhere in the user UI
  const routes = ['/', '/features', '/pricing', '/faq', '/app', '/app/lessons', '/app/tutor',
                  '/app/conversation', '/app/progress', '/app/subscription', '/app/settings',
                  '/app/profile', '/app/help', '/login', '/signup']
  const leaks = []
  for (const r of routes) {
    await page.goto(BASE + r, { waitUntil: 'networkidle2' }); await sleep(1200)
    const txt = await page.evaluate(() => document.body.innerText.toLowerCase())
    for (const w of TECH) if (txt.includes(w)) leaks.push(`${r}: «${w}»`)
  }
  ok('هیچ واژهٔ فنی در هیچ صفحه‌ای دیده نمی‌شود', leaks.length === 0, leaks.slice(0, 3).join(' · '))

  // ---------- 11. signup form reaches the real backend (rate-limit is a real answer, not a UI bug)
  await page.goto(BASE + '/signup', { waitUntil: 'networkidle2' }); await sleep(1500)
  const signupMail = `qa.c.${Date.now().toString().slice(-6)}@lingu-qa.dev`
  await type('input[type=email]', signupMail, page)
  await type('input[type=password]', 'LinguCheck!2026', page)
  await page.evaluate(() => document.querySelector('form button[type=submit], form button').click())
  await sleep(5000)
  const st = await page.evaluate(() => document.body.innerText)
  const productMsg = /[آ-ی]/.test(st) && !/error|Error|429|rate limit/i.test(st.replace(/[آ-ی]/g, ''))
  ok('ثبت‌نام: پاسخ سرور به پیام فارسی تبدیل می‌شود', productMsg, st.split('\n').filter(l => l.trim()).slice(-2).join(' | ').slice(0, 90))

  console.log('\nخطاهای کنسول:', errors.length)
  errors.slice(0, 5).forEach(e => console.log('  ·', e))
  console.log(`\nPASS: ${pass}   FAIL: ${fail}`)
  await browser.close()
})()
